<?php

namespace common\actions\crud;

use common\events\CrudActionEvent;
use common\forms\Form;
use common\services\CrudService;
use yii\db\ActiveRecord;
use yii\rest\Controller;
use yii\web\ForbiddenHttpException;

/**
 * @property Controller $controller
 */
abstract class Action extends \yii\base\Action
{
    public const EVENT_BEFORE_SERVICE_ACTION = 'beforeServiceAction';

    /**
     * @var CrudService
     */
    protected $service;

    public function __construct(string $id, Controller $controller, CrudService $service, array $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param ActiveRecord|null $model
     * @param Form|null $form
     * @return bool
     */
    protected function beforeServiceAction($model, $form): bool
    {
        $event = new CrudActionEvent($this, [
            'service' => $this->service,
            'model' => $model,
            'form' => $form,
        ]);

        $this->trigger(self::EVENT_BEFORE_SERVICE_ACTION, $event);

        return $event->isValid;
    }

    /**
     * @throws ForbiddenHttpException
     */
    protected function handleFailure(): void
    {
        throw new ForbiddenHttpException('Access denied.');
    }
}