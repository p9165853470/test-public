<?php

namespace common\actions\crud;

use common\exceptions\SaveModelException;
use common\forms\Form;
use yii\db\ActiveRecord;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class CreateAction extends Action
{
    /**
     * @param Request $request
     * @param Response $response
     * @return Form|ActiveRecord
     * @throws SaveModelException
     */
    public function run(Request $request, Response $response)
    {
        $form = $this->service->form();

        if (!$this->beforeServiceAction(null, $form)) {
            $this->handleFailure();
        }

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $model = $this->service->create($form);

            $response->setStatusCode(201);

            return $model;
        }
        return $form;
    }
}