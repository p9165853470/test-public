<?php

namespace common\actions\crud;

use common\exceptions\DeleteModelException;
use common\exceptions\NotFoundModelException;
use yii\web\Response;

class DeleteAction extends Action
{
    /**
     * @param $id
     * @param Response $response
     * @throws DeleteModelException
     * @throws NotFoundModelException
     */
    public function run($id, Response $response): void
    {
        $model = $this->service->get($id);

        if (!$this->beforeServiceAction($model, null)) {
            $this->handleFailure();
        }

        $this->service->delete($model);

        $response->setStatusCode(204);
    }
}