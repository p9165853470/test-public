<?php

namespace common\actions\crud;

use common\helpers\Filter;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class DeleteAllAction extends Action
{
    public function run(Request $request, Response $response): void
    {
        $ids = Filter::arrayOfInt($request->post('ids'));

        if (empty($ids)) {
            throw new BadRequestHttpException('No input data.');
        }

        $this->service->deleteAll($ids);

        $response->setStatusCode(204);
    }
}