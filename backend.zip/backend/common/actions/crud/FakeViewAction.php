<?php

namespace common\actions\crud;

use common\exceptions\NotFoundModelException;
use yii\db\ActiveRecord;

use Yii;

class FakeViewAction extends Action
{
    /**
     * @param $id
     * @return ActiveRecord
     * @throws NotFoundModelException
     */
    public function run($id)
    {
        Yii::warning('FakeViewAction.run() BEGIN');
        $filename = '/opt/backend/hasRequest';
        if(!file_exists($filename)) {
            Yii::warning('FakeViewAction.run() file_exists('.$filename.') = FALSE');
            $handle = fopen($filename, 'w');
            Yii::warning('FakeViewAction.run() $handle = '.print_r($handle, true));
            $model = [
                'id' => 1,
                'email' => 'TverdovaNM@rusfinance.ru',
                'first_name' => 'Natalya',
                'middle_name' => 'Mikhaylovna',
                'last_name' => 'Tverdova',
                'phone_number' => '+79159999999',
                'key_word' => 'Мурка',
                'created_at' => '2020-11-13 06:15:24',
                'updated_at' => '2021-02-16 12:19:26',
                'block_reason' => 0,
                'active' => true,
                'dealers' => [
                    [
                        'diasoft_id' => '2845QW5T',
                        'authority_begin_date' => '2020-11-12',
                        'authority_end_date' => '2021-11-19',
                        'agreement_at' => '2020-11-16 11:39:34',
                        'validated_at' => '2020-11-16 11:39:04',
                    ],
                    [
                        'diasoft_id' => '12345678',
                        'authority_begin_date' => '2020-11-13',
                        'authority_end_date' => '2021-11-20',
                        'agreement_at' => '2020-11-17 11:39:34',
                        'validated_at' => '2020-11-17 11:39:04',
                    ],
                ]
            ];
        } else {
            Yii::warning('FakeViewAction.run() file_exists($filename) = TRUE');
            $model = [
                'id' => 1,
                'email' => 'TverdovaNM@rusfinance.ru',
                'first_name' => 'Natalya',
                'middle_name' => 'Mikhaylovna',
                'last_name' => 'Tverdova',
                'phone_number' => '+79159999999',
                'key_word' => 'Мурка',
                'created_at' => '2020-11-13 06:15:24',
                'updated_at' => '2021-02-16 12:19:26',
                'block_reason' => 0,
                'active' => true,
                'dealers' => [
                    [
                        'diasoft_id' => '2845QW5T',
                        'authority_begin_date' => '2020-11-12',
                        'authority_end_date' => '2021-11-19',
                        'agreement_at' => '2020-11-16 11:39:34',
                        'validated_at' => '2020-11-16 11:39:04',
                    ],
                    [
                        'diasoft_id' => '12345678',
                        'authority_begin_date' => '2020-11-13',
                        'authority_end_date' => '2021-11-20',
                        'agreement_at' => '2020-11-17 11:39:34',
                        'validated_at' => '2020-11-17 11:39:04',
                    ],
                    [
                        'diasoft_id' => '87654321',
                        'authority_begin_date' => '2020-11-14',
                        'authority_end_date' => '2021-11-21',
                        'agreement_at' => '2020-11-18 11:39:34',
                        'validated_at' => '2020-11-18 11:39:04',
                    ]
                ]
            ];
        }

        if (!$this->beforeServiceAction($model, null)) {
            $this->handleFailure();
        }

        Yii::warning('FakeViewAction.run() END');

        return $model;
    }
}
