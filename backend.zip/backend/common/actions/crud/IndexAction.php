<?php

namespace common\actions\crud;

use yii\data\DataProviderInterface;
use yii\web\Request;

use Yii;

class IndexAction extends Action
{
    public function run(Request $request): DataProviderInterface
    {
        Yii::warning('common\actions\crud\IndexAction.run() BEGIN');
        $searchModel = $this->service->search();

        if (!$this->beforeServiceAction(null, null)) {
            $this->handleFailure();
        }

        $result = $searchModel->search($request->queryParams);
        Yii::warning('common\actions\crud\IndexAction.run() END: $result = '.print_r($result, true));
        return $result;
    }
}