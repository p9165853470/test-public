<?php

namespace common\actions\crud;

use common\exceptions\NotFoundModelException;
use common\exceptions\SaveModelException;
use common\forms\Form;
use yii\db\ActiveRecord;
use yii\web\BadRequestHttpException;
use yii\web\Request;

class UpdateAction extends Action
{
    /**
     * @param int $id
     * @param Request $request
     * @return Form|ActiveRecord
     * @throws NotFoundModelException
     * @throws SaveModelException
     */
    public function run($id, Request $request)
    {
        $model = $this->service->get($id);
        $form = $this->service->form($model);

        if (!$this->beforeServiceAction($model, $form)) {
            $this->handleFailure();
        }

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $this->service->update($model, $form);

            return $model;
        }
        return $form;
    }
}