<?php

namespace common\actions\crud;

use common\exceptions\NotFoundModelException;
use yii\db\ActiveRecord;

use Yii;

class ViewAction extends Action
{
    /**
     * @param $id
     * @return ActiveRecord
     * @throws NotFoundModelException
     */
    public function run($id)
    {
        Yii::warning('common\actions\crud\ViewAction.run() BEGIN');
        $model = $this->service->get($id);

        if (!$this->beforeServiceAction($model, null)) {
            $this->handleFailure();
        }

        Yii::warning('common\actions\crud\ViewAction.run() END: $model = '.print_r($model, true));
        return $model;
    }
}