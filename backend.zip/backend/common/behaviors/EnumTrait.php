<?php

namespace common\behaviors;

use ReflectionClass;
use yii\helpers\Inflector;

trait EnumTrait
{
    private static function getConstants(): array
    {
        return (new ReflectionClass(static::class))->getConstants();
    }

    public static function getRange(): array
    {
        return array_values(self::getConstants());
    }

    public static function getLabels(): array
    {
        $constants = self::getConstants();

        $keys = array_values($constants);
        $values = array_map(
            [Inflector::class, 'humanize'], array_map('strtolower', array_keys($constants))
        );

        return array_combine($keys, $values);
    }

    public static function getLabel($key): ?string
    {
        $labels = static::getLabels();

        return $labels[$key] ?? null;
    }
}