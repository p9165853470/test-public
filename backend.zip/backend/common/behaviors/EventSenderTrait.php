<?php

namespace common\behaviors;

use yii\base\Event;

trait EventSenderTrait
{
    public function on(string $name, callable $handler, $data = null, bool $append = true): void
    {
        Event::on($this, $name, $handler, $data, $append);
    }

    public function off(string $name, callable $handler = null): void
    {
        Event::off($this, $name, $handler);
    }

    public function trigger(string $name, Event $event = null): void
    {
        Event::trigger($this, $name, $event);
    }
}