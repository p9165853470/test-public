<?php

namespace common\behaviors;

use common\forms\Form;
use yii\db\ActiveRecord;

interface FormProviderInterface
{
    /**
     * @param ActiveRecord|null $model
     * @return Form
     */
    public function getForm($model);
}