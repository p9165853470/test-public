<?php

namespace common\behaviors;

interface GarbageCollectorInterface
{
    /**
     * @return int кол-во удаленного мусора
     */
    public function collectGarbage(): int;
}