<?php

namespace common\behaviors;

interface ParameterizedInterface
{
    public function getParam(string $key);

    public function setParam(string $key, $value): void;

    public function getParams(): array;

    public function setParams(array $params): void;
}