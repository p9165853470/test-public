<?php

namespace common\behaviors;

trait QueryActiveTrait
{
    public function active(bool $value = true): self
    {
        [$tableName, $alias] = $this->getTableNameAndAlias();
        return $this->andWhere(["$alias.active" => $value]);
    }
}