<?php

namespace common\behaviors;

/**
 * Интерфейс используется в проверке удаления записи в методе Repository::delete()
 */
interface SoftDeleteInterface
{
    /**
     *  Является ли сущность "мягко" удаленной
     *
     * @return bool
     */
    public function isSoftDeleted(): bool;
}