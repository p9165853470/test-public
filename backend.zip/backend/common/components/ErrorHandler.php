<?php

namespace common\components;

use common\exceptions\NotFoundModelException;
use common\modules\authentication\exceptions\TokenException;
use common\modules\session\exceptions\SessionException;
use yii\web\NotFoundHttpException;
use yii\web\UnauthorizedHttpException;

class ErrorHandler extends \yii\web\ErrorHandler
{
    protected function renderException($exception): void
    {
        $exception = $this->handleInternalException($exception);

        parent::renderException($exception);
    }

    protected function handleInternalException($ex)
    {
        if ($ex instanceof NotFoundModelException) {
            return new NotFoundHttpException($ex->getMessage(), $ex->getCode(), $ex->getPrevious());
        }

        if ($ex instanceof TokenException || $ex instanceof SessionException) {
            return new UnauthorizedHttpException($ex->getMessage(), $ex->getCode(), $ex->getPrevious());
        }

        return $ex;
    }
}