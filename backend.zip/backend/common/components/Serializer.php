<?php

namespace common\components;

use common\enums\ErrorEnum;
use common\models\errors\ModelError;
use common\resources\Resource;

class Serializer extends \yii\rest\Serializer
{
    public function serialize($data)
    {
        if ($data instanceof Resource) {
            return $data->toArray();
        }

        return parent::serialize($data);
    }

    protected function serializeModels(array $models): array
    {
        foreach ($models as $i => $model) {
            if ($model instanceof Resource) {
                $models[$i] = $model->toArray();
            }
        }

        return parent::serializeModels($models);
    }

    protected function serializeModel($model): ?array
    {
        if ($model instanceof Resource) {
            return $model->toArray();
        }

        return parent::serializeModel($model);
    }

    protected function serializeModelErrors($model): array
    {
        $this->response->setStatusCode(422, 'Data Validation Failed.');

        $result = [];

        foreach ($model->getErrors() as $name => $messages) {
            // Берем последнюю добавленую ошибку
            if ($message = end($messages)) {
                $error = ['field' => $name];

                if ($message instanceof ModelError) {
                    $error['message'] = $message->getMessage();
                    $error['code'] = $message->getCode();
                } else {
                    $error['message'] = $message;
                    $error['code'] = ErrorEnum::DEFAULT;
                }

                $result[] = $error;
            }
        }

        return $result;
    }
}