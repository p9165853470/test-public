<?php
return [
    'components' => [
        'mailer' => [
            'class' => \yii\swiftmailer\Mailer::class,
            'viewPath' => '@common/mail',
            'messageConfig' => [
                'charset' => 'UTF-8',
                'from' => getenv('mail_from'),
            ],
            'transport' => [
                'class' => 'Swift_SmtpTransport',
                'host' => getenv('mail_host'),
                'username' => getenv('mail_username') ?: null,
                'password' => getenv('mail_password') ?: null,
                'encryption' => getenv('mail_encryption') ?: null,
                'port' => getenv('mail_port'),
            ],
        ],
    ],
];
