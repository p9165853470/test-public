<?php
return [
    'backend.host' => getenv('backend_host'),
    'frontend.host' => getenv('frontend_host'),
    'jwt.authTokenLifetime' => 10800, // 3h
    'jwt.refreshTokenLifeTime' => 86400, //24h
    'rfinfo.api.host' => getenv('rfinfo_api_host'),
    'rfinfo.api.username' => getenv('rfinfo_api_username'),
    'rfinfo.api.password' => getenv('rfinfo_api_password'),
    'tranche.exportPath' => getenv('tranche_export_path'),
];
