<?php

namespace common\enums;

use common\behaviors\EnumTrait;

class MimeTypeEnum
{
    use EnumTrait;

    public const XLSX = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    public const PDF = 'application/pdf';
    public const JSON = 'application/json';
    public const XML = 'application/xml';
    public const TXT = 'text/plain';
}