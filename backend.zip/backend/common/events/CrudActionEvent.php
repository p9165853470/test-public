<?php

namespace common\events;

use common\actions\crud\Action;
use common\forms\Form;
use common\services\CrudService;
use yii\base\ActionEvent;
use yii\db\ActiveRecord;

/**
 * @property Action $action
 */
class CrudActionEvent extends ActionEvent
{
    /**
     * @var CrudService
     */
    public $service;
    /**
     * @var ActiveRecord
     */
    public $model;
    /**
     * @var Form
     */
    public $form;
}