<?php

namespace common\events;

use common\forms\Form;
use common\services\CrudService;
use yii\base\Event;
use yii\db\ActiveRecord;

/**
 * @property CrudService $sender
 */
class CrudServiceEvent extends Event
{
    /**
     * @var ActiveRecord|null;
     */
    public $model;
    /**
     * @var Form|null
     */
    public $form;
    /**
     * @var int|null
     */
    public $affectedRowsCount;
}