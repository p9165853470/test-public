<?php

namespace common\events;

use yii\base\Event;
use yii\base\UnknownMethodException;

/**
 * Обработчик события.
 * Наследуется от этого класса. Обрабатывать события можно даумя способами:
 * - реализовать метод __invoke
 * - реализовать метод с именем события (например, afterAction, beforeSave, ect)
 */
abstract class EventHandler
{
    final public static function get(): callable
    {
        return static function (\yii\base\Event $event) {
            /** @var static $instance */
            $instance = \Yii::createObject(static::class);

            if (method_exists($instance, $event->name)) {
                $callable = [$instance, $event->name];
            } elseif (is_callable($instance)) {
                $callable = $instance;
            } else {
                throw new UnknownMethodException(
                    'Class ' . static::class . ' must be invocable or contain a method "' . $event->name . '".'
                );
            }
            $callable(
                ...\Yii::$container->resolveCallableDependencies($callable, [$event])
            );
        };
    }

    public static function subscribe($target, $names): void
    {
        $handler = static::get();

        if (!is_array($names)) {
            $names = [$names];
        }

        foreach ($names as $name) {
            Event::on($target, $name, $handler);
        }
    }
}