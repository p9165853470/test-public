<?php

namespace common\exceptions;

class DeleteModelException extends RepositoryException
{

}