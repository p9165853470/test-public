<?php

namespace common\exceptions;

class NotFoundModelException extends RepositoryException
{

}