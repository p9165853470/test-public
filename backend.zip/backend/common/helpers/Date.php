<?php

namespace common\helpers;

class Date
{
    public const INTERNAL_DATE_FORMAT = 'Y-m-d';
    public const EXTERNAL_DATE_FORMAT = 'd.m.Y';
    public const INTERNAL_DATETIME_FORMAT = 'Y-m-d H:i:s';
    public const EXTERNAL_DATETIME_FORMAT = 'd.m.Y H:i:s';
}