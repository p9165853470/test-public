<?php

namespace common\mail;

use yii\mail\MailerInterface;
use yii\mail\MessageInterface;

abstract class MessageComposer
{
    /**
     * @var MailerInterface
     */
    protected $mailer;
    /**
     * @var array
     */
    protected $params;
    /**
     * @var MessageInterface|null
     */
    protected $message;

    public function __construct(array $params, MailerInterface $mailer)
    {
        $this->params = $params;
        $this->mailer = $mailer;
    }

    public function getMessage(): ?MessageInterface
    {
        return $this->message;
    }

    /**
     * Тема письма
     *
     * @return string
     */
    abstract protected function getSubject(): string;

    /**
     * Путь к файлу html представления
     *
     * @return string|null
     */
    abstract protected function getHtmlView(): ?string;

    /**
     * Путь к файлу текстового представления
     *
     * @return string|null
     */
    abstract protected function getTextView(): ?string;

    public static function compose(array $params = []): self
    {
        /** @var static $composer */
        $composer = \Yii::createObject(static::class, [$params]);
        $composer->message = $composer->createMessage();

        return $composer;
    }

    /**
     * @param string|array $email
     * @param MailerInterface|null $mailer
     * @return bool
     */
    public function send($email, MailerInterface $mailer = null): bool
    {
        return $this->message->setTo($email)->send($mailer ?? $this->mailer);
    }

    protected function createMessage(): MessageInterface
    {
        return $this->mailer
            ->compose([
                'html' => $this->getHtmlView(),
                'text' => $this->getTextView(),
            ], $this->params)
            ->setSubject($this->getSubject());
    }
}