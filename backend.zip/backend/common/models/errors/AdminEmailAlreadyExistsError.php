<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Email администратора уже существует
 */
final class AdminEmailAlreadyExistsError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::ADMIN_EMAIL_ALREADY_EXISTS;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}