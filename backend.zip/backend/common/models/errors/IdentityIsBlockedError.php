<?php

namespace common\models\errors;

use common\enums\ErrorEnum;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\enums\BlockReasonEnum;

/**
 * Пользователь заблокирован
 */
final class IdentityIsBlockedError extends ModelError
{
    public function __construct(IdentityInterface $identity)
    {
        [$message, $code] = $this->detectMessageAndCode($identity);

        parent::__construct($message, $code);
    }

    private function detectMessageAndCode(IdentityInterface $identity): array
    {
        switch (true) {
            case $identity->hasBlock(BlockReasonEnum::BY_FAILED_AUTHENTICATION):
                $code = ErrorEnum::IDENTITY_BLOCKED_BY_FAILED_AUTHENTICATION;
                break;
            case $identity->hasBlock(BlockReasonEnum::BY_ADMIN):
                $code = ErrorEnum::IDENTITY_BLOCKED_BY_ADMIN;
                break;
            default:
                $code = ErrorEnum::IDENTITY_IS_BLOCKED;
        }

        return [(string)ErrorEnum::getLabel($code), $code];
    }
}