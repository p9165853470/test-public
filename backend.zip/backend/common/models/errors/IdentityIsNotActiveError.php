<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Пользователь не активирован
 */
class IdentityIsNotActiveError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::IDENTITY_IS_NOT_ACTIVE;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}