<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Пользователь не найден (про сбросе пароля)
 */
final class IdentityNotFoundError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::IDENTITY_NOT_FOUND;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}