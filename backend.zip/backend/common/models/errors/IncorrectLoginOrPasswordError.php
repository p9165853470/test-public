<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Неправильный логин или пароль (получение токена)
 */
final class IncorrectLoginOrPasswordError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::INVALID_LOGIN_OR_PASSWORD;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}