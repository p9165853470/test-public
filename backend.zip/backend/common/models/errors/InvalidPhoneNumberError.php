<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Непревильный номер телефона
 */
final class InvalidPhoneNumberError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::INVALID_PHONE_NUMBER;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}