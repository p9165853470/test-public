<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

class ModelError
{
    /**
     * @var int
     */
    protected $code;
    /**
     * @var string
     */
    protected $message;

    public function __construct(string $message, int $code)
    {
        $this->message = $message;
        $this->code = $code;
    }

    public function __toString()
    {
        return $this->getMessage();
    }

    public function getCode(): int
    {
        return $this->code;
    }

    public function getMessage(): string
    {
        return $this->message;
    }
}