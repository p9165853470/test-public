<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Старый пароль не правильный
 */
final class OldPasswordIsInvalidError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::OLD_PASSWORD_IS_INVALID;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}