<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

final class RFInfoRequestError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::RFINFO_REQUEST_ERROR;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}