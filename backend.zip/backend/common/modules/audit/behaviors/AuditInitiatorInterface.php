<?php

namespace common\modules\audit\behaviors;

use common\modules\audit\components\AuditTag;

interface AuditInitiatorInterface
{
    public function getAuditTag(): AuditTag;
}