<?php

namespace common\modules\audit\behaviors;

interface AuditTargetInterface
{
    public function audit(AuditMessageInterface $message): void;
}