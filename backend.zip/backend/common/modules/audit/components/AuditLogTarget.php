<?php

namespace common\modules\audit\components;

use common\modules\audit\messages\ErrorAuditMessage;
use common\modules\audit\services\AuditService;
use yii\log\Target;

class AuditLogTarget extends Target
{
    /**
     * @var AuditService
     */
    protected $service;

    public function __construct(AuditService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($config);
    }

    public function export(): void
    {
        $this->service->audit(new ErrorAuditMessage('Возникла внутренняя ошибка приложения'));
    }
}