<?php

namespace common\modules\audit\enum;

use common\behaviors\EnumTrait;

class ActionEnum
{
    use EnumTrait;

    public const CREATE = 'create';
    public const UPDATE = 'update';
    public const DELETE = 'delete';
    public const DELETE_ALL = 'delete-all';
    public const BLOCK_ALL = 'block-all';
    public const UNBLOCK_ALL = 'unblock-all';
    public const PROFILE_UPDATE = 'profile-update';
    public const CHANGE_PASSWORD = 'change-password';
    public const RESET_PASSWORD = 'reset-password';
    public const BLOCK_STATE_CHANGE = 'block-state-change';
    public const ACCEPT_AGREEMENT = 'accept-agreement';
    public const PROFILE_VALIDATE = 'profile-validate';
    public const PHONE_VALIDATE = 'phone-validate';
    public const CHOOSE_DEALER = 'choose-dealer';
    public const SEND_FEEDBACK = 'send-feedback';
    public const CHANGE_PHONE_NUMBER = 'change-phone-number';
    public const CHANGE_KEY_WORD = 'change-key-word';
    public const CREATE_DOCUMENT = 'create-document';

    public static function getLabels(): array
    {
        return [
            self::CREATE => 'Создание',
            self::UPDATE => 'Редактирование',
            self::DELETE => 'Удаление',
            self::DELETE_ALL => 'Множественное удаление',
            self::BLOCK_ALL => 'Множественная блокировка',
            self::UNBLOCK_ALL => 'Множественная разблокировка',
            self::PROFILE_UPDATE => 'Редактирование профиля',
            self::CHANGE_PASSWORD => 'Изменение пароля',
            self::RESET_PASSWORD => 'Сброс пароля',
            self::BLOCK_STATE_CHANGE => 'Изменение статуса блокировки',
            self::ACCEPT_AGREEMENT => 'Принятие соглашения',
            self::PROFILE_VALIDATE => 'Валидация профиля',
            self::PHONE_VALIDATE => 'Валидация телефона',
            self::CHOOSE_DEALER => 'Выбор дилера',
            self::SEND_FEEDBACK => 'Отправка обратной связи',
            self::CHANGE_PHONE_NUMBER => 'Изменение номера телефона',
            self::CHANGE_KEY_WORD => 'Изменение кодового слова',
            self::CREATE_DOCUMENT => 'Создание документа',
        ];
    }
}