<?php

namespace common\modules\audit\exceptions;

use yii\base\Exception;

class AuditException extends Exception
{

}