<?php

namespace common\modules\audit\messages;

use common\modules\audit\behaviors\AuditMessageInterface;
use common\modules\audit\components\AuditTag;

class ErrorAuditMessage implements AuditMessageInterface
{
    /**
     * @var \DateTimeInterface
     */
    protected $date;
    /**
     * @var string
     */
    protected $error;

    public function __construct(string $error)
    {
        $this->date = date_create_immutable();
        $this->error = $error;
    }

    public function getDate(): \DateTimeInterface
    {
        return $this->date;
    }

    public function getTag(): AuditTag
    {
        return new AuditTag(0, 'app');
    }

    public function getMessage(): string
    {
        return $this->error;
    }
}