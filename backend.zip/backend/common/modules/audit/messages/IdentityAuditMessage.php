<?php

namespace common\modules\audit\messages;

use common\modules\audit\behaviors\AuditInitiatorInterface;
use common\modules\audit\behaviors\AuditMessageInterface;
use common\modules\audit\components\AuditTag;
use common\modules\audit\enum\ActionEnum;
use common\modules\user\behaviors\IdentityInterface;
use DateTimeInterface;
use yii\base\InvalidArgumentException;

class IdentityAuditMessage implements AuditMessageInterface
{
    /**
     * @var DateTimeInterface
     */
    protected $date;
    /**
     * @var string
     */
    protected $action;
    /**
     * @var AuditInitiatorInterface
     */
    protected $initiator;

    /**
     * @param string $action
     * @param AuditInitiatorInterface|IdentityInterface $initiator
     */
    public function __construct(string $action, AuditInitiatorInterface $initiator)
    {
        if (!in_array($action, ActionEnum::getRange(), true)) {
            throw new InvalidArgumentException("Invalid audit action: {$action}.");
        }

        $this->date = date_create_immutable();
        $this->action = $action;
        $this->initiator = $initiator;
    }

    public function getDate(): DateTimeInterface
    {
        return $this->date;
    }

    public function getTag(): AuditTag
    {
        return $this->initiator->getAuditTag();
    }

    public function getMessage(): string
    {
        return ActionEnum::getLabel($this->action);
    }
}