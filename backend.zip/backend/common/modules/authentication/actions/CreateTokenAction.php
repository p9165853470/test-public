<?php

namespace common\modules\authentication\actions;

use common\modules\authentication\behaviors\AuthenticationServiceInterface;
use common\modules\authentication\forms\CreateTokenForm;
use common\modules\authentication\resources\AuthenticationTokenResource;
use yii\base\Action;
use yii\web\Request;
use yii\web\User;

class CreateTokenAction extends Action
{
    /**
     * @var AuthenticationServiceInterface
     */
    protected $service;

    public function __construct($id, $controller, AuthenticationServiceInterface $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param Request $request
     * @param User $user
     * @return CreateTokenForm|AuthenticationTokenResource
     */
    public function run(Request $request, User $user)
    {
        /** @var CreateTokenForm $form */
        $form = \Yii::createObject(CreateTokenForm::class, [$user]);
        $form->load($request->post());

        if ($form->validate()) {
            return new AuthenticationTokenResource(
                $this->service->createToken($form->getIdentity())
            );
        }
        return $form;
    }
}