<?php

namespace common\modules\authentication\actions;

use common\modules\authentication\behaviors\AuthenticationServiceInterface;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\Action;
use yii\web\Response;

class DestroyTokenAction extends Action
{
    /**
     * @var AuthenticationServiceInterface
     */
    protected $service;

    public function __construct($id, $controller, AuthenticationServiceInterface $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(IdentityInterface $identity, Response $response): void
    {
        $this->service->destroyToken($identity->getToken());

        \Yii::$app->user->logout();

        $response->setStatusCode(204);
    }
}