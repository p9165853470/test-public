<?php

namespace common\modules\authentication\behaviors;

use common\behaviors\EventSenderTrait;
use common\modules\authentication\events\CreateTokenEvent;
use common\modules\authentication\events\RefreshTokenEvent;
use common\modules\session\behaviors\SessionServiceInterface;
use common\modules\user\behaviors\IdentityInterface;

trait AuthenticationServiceTrait
{
    use EventSenderTrait;

    /**
     * @var TokenServiceInterface
     */
    protected $tokenService;
    /**
     * @var SessionServiceInterface
     */
    protected $sessionService;

    public function createToken(IdentityInterface $identity): TokenInterface
    {
        $token = $this->tokenService->create();

        $this->sessionService->add($token, $identity);

        $this->trigger(static::EVENT_AFTER_CREATE_TOKEN, new CreateTokenEvent([
            'identity' => $identity,
            'token' => $token,
        ]));

        return $token;
    }

    public function refreshToken(TokenInterface $oldToken): TokenInterface
    {
        $identity = $oldToken->getSession()->getIdentity();
        $newToken = $this->tokenService->create();

        $this->sessionService->renew($oldToken->getSession(), $newToken);

        $this->trigger(static::EVENT_AFTER_REFRESH_TOKEN, new RefreshTokenEvent([
            'identity' => $identity,
            'oldToken' => $oldToken,
            'newToken' => $newToken,
        ]));

        return $newToken;
    }

    public function destroyToken(TokenInterface $token): void
    {
        $this->sessionService->destroy($token->getSession());
    }
}