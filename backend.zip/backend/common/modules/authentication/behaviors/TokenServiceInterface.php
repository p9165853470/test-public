<?php

namespace common\modules\authentication\behaviors;

use common\modules\user\behaviors\IdentityInterface;

/**
 * Интерфейс сервиса по работе с токенами
 */
interface TokenServiceInterface
{
    /**
     * Сгенерировать токен
     *
     * @return TokenInterface
     */
    public function create(): TokenInterface;

    /**
     * Получить сущность токена из строки токена
     *
     * @param string $data Токен
     * @param bool $validate Проверка токена валидацией
     * @param bool $verify Проверка токена верификацией
     * @return TokenInterface|null
     */
    public function load(string $data, bool $validate = true, bool $verify = true): ?TokenInterface;
}