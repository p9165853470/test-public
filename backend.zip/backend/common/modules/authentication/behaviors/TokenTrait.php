<?php

namespace common\modules\authentication\behaviors;

use common\modules\authentication\exceptions\TokenException;
use common\modules\session\behaviors\SessionInterface;
use common\modules\session\behaviors\SessionServiceInterface;
use common\modules\session\exceptions\SessionException;
use common\modules\user\behaviors\IdentityInterface;

trait TokenTrait
{
    /**
     * @var SessionServiceInterface
     */
    protected $sessionService;
    /**
     * @var SessionInterface
     */
    private $session;

    public function getSession(): SessionInterface
    {
        if ($this->session === null) {
            try {
                $this->session = $this->sessionService->get($this);
            } catch (SessionException $ex) {
                throw new TokenException($ex->getMessage());
            }
        }

        return $this->session;
    }

    public function isValid(): bool
    {
        try {
            $session = $this->getSession();
        } catch (TokenException $ex) {
            return false;
        }

        return $session->getIdentity() instanceof IdentityInterface && !$session->isExpired();
    }
}