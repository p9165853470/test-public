<?php

namespace common\modules\authentication\components;

use common\modules\authentication\behaviors\TokenInterface;
use common\modules\authentication\helpers\TokenHelper;
use common\modules\session\behaviors\SessionServiceInterface;
use Lcobucci\JWT\Token;

class Jwt extends \bizley\jwt\Jwt
{
    public function loadToken(string $data, bool $validate = true, bool $verify = true): ?Token
    {
        $token = parent::loadToken($data, $validate, $verify);

        if ($validate && $token instanceof Token && !$this->wrapToken($token)->isValid()) {
            return null;
        }
        return $token;
    }

    /**
     * @param Token $token
     * @return TokenInterface|object
     */
    public function wrapToken(Token $token): TokenInterface
    {
        return \Yii::createObject(JwtToken::class, [$token]);
    }
}