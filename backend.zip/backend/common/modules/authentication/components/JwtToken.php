<?php

namespace common\modules\authentication\components;

use common\modules\authentication\behaviors\TokenInterface;
use common\modules\authentication\behaviors\TokenTrait;
use common\modules\session\behaviors\SessionServiceInterface;
use Lcobucci\JWT\Token;

class JwtToken implements TokenInterface
{
    use TokenTrait;

    /**
     * @var JwtToken
     */
    protected $token;

    public function __construct(Token $token, SessionServiceInterface $sessionService)
    {
        $this->token = $token;
        $this->sessionService = $sessionService;
    }

    public function isRefresh(): bool
    {
        $interval = \Yii::$app->params['jwt.refreshTokenLifeTime'];

        return $this->token->hasClaim('jti')
            && $this->token->getClaim('exp')
            && $this->token->getClaim('exp') + $interval > time();
    }

    public function isExpired(): bool
    {
        return $this->token->isExpired();
    }

    public function getId()
    {
        return (string)$this->token->getClaim('jti');
    }

    public function __toString()
    {
        return (string)$this->token;
    }
}