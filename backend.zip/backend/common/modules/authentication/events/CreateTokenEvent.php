<?php

namespace common\modules\authentication\events;

use common\modules\authentication\behaviors\TokenInterface;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\Event;

class CreateTokenEvent extends Event
{
    /**
     * @var IdentityInterface
     */
    public $identity;
    /**
     * @var TokenInterface
     */
    public $token;
}