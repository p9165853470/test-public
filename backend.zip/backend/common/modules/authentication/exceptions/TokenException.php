<?php

namespace common\modules\authentication\exceptions;

use yii\base\Exception;

class TokenException extends Exception
{

}