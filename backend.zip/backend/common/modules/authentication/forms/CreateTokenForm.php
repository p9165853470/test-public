<?php

namespace common\modules\authentication\forms;

use common\enums\ErrorEnum;
use common\models\errors\IdentityIsNotActiveError;
use common\models\errors\IncorrectLoginOrPasswordError;
use common\models\errors\ModelError;
use common\models\errors\IdentityIsBlockedError;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\Model;
use yii\web\User;

class CreateTokenForm extends Model
{
    /**
     * @var string
     */
    public $login;
    /**
     * @var string
     */
    public $password;
    /**
     * @var User
     */
    protected $user;
    /**
     * @var IdentityInterface|bool
     */
    protected $identity = false;
    
    public function __construct(User $user, $config = [])
    {
        $this->user = $user;
        
        parent::__construct($config);
    }

    public function getIdentity(): ?IdentityInterface
    {
        if ($this->identity === false) {
            /** @var IdentityInterface $identityClass */
            $identityClass = $this->user->identityClass;
            $this->identity = $identityClass::findIdentityByLogin((string)$this->login);
        }
        return $this->identity;
    }

    public function rules(): array
    {
        return [
            [['login', 'password'], 'required'],
            [
                'login',
                function () {
                    $identity = $this->getIdentity();

                    if ($identity === null) {
                        $this->addError('login', new IncorrectLoginOrPasswordError());
                    } elseif ($identity->hasBlock()) {
                        $this->addError('login', new IdentityIsBlockedError($identity));
                    } elseif (!$identity->validatePassword($this->password)) {
                        $this->addError('login', new IncorrectLoginOrPasswordError());
                    } elseif (!$identity->isActive()) {
                        $this->addError('login', new IdentityIsNotActiveError());
                    }
                },
            ],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}