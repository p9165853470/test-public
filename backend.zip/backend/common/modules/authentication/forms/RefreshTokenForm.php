<?php

namespace common\modules\authentication\forms;

use common\models\errors\IdentityIsBlockedError;
use common\models\errors\IdentityIsNotActiveError;
use common\modules\authentication\behaviors\TokenInterface;
use common\modules\authentication\exceptions\TokenException;
use common\modules\authentication\helpers\TokenHelper;
use common\modules\session\exceptions\SessionException;
use yii\base\Model;

class RefreshTokenForm extends Model
{
    /**
     * @var TokenInterface|string|null
     */
    public $token;

    public function rules(): array
    {
        return [
            ['token', 'required'],
            ['token', 'string'],
            [
                'token',
                function () {
                    $this->token = TokenHelper::load($this->token, false);

                    if ($this->token === null || !$this->token->isRefresh()) {
                        $this->addError('token', 'Invalid or expired refresh token.');
                    }
                }
            ],
            [
                'token',
                function () {
                    try {
                        if ($this->token->getSession()->isExpired()) {
                            $this->addError('token', 'Session is invalid.');
                        }

                        $identity = $this->token->getSession()->getIdentity();

                        if ($identity->hasBlock()) {
                            $this->addError('login', new IdentityIsBlockedError($identity));
                        } elseif (!$identity->isActive()) {
                            $this->addError('login', new IdentityIsNotActiveError());
                        }
                    } catch (TokenException|SessionException $ex) {
                        $this->addError('token', $ex->getMessage());
                    }
                }
            ],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}