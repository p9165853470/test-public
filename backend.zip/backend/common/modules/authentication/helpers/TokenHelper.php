<?php

namespace common\modules\authentication\helpers;

use common\helpers\StaticInstanceHelper;
use common\modules\authentication\behaviors\TokenInterface;
use common\modules\authentication\behaviors\TokenServiceInterface;
use common\modules\user\behaviors\IdentityInterface;
use yii\di\Instance;

/**
 * @method static TokenInterface create()
 * @method static TokenInterface|null load(string $data, bool $validate = true, bool $verify = true)
 */
class TokenHelper extends StaticInstanceHelper
{
    protected static function getInstance(): object
    {
        return Instance::ensure(TokenServiceInterface::class);
    }
}