<?php

namespace common\modules\authentication\services;

use common\modules\authentication\behaviors\AuthenticationServiceInterface;
use common\modules\authentication\behaviors\AuthenticationServiceTrait;
use common\modules\authentication\behaviors\TokenServiceInterface;
use common\modules\session\behaviors\SessionServiceInterface;

class AuthenticationService implements AuthenticationServiceInterface
{
    use AuthenticationServiceTrait;

    public function __construct(TokenServiceInterface $tokenService, SessionServiceInterface $sessionService)
    {
        $this->tokenService = $tokenService;
        $this->sessionService = $sessionService;
    }
}