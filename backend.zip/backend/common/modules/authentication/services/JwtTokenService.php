<?php

namespace common\modules\authentication\services;

use common\modules\authentication\behaviors\TokenInterface;
use common\modules\authentication\behaviors\TokenServiceInterface;
use common\modules\authentication\components\Jwt;
use Lcobucci\JWT\Signer\Hmac\Sha256;
use Lcobucci\JWT\Signer\Key;
use Yii;
use yii\di\Instance;

class JwtTokenService implements TokenServiceInterface
{
    /**
     * @var Jwt
     */
    protected $jwt;

    public function __construct()
    {
        $this->jwt = Instance::ensure('jwt', Jwt::class);
    }

    public function create(): TokenInterface
    {
        $time = time();

        $builder = $this->jwt->getBuilder()
            ->withClaim('iss', Yii::$app->getRequest()->getHostInfo())
            ->withClaim('iat', $time)
            ->withClaim('nbf', $time)
            ->withClaim('exp', $time + Yii::$app->params['jwt.authTokenLifetime'])
            ->withClaim('jti', Yii::$app->getSecurity()->generateRandomString(16));

        return $this->jwt->wrapToken(
            $builder->getToken(new Sha256(), new Key($this->jwt->key))
        );
    }

    public function load(string $data, bool $validate = true, bool $verify = true): ?TokenInterface
    {
        $token = $this->jwt->loadToken($data, $validate, $verify);

        if ($token !== null) {
            return $this->jwt->wrapToken($token);
        }
        return null;
    }
}