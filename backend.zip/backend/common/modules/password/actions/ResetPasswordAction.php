<?php

namespace common\modules\password\actions;

use common\enums\ErrorEnum;
use common\models\errors\IdentityNotFoundError;
use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\password\forms\ResetPasswordForm;
use yii\base\Action;
use yii\di\Instance;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class ResetPasswordAction extends Action
{
    /**
     * @var PasswordServiceInterface
     */
    protected $service;

    public function __construct($id, $controller, PasswordServiceInterface $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param Request $request
     * @param Response $response
     * @return ResetPasswordForm|void
     * @throws BadRequestHttpException
     */
    public function run(Request $request, Response $response)
    {
        /** @var ResetPasswordForm $form */
        $form = Instance::ensure(ResetPasswordForm::class);

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $this->service->change(
                $form->getIdentity(),
                $form->getPassword(),
                PasswordServiceInterface::CONTEXT_ACTION_RESET
            );
            $response->setStatusCode(204);
        }
        elseif ($form->getFirstError('login')->getCode() == ErrorEnum::IDENTITY_NOT_FOUND) {
           $response->setStatusCode(204);
        }
            else {
            return $form;
        }
    }
}