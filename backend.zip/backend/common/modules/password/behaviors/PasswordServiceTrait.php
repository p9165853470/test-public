<?php

namespace common\modules\password\behaviors;

use common\behaviors\EventSenderTrait;
use common\behaviors\ModelHasRepositoryInterface;
use common\exceptions\SaveModelException;
use common\modules\password\events\PasswordEvent;
use common\modules\user\behaviors\IdentityInterface;
use common\repositories\AnonymousRepository;
use DateTimeInterface;
use yii\db\ActiveRecord;

trait PasswordServiceTrait
{
    use EventSenderTrait;

    /**
     * @var UserPasswordRepositoryInterface
     */
    protected $repository;

    /**
     * Получить дату, после который последний пароль пользователя следует считать устаревшим
     *
     * @return DateTimeInterface
     */
    abstract protected function getExpireDate(): DateTimeInterface;

    public function generatePasswordHash(string $password): string
    {
        return hash('sha256', $password);
    }

    /**
     * @param IdentityInterface|ActiveRecord $identity
     * @param string $password
     * @param string|null $context
     * @throws SaveModelException
     */
    public function change(IdentityInterface $identity, string $password, string $context = null): void
    {
        $identity->setPassword($password);

        if ($identity instanceof ModelHasRepositoryInterface) {
            $repository = $identity::getRepository();
        } else {
            $repository = new AnonymousRepository(get_class($identity));
        }
        $repository->save($identity);

        $this->trigger(static::EVENT_AFTER_CHANGE_PASSWORD, new PasswordEvent([
            'identity' => $identity,
            'password' => $password,
            'context' => $context,
        ]));
    }

    public function hasUnsafePassword(IdentityInterface $identity): bool
    {
        $model = $this->getLastPassword($identity);

        if ($model instanceof UserPasswordInterface && $model->isManual()) {
            return $model->getDate() < $this->getExpireDate();
        }
        return true;
    }

    public function getLastPassword(IdentityInterface $identity): ?UserPasswordInterface
    {
        return $this->repository->findLastByIdentity($identity);
    }

    public function store(IdentityInterface $identity, string $password, bool $isManual): void
    {
        $this->repository->create($identity, $this->generatePasswordHash($password), $isManual);
    }
}