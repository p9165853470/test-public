<?php

namespace common\modules\password\behaviors;

use common\exceptions\SaveModelException;
use common\modules\user\behaviors\IdentityInterface;

/**
 * Интерфейс для репозитория пользовательских паролей
 */
interface UserPasswordRepositoryInterface
{
    /**
     * Найти последний (текущий) пароль пользователя
     *
     * @param IdentityInterface $identity
     * @return UserPasswordInterface|null
     */
    public function findLastByIdentity(IdentityInterface $identity): ?UserPasswordInterface;

    /**
     * Создать запись о новом пароле пользователя
     *
     * @param IdentityInterface $identity
     * @param string $hash
     * @param bool $isManual пароль введен пользователем
     * @return UserPasswordInterface
     * @throws SaveModelException
     */
    public function create(IdentityInterface $identity, string $hash, bool $isManual): UserPasswordInterface;
}