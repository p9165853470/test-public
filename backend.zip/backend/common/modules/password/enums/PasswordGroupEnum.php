<?php

namespace common\modules\password\enums;

use common\behaviors\EnumTrait;
use common\modules\password\helpers\PasswordGenerator;

class PasswordGroupEnum
{
    use EnumTrait;

    public const DIGITS = PasswordGenerator::GROUP_DGT;
    public const LOWERCASE_LETTERS = PasswordGenerator::GROUP_LLT;
    public const UPPERCASE_LETTERS = PasswordGenerator::GROUP_ULT;
    public const PUNCTUATION_CHARACTERS = PasswordGenerator::GROUP_PNC;
}