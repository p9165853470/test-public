<?php

namespace common\modules\password\forms;

use common\models\errors\OldPasswordIsInvalidError;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\Model;

abstract class ChangePasswordForm extends Model
{
    /**
     * @var IdentityInterface
     */
    protected $identity;
    /**
     * @var string
     */
    public $old_password;
    /**
     * @var string
     */
    public $new_password;
    /**
     * @var string
     */
    public $new_password_retry;

    public function setIdentity(IdentityInterface $identity): void
    {
        $this->identity = $identity;
    }

    public function getPassword(): string
    {
        return $this->new_password;
    }

    public function rules(): array
    {
        return [
            [['old_password', 'new_password', 'new_password_retry'], 'required'],
            ['new_password', 'compare', 'compareAttribute' => 'new_password_retry'],
            [
                'old_password',
                function () {
                    if (!$this->identity->validatePassword($this->old_password)) {
                        $this->addError('old_password', new OldPasswordIsInvalidError());
                    }
                }
            ],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}