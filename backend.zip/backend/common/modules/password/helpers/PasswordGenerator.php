<?php

namespace common\modules\password\helpers;

class PasswordGenerator
{
    /**
     * Цифры
     */
    public const GROUP_DGT = 2;
    /**
     * Строчные буквы
     */
    public const GROUP_LLT = 4;
    /**
     * Заглавные буквы
     */
    public const GROUP_ULT = 8;
    /**
     * Знаки пунктуации
     */
    public const GROUP_PNC = 16;

    private const GROUPS = [
        '1234567890',
        'abcdefghijklmnopqrstuvwxyz',
        'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
        '!"#$%&\'()*+,-./:;<=>?@[\]^_`{|}~',
    ];

    /**
     * @param int $length
     * @param int $groups группы символов, указаных при помощи побитового оператора |
     * @return string
     */
    public static function generate(int $length, int $groups): string
    {
        $lines = [];

        if (self::GROUP_DGT & $groups) {
            $lines[] = self::GROUPS[0];
        }

        if (self::GROUP_LLT & $groups) {
            $lines[] = self::GROUPS[1];
        }

        if (self::GROUP_ULT & $groups) {
            $lines[] = self::GROUPS[2];
        }

        if (self::GROUP_PNC & $groups) {
            $lines[] = self::GROUPS[3];
        }

        if (empty($lines)) {
            return '';
        }

        $data = [];

        for ($i = 1; $i <= $length; $i++) {
            $line = current($lines);
            $chars = mb_str_split($line);
            $index = array_rand($chars);

            $data[] = $chars[$index];

            if (next($lines) === false) {
                reset($lines);
            }
        }
        shuffle($data);

        return implode('', $data);
    }
}