<?php

namespace common\modules\password\helpers;

use common\helpers\StaticInstanceHelper;
use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\user\behaviors\IdentityInterface;
use DateTimeInterface;
use yii\di\Instance;

/**
 * @method static bool validate(IdentityInterface $identity, string $password)
 * @method static void change(IdentityInterface $identity, string $password)
 * @method static bool isNewPasswordRequired(IdentityInterface $identity)
 * @method static string generatePasswordHash(string $password)
 */
class PasswordHelper extends StaticInstanceHelper
{
    protected static function getInstance(): object
    {
        return Instance::ensure(PasswordServiceInterface::class);
    }
}