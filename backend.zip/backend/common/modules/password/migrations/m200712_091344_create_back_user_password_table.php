<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%back_user_password}}`.
 */
class m200712_091344_create_back_user_password_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%back_user_password}}', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'password_hash' => $this->string(128)->notNull(),
            'created_at' => $this->timestamp()->notNull(),
        ]);

        $this->addForeignKeyNamed('{{%back_user_password}}', 'user_id', '{{%back_user}}', 'id');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%back_user_password}}');
    }
}
