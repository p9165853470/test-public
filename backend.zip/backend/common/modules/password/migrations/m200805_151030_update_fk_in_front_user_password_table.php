<?php

use console\components\Migration;

/**
 * Class m200805_151030_update_fk_in_front_user_password_table
 */
class m200805_151030_update_fk_in_front_user_password_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropForeignKeyNamed('{{%front_user_password}}', 'user_id', '{{%front_user}}', 'id');
        $this->addForeignKeyNamed('{{%front_user_password}}', 'user_id', '{{%front_user}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKeyNamed('{{%front_user_password}}', 'user_id', '{{%front_user}}', 'id');
        $this->addForeignKeyNamed('{{%front_user_password}}', 'user_id', '{{%front_user}}', 'id');
    }
}
