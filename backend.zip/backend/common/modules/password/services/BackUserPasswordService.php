<?php

namespace common\modules\password\services;

use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\password\behaviors\PasswordServiceTrait;
use common\modules\password\models\BackUserPassword;
use common\modules\password\repositories\BackUserPasswordRepository;
use common\modules\user\behaviors\IdentityInterface;
use DateTimeInterface;
use yii\base\StaticInstanceInterface;
use yii\base\StaticInstanceTrait;
use yii\db\Expression;

class BackUserPasswordService implements PasswordServiceInterface, StaticInstanceInterface
{
    use StaticInstanceTrait;
    use PasswordServiceTrait;

    public function __construct(BackUserPasswordRepository $repository)
    {
        $this->repository = $repository;
    }

    public function validate(IdentityInterface $identity, string $password): bool
    {
        $subQuery = $this->repository->find(['user_id' => $identity->getId()])
            ->orderBy(['created_at' => SORT_DESC])
            ->limit(BackUserPassword::NUMBER_TO_CHECK_FOR_REUSE);

        return !$this->repository->find()
            ->from($subQuery)
            ->andWhere(['password_hash' => $this->generatePasswordHash($password)])
            ->exists();
    }

    public function collectGarbage(): int
    {
        $subQuery = $this->repository->find()
            ->select('t1.id')
            ->from(['t1' => BackUserPassword::tableName()])
            ->andWhere([
                'not in',
                't1.id',
                $this->repository->find()
                    ->select('t2.id')
                    ->from(['t2' => BackUserPassword::tableName()])
                    ->andWhere(['t2.user_id' => new Expression('{{t1}}.[[user_id]]')])
                    ->orderBy(['t2.created_at' => SORT_DESC])
                    ->limit(BackUserPassword::NUMBER_TO_CHECK_FOR_REUSE)
            ]);

        return BackUserPassword::deleteAll(['in', 'id', $subQuery]);
    }

    protected function getExpireDate(): DateTimeInterface
    {
        return date_create()->sub(new \DateInterval(BackUserPassword::PASSWORD_UNSAFE_INTERVAL));
    }

    public function getRepository(): BackUserPasswordRepository
    {
        return $this->repository;
    }
}