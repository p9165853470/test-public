<?php

namespace common\modules\password\services;

use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\password\behaviors\PasswordServiceTrait;
use common\modules\password\models\FrontUserPassword;
use common\modules\password\repositories\FrontUserPasswordRepository;
use common\modules\user\behaviors\IdentityInterface;
use DateTimeInterface;
use yii\base\StaticInstanceInterface;
use yii\base\StaticInstanceTrait;
use yii\db\Expression;

class FrontUserPasswordService implements PasswordServiceInterface, StaticInstanceInterface
{
    use StaticInstanceTrait;
    use PasswordServiceTrait;

    public function __construct(FrontUserPasswordRepository $repository)
    {
        $this->repository = $repository;
    }

    public function validate(IdentityInterface $identity, string $password): bool
    {
        $subQuery = $this->repository->find(['user_id' => $identity->getId()])
            ->orderBy(['created_at' => SORT_DESC])
            ->limit(FrontUserPassword::NUMBER_TO_CHECK_FOR_REUSE);

        return !$this->repository->find()
            ->from($subQuery)
            ->andWhere(['password_hash' => $this->generatePasswordHash($password)])
            ->exists();
    }

    public function collectGarbage(): int
    {
        $subQuery = $this->repository->find()
            ->select('t1.id')
            ->from(['t1' => FrontUserPassword::tableName()])
            ->andWhere([
                'not in',
                't1.id',
                $this->repository->find()
                    ->select('t2.id')
                    ->from(['t2' => FrontUserPassword::tableName()])
                    ->andWhere(['t2.user_id' => new Expression('{{t1}}.[[user_id]]')])
                    ->orderBy(['t2.created_at' => SORT_DESC])
                    ->limit(FrontUserPassword::NUMBER_TO_CHECK_FOR_REUSE)
            ]);

        return FrontUserPassword::deleteAll(['in', 'id', $subQuery]);
    }

    protected function getExpireDate(): DateTimeInterface
    {
        return date_create()->sub(new \DateInterval(FrontUserPassword::PASSWORD_UNSAFE_INTERVAL));
    }

    public function getRepository(): FrontUserPasswordRepository
    {
        return $this->repository;
    }
}