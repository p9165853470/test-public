<?php

namespace common\modules\password\validators;

use common\modules\password\enums\PasswordGroupEnum;
use common\modules\password\helpers\PasswordGenerator;
use yii\validators\Validator;

class PasswordValidator extends Validator
{
    /**
     * @var int минимальное кол-во символов
     */
    public $min;
    /**
     * @var int максимальное кол-во символов
     */
    public $max;
    /**
     * @var int мин. кол-во групп символов, которык должны содержаться в пароле
     * @todo Вынести в конфиг или константу класса пользователя
     */
    public $minGroupsCount = 3;

    public function validateAttribute($model, $attribute): void
    {
        // Минимальная длина пароля
        if (is_int($this->min) && mb_strlen($model->$attribute) < $this->min) {
            $this->addError($model, $attribute, "Password must be at least {$this->min} characters long.");
        }
        // Максимальная лоина пароля
        if (is_int($this->max) && mb_strlen($model->$attribute) > $this->max) {
            $this->addError($model, $attribute, "Password must be no more than {$this->max} characters long.");
        }

        $groups = [];

        // Наличие цифр
        if (preg_match('/\d/', $model->$attribute)) {
            $groups[] = PasswordGenerator::GROUP_DGT;
        }
        // Наличие строчных букв
        if (preg_match('/\p{Ll}/u', $model->$attribute)) {
            $groups[] = PasswordGenerator::GROUP_LLT;
        }
        // Наличие заглавных букв
        if (preg_match('/\p{Lu}/u', $model->$attribute)) {
            $groups[] = PasswordGenerator::GROUP_ULT;
        }
        // Наличие символов пунктуации
        if (preg_match('/\p{P}/u', $model->$attribute)) {
            $groups[] = PasswordGenerator::GROUP_PNC;
        }

        if (count($groups) < $this->minGroupsCount) {
            $unusedGroups = array_diff(PasswordGroupEnum::getRange(), $groups);
            $unusedGroups = array_map([PasswordGroupEnum::class, 'getLabel'], $unusedGroups);

            $lastUnusedGroup = array_pop($unusedGroups);

            if (empty($unusedGroups)) {
                $message = $lastUnusedGroup;
            } else {
                $message = implode(', ', $unusedGroups) . ' or ' . $lastUnusedGroup;
            }

            $message = mb_strtolower($message);

            $this->addError($model, $attribute, "Password must contain {$message}.");
        }

        /*// Наличие цифр
        if (PasswordGenerator::GROUP_DGT & $this->groups && !preg_match('/\d/', $model->$attribute)) {
            $this->addError($model, $attribute, 'Password must contain digits.');
        }
        // Наличие строчных букв
        if (PasswordGenerator::GROUP_LLT & $this->groups && !preg_match('/\p{Ll}/u', $model->$attribute)) {
            $this->addError($model, $attribute, 'Password must contain lowercase letters.');
        }
        // Наличие заглавных букв
        if (PasswordGenerator::GROUP_ULT & $this->groups && !preg_match('/\p{Lu}/u', $model->$attribute)) {
            $this->addError($model, $attribute, 'Password must contain uppercase letters.');
        }
        // Наличие символов пунктуации
        if (PasswordGenerator::GROUP_PNC & $this->groups && !preg_match('/\p{P}/u', $model->$attribute)) {
            $this->addError($model, $attribute, 'Password must contain punctuation characters.');
        }*/
    }
}