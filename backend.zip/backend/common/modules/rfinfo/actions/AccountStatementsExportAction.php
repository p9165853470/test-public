<?php

namespace common\modules\rfinfo\actions;

use common\enums\ErrorEnum;
use common\modules\rfinfo\behaviors\RequestCacheServiceInterface;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\factories\AccountStatementsFormatterFactory;
use common\modules\rfinfo\factories\RequestFactory;
use Yii;
use yii\base\Action;
use yii\base\InvalidArgumentException;
use yii\helpers\FileHelper;
use yii\web\BadRequestHttpException;
use yii\web\NotAcceptableHttpException;
use yii\web\Request;
use yii\web\Response;

class AccountStatementsExportAction extends Action
{
    /**
     * @var RequestCacheServiceInterface
     */
    protected $service;
    /**
     * @var RequestFactory
     */
    protected $factory;
    /**
     * @var AccountStatementsFormatterFactory
     */
    protected $formatterFactory;

    public function __construct(
        $id,
        $controller,
        RequestFactory $factory,
        AccountStatementsFormatterFactory $formatterFactory,
        RequestCacheServiceInterface $service,
        $config = []
    ) {
        $this->factory = $factory;
        $this->formatterFactory = $formatterFactory;
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(Request $request, Response $response)
    {
        try {
            $formatter = $this->formatterFactory->getFormatterFromRequest($request);
        } catch (InvalidArgumentException $ex) {
            throw new NotAcceptableHttpException($ex->getMessage());
        }

        $data = $request->getIsPost() ? $request->post() : $request->get();
        $context = $this->factory->getContext(RequestMethodEnum::ACCOUNT_STATEMENTS, $data);

        if (!$context->getQuery()->hasErrors()) {
            try {
                $info = $this->getInfo();
                $statements = $this->service->getAccountStatements($context);
            } catch (RequestServiceException $ex) {
                Yii::error($ex);

                $response->format = Response::FORMAT_JSON;

                throw new BadRequestHttpException('RFInfo request error.', ErrorEnum::RFINFO_REQUEST_ERROR);
            }

            $response->headers->set('X-Request-Id', $context->getQuery()->id);

            $formatter->setInfo($info);
            $formatter->setQuery($context->getQuery());
            $formatter->setAccountStatements($statements);

            $mimeType = $formatter->getMimeType();
            $extensions = FileHelper::getExtensionsByMimeType($mimeType, '@common/modules/rfinfo/data/mimeTypes.php');
            $attachmentName = 'account_statements.' . reset($extensions);

            return $response->sendContentAsFile($formatter->format(), $attachmentName, ['mimeType' => $mimeType]);
        }

        $response->format = Response::FORMAT_JSON;

        return $context->getQuery();
    }

    /**
     * @return Info
     * @throws RequestServiceException
     */
    protected function getInfo()
    {
        return $this->service->getInfo($this->factory->getContext(RequestMethodEnum::INFO));
    }
}