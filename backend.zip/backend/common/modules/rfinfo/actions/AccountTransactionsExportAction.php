<?php

namespace common\modules\rfinfo\actions;

use common\enums\ErrorEnum;
use common\exceptions\NotFoundModelException;
use common\modules\rfinfo\behaviors\RequestCacheServiceInterface;
use common\modules\rfinfo\dto\Account;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\factories\AccountTransactionsFormatterFactory;
use common\modules\rfinfo\factories\RequestFactory;
use Yii;
use yii\base\Action;
use yii\base\InvalidArgumentException;
use yii\helpers\FileHelper;
use yii\web\BadRequestHttpException;
use yii\web\NotAcceptableHttpException;
use yii\web\Request;
use yii\web\Response;

class AccountTransactionsExportAction extends Action
{
    /**
     * @var RequestFactory
     */
    protected $factory;
    /**
     * @var AccountTransactionsFormatterFactory
     */
    protected $formatterFactory;
    /**
     * @var RequestCacheServiceInterface
     */
    protected $service;

    public function __construct(
        $id,
        $controller,
        RequestFactory $factory,
        AccountTransactionsFormatterFactory $formatterFactory,
        RequestCacheServiceInterface $service,
        $config = []
    ) {
        $this->factory = $factory;
        $this->formatterFactory = $formatterFactory;
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(Request $request, Response $response)
    {
        try {
            $formatter = $this->formatterFactory->getFormatterFromRequest($request);
        } catch (InvalidArgumentException $ex) {
            throw new NotAcceptableHttpException($ex->getMessage());
        }

        $data = $request->getIsPost() ? $request->post() : $request->get();
        $context = $this->factory->getContext(RequestMethodEnum::ACCOUNT_TRANSACTIONS, $data);

        if (!$context->getQuery()->hasErrors()) {
            try {
                $account = $this->getAccount($context->getQuery()->account);
                $info = $this->getInfo();
                $transactions = $this->service->getAccountTransactions($context);
            } catch (NotFoundModelException|RequestServiceException $ex) {
                Yii::error($ex);

                $response->format = Response::FORMAT_JSON;

                throw new BadRequestHttpException('RFInfo request error.', ErrorEnum::RFINFO_REQUEST_ERROR);
            }

            $response->headers->set('X-Request-Id', $context->getQuery()->id);

            $formatter->setInfo($info);
            $formatter->setAccount($account);
            $formatter->setAccountTransactions($transactions);
            $formatter->setQuery($context->getQuery());

            $mimeType = $formatter->getMimeType();
            $extensions = FileHelper::getExtensionsByMimeType($mimeType, '@common/modules/rfinfo/data/mimeTypes.php');
            $attachmentName = 'account_transactions.' . reset($extensions);

            return $response->sendContentAsFile($formatter->format(), $attachmentName, ['mimeType' => $mimeType]);
        }

        $response->format = Response::FORMAT_JSON;

        return $context->getQuery();
    }

    /**
     * @return Info
     * @throws RequestServiceException
     */
    public function getInfo()
    {
        return $this->service->getInfo(
            $this->factory->getContext(RequestMethodEnum::INFO)
        );
    }

    /**
     * @param string $accountNumber
     * @return Account
     * @throws NotFoundModelException
     * @throws RequestServiceException
     */
    public function getAccount(string $accountNumber)
    {
        $context = $this->factory->getContext(RequestMethodEnum::ACCOUNTS);
        $accounts = $this->service->getAccounts($context);

        $account = current(array_filter($accounts, static function ($account) use ($accountNumber) {
            return $account->account === $accountNumber;
        }));

        if ($account === false) {
            throw new NotFoundModelException('Cannot find account.');
        }

        return $account;
    }
}