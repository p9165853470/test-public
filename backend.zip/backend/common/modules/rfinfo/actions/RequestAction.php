<?php

namespace common\modules\rfinfo\actions;

use common\enums\ErrorEnum;
use common\modules\rfinfo\behaviors\RequestCacheServiceInterface;
use common\modules\rfinfo\behaviors\ResponseResourceInterface;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\factories\RequestFactory;
use common\modules\rfinfo\resources\ResponseDataProviderResource;
use Yii;
use yii\base\Action;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class RequestAction extends Action
{
    /**
     * @var RequestFactory
     */
    protected $requestFactory;
    /**
     * @var RequestCacheServiceInterface
     */
    protected $service;

    public function __construct(
        $id,
        $controller,
        RequestFactory $factory,
        RequestCacheServiceInterface $service,
        $config = []
    ) {
        $this->requestFactory = $factory;
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function init(): void
    {
        parent::init();

        Yii::$container->set(ResponseResourceInterface::class, ResponseDataProviderResource::class);
    }

    public function run(string $method, Request $request, Response $response)
    {
        $data = $request->getIsPost() ? $request->post() : $request->get();

        $context = $this->requestFactory->getContext($method, $data);

        if (!$context->getQuery()->hasErrors()) {
            $methodName = RequestMethodEnum::getName($method);

            try {
                $result = $this->service->{$methodName}($context);
            } catch (RequestServiceException $ex) {
                Yii::error($ex);

                throw new BadRequestHttpException('RFInfo request error.', ErrorEnum::RFINFO_REQUEST_ERROR);
            }

            $response->headers->set('X-Request-Id', $context->getQuery()->id);

            return $context->getFilter()->apply($result);
        }

        return $context->getQuery();
    }
}