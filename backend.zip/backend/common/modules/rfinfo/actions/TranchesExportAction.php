<?php

namespace common\modules\rfinfo\actions;

use common\enums\ErrorEnum;
use common\modules\rfinfo\behaviors\RequestCacheServiceInterface;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\factories\RequestFactory;
use common\modules\rfinfo\services\TranchesXlsxFormatter;
use Yii;
use yii\base\Action;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class TranchesExportAction extends Action
{
    /**
     * @var RequestCacheServiceInterface
     */
    protected $service;
    /**
     * @var RequestFactory
     */
    protected $factory;
    /**
     * @var TranchesXlsxFormatter
     */
    protected $formatter;

    public function __construct(
        $id,
        $controller,
        RequestCacheServiceInterface $service,
        RequestFactory $factory,
        TranchesXlsxFormatter $formatter,
        $config = []
    ) {
        $this->service = $service;
        $this->factory = $factory;
        $this->formatter = $formatter;

        parent::__construct($id, $controller, $config);
    }

    public function run(Request $request, Response $response)
    {
        $data = $request->getIsPost() ? $request->post() : $request->get();
        $context = $this->factory->getContext(RequestMethodEnum::TRANCHES, $data);

        if (!$context->getQuery()->hasErrors()) {
            try {
                $info = $this->getInfo();
                $tranches = $this->service->getTranches($context);
            } catch (RequestServiceException $ex) {
                Yii::error($ex);

                $response->format = Response::FORMAT_JSON;

                throw new BadRequestHttpException('RFInfo request error.', ErrorEnum::RFINFO_REQUEST_ERROR);
            }

            $response->headers->set('X-Request-Id', $context->getQuery()->id);

            $this->formatter->setInfo($info);
            $this->formatter->setTranches($tranches);
            $this->formatter->setQuery($context->getQuery());

            return $response->sendContentAsFile(
                $this->formatter->format(),
                'tranches.xlsx',
                ['mimeType' => $this->formatter->getMimeType()]
            );
        }

        $response->format = Response::FORMAT_JSON;

        return $context->getQuery();
    }

    /**
     * @return Info
     * @throws RequestServiceException
     */
    public function getInfo()
    {
        return $this->service->getInfo(
            $this->factory->getContext(RequestMethodEnum::INFO)
        );
    }
}