<?php

namespace common\modules\rfinfo\behaviors;

use common\modules\rfinfo\dto\AccountStatements;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\forms\AccountStatementsQueryForm;

/**
 * Интерфейс форматера для выписок расчетного счета
 */
interface AccountStatementsFormatterInterface extends FormatterInterface
{
    /**
     * Указать данные юр. лица/ип/итд
     *
     * @param Info|ResponseResourceInterface $info
     */
    public function setInfo($info): void;

    /**
     * Указать параметры запроса
     *
     * @param AccountStatementsQueryForm $query
     */
    public function setQuery(AccountStatementsQueryForm $query): void;

    /**
     * Указать выгружаемые данные по выпискам расчетного счета
     *
     * @param AccountStatements|ResponseResourceInterface $accountStatements
     */
    public function setAccountStatements($accountStatements): void;

    /**
     * Получение форматированного представления выгрузки
     *
     * @return string
     */
    public function format(): string;

    /**
     * Получение mime-type выгрузки
     *
     * @return string
     */
    public function getMimeType(): string;
}