<?php

namespace common\modules\rfinfo\behaviors;

use common\modules\rfinfo\dto\AccountStatements;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\forms\AccountStatementsQueryForm;

trait AccountStatementsFormatterTrait
{
    use XlsxFormatterTrait;

    /**
     * @var AccountStatements
     */
    protected $accountStatements;
    /**
     * @var Info
     */
    protected $info;
    /**
     * @var AccountStatementsQueryForm
     */
    protected $query;

    public function setAccountStatements($accountStatements): void
    {
        $this->accountStatements = $accountStatements;
    }

    public function setInfo($info): void
    {
        $this->info = $info;
    }

    public function setQuery(AccountStatementsQueryForm $query): void
    {
        $this->query = $query;
    }

    protected function formatNumber($number): string
    {
        return number_format($number, 2, ',', ' ');
    }
}