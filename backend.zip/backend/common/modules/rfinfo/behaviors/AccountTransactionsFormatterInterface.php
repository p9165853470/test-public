<?php

namespace common\modules\rfinfo\behaviors;

use common\modules\rfinfo\dto\Account;
use common\modules\rfinfo\dto\AccountTransactions;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\forms\AccountStatementsQueryForm;

interface AccountTransactionsFormatterInterface extends FormatterInterface
{
    /**
     * @param Info|object $info
     */
    public function setInfo($info): void;

    /**
     * @param Account|object $account
     */
    public function setAccount($account): void;

    /**
     * @param AccountTransactions|object $accountTransactions
     */
    public function setAccountTransactions($accountTransactions): void;

    /**
     * @param AccountStatementsQueryForm $query
     */
    public function setQuery(AccountStatementsQueryForm $query): void;
}