<?php

namespace common\modules\rfinfo\behaviors;

use common\modules\rfinfo\dto\Account;
use common\modules\rfinfo\dto\AccountTransactions;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\forms\AccountStatementsQueryForm;

trait AccountTransactionsFormatterTrait
{
    use XlsxFormatterTrait;

    /**
     * @var Info
     */
    protected $info;
    /**
     * @var Account
     */
    protected $account;
    /**
     * @var AccountTransactions
     */
    protected $accountTransactions;
    /**
     * @var AccountStatementsQueryForm
     */
    protected $query;

    public function setInfo($info): void
    {
        $this->info = $info;
    }

    public function setAccount($account): void
    {
        $this->account = $account;
    }

    public function setAccountTransactions($accountTransactions): void
    {
        $this->accountTransactions = $accountTransactions;
    }

    public function setQuery(AccountStatementsQueryForm $query): void
    {
        $this->query = $query;
    }
}