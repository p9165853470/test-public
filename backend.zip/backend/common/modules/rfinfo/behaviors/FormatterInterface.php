<?php

namespace common\modules\rfinfo\behaviors;

interface FormatterInterface
{
    /**
     * @return string
     */
    public function format(): string;

    /**
     * @return string
     */
    public function getMimeType(): string;
}