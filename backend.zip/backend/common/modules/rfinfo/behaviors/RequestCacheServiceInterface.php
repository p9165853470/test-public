<?php

namespace common\modules\rfinfo\behaviors;

interface RequestCacheServiceInterface extends RequestServiceInterface
{

}