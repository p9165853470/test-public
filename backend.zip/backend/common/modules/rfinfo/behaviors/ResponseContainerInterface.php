<?php

namespace common\modules\rfinfo\behaviors;

use yii\db\ActiveQuery;

interface ResponseContainerInterface
{
    public function setItems(array $items);

    public function getItems(): array;

    public function getItemsQuery(): ActiveQuery;

    public function setItemsSerializer($callback): void;
}