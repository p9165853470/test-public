<?php

namespace common\modules\rfinfo\behaviors;

use common\modules\rfinfo\forms\FilterForm;

interface ResponseResourceInterface
{
    /**
     * @param FilterForm $filter
     * @return mixed
     */
    public function getData(FilterForm $filter);

    /**
     * @return mixed
     */
    public function getResource();
}