<?php

namespace common\modules\rfinfo\behaviors;

use common\modules\rfinfo\forms\FilterForm;
use common\modules\rfinfo\forms\QueryForm;

interface ResponseServiceInterface
{
    /**
     * @param QueryForm $query
     * @return bool
     */
    public function has(QueryForm $query): bool;

    /**
     * @param QueryForm $query
     * @param $data
     */
    public function set(QueryForm $query, $data): void;

    /**
     * @param QueryForm $query
     * @return ResponseResourceInterface
     */
    public function get(QueryForm $query): ResponseResourceInterface;
}