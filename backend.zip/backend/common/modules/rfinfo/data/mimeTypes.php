<?php

use common\enums\MimeTypeEnum;

return [
    'xlsx' => MimeTypeEnum::XLSX,
    'pdf' => MimeTypeEnum::PDF,
    'txt' => MimeTypeEnum::TXT,
];