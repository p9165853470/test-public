<?php

namespace common\modules\rfinfo\dto;

use yii\base\Arrayable;
use yii\base\ArrayableTrait;
use yii\base\BaseObject;

abstract class AbstractDto extends BaseObject implements Arrayable
{
    use ArrayableTrait;
}