<?php

namespace common\modules\rfinfo\dto;

class Account extends AbstractDto
{
    public $diasoft_id;
    public $account;
    public $rest;
    public $rko_debt;
    public $arrest;
    public $open_date;
    public $close_date;
}