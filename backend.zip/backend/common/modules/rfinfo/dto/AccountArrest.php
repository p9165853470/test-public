<?php

namespace common\modules\rfinfo\dto;

class AccountArrest extends AbstractDto
{
    public $diasoft_id;
    public $account;
    public $arrest_type;
    public $arrest_date;
    public $arrest_qty;
    public $arrest_organization;
}