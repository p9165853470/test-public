<?php

namespace common\modules\rfinfo\dto;

class AccountStatement extends AbstractDto
{
    public $diasoft_id;
    public $account;
    public $date_start;
    public $date_end;
    public $doc_date;
    public $doc_number;
    public $vo;
    public $bic_contractor;
    public $account_contractor;
    public $qty_cred;
    public $qty_debt;
    public $contractor;
    public $inn_contractor;
    public $comment;
}