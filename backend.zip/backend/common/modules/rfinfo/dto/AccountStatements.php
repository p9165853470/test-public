<?php

namespace common\modules\rfinfo\dto;

class AccountStatements extends AbstractDto
{
    /**
     * @var AccountStatement[]
     */
    public $statements = [];
    public $rest_in;
    public $turn_cred;
    public $turn_debt;
    public $doc_quantity;
    public $rest_out;
}