<?php

namespace common\modules\rfinfo\dto;

class AccountTransaction extends AbstractDto
{
    public $diasoft_id;
    public $doc_date;
    public $doc_number;
    public $qty_cred;
    public $qty_debt;
    public $comment;
}