<?php


namespace common\modules\rfinfo\dto;


class CheckCode  extends AbstractDto
{
    public $check_factor_result;
    public $check_factor_msg;
}