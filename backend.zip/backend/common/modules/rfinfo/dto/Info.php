<?php

namespace common\modules\rfinfo\dto;

class Info extends AbstractDto
{
    public $diasoft_id;
    public $name;
    public $inn;
    public $kpp;
}