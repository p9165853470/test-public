<?php

namespace common\modules\rfinfo\dto;

class Rate extends AbstractDto
{
    public $date_rate;
    public $value;
}