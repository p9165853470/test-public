<?php


namespace common\modules\rfinfo\dto;


class SendSms  extends AbstractDto
{
    public $masked_phone_number;
    public $factor_url;
}