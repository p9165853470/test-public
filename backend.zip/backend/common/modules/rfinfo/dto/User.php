<?php

namespace common\modules\rfinfo\dto;

class User extends AbstractDto
{
    public $user_name;
    public $authority_begin_date;
    public $authority_end_date;
    public $phone_number;
    public $key_word;
    public $diasoft_id;
    public $name;
    public $inn;
    public $kpp;
}