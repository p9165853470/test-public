<?php

namespace common\modules\rfinfo\enums;

use common\behaviors\EnumTrait;

class AccountArrestEnum
{
    use EnumTrait;

    public const DOESNT_HAS_ARRESTS = 0;
    public const HAS_ARRESTS = 1;
}