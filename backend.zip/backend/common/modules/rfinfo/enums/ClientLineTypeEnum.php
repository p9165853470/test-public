<?php

namespace common\modules\rfinfo\enums;

use common\behaviors\EnumTrait;

class ClientLineTypeEnum
{
    use EnumTrait;

    public const KL = 'KL';
    public const FL1 = 'FL1';
    public const FL2 = 'FL2';
    public const ALL = 'ALL';
}