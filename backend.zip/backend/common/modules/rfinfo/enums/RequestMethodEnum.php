<?php

namespace common\modules\rfinfo\enums;

use common\behaviors\EnumTrait;
use yii\helpers\Inflector;

class RequestMethodEnum
{
    use EnumTrait;

    public const INFO = 'info';
    public const CLIENT_LINES = 'client-lines';
    public const CLIENT_LINE = 'client-line';
    public const TRANCHES = 'tranches';
    public const ACCOUNTS = 'accounts';
    public const ACCOUNT_STATEMENTS = 'account-statements';
    public const ACCOUNT_ARRESTS = 'account-arrests';
    public const ACCOUNT_TRANSACTIONS = 'account-transactions';
    public const RATE = 'rate';
    public const USER = 'user';
    public const SEND_SMS = 'send-sms';
    public const CHECK_CODE = 'check-code';
    public const CONTACT = 'contact';

    public static function getName(string $name): string
    {
        switch ($name) {
            case ($name == self::SEND_SMS || $name == self::CHECK_CODE || $name == self::CONTACT):
                return 'post' . ucfirst(Inflector::id2camel($name));
            default:
                return 'get' . ucfirst(Inflector::id2camel($name));
        }
    }
}