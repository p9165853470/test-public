<?php

namespace common\modules\rfinfo\enums;

use common\behaviors\EnumTrait;

class SmsTypeEnum
{
    use EnumTrait;

    public const IBD_CONFIRM_TRANCHE = 'IBD_CONFIRM_TRANCHE';
    public const IBD_CONFIRM_FINANCE = 'IBD_CONFIRM_FINANCE';
    public const IBD_CONFIRM_CHANGE = 'IBD_CONFIRM_CHANGE';
    public const LOGIN = 'LOGIN';

}