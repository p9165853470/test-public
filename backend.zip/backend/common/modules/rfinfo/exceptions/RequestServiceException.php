<?php

namespace common\modules\rfinfo\exceptions;

use yii\base\Exception;

class RequestServiceException extends Exception
{

}