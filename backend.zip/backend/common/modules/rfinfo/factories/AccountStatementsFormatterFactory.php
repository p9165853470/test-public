<?php

namespace common\modules\rfinfo\factories;

use common\enums\MimeTypeEnum;
use common\modules\rfinfo\behaviors\AccountStatementsFormatterInterface;
use common\modules\rfinfo\services\AccountStatementsTxtFormatter;
use common\modules\rfinfo\services\AccountStatementsXlsxFormatter;
use yii\base\InvalidArgumentException;
use yii\base\InvalidConfigException;
use yii\di\Instance;
use yii\web\Request;

class AccountStatementsFormatterFactory
{
    /**
     * @param Request $request
     * @return AccountStatementsFormatterInterface|object
     * @throws InvalidConfigException
     */
    public function getFormatterFromRequest(Request $request): AccountStatementsFormatterInterface
    {
        switch ($request->headers->get('Accept')) {
            case MimeTypeEnum::XLSX:
                $formatterClass = AccountStatementsXlsxFormatter::class;
                break;
            case MimeTypeEnum::TXT:
                $formatterClass = AccountStatementsTxtFormatter::class;
                break;
            case MimeTypeEnum::PDF:
                throw new InvalidArgumentException('TODO: Add PDF Formatter.');
            default:
                throw new InvalidArgumentException('Cannot detect formatter from request.');
        }

        return Instance::ensure($formatterClass);
    }
}