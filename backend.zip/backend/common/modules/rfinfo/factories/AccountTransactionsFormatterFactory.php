<?php

namespace common\modules\rfinfo\factories;

use common\enums\MimeTypeEnum;
use common\modules\rfinfo\behaviors\AccountTransactionsFormatterInterface;
use common\modules\rfinfo\services\AccountTransactionsXlsxFormatter;
use yii\base\InvalidArgumentException;
use yii\di\Instance;
use yii\web\Request;

class AccountTransactionsFormatterFactory
{
    /**
     * @param Request $request
     * @return AccountTransactionsFormatterInterface|object
     * @throws \yii\base\InvalidConfigException
     */
    public function getFormatterFromRequest(Request $request): AccountTransactionsFormatterInterface
    {
        switch ($request->headers->get('Accept')) {
            case MimeTypeEnum::XLSX:
                $factoryClass = AccountTransactionsXlsxFormatter::class;
                break;
            case MimeTypeEnum::PDF:
                throw new InvalidArgumentException('TODO: Add PDF Formatter.');
            default:
                throw new InvalidArgumentException('Cannot detect formatter from request.');
        }

        return Instance::ensure($factoryClass);
    }
}