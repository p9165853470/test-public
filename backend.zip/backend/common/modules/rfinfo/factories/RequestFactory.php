<?php

namespace common\modules\rfinfo\factories;

use common\modules\rfinfo\behaviors\ResponseServiceInterface;
use common\modules\rfinfo\behaviors\RequestServiceInterface;
use common\modules\rfinfo\components\RequestContext;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\forms\AccountArrestsQueryForm;
use common\modules\rfinfo\forms\AccountsQueryForm;
use common\modules\rfinfo\forms\AccountStatementsQueryForm;
use common\modules\rfinfo\forms\CheckCodeQueryForm;
use common\modules\rfinfo\forms\ClientLineQueryForm;
use common\modules\rfinfo\forms\ClientLinesQueryForm;
use common\modules\rfinfo\forms\FilterForm;
use common\modules\rfinfo\forms\InfoQueryForm;
use common\modules\rfinfo\forms\ContactQueryForm;
use common\modules\rfinfo\forms\QueryForm;
use common\modules\rfinfo\forms\RateQueryForm;
use common\modules\rfinfo\forms\SendSmsQueryForm;
use common\modules\rfinfo\forms\TranchesFilterForm;
use common\modules\rfinfo\forms\TranchesQueryForm;
use common\modules\rfinfo\forms\UserQueryForm;
use yii\base\InvalidArgumentException;
use yii\base\UnknownMethodException;
use yii\di\Instance;
use yii\helpers\Inflector;

class RequestFactory
{
    public function getService(): RequestServiceInterface
    {
        /** @var RequestServiceInterface $service */
        $service = Instance::ensure(RequestServiceInterface::class);

        return $service;
    }

    public function getQuery(RequestContext $context): QueryForm
    {
        switch ($context->getMethod()) {
            case RequestMethodEnum::INFO:
                return new InfoQueryForm($context);
            case RequestMethodEnum::CLIENT_LINES:
                return new ClientLinesQueryForm($context);
            case RequestMethodEnum::CLIENT_LINE:
                return new ClientLineQueryForm($context);
            case RequestMethodEnum::TRANCHES:
                return new TranchesQueryForm($context);
            case RequestMethodEnum::ACCOUNTS:
                return new AccountsQueryForm($context);
            case RequestMethodEnum::ACCOUNT_STATEMENTS:
            case RequestMethodEnum::ACCOUNT_TRANSACTIONS:
                return new AccountStatementsQueryForm($context);
            case RequestMethodEnum::ACCOUNT_ARRESTS:
                return new AccountArrestsQueryForm($context);
            case RequestMethodEnum::RATE:
                return new RateQueryForm($context);
            case RequestMethodEnum::USER:
                return new UserQueryForm($context);
            case RequestMethodEnum::SEND_SMS:
                return new SendSmsQueryForm($context);
            case RequestMethodEnum::CHECK_CODE:
                return new CheckCodeQueryForm($context);
            case RequestMethodEnum::CONTACT:
                return new ContactQueryForm($context);
        }
        return new QueryForm($context);
    }

    public function getFilter(RequestContext $context): FilterForm
    {
        switch ($context->getMethod()) {
            case RequestMethodEnum::TRANCHES:
                return new TranchesFilterForm($context);
        }

        return new FilterForm($context);
    }

    public function getContext(string $method, array $data = []): RequestContext
    {
        if (!in_array($method, RequestMethodEnum::getRange(), true)) {
            throw new InvalidArgumentException("Invalid method name: {$method}");
        }

        $context = new RequestContext($method);

        $query = $this->getQuery($context);
        $query->load($data);
        $query->validate();

        $filter = $this->getFilter($context);
        $filter->load($data);
        $filter->validate();

        $context->setQuery($query);
        $context->setFilter($filter);

        return $context;
    }
}