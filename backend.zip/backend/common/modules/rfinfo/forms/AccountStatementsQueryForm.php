<?php

namespace common\modules\rfinfo\forms;

use common\helpers\Date;

class AccountStatementsQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $diasoft_id;
    /**
     * @var string
     */
    public $account;
    /**
     * @var string
     */
    public $start_date;
    /**
     * @var string
     */
    public $end_date;

    public function rules(): array
    {
        return [
            [['diasoft_id', 'account', 'start_date', 'end_date'], 'required'],
            [['start_date', 'end_date'], 'date', 'format' => 'php:' . Date::INTERNAL_DATE_FORMAT],
        ];
    }
}