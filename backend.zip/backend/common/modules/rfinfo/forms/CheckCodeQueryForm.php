<?php
namespace common\modules\rfinfo\forms;

use common\modules\rfinfo\enums\SmsTypeEnum;

class CheckCodeQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $diasoft_id;
    /**
     * @var string
     */
    public $factor_url;
    /**
     * @var string
     */
    public $confirm_code;
    /**
     * @var string
     */
    public $type_confirm_code;

    public function rules(): array
    {
        return [
            [['diasoft_id', 'factor_url', 'confirm_code'], 'required'],
            ['diasoft_id', 'string', 'max' => 16],
            //['factor_url', 'url'],
            ['type_confirm_code',  'in', 'range' => SmsTypeEnum::getRange()]
        ];
    }
}
