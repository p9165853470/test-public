<?php

namespace common\modules\rfinfo\forms;

use common\modules\rfinfo\enums\ClientLineTypeEnum;

class ClientLineQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $diasoft_id;
    /**
     * @var string
     */
    public $number_line;
    /**
     * @var string
     */
    public $type_line;

    public function rules(): array
    {
        return [
            [['diasoft_id', 'number_line', 'type_line'], 'required'],
            ['type_line', 'in', 'range' => ClientLineTypeEnum::getRange()],
        ];
    }
}