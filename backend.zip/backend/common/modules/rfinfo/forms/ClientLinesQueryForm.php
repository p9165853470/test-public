<?php

namespace common\modules\rfinfo\forms;

use common\modules\rfinfo\enums\ClientLineStatusEnum;

class ClientLinesQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $diasoft_id;
    /**
     * @var int
     */
    public $line_status;

    public function rules(): array
    {
        return [
            [['diasoft_id', 'line_status'], 'required'],
            ['line_status', 'in', 'range' => ClientLineStatusEnum::getRange()],
        ];
    }
}