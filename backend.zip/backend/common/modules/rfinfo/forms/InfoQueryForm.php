<?php

namespace common\modules\rfinfo\forms;

class InfoQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $diasoft_id;

    public function rules(): array
    {
        return [
            ['diasoft_id', 'required'],
        ];
    }
}