<?php
namespace common\modules\rfinfo\forms;

use common\modules\rfinfo\enums\SmsTypeEnum;

class SendSmsQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $diasoft_id;
    /**
     * @var string
     */
    public $phone_number;
    /**
     * @var string
     */
    public $type_confirm_code;

    public function rules(): array
    {
        return [
            [['diasoft_id','phone_number','type_confirm_code'], 'required'],
            ['type_confirm_code',  'in', 'range' => SmsTypeEnum::getRange()]
        ];
    }
}
