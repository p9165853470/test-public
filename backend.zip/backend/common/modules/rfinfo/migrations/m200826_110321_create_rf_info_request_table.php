<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_request}}`.
 */
class m200826_110321_create_rf_info_request_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_request}}', [
            'id' => $this->primaryKey(),
            'form_id' => $this->string(16)->notNull(),
            'form_hash' => $this->string(32)->notNull(),
            'method' => $this->string(32)->notNull(),
            'multiple' => $this->boolean()->notNull()->defaultValue(false),
            'created_at' => $this->timestamp()->notNull(),
        ]);

        $this->createIndexNamed('{{%rf_info_request}}', ['form_id', 'form_hash'], true);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_request}}');
    }
}
