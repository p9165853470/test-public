<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_account_arrests}}`.
 */
class m200828_104257_create_rf_info_account_arrests_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_account_arrests}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'krt_count' => $this->integer(),
            'krt_qty' => $this->float(2),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_account_arrests}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');

        $this->createTable('{{%rf_info_account_arrest}}', [
            'id' => $this->primaryKey(),
            'container_id' => $this->integer()->notNull(),
            'diasoft_id' => $this->string(20),
            'account' => $this->string(255),
            'arrest_type' => $this->string(255),
            'arrest_date' => $this->date(),
            'arrest_qty' => $this->integer(),
            'arrest_organization' => $this->string(255),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_account_arrest}}', 'container_id', '{{%rf_info_account_arrests}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_account_arrest}}');

        $this->dropTable('{{%rf_info_account_arrests}}');
    }
}
