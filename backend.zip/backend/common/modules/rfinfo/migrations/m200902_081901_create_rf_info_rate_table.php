<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_rate}}`.
 */
class m200902_081901_create_rf_info_rate_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_rate}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'date_rate' => $this->date(),
            'value' => $this->float(2),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_rate}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_rate}}');
    }
}
