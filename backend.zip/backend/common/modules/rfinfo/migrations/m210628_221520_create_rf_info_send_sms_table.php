<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_send_sms}}`.
 */
class m210628_221520_create_rf_info_send_sms_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_send_sms}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'masked_phone_number' => $this->string(30),
            'factor_url' => $this->string(255),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_send_sms}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_send_sms}}');
    }
}
