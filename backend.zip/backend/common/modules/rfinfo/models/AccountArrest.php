<?php


namespace common\modules\rfinfo\models;

use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $container_id
 * @property string $diasoft_id;
 * @property string $account;
 * @property string $arrest_type;
 * @property string $arrest_date;
 * @property int $arrest_qty;
 * @property string $arrest_organization;
 *
 * @property-read AccountArrests $container
 */
class AccountArrest extends ActiveRecord
{
    public static function tableName(): string
    {
        return '{{%rf_info_account_arrest}}';
    }

    public function fields(): array
    {
        return $this->dtoAttributes();
    }

    public function rules(): array
    {
        return [
            [$this->dtoAttributes(), 'safe'],
        ];
    }

    public function dtoAttributes(): array
    {
        return array_diff($this->attributes(), ['id', 'container_id']);
    }

    public function getContainer(): ActiveQuery
    {
        return $this->hasOne(AccountArrests::class, ['id' => 'container_id']);
    }
}