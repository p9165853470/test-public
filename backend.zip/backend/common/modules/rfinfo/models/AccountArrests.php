<?php

namespace common\modules\rfinfo\models;

use common\modules\rfinfo\behaviors\ResponseContainerInterface;
use common\modules\rfinfo\behaviors\ResponseContainerTrait;
use common\modules\rfinfo\dto\AbstractDto;
use common\repositories\AnonymousRepository;
use yii\db\ActiveQuery;

/**
 * @property int $krt_count;
 * @property float $krt_qty;
 *
 * @property AccountArrest[] $arrests
 */
class AccountArrests extends AbstractResponse implements ResponseContainerInterface
{
    use ResponseContainerTrait;

    public static function tableName(): string
    {
        return '{{%rf_info_account_arrests}}';
    }

    public function getArrests(): ActiveQuery
    {
        return $this->hasMany(AccountArrest::class, ['container_id' => 'id']);
    }

    public function setArrests($value): void
    {
        $this->attachItems($value);
    }

    public function dtoAttributes(): array
    {
        return array_merge(parent::dtoAttributes(), ['arrests']);
    }

    public function getItemsAttribute(): string
    {
        return 'arrests';
    }
}