<?php

namespace common\modules\rfinfo\models;

use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $container_id
 * @property string $diasoft_id
 * @property string $account
 * @property string $date_start
 * @property string $date_end
 * @property string $doc_date
 * @property string $doc_number
 * @property string $vo
 * @property string $bic_contractor
 * @property string $account_contractor
 * @property string $contractor
 * @property float $qty_cred
 * @property float $qty_debt
 * @property string $inn_contractor
 * @property string $comment
 *
 * @property-read AccountStatements $container
 */
class AccountStatement extends ActiveRecord
{
    public static function tableName(): string
    {
        return '{{%rf_info_account_statement}}';
    }

    public function fields(): array
    {
        return $this->dtoAttributes();
    }

    public function rules(): array
    {
        return [
            [$this->dtoAttributes(), 'safe'],
        ];
    }

    public function dtoAttributes(): array
    {
        return array_diff($this->attributes(), ['id', 'container_id']);
    }

    public function getContainer(): ActiveQuery
    {
        return $this->hasOne(AccountStatements::class, ['id' => 'container_id']);
    }
}