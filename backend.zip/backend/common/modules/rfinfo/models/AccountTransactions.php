<?php

namespace common\modules\rfinfo\models;

use common\modules\rfinfo\behaviors\ResponseContainerInterface;
use common\modules\rfinfo\behaviors\ResponseContainerTrait;
use yii\db\ActiveQuery;

/**
 * @property float $rest_in
 * @property float $turn_cred
 * @property float $turn_debt
 * @property float $rest_out
 *
 * @property AccountTransaction[] $transactions
 */
class AccountTransactions extends AbstractResponse implements ResponseContainerInterface
{
    use ResponseContainerTrait;

    public static function tableName(): string
    {
        return '{{%rf_info_account_statements}}';
    }

    public function dtoAttributes(): array
    {
        return ['rest_in', 'rest_out', 'turn_cred', 'turn_debt', 'transactions'];
    }

    public function getTransactions(): ActiveQuery
    {
        return $this->hasMany(AccountTransaction::class, ['container_id' => 'id']);
    }

    public function setTransactions(array $items): void
    {
        $this->attachItems($items);
    }

    protected function getItemsAttribute(): string
    {
        return 'transactions';
    }
}