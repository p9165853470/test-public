<?php

namespace common\modules\rfinfo\models;


/**
 * @property string $check_factor_result
 * @property string $check_factor_msg
 *
 */

class CheckCode extends AbstractResponse
{
    public static function tableName(): string
{
    return '{{%rf_info_check_code}}';
}
}