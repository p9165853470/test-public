<?php

namespace common\modules\rfinfo\models;

/**
 * @property string $number
 * @property string $type
 * @property int $status
 * @property string $name_brand
 * @property string $name_product
 * @property string $start_date
 * @property string $real_finish_date
 * @property string $finish_date
 * @property float $limit_amount
 * @property float $total_main_debt
 * @property float $rest_limit
 * @property string $date_near_line_pay
 * @property int $flag_near_line_pay
 * @property string $percent_rate
 * @property string $date_percent_rate
 * @property string $comiss_type
 * @property float $summ_comiss_debt
 * @property int $line_block
 * @property int $overdue_debt
 */
class ClientLine extends AbstractResponse
{
    public static function tableName(): string
    {
        return '{{%rf_info_client_line}}';
    }
}