<?php

namespace common\modules\rfinfo\models;

/**
 * @property string $diasoft_id
 * @property string $name
 * @property string $inn
 * @property string $kpp
 */
class Info extends AbstractResponse
{
    public static function tableName(): string
    {
        return '{{%rf_info_info}}';
    }
}