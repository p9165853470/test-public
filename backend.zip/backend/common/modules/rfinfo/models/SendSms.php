<?php

namespace common\modules\rfinfo\models;


/**
 * @property string $masked_phone_number
 *
 */
class SendSms extends AbstractResponse
{
    public static function tableName(): string
{
    return '{{%rf_info_send_sms}}';
}
}