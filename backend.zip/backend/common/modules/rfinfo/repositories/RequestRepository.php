<?php

namespace common\modules\rfinfo\repositories;

use common\exceptions\NotFoundModelException;
use common\helpers\Date;
use common\modules\rfinfo\forms\QueryForm;
use common\modules\rfinfo\models\Request;
use common\repositories\Repository;

/**
 * @method Request model()
 * @method Request findOne($condition = null)
 * @method Request[] findAll($condition = null)
 */
class RequestRepository extends Repository
{
    public function getModelClass(): string
    {
        return Request::class;
    }

    public function findOneByQuery(QueryForm $query): Request
    {
        $date = date_create()
            ->sub(new \DateInterval(Request::EXPIRE_INTERVAL))
            ->format(Date::INTERNAL_DATETIME_FORMAT);

        /** @var Request $model */
        $model = $this->find()
            ->andWhere([
                'or',
                ['form_id' => $query->id],
                ['form_hash' => $query->getHash()],
            ])
            ->andWhere(['>=', 'created_at', $date])
            ->orderBy(['created_at' => SORT_DESC])
            ->one();

        if ($model === null) {
            throw new NotFoundModelException('Model not found.');
        }

        return $model;
    }

    public function create(QueryForm $query, bool $isMultiple): Request
    {
        $model = $this->model();
        $model->form_id = $query->generateId();
        $model->form_hash = $query->getHash();
        $model->method = $query->getContext()->getMethod();
        $model->multiple = $isMultiple;

        $this->save($model);

        return $model;
    }

    public function deleteAll(): int
    {
        return Request::deleteAll();
    }

    public function deleteAllExpired(): int
    {
        $date = date_create()
            ->sub(new \DateInterval(Request::EXPIRE_INTERVAL))
            ->format(Date::INTERNAL_DATETIME_FORMAT);

        return Request::deleteAll(['<', 'created_at', $date]);
    }
}