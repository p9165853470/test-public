<?php

namespace common\modules\rfinfo\resources;

use common\components\Serializer;
use common\modules\rfinfo\behaviors\ResponseContainerInterface;
use common\modules\rfinfo\behaviors\ResponseResourceInterface;
use common\modules\rfinfo\forms\FilterForm;
use common\modules\rfinfo\models\AbstractResponse;
use yii\data\ActiveDataProvider;
use yii\data\DataProviderInterface;
use yii\db\ActiveQuery;

class ResponseDataProviderResource implements ResponseResourceInterface
{
    /**
     * @var ActiveQuery
     */
    protected $resource;
    /**
     * @var Serializer
     */
    protected $serializer;

    public function __construct(ActiveQuery $resource, Serializer $serializer)
    {
        $this->resource = $resource;
        $this->serializer = $serializer;
    }

    public function getResource(): ActiveQuery
    {
        return $this->resource;
    }

    /**
     * @param FilterForm $filter
     * @return DataProviderInterface|AbstractResponse|null
     */
    public function getData(FilterForm $filter)
    {
        $query = clone $this->resource;

        if ($query->multiple) {
            $filter->getContext()->setParam('query', clone $query);
            $filter->apply($query);

            return $this->getDataProvider($query);
        }

        /** @var AbstractResponse|null $response */
        $response = $query->one();

        if ($response === null) {
            return null;
        }

        if ($response instanceof ResponseContainerInterface) {
            $filter->getContext()->setParam('query', $response->getItemsQuery());

            $response->setItemsSerializer(function (ActiveQuery $query) use ($filter) {
                $filter->apply($query);

                return $this->serializer->serialize($this->getDataProvider($query));
            });
        }

        return $response;
    }

    protected function getDataProvider(ActiveQuery $query): DataProviderInterface
    {
        $dataProvider = new ActiveDataProvider(['query' => $query]);
        $pagination = $dataProvider->getPagination();

        $perPage = (int)\Yii::$app->request->get($pagination->pageSizeParam);

        if ($perPage === -1) {
            $dataProvider->setPagination(false);
        }

        return $dataProvider;
    }
}