<?php


namespace common\modules\rfinfo\resources;


use common\modules\rfinfo\behaviors\ResponseResourceInterface;
use common\modules\rfinfo\behaviors\ResponseContainerInterface;
use common\modules\rfinfo\forms\FilterForm;
use common\modules\rfinfo\models\AbstractResponse;
use yii\db\ActiveQuery;

class ResponseResource implements ResponseResourceInterface
{
    /**
     * @var ActiveQuery
     */
    protected $resource;

    public function __construct(ActiveQuery $resource)
    {
        $this->resource = $resource;
    }

    public function getResource(): ActiveQuery
    {
        return $this->resource;
    }

    public function getData(FilterForm $filter)
    {
        $query = clone $this->resource;

        if ($query->multiple) {
            $filter->getContext()->setParam('query', clone $query);
            $filter->apply($query);

            return $query->all();
        }

        $response = $query->one();

        if ($response instanceof ResponseContainerInterface) {
            $itemQuery = $response->getItemsQuery();

            $filter->getContext()->setParam('query', clone $itemQuery);
            $filter->apply($itemQuery);

            $response->setItems($itemQuery->all());
        }

        return $response;
    }
}