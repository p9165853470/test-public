<?php

namespace common\modules\rfinfo\services;

use common\enums\MimeTypeEnum;
use common\modules\rfinfo\behaviors\AccountStatementsFormatterInterface;
use common\modules\rfinfo\behaviors\AccountStatementsFormatterTrait;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx as XlsxReader;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx as XlsxWriter;

class AccountStatementsXlsxFormatter implements AccountStatementsFormatterInterface
{
    use AccountStatementsFormatterTrait;

    private const DATE_FORMAT = 'd.m.Y';

    /**
     * @var string
     */
    private $templatePath = '@common/modules/rfinfo/templates/account-statements.xlsx';

    public function __construct()
    {
        $this->templatePath = \Yii::getAlias($this->templatePath);
    }

    public function format(): string
    {
        $reader = new XlsxReader();

        $spreadsheet = $reader->load($this->templatePath);
        $worksheet = $spreadsheet->getActiveSheet();

        $this->modifyWorksheet($worksheet);

        $writer = new XlsxWriter($spreadsheet);
        $output = fopen('php://temp', 'rb+');
        $writer->save($output);

        rewind($output);

        return stream_get_contents($output);
    }

    public function getMimeType(): string
    {
        return MimeTypeEnum::XLSX;
    }

    private function modifyWorksheet(Worksheet $worksheet): void
    {
        $worksheet->setCellValue('A4', sprintf(
            '%s-%s',
            date_create($this->query->start_date)->format(self::DATE_FORMAT),
            date_create($this->query->end_date)->format(self::DATE_FORMAT)
        ));

        $worksheet->setCellValue('A6', $this->info->name);

        $worksheet->setCellValue('A7', 'Лицевой счет:');
        $this->setCellValueAsText($worksheet, 'B7', $this->query->account);

        $worksheet->setCellValue('A16', 'Входящее сальдо:');
        $this->setCellValueAsNumeric($worksheet, 'B16', $this->accountStatements->rest_in);

        $worksheet->setCellValue('A17', 'Оборот по дебету:');
        $this->setCellValueAsNumeric($worksheet, 'B17', $this->accountStatements->turn_debt);

        $worksheet->setCellValue('A18', 'Оборот по кредиту:');
        $this->setCellValueAsNumeric($worksheet, 'B18', $this->accountStatements->turn_cred);

        $worksheet->setCellValue('A19', 'Количество документов:');
        $this->setCellValueAsNumber($worksheet, 'B19', $this->accountStatements->doc_quantity);

        $worksheet->setCellValue('A20', 'Исходящее сальдо:');
        $this->setCellValueAsNumeric($worksheet, 'B20', $this->accountStatements->rest_out);

        $row = 13;
        $credSum = 0;
        $debtSum = 0;

        foreach ($this->accountStatements->statements as $i => $statement) {
            $credSum += $statement->qty_cred;
            $debtSum += $statement->qty_debt;

            $worksheet->insertNewRowBefore($row);
            $this->setCellValueAsDate($worksheet, 'A' . $row, date_create($statement->doc_date));
            $this->setCellValueAsNumber($worksheet, 'B' . $row, $statement->doc_number);
            $this->setCellValueAsNumber($worksheet, 'C' . $row, $statement->vo);
            $this->setCellValueAsText($worksheet, 'D' . $row, $statement->bic_contractor);
            $this->setCellValueAsText($worksheet, 'E' . $row, $statement->account_contractor);
            $this->setCellValueAsNumeric($worksheet, 'F' . $row, $statement->qty_debt);
            $this->setCellValueAsNumeric($worksheet, 'G' . $row, $statement->qty_cred);
            $this->setCellValueAsText($worksheet, 'H' . $row, $statement->contractor);
            $this->setCellValueAsText($worksheet, 'I' . $row, $statement->inn_contractor);
            $this->setCellValueAsText($worksheet, 'J' . $row, $statement->comment);

            $row++;
        }

        $this->setCellValueAsNumeric($worksheet, 'F' . $row, $debtSum);
        $this->setCellValueAsNumeric($worksheet, 'G' . $row, $credSum);

        $worksheet->removeRow(11, 2);
    }
}