<?php

namespace common\modules\rfinfo\services;

use common\enums\MimeTypeEnum;
use common\helpers\Date;
use common\modules\rfinfo\behaviors\AccountTransactionsFormatterInterface;
use common\modules\rfinfo\behaviors\AccountTransactionsFormatterTrait;
use common\modules\rfinfo\enums\AccountArrestEnum;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx as XlsxReader;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx as XlsxWriter;

class AccountTransactionsXlsxFormatter implements AccountTransactionsFormatterInterface
{
    use AccountTransactionsFormatterTrait;

    private const DATE_FORMAT = 'd.m.Y';

    public function format(): string
    {
        $reader = new XlsxReader();

        $spreadsheet = $reader->load(\Yii::getAlias('@common/modules/rfinfo/templates/account-transactions.xlsx'));
        $worksheet = $spreadsheet->getActiveSheet();

        $this->modifyWorksheet($worksheet);

        $writer = new XlsxWriter($spreadsheet);
        $output = fopen('php://temp', 'rb+');
        $writer->save($output);

        rewind($output);

        return stream_get_contents($output);
    }

    public function getMimeType(): string
    {
        return MimeTypeEnum::XLSX;
    }

    protected function modifyWorksheet(Worksheet $worksheet): void
    {
        $worksheet->setCellValue('A1', $this->info->name);
        $this->setCellValueAsText($worksheet, 'B3', $this->account->account);
        $this->setCellValueAsDate($worksheet, 'B4', date_create($this->account->open_date));
        $worksheet->setCellValue('C3', $this->account->close_date !== null ? 'закрыт' : 'открыт');
        $this->setCellValueAsNumeric($worksheet, 'B7', $this->account->rest);
        $this->setCellValueAsNumeric($worksheet, 'B8', $this->account->rko_debt);
        $this->setCellValueAsNumeric($worksheet, 'B12', $this->accountTransactions->rest_in);
        $this->setCellValueAsNumeric($worksheet, 'B13', $this->accountTransactions->rest_out);
        $worksheet->setCellValue('D8', $this->account->arrest === AccountArrestEnum::HAS_ARRESTS ? 'да' : 'нет');
        $this->setCellValueAsNumeric($worksheet, 'E12', $this->accountTransactions->turn_cred);
        $this->setCellValueAsNumeric($worksheet, 'E13', $this->accountTransactions->turn_debt);

        if ($this->account->close_date !== null) {
            $worksheet->setCellValue('A5', 'Дата закрытия');
            $this->setCellValueAsDate($worksheet, 'B5', date_create($this->account->close_date));
        }

        $worksheet->setCellValue('C11', sprintf(
            '%s-%s',
            date_create($this->query->start_date)->format(self::DATE_FORMAT),
            date_create($this->query->end_date)->format(self::DATE_FORMAT)
        ));

        $row = 17;

        foreach ($this->accountTransactions->transactions as $transaction) {
            $worksheet->insertNewRowBefore($row);
            $this->setCellValueAsDate($worksheet, 'A' . $row, date_create($transaction->doc_date));
            $this->setCellValueAsNumber($worksheet, 'B' . $row, $transaction->doc_number);
            $this->setCellValueAsText($worksheet, 'C' . $row, $transaction->comment);
            $this->setCellValueAsNumeric($worksheet, 'D' . $row, $transaction->qty_cred);
            $this->setCellValueAsNumeric($worksheet, 'E' . $row, $transaction->qty_debt);

            $row++;
        }

        $worksheet->removeRow(16);
    }
}