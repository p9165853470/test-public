<?php

namespace common\modules\rfinfo\services;

use common\modules\rfinfo\behaviors\RequestServiceInterface;
use common\modules\rfinfo\components\RequestContext;
use common\modules\rfinfo\dto\AbstractDto;
use common\modules\rfinfo\dto\Account;
use common\modules\rfinfo\dto\AccountArrest;
use common\modules\rfinfo\dto\AccountArrests;
use common\modules\rfinfo\dto\AccountStatement;
use common\modules\rfinfo\dto\AccountStatements;
use common\modules\rfinfo\dto\AccountTransaction;
use common\modules\rfinfo\dto\AccountTransactions;
use common\modules\rfinfo\dto\CheckCode;
use common\modules\rfinfo\dto\ClientLine;
use common\modules\rfinfo\dto\ClientLineShort;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\dto\User;
use common\modules\rfinfo\dto\Rate;
use common\modules\rfinfo\dto\Tranche;
use common\modules\rfinfo\dto\SendSms;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\forms\AccountArrestsQueryForm;
use common\modules\rfinfo\forms\AccountsQueryForm;
use common\modules\rfinfo\forms\AccountStatementsQueryForm;
use common\modules\rfinfo\forms\ClientLineQueryForm;
use common\modules\rfinfo\forms\ClientLinesQueryForm;
use common\modules\rfinfo\forms\InfoQueryForm;
use common\modules\rfinfo\forms\SendSmsQueryForm;
use common\modules\rfinfo\forms\UserQueryForm;
use common\modules\rfinfo\forms\RateQueryForm;
use common\modules\rfinfo\forms\TranchesQueryForm;
use common\modules\rfinfo\forms\CheckCodeQueryForm;
use common\modules\rfinfo\forms\ContactQueryForm;
use Yii;
use yii\helpers\Inflector;
use yii\httpclient\Client;
use yii\httpclient\Exception as HttpClientException;
use yii\httpclient\Request;
use yii\httpclient\Response;

class RFInfoRequestService implements RequestServiceInterface
{
    /**
     * @var Client
     */
    protected $client;

    public function __construct()
    {
        $this->client = $this->createClient('/infobank-for-dealers/api/v1');
    }

    protected function createClient(string $baseUrl = ''): Client
    {
        return new Client([
            'baseUrl' => Yii::$app->params['rfinfo.api.host'] . $baseUrl,
            'requestConfig' => [
                'headers' => [
                    'Authorization' => base64_encode(implode(':', [
                        Yii::$app->params['rfinfo.api.username'],
                        Yii::$app->params['rfinfo.api.password'],
                    ])),
                ],
                'options' => [
                    'followLocation' => false,
                ],
            ],
            'responseConfig' => [
                'format' => Client::FORMAT_JSON,
            ]
        ]);
    }

    /**
     * Аналог метода getUser(Request), но более низкоуровневый, с параметром только diasoft_id 
     * @param string $diasoft_id
     * @return Info|AbstractDto
     */
    public function getInfo2(string $diasoft_id): Info
    {
        Yii::warning('getInfo2() BEGIN');
        $request = $this->createDiasoftRequest($diasoft_id, '');

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            $result = $this->createDto(Info::class, $response->getData());
            Yii::warning('getInfo2() BEGIN $result = '.$result);
            return $result;
        }

        Yii::warning('BEFORE throw $this->createError($response) $response = '.print_r($response, true));
        throw $this->createError($response);
    }

    /**
     * @param RequestContext $context
     * @return Info|AbstractDto
     */
    public function getInfo(RequestContext $context): Info
    {
        /** @var InfoQueryForm $query */
        $query = $context->getQuery();
        
        return $this->getInfo2($query->diasoft_id);
    }

    /**
     * @param RequestContext $context
     * @return User|AbstractDto
     */
    public function getUser(RequestContext $context): array
    {
        /** @var UserQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createRequest('/user', [
            'email' => $query->email,
        ]);

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            return $this->createDtoList(User::class, $response->getData() ?? []
                ,['FIO' => 'user_name'
                    , 'DatNachPol' => 'authority_begin_date'
                    , 'DatOkonPol'=>'authority_end_date'
                    , 'CodeWord' => 'key_word',
                    ]);
        }

        throw $this->createError($response);
    }

    public function getClientLines(RequestContext $context): array
    {
        /** @var ClientLinesQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createDiasoftRequest($query->diasoft_id, '/client-lines', [
            'statusLine' => $query->line_status,
        ]);

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            return $this->createDtoList(ClientLineShort::class, $response->getData() ?? []);
        }

        throw $this->createError($response);
    }

    /**
     * @param RequestContext $context
     * @return ClientLine|AbstractDto
     */
    public function getClientLine(RequestContext $context): ClientLine
    {
        /** @var ClientLineQueryForm $query */
        $query = $context->getQuery();
        $url = sprintf('/client-lines/numberLine=%s~typeLine=%s', $query->number_line, $query->type_line);
        $request = $this->createDiasoftRequest($query->diasoft_id, $url);

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            return $this->createDto(ClientLine::class, $response->getData());
        }

        throw $this->createError($response);
    }

    public function getTranches(RequestContext $context): array
    {
        Yii::warning('RFInfoRequestService.getTranches() BEGIN');
        /** @var TranchesQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createDiasoftRequest($query->diasoft_id, '/tranches', [
            'statusTranche' => $query->status_tranche,
            'numberLine' => $query->number_line,
            'typeLine' => $query->type_line,
            'startDate' => $query->start_date,
            'endDate' => $query->end_date,
        ]);

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            $result = $this->createDtoList(Tranche::class, $response->getData() ?? []);
            Yii::warning('RFInfoRequestService.getTranches() END');
            return $result;
        }

        throw $this->createError($response);
    }

    public function getAccounts(RequestContext $context): array
    {
        /** @var AccountsQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createDiasoftRequest($query->diasoft_id, '/accounts');

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            return $this->createDtoList(Account::class, $response->getData() ?? [], [
                'RKODebt' => 'rko_debt',
            ]);
        }
        
        throw $this->createError($response);
    }

    public function getAccountTransactions(RequestContext $context): AccountTransactions
    {
        $accountStatements = $this->getAccountStatements(
            $context->create(RequestMethodEnum::ACCOUNT_STATEMENTS)
        );

        $container = new AccountTransactions([
            'rest_in' => $accountStatements->rest_in,
            'rest_out' => $accountStatements->rest_out,
            'turn_cred' => $accountStatements->turn_cred,
            'turn_debt' => $accountStatements->turn_debt,
        ]);

        foreach ($accountStatements->statements as $statement) {
            $container->transactions[] = new AccountTransaction([
                'diasoft_id' => $statement->diasoft_id,
                'doc_date' => $statement->doc_date,
                'doc_number' => $statement->doc_number,
                'qty_cred' => $statement->qty_cred,
                'qty_debt' => $statement->qty_debt,
                'comment' => $statement->comment,
            ]);
        }

        return $container;
    }

    public function getAccountStatements(RequestContext $context): AccountStatements
    {
        /** @var AccountStatementsQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createDiasoftRequest($query->diasoft_id, "/accounts/{$query->account}/statement", [
            'startDate' => $query->start_date,
            'endDate' => $query->end_date,
        ]);

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            $data = $response->getData();
            /** @var AccountStatements $container */
            $container = $this->createDto(AccountStatements::class, $data['summary']);
            $container->statements = $this->createDtoList(AccountStatement::class, $data['statements'] ?? [], [
                'BIСContractor' => 'bic_contractor',
                'INNContractor' => 'inn_contractor',
            ]);

            return $container;
        }
        
        throw $this->createError($response);
    }

    public function getAccountArrests(RequestContext $context): AccountArrests
    {
        /** @var AccountArrestsQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createDiasoftRequest($query->diasoft_id, "/accounts/{$query->account}/arrests");

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            $data = $response->getData();
            /** @var AccountArrests $container */
            $container = $this->createDto(AccountArrests::class, $data['summary']);
            $container->arrests = $this->createDtoList(AccountArrest::class, $data['arrests'] ?? []);

            return $container;
        }

        throw $this->createError($response);
    }

    public function getRate(RequestContext $context): array
    {
        /** @var RateQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createRequest('/mos-prime-rates-history', [
            'startDate' => $query->start_date,
            'endDate' => $query->end_date,
        ]);

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            return $this->createDtoList(Rate::class, $response->getData() ?? [], [
                'Date_Rate' => 'date_rate',
            ]);
        }

        throw $this->createError($response);
    }

    public function postSendSms(RequestContext $context): SendSms
    {
        Yii::warning('RFInfoRequestService.postSendSms() BEGIN');
        /** @var SendSmsQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createPostRequest('/sms', json_encode([
            'diasoftID' => $query->diasoft_id,
            'phoneNumber' => $query->phone_number,
            'confirmTypeCode' => $query->type_confirm_code,
        ]),['Content-Type' => 'application/json']);
        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            Yii::warning('RFInfoRequestService.postSendSms() BEFORE throw $this->createClientError($ex->getMessage())');
            throw $this->createClientError($ex->getMessage());
        }
        if ($response->getIsOk()) {
            Yii::warning('RFInfoRequestService.postSendSms() BEFORE return $this->createDto(SendSms::class ...');
            return $this->createDto(SendSms::class,
                ['masked_phone_number' => substr_replace($query->phone_number,'*****',4,5)
                ,'factor_url' => $response->getHeaders()->get('location')]);
        }

        Yii::warning('RFInfoRequestService.postSendSms() BEFORE throw $this->createError($response)');
        throw $this->createError($response);
    }

    public function postCheckCode(RequestContext $context): CheckCode
    {
        /** @var CheckCodeQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createPostRequest($query->factor_url, json_encode([
            'diasoftID' => $query->diasoft_id,
            'confirmCode' => $query->confirm_code,
            'confirmTypeCode' => $query->type_confirm_code,
        ]),['Content-Type' => 'application/json']);
        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }
        if ($response->getIsOk()) {
            return $this->createDto(CheckCode::class, $response->getData());
        }

        throw $this->createError($response);
    }

    /**
     * Установить новый номер телефона пользователя
     * @param RequestContext $context
     */
    public function postContact(RequestContext $context): void
    {
        /** @var ContactQueryForm $query */
        $query = $context->getQuery();
        $request = $this->createPutRequest('/user/contact'.'?email='.urlencode($query->email)
            , json_encode([
            'type' => $query->type,
            'value' => $query->value,
        ]),['Content-Type' => 'application/json']);

        try {
            $response = $request->send();
        } catch (HttpClientException $ex) {
            throw $this->createClientError($ex->getMessage());
        }

        if ($response->getIsOk()) {
            return;
//            return $this->createDto(Info::class, $response->getData());
        }

        throw $this->createError($response);
    }


    protected function createPostRequest(string $url, $data = null, $headers = [], $options = []): Request
    {
        return $this->client->post($url, $data, $headers, $options);
    }

    protected function createPutRequest(string $url, $data = null, $headers = [], $options = []): Request
    {
        return $this->client->put($url, $data, $headers, $options);
    }

    protected function createRequest(string $url, $data = null, $headers = [], $options = []): Request
    {
        return $this->client->get($url, $data, $headers, $options);
    }

    protected function createDiasoftRequest(string $diasoftId, string $url, $data = null, $headers = [], $options = []): Request
    {
        $url = ltrim($url, '/');
        $url = $url === '' ? $diasoftId : $diasoftId . '/' . $url;

        return $this->createRequest("/dealers-diasoft/$url", $data, $headers, $options);
    }

    protected function createError(Response $response): RequestServiceException
    {
        Yii::warning('RFInfoRequestService.createError() BEGIN');
        $data = $response->getData();
        Yii::warning('RFInfoRequestService.createError() $data = '.print_r($data, true));
        $statusCode = $response->getStatusCode();

        if (is_array($data) && isset($data['text'])) {
            $message = $data['text'];
        } elseif (is_array($data) && isset($data['errorMessage'])) {
            $message = $data['errorMessage'];
        }
          else {
            $message = 'Ошибка запроса к сервису к RFInfo';
        }

        Yii::warning('RFInfoRequestService.createError() END');
        return new RequestServiceException("[$statusCode] {$message}");
    }

    protected function createClientError(string $message): RequestServiceException
    {
        return new RequestServiceException($message);
    }

    protected function createDto(string $dtoClass, array $data, array $mapper = []): AbstractDto
    {
        $keys = array_keys($data);
        $keysMap = array_combine($keys, $keys);
        $dtoKeysMap = array_map(static function (string $key) {
            return Inflector::camel2id($key, '_');
        }, $keysMap);
        $dtoKeysMap = array_merge($dtoKeysMap, $mapper);

        $config = [];

        foreach ($dtoKeysMap as $key => $dtoKey) {
            if (isset($data[$key])) {
                $config[$dtoKey] = $data[$key];
            }
        }

        $config['class'] = $dtoClass;

        /** @var AbstractDto $dto */
        $dto = Yii::createObject($config);

        return $dto;
    }

    protected function createDtoList(string $dtoClass, array $items, array $mapper = []): array
    {
        $models = [];

        foreach ($items as $item) {
            $models[] = $this->createDto($dtoClass, $item, $mapper);
        }

        return $models;
    }
}