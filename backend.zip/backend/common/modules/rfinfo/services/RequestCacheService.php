<?php

namespace common\modules\rfinfo\services;

use common\modules\rfinfo\behaviors\RequestCacheServiceInterface;
use common\modules\rfinfo\behaviors\RequestServiceInterface;
use common\modules\rfinfo\behaviors\ResponseResourceInterface;
use common\modules\rfinfo\behaviors\ResponseServiceInterface;
use common\modules\rfinfo\components\RequestContext;

use Yii;

class RequestCacheService implements RequestCacheServiceInterface
{
    /**
     * @var RequestServiceInterface
     */
    protected $requestService;
    /**
     * @var ResponseServiceInterface
     */
    protected $responseService;

    public function __construct(RequestServiceInterface $requestService, ResponseServiceInterface $responseService)
    {
        $this->requestService = $requestService;
        $this->responseService = $responseService;
    }

    protected function call(string $method, RequestContext $context)
    {
//        if (!$this->responseService->has($context->getQuery())) {
        if (true) {
            $data = call_user_func([$this->requestService, $method], $context);

            $this->responseService->set($context->getQuery(), $data);
        }

        $result = $this->responseService->get($context->getQuery());

        if ($result instanceof ResponseResourceInterface) {
            return $result->getData($context->getFilter());
        }

        return $result;
    }

    public function getInfo(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function getClientLines(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function getClientLine(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function getTranches(RequestContext $context)
    {
        Yii::warning('RequestCacheService.getTranches() BEGIN');
        $result = $this->call(__FUNCTION__, $context);
        Yii::warning('RequestCacheService.getTranches() END');
        return $result;
    }

    public function getAccounts(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function getAccountTransactions(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function getAccountStatements(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function getAccountArrests(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function getRate(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function getUser(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }

    public function postSendSms(RequestContext $context)
    {
        Yii::warning('RequestCacheService.postSendSms() BEGIN');
        $result = $this->call(__FUNCTION__, $context);
        Yii::warning('RequestCacheService.postSendSms() END: $result = '.print_r($result, true));
        return $result;
    }

    public function postCheckCode(RequestContext $context)
    {
        Yii::warning('RequestCacheService.postCheckCode() BEGIN');
        $result = $this->call(__FUNCTION__, $context);
        Yii::warning('RequestCacheService.postCheckCode() END: $result = '.print_r($result, true));
        return $result;

    }

    public function postContact(RequestContext $context)
    {
        return $this->call(__FUNCTION__, $context);
    }
}