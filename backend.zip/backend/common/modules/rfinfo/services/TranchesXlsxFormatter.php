<?php

namespace common\modules\rfinfo\services;

use common\enums\MimeTypeEnum;
use common\modules\rfinfo\behaviors\FormatterInterface;
use common\modules\rfinfo\behaviors\XlsxFormatterTrait;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\dto\Tranche;
use common\modules\rfinfo\enums\TrancheStatusEnum;
use common\modules\rfinfo\forms\TranchesQueryForm;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx as XlsxReader;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx as XlsxWriter;

class TranchesXlsxFormatter implements FormatterInterface
{
    use XlsxFormatterTrait;

    private const DATE_FORMAT = 'd.m.Y';

    /**
     * @var Info
     */
    protected $info;
    /**
     * @var Tranche[]
     */
    protected $tranches;
    /**
     * @var TranchesQueryForm
     */
    protected $query;
    /**
     * @var string
     */
    protected $templatePath = '@common/modules/rfinfo/templates/tranches.xlsx';

    public function __construct()
    {
        $this->templatePath = \Yii::getAlias($this->templatePath);
    }

    /**
     * @param Info $info
     */
    public function setInfo($info): void
    {
        $this->info = $info;
    }

    /**
     * @param Tranche[] $tranches
     */
    public function setTranches(array $tranches): void
    {
        $this->tranches = $tranches;
    }

    public function setQuery(TranchesQueryForm $query): void
    {
        $this->query = $query;
    }

    public function format(): string
    {
        $reader = new XlsxReader();

        $spreadsheet = $reader->load($this->templatePath);
        $worksheet = $spreadsheet->getActiveSheet();

        $this->modifyWorksheet($worksheet);

        $writer = new XlsxWriter($spreadsheet);
        $output = fopen('php://temp', 'rb+');
        $writer->save($output);

        rewind($output);

        return stream_get_contents($output);
    }

    protected function modifyWorksheet(Worksheet $worksheet): void
    {
        $worksheet->setCellValue('A1', $this->info->name);
        $this->setCellValueAsDate($worksheet, 'B3', date_create());
        $worksheet->setCellValue('B7', TrancheStatusEnum::getLabel($this->query->status_tranche ?? TrancheStatusEnum::ALL));

        if ($this->query->start_date === null && $this->query->end_date === null) {
            $worksheet->setCellValue('B6', 'по открытым договорам');
        } else {
            $worksheet->setCellValue('B6', 'выданные за период');
            $worksheet->setCellValue('C6', 'Период');

            $parts = [];

            if ($this->query->start_date !== null) {
                $parts[] = date_create($this->query->start_date)->format(self::DATE_FORMAT);
            }

            if ($this->query->end_date !== null) {
                if (!empty($parts)) {
                    $parts[] = '-';
                }
                $parts[] = date_create($this->query->end_date)->format(self::DATE_FORMAT);
            }

            $worksheet->setCellValue('D6', implode(' ', $parts));
        }

        $row = 11;

        foreach ($this->tranches as $tranche) {
            $worksheet->insertNewRowBefore($row);
            $worksheet->setCellValue('A' . $row, $tranche->vin);
            $worksheet->setCellValue('B' . $row, $tranche->name_brand);
            $worksheet->setCellValue('C' . $row, $tranche->model);
            $worksheet->setCellValue('D' . $row, $tranche->number);
            $worksheet->setCellValue('E' . $row, TrancheStatusEnum::getLabel($tranche->status));
            $this->setCellValueAsDate($worksheet, 'F' . $row, date_create($tranche->real_start_date));
            $this->setCellValueAsNumeric($worksheet, 'G' . $row, $tranche->sum_amount);
            $this->setCellValueAsNumeric($worksheet, 'H' . $row, $tranche->sum_pre_pay);
            $this->setCellValueAsDate($worksheet, 'I' . $row, date_create($tranche->date_beg_pay));
            $this->setCellValueAsDate($worksheet, 'J' . $row, date_create($tranche->finish_date));
            $this->setCellValueAsNumeric($worksheet, 'K' . $row, $tranche->rest_main_debt);
            $this->setCellValueAsNumeric($worksheet, 'L' . $row, $tranche->overdue_debt);
            $this->setCellValueAsNumeric($worksheet, 'M' . $row, $tranche->flag_overdue_debt);
            $this->setCellValueAsNumeric($worksheet, 'N' . $row, $tranche->percent_rate);
            $this->setCellValueAsNumeric($worksheet, 'O' . $row, $tranche->sum_percent);
            $this->setCellValueAsNumeric($worksheet, 'P' . $row, $tranche->sum_fin);
            $this->setCellValueAsNumeric($worksheet, 'Q' . $row, $tranche->sum_comiss);

            $row++;
        }

        $worksheet->removeRow(10);
    }

    public function getMimeType(): string
    {
        return MimeTypeEnum::XLSX;
    }
}