<?php

namespace common\modules\session\behaviors;

use common\modules\authentication\behaviors\TokenInterface;
use common\modules\authentication\exceptions\TokenException;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\Action;
use yii\base\ActionFilter;
use yii\base\Behavior;
use yii\base\Controller;

class SessionTouchBehavior extends ActionFilter
{
    /**
     * @var SessionServiceInterface
     */
    protected $sessionService;

    public function __construct(SessionServiceInterface $sessionService, $config = [])
    {
        $this->sessionService = $sessionService;

        parent::__construct($config);
    }

    /**
     * @param Action $action
     * @return mixed
     * @throws TokenException
     */
    public function beforeAction($action)
    {
        $result = parent::beforeAction($action);

        if ($result) {
            $identity = \Yii::$app->getUser()->getIdentity();

            if ($identity instanceof IdentityInterface && $identity->getToken() instanceof TokenInterface) {
                $this->sessionService->touch($identity->getToken()->getSession());
            }
        }

        return $result;
    }
}