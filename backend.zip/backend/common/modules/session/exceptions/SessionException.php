<?php

namespace common\modules\session\exceptions;

use yii\base\Exception;

class SessionException extends Exception
{

}