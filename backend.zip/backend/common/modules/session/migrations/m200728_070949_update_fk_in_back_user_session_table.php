<?php

use console\components\Migration;

/**
 * Class m200728_070949_update_fk_in_back_user_session_table
 */
class m200728_070949_update_fk_in_back_user_session_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropForeignKeyNamed('{{%back_user_session}}', 'user_id', '{{%back_user}}', 'id');
        $this->addForeignKeyNamed('{{%back_user_session}}', 'user_id', '{{%back_user}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKeyNamed('{{%back_user_session}}', 'user_id', '{{%back_user}}', 'id');
        $this->addForeignKeyNamed('{{%back_user_session}}', 'user_id', '{{%back_user}}', 'id');
    }
}
