<?php

use yii\db\Migration;

/**
 * Class m210621_143849_add_confirm_date_to_front_user_session_table
 */
class m210621_143849_add_confirm_date_to_front_user_session_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%front_user_session}}', 'confirm_date', $this->timestamp()->null());
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user_session}}', 'confirm_date');
    }
}
