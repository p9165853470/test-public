<?php

use yii\db\Migration;

/**
 * Class m210702_112121_add_diasoft_id_to_front_user_session_table
 */
class m210702_112121_add_diasoft_id_to_front_user_session_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%front_user_session}}', 'diasoft_id', $this->string(16)->null());
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user_session}}', 'diasoft_id');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210702_112121_add_diasoft_id_to_front_user_session_table cannot be reverted.\n";

        return false;
    }
    */
}
