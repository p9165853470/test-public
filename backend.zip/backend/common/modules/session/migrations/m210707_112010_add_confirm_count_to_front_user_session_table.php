<?php

use yii\db\Migration;

/**
 * Class m210707_112010_add_confirm_count_to_front_user_session_table
 */
class m210707_112010_add_confirm_count_to_front_user_session_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%front_user_session}}', 'confirm_count', $this->integer()->null()->defaultValue(0));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user_session}}', 'confirm_count');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210707_112010_add_confirm_count_to_front_user_session_table cannot be reverted.\n";

        return false;
    }
    */
}
