<?php

namespace common\modules\session\services;

use common\helpers\Date;
use common\modules\session\behaviors\SessionInterface;
use common\modules\session\behaviors\SessionServiceInterface;
use common\modules\session\behaviors\SessionServiceTrait;
use common\modules\session\models\FrontUserSession;
use common\modules\session\repositories\FrontUserSessionRepository;

use Yii;

class FrontUserSessionService implements SessionServiceInterface
{
    use SessionServiceTrait;

    public function __construct(FrontUserSessionRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param SessionInterface|FrontUserSession $session
     */
    public function touch(SessionInterface $session): void
    {
        $session->touch('updated_at');
    }

    /**
     * @param SessionInterface|FrontUserSession $session
     */
    public function confirm(FrontUserSession $session): void
    {
        $session->setConfirm();
        $session->resetConfirmCount();
        $this->repository->save($session);
    }

    /**
     * @param SessionInterface|FrontUserSession $session
     */
    public function confirmError(FrontUserSession $session): void
    {
        $session->addConfirmCount();
        $this->repository->save($session);
    }
    public function collectGarbage(): int
    {
        $date = date_create()
            ->sub(new \DateInterval(FrontUserSession::EXPIRE_INTERVAL))
            ->format(Date::INTERNAL_DATETIME_FORMAT);

        return FrontUserSession::deleteAll(['<', 'updated_at', $date]);
    }

    /**
     * @param SessionInterface|FrontUserSession $session
     * @param string $diasoft_id
     */
    public function chooseDealer(FrontUserSession $session, ?string $diasoft_id): void
    {
        Yii::warning('FrontUserSessionService.chooseDealer() BEGIN');
        $session->setDiasoftId($diasoft_id);

        $this->repository->save($session);
        Yii::warning('FrontUserSessionService.chooseDealer() END');
    }
}