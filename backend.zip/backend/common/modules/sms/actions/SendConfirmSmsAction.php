<?php

namespace common\modules\sms\actions;

use common\enums\ErrorEnum;
use common\models\errors\RFInfoRequestError;
use common\modules\rfinfo\behaviors\RequestServiceInterface;
use common\modules\sms\resources\SendSmsResource;
use common\modules\rfinfo\behaviors\RequestCacheServiceInterface;
use common\modules\rfinfo\behaviors\ResponseResourceInterface;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\enums\TrancheStatusEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\factories\RequestFactory;
use common\modules\rfinfo\resources\ResponseResource;
use common\modules\sms\forms\SendSmsForm;
use common\modules\sms\services\SendSmsService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use common\resources\Resource;
use Yii;
use yii\base\Action;
use yii\di\Instance;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class SendConfirmSmsAction extends Action
{
    /**
     * @var SendSmsService
     */
    protected $service;
    /**
     * @var RequestCacheServiceInterface
     */
    protected $requestService;
    /**
     * @var RequestFactory
     */
    protected $requestFactory;

    public function __construct(
        $id,
        $controller,
        SendSmsService $service,
        RequestCacheServiceInterface $requestService,
        RequestFactory $requestFactory,
        $config = []
    ) {
        $this->service = $service;
        $this->requestService = $requestService;
        $this->requestFactory = $requestFactory;

        parent::__construct($id, $controller, $config);
    }

    public function init(): void
    {
        parent::init();

        Yii::$container->set(ResponseResourceInterface::class, ResponseResource::class);
    }

    /**
     * @param Request $request
     * @param Response $response
     * @param IdentityInterface|FrontUser $identity
     * @return SendSmsForm|SendSmsResource
     * @throws BadRequestHttpException
     */
    public function run(Request $request, Response $response, IdentityInterface $identity)
    {
        Yii::warning('SendConfirmSmsAction.run() BEGIN');
        $form = new SendSmsForm();

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }
        if ($form->validate()) {
            /** @var RequestServiceInterface $service */
            $service = Instance::ensure(RequestServiceInterface::class);
            /** @var RequestFactory $factory */
            $factory = Instance::ensure(RequestFactory::class);
            $context = $factory->getContext(RequestMethodEnum::SEND_SMS,
//todo Заменить diasoft_id на адекватное наименование - уникальный номер сессии.
                ['diasoft_id' => substr_replace($identity->phone_number,'1',0,1),
                    'phone_number' => $identity->phone_number,
                    'type_confirm_code' => $form->type_confirm_code
                ]);
            try {
                $SendSms = $service->postSendSms($context);
            } catch (RequestServiceException $ex) {
                throw new BadRequestHttpException($ex->getMessage());
            }

            $response->setStatusCode(201);
            $response->headers->add('location', $SendSms->factor_url);

            $result = new SendSmsResource(
                $SendSms
            );
            Yii::warning('SendConfirmSmsAction.run() END 1');
            return $result;
        }
        Yii::warning('SendConfirmSmsAction.run() END 2');
        return $form;
    }
}