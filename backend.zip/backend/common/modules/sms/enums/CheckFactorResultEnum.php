<?php

namespace common\modules\sms\enums;

use common\behaviors\EnumTrait;

class CheckFactorResultEnum
{
    use EnumTrait;

    public const BAD_AUTH_CODE = 'BAD_AUTH_CODE';
    public const LIFE_TIME_EXPIRED = 'LIFE_TIME_EXPIRED';
    public const CONFIRM_ATTEMPT_COUNT_EXCEEDED = 'CONFIRM_ATTEMPT_COUNT_EXCEEDED';
    public const OK = 'OK';
    public const CONFIRM_SMS_COUNT_EXCEEDED = 'CONFIRM_SMS_COUNT_EXCEEDED';

}
