<?php

namespace common\modules\sms\resources;

use common\modules\authentication\behaviors\TokenInterface;
use common\resources\Resource;
use yii\base\Arrayable;
use yii\base\ArrayableTrait;

class CheckCodeResource extends Resource
{
    public function toArray(): array
    {
        return [
            'check_factor_result' => $this->resource->check_factor_result,
            'check_factor_msg' => $this->resource->check_factor_msg,
        ];
    }
}
