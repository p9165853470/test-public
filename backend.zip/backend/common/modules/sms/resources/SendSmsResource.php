<?php

namespace common\modules\sms\resources;

use common\modules\authentication\behaviors\TokenInterface;
use common\resources\Resource;
use yii\base\Arrayable;
use yii\base\ArrayableTrait;

class SendSmsResource extends Resource
{
    public function toArray(): array
    {
        return [
            'masked_phone_number' => $this->resource->masked_phone_number,
            'factor_url' => $this->resource->factor_url,
        ];
    }
}
