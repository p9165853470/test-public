<?php

namespace common\modules\sms\services;

use common\modules\rfinfo\models\SendSms;
use common\modules\sms\repositories\TranchePaymentRepository;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use common\services\Service;
use Yii;
use yii\helpers\ArrayHelper;

class CheckCodeService extends Service
{

    public function __construct()
    {

    }
}