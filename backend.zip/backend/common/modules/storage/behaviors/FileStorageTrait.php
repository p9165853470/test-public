<?php

namespace common\modules\storage\behaviors;

use common\modules\storage\exceptions\StorageException;
use common\modules\storage\models\File;
use yii\helpers\FileHelper;
use yii\web\UploadedFile;

trait FileStorageTrait
{
    /**
     * @var string
     */
    protected $root;

    public function save(File $model, UploadedFile $file): void
    {
        $path = $this->root . '/' . $model->group_code . '/' . $model->name;

        if (!FileHelper::createDirectory(dirname($path), 0755, false)) {
            throw new StorageException("Failed to create directory for file: \"{$path}\"");
        }

        if (!$file->saveAs($path)) {
            throw new StorageException("Failed to move file to: \"{$path}\"");
        }
    }

    public function delete(File $model): void
    {
        $path = $this->root . '/' . $model->group_code . '/' . $model->name;

        if (is_file($path)) {
            @unlink($path);
        }
    }
}