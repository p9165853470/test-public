<?php

namespace common\modules\storage\behaviors;

use common\modules\storage\models\File;
use yii\db\ActiveRecord;
use yii\web\UploadedFile;

interface UploadServiceInterface
{
    /**
     * Загрузить файл и прикрепить к нему контекст
     *
     * @param ActiveRecord $owner
     * @param UploadedFile[]|UploadedFile $files
     * @param string $group
     * @return File[]|File
     */
    public function upload(ActiveRecord $owner, $files, string $group);
}