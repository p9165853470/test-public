<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%file}}`.
 */
class m200915_073617_create_file_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%file}}', [
            'id' => $this->primaryKey(),
            'group_code' => $this->string(32)->notNull(),
            'owner_id' => $this->integer()->notNull(),
            'name' => $this->string(300)->notNull(),
            'original_name' => $this->string(300)->notNull(),
            'created_at' => $this->timestamp()->notNull(),
        ]);

        $this->createIndexNamed('{{%file}}', ['group_code', 'owner_id']);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%file}}');
    }
}
