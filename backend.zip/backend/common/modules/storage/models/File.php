<?php

namespace common\modules\storage\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\behaviors\ModelHasRepositoryTrait;
use common\modules\storage\repositories\FileRepository;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property string $group_code
 * @property int $owner_id
 * @property string $name
 * @property string $original_name
 * @property string $created_at
 *
 * @method static FileRepository getRepository()
 */
class File extends ActiveRecord implements ModelHasRepositoryInterface
{
    use ModelHasRepositoryTrait;

    public static function getRepositoryClass(): string
    {
        return FileRepository::class;
    }

    public function behaviors(): array
    {
        return [
            [
                'class' => TimestampBehavior::class,
                'attributes' => [
                    self::EVENT_BEFORE_INSERT => ['created_at'],
                ]
            ]
        ];
    }
}