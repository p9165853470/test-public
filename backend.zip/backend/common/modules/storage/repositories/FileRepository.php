<?php

namespace common\modules\storage\repositories;

use common\modules\storage\models\File;
use common\repositories\Repository;

/**
 * @method File model()
 * @method File findOne($condition = null)
 * @method File[] findAll($condition = null)
 */
class FileRepository extends Repository
{
    public function getModelClass(): string
    {
        return File::class;
    }
}