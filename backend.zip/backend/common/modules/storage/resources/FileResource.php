<?php


namespace common\modules\storage\resources;

use common\modules\storage\behaviors\FileStorageInterface;
use common\modules\storage\models\File;
use common\resources\Resource;
use yii\di\Instance;

class FileResource extends Resource
{
    /**
     * @var FileStorageInterface
     */
    protected $storage;

    public function __construct($resource)
    {
        $this->storage = Instance::ensure(FileStorageInterface::class);

        parent::__construct($resource);
    }

    protected function properties(): array
    {
        return [
            'id',
            'url' => function (File $model) {
                return $this->storage->getUrl($model);
            }
        ];
    }

    public function toArray(): ?array
    {
        if (is_array($this->resource)) {
            return self::collection($this->resource);
        }

        return parent::toArray();
    }
}