<?php

namespace common\modules\storage\services;

use common\modules\storage\behaviors\FileStorageInterface;
use common\modules\storage\behaviors\FileStorageTrait;
use common\modules\storage\models\File;
use Yii;
use yii\base\StaticInstanceInterface;
use yii\base\StaticInstanceTrait;

class FrontFileStorage implements FileStorageInterface, StaticInstanceInterface
{
    use FileStorageTrait;
    use StaticInstanceTrait;

    public function __construct()
    {
        $this->root = Yii::getAlias('@frontend/web/uploads');
    }

    public function getUrl(File $model): string
    {
        return Yii::$app->params['frontend.host'] . '/uploads/' . $model->group_code . '/' . $model->name;
    }
}