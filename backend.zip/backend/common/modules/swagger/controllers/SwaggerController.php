<?php

namespace common\modules\swagger\controllers;

use common\modules\swagger\controllers\swagger\FileAction;
use common\modules\swagger\controllers\swagger\IndexAction;
use yii\web\Controller;

class SwaggerController extends Controller
{
    /**
     * @var string
     */
    public $fileUrl;
    /**
     * @var string
     */
    public $filePath;
    /**
     * @var string
     */
    public $validatorUrl = 'https://validator.swagger.io/validator';
    /**
     * @var string
     */
    public $layout = '@common/modules/swagger/views/layouts/swagger';

    public function actions(): array
    {
        return [
            'index' => IndexAction::class,
            'file' => FileAction::class,
        ];
    }
}