<?php

namespace common\modules\swagger\controllers\swagger;

use common\modules\swagger\controllers\SwaggerController;
use yii\base\Action;
use yii\web\Response;

class IndexAction extends Action
{
    /** @var SwaggerController */
    public $controller;

    public function run(Response $response): string
    {
        $response->format = Response::FORMAT_HTML;

        $this->controller->view->params['url'] = $this->controller->fileUrl;

        return $this->controller->renderContent('');
    }
}