<?php

namespace common\modules\swagger\exceptions;

class SwaggerException extends \yii\base\Exception
{

}