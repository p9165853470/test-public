<?php

namespace common\modules\swagger\services;

use common\modules\swagger\exceptions\SwaggerException;

class SwaggerService
{
    public function findFile(string $basePath, string $fileName): string
    {
        $fileName = preg_replace('/\./u', '/', $fileName, mb_substr_count($fileName, '.') - 1);
        $filePath = $basePath . '/' . $fileName;

        if (is_file($filePath)) {
            return $filePath;
        }
        throw new SwaggerException('File "' . $filePath . '" doesn\' exists.');
    }
}