<?php
/**
 * @var View $this
 * @var string $content
 */

use common\modules\swagger\assets\SwaggerAsset;
use yii\web\View;

SwaggerAsset::register($this);

$this->beginPage() ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Swagger UI</title>
        <?php $this->head() ?>
        <style>
            html
            {
                box-sizing: border-box;
                overflow: -moz-scrollbars-vertical;
                overflow-y: scroll;
            }

            *,
            *:before,
            *:after
            {
                box-sizing: inherit;
            }

            body
            {
                margin:0;
                background: #fafafa;
            }
        </style>
    </head>
    <body>
    <?php $this->beginBody() ?>
    <div id="swagger-ui"></div>
    <?php $this->endBody() ?>
    <script>
        window.onload = function() {
            const ui = SwaggerUIBundle({
                dom_id: "#swagger-ui",
                deepLinking: true,
                presets: [
                    SwaggerUIBundle.presets.apis,
                    SwaggerUIStandalonePreset
                ],
                plugins: [
                    SwaggerUIBundle.plugins.DownloadUrl
                ],
                layout: "<?= $this->params['layout'] ?? 'StandaloneLayout' ?>",
                validatorUrl: false,
                url: "<?= $this->params['url'] ?>",
            })

            window.ui = ui
        }
    </script>
    </body>
    </html>
<?php $this->endPage();