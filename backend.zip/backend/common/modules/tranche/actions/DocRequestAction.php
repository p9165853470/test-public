<?php

namespace common\modules\tranche\actions;

use common\enums\ErrorEnum;
use common\exceptions\SaveModelException;
use common\modules\rfinfo\behaviors\RequestCacheServiceInterface;
use common\modules\rfinfo\behaviors\ResponseResourceInterface;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\enums\ClientLineTypeEnum;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\enums\TrancheStatusEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\factories\RequestFactory;
use common\modules\rfinfo\resources\ResponseResource;
use common\modules\rfinfo\services\TranchesXlsxFormatter;
use common\modules\tranche\forms\TranchePaymentsForm;
use common\modules\tranche\services\TranchePaymentPdfFormatter;
use common\modules\tranche\services\TranchePaymentService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use Yii;
use yii\base\Action;
use yii\base\BaseObject;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class DocRequestAction extends Action
{
    /**
     * @var TranchePaymentService
     */
    protected $service;
    /**
     * @var RequestCacheServiceInterface
     */
    protected $requestService;
    /**
     * @var RequestFactory
     */
    protected $requestFactory;

    public function __construct(
        $id,
        $controller,
        TranchePaymentService $service,
        RequestCacheServiceInterface $requestService,
        RequestFactory $requestFactory,
        $config = []
    ) {
        $this->service = $service;
        $this->requestService = $requestService;
        $this->requestFactory = $requestFactory;

        parent::__construct($id, $controller, $config);
    }

    public function init(): void
    {
        parent::init();

        Yii::$container->set(ResponseResourceInterface::class, ResponseResource::class);
    }

    /**
     * @param Request $request
     * @param Response $response
     * @param IdentityInterface|FrontUser $identity
     * @return TranchePaymentsForm|void
     * @throws BadRequestHttpException
     * @throws SaveModelException
     */
    public function run(Request $request, Response $response, IdentityInterface $identity)
    {
        Yii::warning('DocRequestAction.run() BEGIN');
        $form = new TranchePaymentsForm();

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        $context = $this->requestFactory->getContext(RequestMethodEnum::TRANCHES, [
            'type_line' => ClientLineTypeEnum::ALL,
            'status_tranche' => TrancheStatusEnum::OPENED,
        ]);

        try {
            $tranches = $this->requestService->getTranches($context);
        } catch (RequestServiceException $ex) {
            Yii::error($ex);
            throw new BadRequestHttpException('RFInfo request error.', ErrorEnum::RFINFO_REQUEST_ERROR);
        }

        $form->setTranches($tranches);

        if ($form->validate()) {
            $models = $this->service->create($form, $identity);
            $this->service->exportPdf($models, $identity, new TranchePaymentPdfFormatter());
            $response->setStatusCode(204);
            Yii::warning('DocRequestAction.run() END 1');
            return;
        }

        Yii::warning('DocRequestAction.run() END 2');
        return $form;
    }
}