<?php

namespace common\modules\tranche\forms;

use common\modules\rfinfo\dto\Tranche;
use common\modules\tranche\enums\PaymentTypeEnum;
use common\modules\tranche\models\TranchePayment;
use yii\base\Model;
use yii\helpers\ArrayHelper;

class TranchePaymentForm extends Model
{
    /**
     * @var string
     */
    public $vin;
    /**
     * @var string
     */
    public $payment_type;
    /**
     * @var Tranche[]
     */
    protected $tranches = [];

    /**
     * @param Tranche[] $tranches
     */
    public function setTranches(array $tranches): void
    {
        $this->tranches = $tranches;
    }

    public function rules(): array
    {
        return [
            [['vin', 'payment_type'], 'required'],
            [
                'vin',
                'in',
                'range' => static function (self $model) {
                    return ArrayHelper::getColumn($model->tranches, 'vin');
                }
            ],
            [
                'vin',
                'unique',
                'targetClass' => TranchePayment::class,
                'targetAttribute' => 'vin',
            ],
            ['payment_type', 'in', 'range' => PaymentTypeEnum::getRange()],
            [
                'vin',
                function () {
                    switch ($this->payment_type) {
                        case PaymentTypeEnum::FULL_REPAYMENT:
                            $paymentAttribute = 'sum_amount';
                            break;
                        case PaymentTypeEnum::PREPAYMENT:
                            $paymentAttribute = 'sum_pre_pay';
                            break;
                        default:
                            return;

                    }
                    $map = ArrayHelper::map($this->tranches, 'vin', $paymentAttribute);
                    $sum = (float)($map[$this->vin] ?? 0);

                    if ($sum === 0.0) {
                        $this->addError('vin', 'Sum of payment cannot be zero.');
                    }
                },
            ],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}