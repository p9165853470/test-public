<?php

namespace common\modules\tranche\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\behaviors\ModelHasRepositoryTrait;
use common\modules\tranche\repositories\TranchePaymentRepository;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $user_id
 * @property string $vin
 * @property float $sum
 * @property string $type
 * @property bool $exported
 * @property string $created_at
 *
 * @method static TranchePaymentRepository getRepository()
 */
class TranchePayment extends ActiveRecord implements ModelHasRepositoryInterface
{
    use ModelHasRepositoryTrait;

    public static function getRepositoryClass(): string
    {
        return TranchePaymentRepository::class;
    }

    public function behaviors(): array
    {
        return [
            [
                'class' => TimestampBehavior::class,
                'attributes' => [
                    self::EVENT_BEFORE_INSERT => ['created_at']
                ]
            ]
        ];
    }
}