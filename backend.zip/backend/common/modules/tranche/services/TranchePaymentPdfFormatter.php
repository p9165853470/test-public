<?php

namespace common\modules\tranche\services;

use common\modules\user\behaviors\IdentityInterface;
use PhpOffice\PhpWord\Exception\CopyFileException;
use PhpOffice\PhpWord\Exception\CreateTemporaryFileException;
use PhpOffice\PhpWord\TemplateProcessor;
use Yii;

use common\modules\tranche\models\TranchePayment;

putenv("PATH=/usr/lib64/libreoffice/program");

class TranchePaymentPdfFormatter
{
    public function format($docParameters,  $payments)
    {
        Yii::warning('TranchePaymentPdfFormatter.format() BEGIN NEW');

        require_once '/opt/backend/vendor/autoload.php';

        $requestForRepayment = [
            'tf_number' => 'ТФ-1234-56/7',
//            'dealer_name' => 'ООО Автодилер',
            'dealer_name' => $docParameters['dealer_name'],
            'inn' => '012345678901',
            'repayment_conditions_table' => [],
            'total_prepayment_amount' => '2000000.00',
            'total_repayment_amount' => '4000000.00',
            'owner' => 'Михайлова Александра Андреевна',
            'signing_time' => '2020-07-27 19:17:23',
        ];

        $table_length = count($payments);
        $table = [];
        $requestForRepayment['total_repayment_amount'] = 0;
        $requestForRepayment['total_prepayment_amount'] = 0;
        for($i = 0; $i < $table_length; $i++)
        {
            $table[$i]['repayment_priority'] = $i + 1;
            $table[$i]['vin'] = $payments[$i]['vin'];
            $table[$i]['name_brand'] = 'Toyota/Camry';  // TODO Заполнить реальным значением
            $table[$i]['repayment_amount'] = '0';       // TODO Заполнить реальным значением
            $table[$i]['prepayment_amount'] = $payments[$i]['sum'];
            $requestForRepayment['total_prepayment_amount'] += $table[$i]['prepayment_amount']; // TODO Лучше получать в готовом виде
            $requestForRepayment['total_repayment_amount'] += $table[$i]['repayment_amount'];   // TODO Лучше получать в готовом виде
        }
        $requestForRepayment['repayment_conditions_table'] = $table;

        $this->getRFRPdf($requestForRepayment);
        Yii::warning('TranchePaymentPdfFormatter.format() END NEW');
    }

    public function getRFRPdf(array $requestForRepayment): string
    {
        try {
            $templatePath = '/opt/backend/frontend/web/templates/RequestForRepaymentTemplate.docx';
            $docPath = '/opt/backend/frontend/runtime/RequestForRepayment.docx';
            $pdfPath = '/opt/backend/frontend/runtime/RequestForRepayment.pdf';
            $this->createRFRDoc($requestForRepayment, $templatePath, $docPath);
            $this->doc2pdf($docPath, $pdfPath);
            unlink($docPath);
        } catch (CopyFileException | CreateTemporaryFileException $e) {
            Yii::error($e);
        }

        return $pdfPath;
    }

    /**
     * @throws CopyFileException
     * @throws CreateTemporaryFileException
     */
    public function createRFRDoc(array $requestForRepayment, string $templatePath, string $docPath) {
        $templateProcessor = new TemplateProcessor($templatePath);

        $templateProcessor->setValue('tf_number', $requestForRepayment['tf_number']);
        $templateProcessor->setValue('dealer_name', $requestForRepayment['dealer_name']);
        $templateProcessor->setValue('inn', $requestForRepayment['inn']);

        $table = $requestForRepayment['repayment_conditions_table'];
        $table_length = count($table);
        $templateProcessor->cloneRow('vin', $table_length);
        for($i = 1; $i <= $table_length; $i++)
        {
            $templateProcessor->setValue('repayment_priority#'.$i, $table[($i-1)]['repayment_priority']);
            $templateProcessor->setValue('vin#'.$i, $table[($i-1)]['vin']);
            $templateProcessor->setValue('name_brand#'.$i, $table[($i-1)]['name_brand']);
            $templateProcessor->setValue('prepayment_amount#'.$i, $table[($i-1)]['prepayment_amount']);
            $templateProcessor->setValue('repayment_amount#'.$i, $table[($i-1)]['repayment_amount']);
        }
        $templateProcessor->setValue('total_prepayment_amount', $requestForRepayment['total_prepayment_amount']);
        $templateProcessor->setValue('total_repayment_amount', $requestForRepayment['total_repayment_amount']);

        $templateProcessor->setValue('owner', $requestForRepayment['owner']);
        $templateProcessor->setValue('signing_time', $requestForRepayment['signing_time']);

        $templateProcessor->saveAs($docPath);
    }

    public function doc2pdf(string $docPath, string $pdfPath)
    {
        try {
            $cmd = 'unoconv -o '.$pdfPath.' -f pdf '.$docPath;
            shell_exec($cmd);
        } catch(Exception $e) {
            echo "Exception : " . $e->getMessage().EOL;
        }
    }
}