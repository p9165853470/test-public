<?php

namespace common\modules\tranche\services;

use common\exceptions\SaveModelException;
use common\modules\authentication\exceptions\TokenException;
use common\modules\rfinfo\dto\Tranche;
use common\modules\tranche\forms\TranchePaymentsForm;
use common\modules\tranche\models\TranchePayment;
use common\modules\tranche\repositories\TranchePaymentRepository;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\Dealer;
use common\modules\user\models\FrontUser;
use common\services\Service;
use Yii;
use yii\helpers\ArrayHelper;

/**
 * @method TranchePayment get($id)
 * @method TranchePayment[] getAll()
 * @method TranchePaymentRepository getRepository()
 */
class TranchePaymentService extends Service
{
    /**
     * @var TranchePaymentPdfFormatter
     */
//    protected $formatter;

//    public function __construct(TranchePaymentRepository $repository, TranchePaymentCsvFormatter $formatter)
//    {
//        $this->repository = $repository;
//        $this->formatter = $formatter;
//    }

    public function __construct(TranchePaymentRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param Tranche[] $tranches
     */
    public function load(array $tranches): void
    {
        /** @var array $payments */
        $payments = $this->repository
            ->find([
                'vin' => ArrayHelper::getColumn($tranches, 'vin'),
            ])
            ->select(['vin', 'type'])
            ->asArray()
            ->all();

        $payments = ArrayHelper::map($payments, 'vin', 'type');

        foreach ($tranches as $tranche) {
            $tranche->payment_type = $payments[$tranche->vin] ?? null;
        }
    }

    public function create(TranchePaymentsForm $form, IdentityInterface $identity): array
    {
        Yii::warning('TranchePaymentService.create() BEGIN');
        Yii::warning('TranchePaymentService.create() $form = '.print_r($form, true));
        Yii::warning('TranchePaymentService.create() $identity = '.print_r($identity, true));
        $transaction = Yii::$app->getDb()->beginTransaction();
        $models = [];

        /** @var Tranche[] $tranches */
        $tranches = ArrayHelper::index($form->getTranches(), 'vin');
        Yii::warning('TranchePaymentService.create() $tranches = '.print_r($tranches, true));

        foreach ($form->payments as $payment) {
            Yii::warning('TranchePaymentService.create() $payment = '.print_r($payment, true));
            try {
                $models[] = $this->repository->create(
                    $tranches[$payment->vin],
                    $payment->payment_type,
                    $identity
                );
            } catch (SaveModelException $ex) {
                if ($transaction !== null) {
                    $transaction->rollBack();
                }

                throw $ex;
            }
        }

        if ($transaction !== null) {
            $transaction->commit();
        }

        Yii::warning('TranchePaymentService.create() END: $models = '.print_r($models, true));
        return $models;
    }

    /**
     * @param TranchePayment[] $models
     * @param FrontUser|IdentityInterface $user
     * @throws SaveModelException
     */
    public function export(array $models, IdentityInterface $user, TranchePaymentPdfFormatter $formatter): void
    {
        Yii::warning('TranchePaymentService.export() BEGIN $models = '.print_r($models, true));
        $formatter->setPayments($models);

        $content = $formatter->format();
        Yii::warning('TranchePaymentService.export() $content = '.print_r($content, true));

        $file = "Pay_{$user->diasoft_id}_" . date('H.i.s_d.m.Y') . '.csv';
        $directory = Yii::getAlias(Yii::$app->params['tranche.exportPath']);
        file_put_contents($directory . '/' . $file, $content);

        $this->repository->markAsExported($models);
        Yii::warning('TranchePaymentService.export() END');
    }

    /**
     * @param TranchePayment[] $payments
     * @param FrontUser|IdentityInterface $user
     * @throws TokenException
     */
    public function exportPdf(array $payments, IdentityInterface $user, TranchePaymentPdfFormatter $formatter): void
    {
        Yii::warning('TranchePaymentService.exportPdf() BEGIN $user = '. print_r($user, true));
        Yii::warning('TranchePaymentService.exportPdf() BEGIN $models = '. print_r($payments, true));

        $diasoftId = $user->getToken()->getSession()->getDiasoftId();
        Yii::warning('TranchePaymentService.exportPdf() BEGIN $diasoftId = '. print_r($diasoftId, true));
        Yii::warning('TranchePaymentService.exportPdf() BEGIN $user->getId() = '. print_r($user->getId(), true));
        $dealer = Dealer::find()->where(['user_id' => $user->getId(), 'diasoft_id' => $diasoftId])->one();
        Yii::warning('TranchePaymentService.exportPdf() BEGIN $dealer = '. print_r($dealer, true));
        $docParameters = [
            'dealer_name' => '$dealer->name'
        ];
        $formatter->format($docParameters, $payments);

        Yii::warning('TranchePaymentService.exportPdf() END');
    }

    public function createAndExport(TranchePaymentsForm $form, IdentityInterface $identity): void
    {
        Yii::warning('TranchePaymentService.createAndExport() BEGIN');
        $transaction = Yii::$app->getDb()->beginTransaction();

        try {
            Yii::warning('TranchePaymentService.createAndExport() BEFORE \'$this->export($this->create($form, $identity), $identity)\'');
            $this->export($this->create($form, $identity), $identity, new TranchePaymentPdfFormatter());
            Yii::warning('TranchePaymentService.createAndExport() AFTER \'$this->export($this->create($form, $identity), $identity)\'');

            if ($transaction !== null) {
                $transaction->commit();
            }
        } catch (\Throwable $ex) {
            if ($transaction !== null) {
                $transaction->rollBack();
            }

            throw $ex;
        }
        Yii::warning('TranchePaymentService.createAndExport() END');
    }

    /**
     * @return TranchePayment[]
     */
    public function getAllExported(): array
    {
        return $this->repository->findAll(['exported' => true]);
    }

    public function delete(TranchePayment $model): void
    {
        $this->repository->delete($model);
    }
}