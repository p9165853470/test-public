<?php

namespace common\modules\user\behaviors;

use common\modules\authentication\behaviors\TokenInterface;
use common\modules\user\models\Dealer;

interface IdentityInterface extends \yii\web\IdentityInterface
{
    /**
     * Найти учетную запись по логину
     *
     * @param string $login
     * @return IdentityInterface|null
     */
    public static function findIdentityByLogin(string $login): ?IdentityInterface;

    /**
     * Учетная запись активна
     *
     * @return bool
     */
    public function isActive(): bool;

    /**
     * Учетная запись заблокирована
     *
     * @param int|null $reason проверить блокировку по причине
     * @return bool
     */
    public function hasBlock(int $reason = null): bool;

    /**
     * Установить пароль для учетной записи
     *
     * @param string $password
     */
    public function setPassword(string $password): void;

    /**
     * Сверить пароль с паролем учетной записи
     *
     * @param string $password
     * @return bool
     */
    public function validatePassword(string $password): bool;

    /**
     * Получить токен, по которому авторизована учетная запись
     *
     * @return TokenInterface|null
     */
    public function getToken(): ?TokenInterface;
    
    public function getDealer(): ?Dealer; 
}