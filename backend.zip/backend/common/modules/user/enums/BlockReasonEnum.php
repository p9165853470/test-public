<?php

namespace common\modules\user\enums;

use common\behaviors\EnumTrait;

class BlockReasonEnum
{
    use EnumTrait;

    /**
     * Нет причины
     */
    public const NO_REASON = 0;
    /**
     * Заблокирован администратором
     */
    public const BY_ADMIN = 1;
    /**
     * Заблокирован после череды неудачных попыток аутентификации
     */
    public const BY_FAILED_AUTHENTICATION = 2;
    /**
     * Заблокирован после череды неудачных попыток подтверждения кода СМС
     */
    public const BY_FAILED_CONFIRM = 3;
}