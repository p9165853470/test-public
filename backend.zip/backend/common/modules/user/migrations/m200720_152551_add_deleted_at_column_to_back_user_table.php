<?php

use yii\db\Migration;

/**
 * Handles adding columns to table `{{%back_user}}`.
 */
class m200720_152551_add_deleted_at_column_to_back_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%back_user}}', 'deleted_at', $this->timestamp()->null());
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%back_user}}', 'deleted_at');
    }
}
