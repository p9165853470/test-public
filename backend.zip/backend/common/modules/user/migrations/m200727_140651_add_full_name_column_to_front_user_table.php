<?php

use console\components\Migration;

/**
 * Handles adding columns to table `{{%front_user}}`.
 */
class m200727_140651_add_full_name_column_to_front_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->alterColumn('{{%front_user}}', 'first_name', $this->string(80));
        $this->alterColumn('{{%front_user}}', 'middle_name', $this->string(80));
        $this->alterColumn('{{%front_user}}', 'last_name', $this->string(80));

        $this->addColumn('{{%front_user}}', 'search_name', $this->string(256));

        $rows = (new \yii\db\Query())
            ->select(['id', 'first_name', 'middle_name', 'last_name'])
            ->from('{{%front_user}}')
            ->all();

        foreach ($rows as $row) {
            $searchName = implode(' ', array_filter([
                $row['last_name'], $row['first_name'], $row['middle_name']
            ]));
            $searchName = mb_strtolower($searchName);
            $searchName = str_replace('ё', 'е', $searchName);

            $this->update('{{%front_user}}', ['search_name' => $searchName], ['id' => $row['id']]);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user}}', 'search_name');

        $this->alterColumn('{{%front_user}}', 'last_name', $this->string(128));
        $this->alterColumn('{{%front_user}}', 'middle_name', $this->string(128));
        $this->alterColumn('{{%front_user}}', 'first_name', $this->string(128));
    }
}
