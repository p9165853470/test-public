<?php

use console\components\Migration;

/**
 * Handles dropping columns from table `{{%back_user}}`.
 */
class m200728_064049_drop_blameable_and_delete_columns_from_back_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropForeignKeyNamed('{{%back_user}}', 'created_by', '{{%back_user}}', 'id');
        $this->dropColumn('{{%back_user}}', 'created_by');

        $this->dropForeignKeyNamed('{{%back_user}}', 'updated_by', '{{%back_user}}', 'id');
        $this->dropColumn('{{%back_user}}', 'updated_by');

        $this->dropColumn('{{%back_user}}', 'deleted_at');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->addColumn('{{%back_user}}', 'deleted_at', $this->timestamp());

        $this->addColumn('{{%back_user}}', 'updated_by', $this->integer());
        $this->addForeignKeyNamed('{{%back_user}}', 'updated_by', '{{%back_user}}', 'id');

        $this->addColumn('{{%back_user}}', 'created_by', $this->integer());
        $this->addForeignKeyNamed('{{%back_user}}', 'created_by', '{{%back_user}}', 'id');
    }
}
