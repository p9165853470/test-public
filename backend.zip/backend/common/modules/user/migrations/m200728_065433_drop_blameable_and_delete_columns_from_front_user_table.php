<?php

use console\components\Migration;

/**
 * Handles dropping columns from table `{{%front_user}}`.
 */
class m200728_065433_drop_blameable_and_delete_columns_from_front_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropForeignKeyNamed('{{%front_user}}', 'created_by', '{{%back_user}}', 'id');
        $this->dropColumn('{{%front_user}}', 'created_by');

        $this->dropForeignKeyNamed('{{%front_user}}', 'updated_by', '{{%back_user}}', 'id');
        $this->dropColumn('{{%front_user}}', 'updated_by');

        $this->dropColumn('{{%front_user}}', 'deleted_at');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->addColumn('{{%front_user}}', 'deleted_at', $this->timestamp());

        $this->addColumn('{{%front_user}}', 'updated_by', $this->integer());
        $this->addForeignKeyNamed('{{%front_user}}', 'updated_by', '{{%back_user}}', 'id');

        $this->addColumn('{{%front_user}}', 'created_by', $this->integer());
        $this->addForeignKeyNamed('{{%front_user}}', 'created_by', '{{%back_user}}', 'id');
    }
}
