<?php

use console\components\Migration;

/**
 * Handles adding columns to table `{{%front_user}}`.
 */
class m200730_122923_add_agreement_column_to_front_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%front_user}}', 'agreement', $this->boolean()->notNull()->defaultValue(false));
        $this->addColumn('{{%front_user}}', 'agreement_at', $this->timestamp());
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user}}', 'agreement_at');
        $this->dropColumn('{{%front_user}}', 'agreement');
    }
}
