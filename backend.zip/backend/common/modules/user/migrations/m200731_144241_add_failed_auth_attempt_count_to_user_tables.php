<?php

use yii\db\Migration;

/**
 * Class m200731_144241_add_failed_auth_attempt_count_to_user_tables
 */
class m200731_144241_add_failed_auth_attempt_count_to_user_tables extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%back_user}}', 'failed_auth_attempt_count', $this->tinyInteger()->notNull()->defaultValue(0));
        $this->addColumn('{{%front_user}}', 'failed_auth_attempt_count', $this->tinyInteger()->notNull()->defaultValue(0));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user}}', 'failed_auth_attempt_count');
        $this->dropColumn('{{%back_user}}', 'failed_auth_attempt_count');
    }
}
