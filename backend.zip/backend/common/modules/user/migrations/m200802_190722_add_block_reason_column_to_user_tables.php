<?php

use console\components\Migration;

/**
 * Class m200802_190722_add_block_reason_column_to_user_tables
 */
class m200802_190722_add_block_reason_column_to_user_tables extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropColumn('{{%back_user}}', 'block');
        $this->dropColumn('{{%front_user}}', 'block');

        $this->addColumn('{{%back_user}}', 'block_reason', $this->tinyInteger()->notNull()->defaultValue(0));
        $this->addColumn('{{%front_user}}', 'block_reason', $this->tinyInteger()->notNull()->defaultValue(0));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user}}', 'block_reason');
        $this->dropColumn('{{%back_user}}', 'block_reason');

        $this->addColumn('{{%front_user}}', 'block', $this->boolean()->notNull()->defaultValue(false));
        $this->addColumn('{{%back_user}}', 'block', $this->boolean()->notNull()->defaultValue(false));
    }
}
