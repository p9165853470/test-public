<?php

use console\components\Migration;

/**
 * Class m200806_173029_modify_front_user_table
 */
class m200806_173029_modify_front_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropIndexNamed('{{%front_user}}', ['email', 'code'], true);
        $this->renameColumn('{{%front_user}}', 'code', 'diasoft_id');
        $this->createIndexNamed('{{%front_user}}', ['email', 'diasoft_id'], true);

        $this->dropColumn('{{%front_user}}', 'agreement');

        $this->addColumn('{{%front_user}}', 'validated_at', $this->timestamp());
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user}}', 'validated_at');

        $this->addColumn('{{%front_user}}', 'agreement', $this->boolean()->notNull()->defaultValue(false));

        $this->dropIndexNamed('{{%front_user}}', ['email', 'diasoft_id'], true);
        $this->renameColumn('{{%front_user}}', 'diasoft_id', 'code');
        $this->createIndexNamed('{{%front_user}}', ['email', 'code'], true);
    }
}
