<?php

use console\components\Migration;

/**
 * Handles adding columns to table `{{%back_user}}`.
 */
class m201021_221800_add_full_name_column_to_back_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->alterColumn('{{%back_user}}', 'first_name', $this->string(80));
        $this->alterColumn('{{%back_user}}', 'middle_name', $this->string(80));
        $this->alterColumn('{{%back_user}}', 'last_name', $this->string(80));

        $this->addColumn('{{%back_user}}', 'search_name', $this->string(256));

        $rows = (new \yii\db\Query())
            ->select(['id', 'first_name', 'middle_name', 'last_name'])
            ->from('{{%back_user}}')
            ->all();

        foreach ($rows as $row) {
            $searchName = implode(' ', array_filter([
                $row['last_name'], $row['first_name'], $row['middle_name']
            ]));
            $searchName = mb_strtolower($searchName);
            $searchName = str_replace('ё', 'е', $searchName);

            $this->update('{{%back_user}}', ['search_name' => $searchName], ['id' => $row['id']]);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%back_user}}', 'search_name');

        $this->alterColumn('{{%back_user}}', 'last_name', $this->string(128));
        $this->alterColumn('{{%back_user}}', 'middle_name', $this->string(128));
        $this->alterColumn('{{%back_user}}', 'first_name', $this->string(128));
    }
}
