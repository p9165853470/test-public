CREATE OR REPLACE PROCEDURE addUserCodeHistory(
    IN  historyData     user_code_history
)
AS
$BODY$
/**
* Добавляет историческую запись в user_code_history.
*
* @param historyData    Данные исторической записи
*/
DECLARE
-- addUserCodeHistory
BEGIN
    INSERT INTO user_code_history(
        user_code_id
        , user_id
        , diasoft_id
        , authority_begin_date
        , authority_end_date
        , created_at
        , updated_at
        , agreement_at
        , validated_at

        , deleted
        , change_number
        , change_date
        , change_back_user_id
        , change_front_user_id
        , base_date_ins
        , date_ins
        , insert_back_user_id
    ) VALUES (
        historyData.user_code_id
        , historyData.user_id
        , historyData.diasoft_id
        , historyData.authority_begin_date
        , historyData.authority_end_date
        , historyData.created_at
        , historyData.updated_at
        , historyData.agreement_at
        , historyData.validated_at

        , historyData.deleted
        , historyData.change_number
        , historyData.change_date
        , historyData.change_back_user_id
        , historyData.change_front_user_id
        , historyData.base_date_ins
        , historyData.date_ins
        , historyData.insert_back_user_id
    );
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION '%: Ошибка при добавлении исторической записи в user_code_history (id=%)',-20150,user_code_history.id;
END
$BODY$
LANGUAGE 'plpgsql'
SECURITY DEFINER -- выполняется с правами создателя, т.к. будет запускаться не пользователем, а системой
;
