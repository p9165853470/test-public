COMMENT ON PROCEDURE addUserCodeHistory(user_code_history) IS 'Добавляет историческую запись в user_code_history.';
