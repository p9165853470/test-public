CREATE OR REPLACE FUNCTION user_code_bi_define_tf()
RETURNS trigger
AS
$BODY$
/**
* Инициализация полей таблицы user_code при добавлении записи.
*
*/
DECLARE
-- user_code_bi_define_tf
BEGIN
    -- Определяем значение первичного ключа
    IF NEW.user_code_id is null THEN
        NEW.user_code_id = nextval('user_code_id_seq');
    END IF;

    -- Определяем дату добавления записи
    IF NEW.date_ins is null THEN
        NEW.date_ins = current_timestamp;
    END IF;

    -- Запись действующая по умолчанию
    IF NEW.deleted is null THEN
        NEW.deleted = 0;
    END IF;

    -- Определяем номер изменения
    IF NEW.change_number is null THEN
        NEW.change_number = 1;
    END IF;

    -- Определяем дату изменения записи
    IF NEW.change_date is null THEN
        NEW.change_date = NEW.date_ins;
    END IF;

    -- ID оператора, изменившего запись
    IF NEW.change_back_user_id is null THEN
        NEW.change_back_user_id = NEW.insert_back_user_id;
    END IF;

    RETURN NEW;
END
$BODY$
LANGUAGE 'plpgsql';
