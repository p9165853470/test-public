COMMENT ON FUNCTION user_code_bi_define_tf() IS 'Инициализация полей таблицы user_code при добавлении записи.';
