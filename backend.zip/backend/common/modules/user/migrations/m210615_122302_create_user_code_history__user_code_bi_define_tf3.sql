CREATE TRIGGER user_code_bi_define
BEFORE INSERT ON user_code
FOR EACH ROW EXECUTE PROCEDURE user_code_bi_define_tf();
