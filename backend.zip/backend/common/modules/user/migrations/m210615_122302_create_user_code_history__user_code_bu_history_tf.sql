CREATE OR REPLACE FUNCTION user_code_bu_history_tf()
RETURNS trigger
AS
$BODY$
/**
* Инициализация полей таблицы user_code при изменении записи и добавление информации в историческую таблицу user_code_history.
*
*/
DECLARE
  hs    user_code_history%rowtype;
-- user_code_bu_history_tf
BEGIN
    -- Определяем дату изменения записи
    NEW.updated_at = current_timestamp;

    -- Увеличиваем счетчик обновлений
    NEW.change_number = OLD.change_number + 1;
    
    -- Заполняем поля с данными
    hs.user_code_id = OLD.user_code_id;
    hs.user_id = OLD.user_id;
    hs.diasoft_id = OLD.diasoft_id;
    hs.authority_begin_date = OLD.authority_begin_date;
    hs.authority_end_date = OLD.authority_end_date;
    hs.created_at = OLD.created_at;
    hs.updated_at = OLD.updated_at;
    hs.agreement_at = OLD.agreement_at;
    hs.validated_at = OLD.validated_at;

    -- Устанавливаем служебные поля
    hs.deleted             = OLD.deleted;
    hs.change_number       = OLD.change_number;
    hs.change_date         = OLD.change_date;
    hs.change_back_user_id  = OLD.change_back_user_id;
    hs.change_front_user_id  = OLD.change_front_user_id;
    hs.insert_back_user_id = OLD.insert_back_user_id;
    hs.base_date_ins       = OLD.date_ins;
    hs.date_ins            = NEW.change_date;
    
    -- Сохраняем старые данные
    CALL addUserCodeHistory(hs);

    RETURN NEW;
END
$BODY$
LANGUAGE 'plpgsql';
