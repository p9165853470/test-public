<?php

use yii\db\Migration;

/**
 * Class m210615_122322_alter_back_user
 */
class m210615_122322_alter_back_user extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->execute('INSERT INTO public.back_user(
    email, password_hash, first_name, middle_name, last_name, master, created_at, updated_at, failed_auth_attempt_count, block_reason, search_name)
VALUES (\'system@user.ins\', \'\',\'Служебная\', \'Запись\', \'Для-инициализации-данных\', false, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0, 0, \'Служебная Запись Для-инициализации-данных\');');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->execute('delete from back_user where email = \'system@user.ins\';');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210615_122402_alter_front_user cannot be reverted.\n";

        return false;
    }
    */
}
