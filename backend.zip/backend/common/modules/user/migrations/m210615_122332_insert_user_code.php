<?php

use yii\db\Migration;

/**
 * Class m210615_122332_insert_user_code
 */
class m210615_122332_insert_user_code extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->execute(file_get_contents(__DIR__ . '/m210615_122332_insert_user_code__.sql'));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->execute('delete from user_code');
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210615_122402_alter_front_user cannot be reverted.\n";

        return false;
    }
    */
}
