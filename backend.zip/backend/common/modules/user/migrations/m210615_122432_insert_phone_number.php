<?php

use yii\db\Migration;

/**
 * Class m210615_122432_insert_phone_number
 */
class m210615_122432_insert_phone_number extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->execute(file_get_contents(__DIR__ . '/m210615_122432_insert_phone_number__insertPhoneNumber.sql'));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        return true;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {
        
    }

    public function down()
    {
        echo "m210615_122402_alter_front_user cannot be reverted.\n";

        return false;
    }
    */
}
