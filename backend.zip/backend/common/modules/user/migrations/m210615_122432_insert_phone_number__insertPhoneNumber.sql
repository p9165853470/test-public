update front_user t0 set phone_number = (select phone_number from(
select '79219802538' as phone_number, 'kbaklanov@alarm-motors.ru' as email
 union all select '79219802538' as phone_number, 'mandrikinam@alarm-motors.ru' as email
 union all select '79525555630' as phone_number, 'y.hudyakova@avtogradplus.ru' as email
 union all select '79081454842' as phone_number, 'chureeva@landrover.vrn.ru' as email
 union all select '70289268888' as phone_number, 'anufrieva@bmw-mservice.ru' as email
 union all select '79097444111' as phone_number, 'natalia.alexeeva@bmw-mservice.ru' as email
 union all select '79502724490' as phone_number, 'e.shelkovaya@cartelauto.ru' as email
 union all select '79181201076' as phone_number, 'Aleksandr.safronov@yug-avto.ru' as email
 union all select '79222057815' as phone_number, 'aburkov@lmkia.ru' as email
 union all select '79506369324' as phone_number, 'elizaveta.yaskina@hyundai-al.ru' as email
 union all select '79826551654' as phone_number, 'rozalia.shaihaidarova@opel-al.ru' as email
 union all select '79027984204' as phone_number, 'balish.my@saturn-r.ru' as email
 union all select '79094081317' as phone_number, 'Reno-buh@aaanet.ru' as email
 union all select '79608958013' as phone_number, 'michail@asauto.ru' as email
 union all select '79610653233' as phone_number, 'eekovalchuk@asauto.ru' as email
 union all select '79608798466' as phone_number, 'ivrebrina@asauto.ru' as email
 union all select '79297474276' as phone_number, 'buhgalter@saranskmotors.ru' as email
 union all select '7926 5507592' as phone_number, 'mikhail.belov@aaron-auto.ru' as email
 union all select '79200752155' as phone_number, 'denisova.natalia@avtoliga.nnov.ru' as email
 union all select '79200639795' as phone_number, 'krasheninnikova.mariya@avtoliga.nnov.ru' as email
 union all select '79082307257' as phone_number, 'gracheva@avtoliga.nnov.ru' as email
 union all select '79308171027' as phone_number, 'gusarova@avtoliga.nnov.ru' as email
 union all select '79534156707' as phone_number, 'nikolai.nazarenko@avtoliga-group.ru' as email
 union all select '79198719615' as phone_number, 'anzelakamysnaa@gmail.com' as email
 union all select '79198719615' as phone_number, 'zp@gk-artex.ru' as email
 union all select '79198719615' as phone_number, 'payments@gk-artex.ru' as email
 union all select '79033874858' as phone_number, 'Khakimullina.A@tts.ru' as email
 union all select '79177778903' as phone_number, 'Gabbasova.Z@tts.ru' as email
 union all select '79081840845' as phone_number, 'o.babenko@kia-taganrog.ru' as email
 union all select '79298154338' as phone_number, 'e.andreeva@gedon.ru' as email
 union all select '79508602975' as phone_number, 'buhyy@vw-rostov.ru' as email
 union all select '79896138472' as phone_number, 'iapodoprigora@gedon.ru' as email
 union all select '79832697784' as phone_number, 'N.Karelina@sialauto.ru' as email
 union all select '79832697784' as phone_number, 'chou@sialauto.ru' as email
 union all select '79214300335' as phone_number, 'Anna.Senchenkova@autopremium.spb.ru' as email
 union all select '79217687194' as phone_number, 'Anna.Makrushina@autoskoda.spb.ru' as email
 union all select '79658145098' as phone_number, 'Anna.Panova@autopremium.spb.ru' as email
 union all select '9250429770' as phone_number, 'r.shchiptsov@tmgauto.ru' as email
 union all select '79631229627' as phone_number, 'Gimadeeva.R@tts.ru' as email
 union all select '79174220266' as phone_number, 'Hakimzyanova.K@tts.ru' as email
 union all select '79173885993' as phone_number, 'anzhelika.gaynetdinova@tts.ru' as email
 union all select '79033183953' as phone_number, 'Polikarpova.D@tts-kia.ru' as email
 union all select '79600327561' as phone_number, 'Guzel.Mannapova@tts-kia.ru' as email
 union all select '79289547142' as phone_number, 'k.grosheva@freshauto.ru' as email
 union all select '79173000004' as phone_number, 'director@elvis-kia.ru' as email
 union all select '79231961921' as phone_number, 'adakina.natalia@patriotauto.ru' as email
 union all select '79525219945' as phone_number, 'tgashkova@planeta-avto.ru' as email
 union all select '79025286509' as phone_number, 'glbuh.dv@gazdv.com' as email
 union all select '79644409775' as phone_number, 'economist@yuaz.ru' as email
 union all select '79227551173' as phone_number, 'tatyana.pashnina@vw-golfstream.ru' as email
 union all select '79263033483' as phone_number, 'dkozulin@autocentercity.ru' as email
 union all select '79169044435' as phone_number, 'emoiseeva@autocentercity.ru' as email
 union all select '79029400141' as phone_number, 'sychevskiy.av@jlr-westminster.ru' as email
 union all select '79029270778' as phone_number, 'strekalovskaya.aa@jrl-westminster.ru' as email	
) t1
where upper(t1.email) = upper(t0.email))
where t0.phone_number is null