<?php

use yii\db\Migration;

/**
 * Class m210615_140734_create_front_user_history
 */
class m210615_140734_create_front_user_history extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        
        // а) добавить в исходную таблицу поля
        $this->addColumn('front_user', 'deleted', $this->tinyInteger()->notNull()->defaultValue(0));
        $this->addColumn('front_user', 'change_number', $this->integer()->notNull()->defaultValue(1));
        // change_date = updated_at
        $this->addColumn('front_user', 'change_back_user_id', $this->integer());
        $this->addColumn('front_user', 'change_front_user_id', $this->integer());


        // б) добавить ограничения
        $this->execute('ALTER TABLE front_user ADD constraint front_user_ck_change_number check ( change_number >= 1)');
        $this->execute('ALTER TABLE front_user ADD constraint front_user_ck_deleted check ( deleted in ( 0, 1))');


        // в) добавить внешний ключ для change_user_id ссылающийся на user_id
        $this->addForeignKey('fk-front_user-change_back_user_id', 'front_user', 'change_back_user_id', 'back_user', 'id', 'NO ACTION', 'NO ACTION');
        $this->addForeignKey('fk-front_user-change_front_user_id', 'front_user', 'change_front_user_id', 'front_user', 'id', 'NO ACTION', 'NO ACTION');


        // г) добавить таблицу any_table_history, содержащую, собственно, историю изменений
        $this->execute('CREATE SEQUENCE front_user_history_id_seq');
        
        $this->createTable('front_user_history', [
            'user_history_id' => 'INT NOT NULL DEFAULT nextval(\'front_user_history_id_seq\'::regclass)',
            'id' => $this->integer()->notNull(),
            'email' => $this->string(128)->notNull(),
            'diasoft_id' => $this->string(16),
            'password_hash' => $this->string(128)->notNull(),
            'first_name' => $this->string(80),
            'middle_name' => $this->string(80),
            'last_name' => $this->string(80),
            'phone_number' => $this->string(30),
            'key_word' => $this->string(30),
            'created_at' => $this->timestamp(0)->notNull(), // date_ins
            'updated_at' => $this->timestamp(0)->notNull(), // change_date
            'self_updated_at' => 'timestamp(0) without time zone DEFAULT NULL::timestamp without time zone',
            'search_name' => $this->string(256),
            'failed_auth_attempt_count' => $this->tinyInteger()->notNull()->defaultValue(0),
            'block_reason' => $this->tinyInteger()->notNull()->defaultValue(0),
            'deleted' => $this->tinyInteger()->notNull()->defaultValue(0),
            'change_number' => $this->integer()->notNull()->defaultValue(1),
            'change_back_user_id' => $this->integer(),
            'change_front_user_id' => $this->integer(),
            'insert_back_user_id' => $this->integer()->notNull()->defaultValue(0),
            'date_ins' => 'TIMESTAMP DEFAULT current_timestamp NOT NULL'
        ]);


        // д) добавить ограничение в исторической таблице
        $this->execute('ALTER TABLE front_user_history ADD constraint front_user_history_uk unique (user_history_id, change_number)');

        // е) добавить в исторической таблице внешние ключи для
        $this->addForeignKey('fk-front_user_history-change_back_user_id', 'front_user_history', 'change_back_user_id', 'back_user', 'id', 'NO ACTION', 'NO ACTION');
        $this->addForeignKey('fk-front_user_history-change_front_user_id', 'front_user_history', 'change_front_user_id', 'front_user', 'id', 'NO ACTION', 'NO ACTION');
        $this->addForeignKey('fk-front_user_history-insert_back_user_id', 'front_user_history', 'insert_back_user_id', 'back_user', 'id', 'NO ACTION', 'NO ACTION');
        $this->addForeignKey('fk-front_user_history-id', 'front_user_history', 'id', 'front_user', 'id', 'NO ACTION', 'NO ACTION');

        // ж) Добавить процедуру записи исторической информации в таблицу
        $this->execute(file_get_contents(__DIR__ . '/m210615_140734_create_front_user_history__addFrontUserHistory.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_140734_create_front_user_history__addFrontUserHistory2.sql'));

        // з) добавить триггер исходной таблицы front_user
        $this->execute('DROP TRIGGER IF EXISTS front_user_bi_define ON front_user CASCADE');
        $this->execute(file_get_contents(__DIR__ . '/m210615_140734_create_front_user_history__front_user_bi_define_tf.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_140734_create_front_user_history__front_user_bi_define_tf2.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_140734_create_front_user_history__front_user_bi_define_tf3.sql'));

        // з) добавить триггер для исходной таблицы front_user записывающий изменения в историческую таблицу front_user_history
        $this->execute('DROP TRIGGER IF EXISTS front_user_bu_history ON front_user CASCADE');
        $this->execute(file_get_contents(__DIR__ . '/m210615_140734_create_front_user_history__front_user_bu_history_tf.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_140734_create_front_user_history__front_user_bu_history_tf2.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_140734_create_front_user_history__front_user_bu_history_tf3.sql'));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->execute('DROP TRIGGER IF EXISTS front_user_bu_history ON front_user CASCADE');  
        $this->execute('DROP FUNCTION IF EXISTS front_user_bu_history_tf');

        $this->execute('DROP TRIGGER IF EXISTS front_user_bi_define ON front_user CASCADE');
        $this->execute('DROP FUNCTION IF EXISTS front_user_bi_define_tf');

        $this->execute('DROP PROCEDURE addFrontUserHistory');

        $this->dropForeignKey('fk-front_user_history-id', 'front_user_history');
        $this->dropForeignKey('fk-front_user_history-insert_back_user_id', 'front_user_history');
        $this->dropForeignKey('fk-front_user_history-change_front_user_id', 'front_user_history');
        $this->dropForeignKey('fk-front_user_history-change_back_user_id', 'front_user_history');        

        $this->execute('ALTER TABLE front_user_history DROP constraint front_user_history_uk');        

        $this->dropTable('front_user_history');
        $this->execute('DROP SEQUENCE front_user_history_id_seq');
        
        $this->dropForeignKey('fk-front_user-change_front_user_id', 'front_user');
        $this->dropForeignKey('fk-front_user-change_back_user_id', 'front_user');

        $this->execute('ALTER TABLE front_user DROP constraint front_user_ck_deleted');
        $this->execute('ALTER TABLE front_user DROP constraint front_user_ck_change_number');
        
        $this->dropColumn('front_user', 'change_front_user_id');
        $this->dropColumn('front_user', 'change_back_user_id');
        $this->dropColumn('front_user', 'change_number');
        $this->dropColumn('front_user', 'deleted');
        
        return true;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210615_140734_create_front_user_history cannot be reverted.\n";

        return false;
    }
    */
}
