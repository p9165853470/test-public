CREATE OR REPLACE PROCEDURE addFrontUserHistory(
    IN  historyData     front_user_history
)
AS
$BODY$
/**
* Добавляет историческую запись в front_user_history.
*
* @param historyData    Данные исторической записи
*/
DECLARE
-- addFrontUserHistory
BEGIN
    INSERT INTO front_user_history(
        id
        , email
        , diasoft_id
        , password_hash
        , first_name
        , middle_name
        , last_name
        , phone_number
        , key_word
        , created_at
        , updated_at
        , self_updated_at
        , search_name
        , failed_auth_attempt_count
        , block_reason

        , deleted
        , change_number
        , change_back_user_id
        , change_front_user_id
        , insert_back_user_id
        , date_ins
    ) VALUES (
        historyData.id
        , historyData.email
        , historyData.diasoft_id
        , historyData.password_hash
        , historyData.first_name
        , historyData.middle_name
        , historyData.last_name
        , historyData.phone_number
        , historyData.key_word
        , historyData.created_at
        , historyData.updated_at
        , historyData.self_updated_at
        , historyData.search_name
        , historyData.failed_auth_attempt_count
        , historyData.block_reason

        , historyData.deleted
        , historyData.change_number
        , historyData.change_back_user_id
        , historyData.change_front_user_id
        , historyData.insert_back_user_id
        , historyData.date_ins
    );
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION '%: Ошибка при добавлении исторической записи в front_user_history (id=%)',-20150,front_user_history.id;
END
$BODY$
LANGUAGE 'plpgsql'
SECURITY DEFINER -- выполняется с правами создателя, т.к. будет запускаться не пользователем, а системой
;
