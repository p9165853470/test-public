-- noinspection SqlDialectInspectionForFile

-- noinspection SqlNoDataSourceInspectionForFile

CREATE OR REPLACE FUNCTION front_user_bi_define_tf()
RETURNS trigger
AS
$BODY$
/**
* Инициализация полей таблицы front_user при добавлении записи.
*
*/
DECLARE
-- front_user_bi_define_tf
BEGIN
    -- Определяем значение первичного ключа
    IF NEW.id is null THEN
        NEW.id = nextval('front_user_id_seq');
    END IF;

    -- Определяем дату добавления записи
    IF NEW.created_at is null THEN
        NEW.created_at = current_timestamp;
    END IF;

    -- Запись действующая по умолчанию
    IF NEW.deleted is null THEN
        NEW.deleted = 0;
    END IF;

    -- Определяем номер изменения
    IF NEW.change_number is null THEN
        NEW.change_number = 1;
    END IF;

    -- Определяем дату изменения записи
    IF NEW.updated_at is null THEN
        NEW.updated_at = NEW.created_at;
    END IF;

    -- ID оператора, изменившего запись
    IF NEW.change_back_user_id is null THEN
        NEW.change_back_user_id = NEW.insert_back_user_id;
    END IF;

    RETURN NEW;
END
$BODY$
LANGUAGE 'plpgsql';
