COMMENT ON FUNCTION front_user_bi_define_tf() IS 'Инициализация полей таблицы front_user при добавлении записи.';
