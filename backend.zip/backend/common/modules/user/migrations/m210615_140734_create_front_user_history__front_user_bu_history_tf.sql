CREATE OR REPLACE FUNCTION front_user_bu_history_tf()
RETURNS trigger
AS
$BODY$
/**
* Инициализация полей таблицы front_user при изменении записи и добавление информации в историческую таблицу front_user_history.
*
*/
DECLARE
  hs    front_user_history%rowtype;
-- front_user_bu_history_tf
BEGIN
    -- Определяем дату изменения записи
    NEW.updated_at = current_timestamp;

    -- Увеличиваем счетчик обновлений
    NEW.change_number = OLD.change_number + 1;
    
    -- Заполняем поля с данными
    hs.id = OLD.id;
    hs.email = OLD.email;
    hs.diasoft_id = OLD.diasoft_id;
    hs.password_hash = OLD.password_hash;
    hs.first_name = OLD.first_name;
    hs.middle_name = OLD.middle_name;
    hs.last_name = OLD.last_name;
    hs.self_updated_at = OLD.self_updated_at;
    hs.search_name = OLD.search_name;
    hs.failed_auth_attempt_count = OLD.failed_auth_attempt_count;
    hs.block_reason = OLD.block_reason;
    hs.phone_number = OLD.phone_number;
    hs.key_word = OLD.key_word;

    -- Устанавливаем служебные поля
    hs.deleted             = OLD.deleted;
    hs.change_number       = OLD.change_number;
    hs.updated_at         = OLD.updated_at;
    hs.change_back_user_id  = OLD.change_back_user_id;
    hs.change_front_user_id  = OLD.change_front_user_id;
    hs.created_at       = OLD.created_at;
    hs.insert_back_user_id = OLD.insert_back_user_id;
    hs.date_ins            = NEW.updated_at;
    
    -- Сохраняем старые данные
    CALL addFrontUserHistory(hs);

    RETURN NEW;
END
$BODY$
LANGUAGE 'plpgsql';
