CREATE TRIGGER front_user_bu_history
BEFORE UPDATE ON front_user
FOR EACH ROW EXECUTE PROCEDURE front_user_bu_history_tf();
