<?php

use yii\db\Migration;

/**
 * Class m210621_054504_add_validate_phone_date_to_front_user_table
 */
class m210621_054504_add_validate_phone_date_to_front_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%front_user}}', 'validate_phone_date', $this->timestamp()->null());
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user}}', 'validate_phone_date');
        return true;
    }

}
