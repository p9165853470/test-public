<?php

namespace common\modules\user\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\behaviors\ModelHasRepositoryTrait;
use common\exceptions\NotFoundModelException;
use common\modules\audit\behaviors\AuditInitiatorInterface;
use common\modules\audit\components\AuditTag;
use common\modules\password\helpers\PasswordGenerator;
use common\modules\password\services\FrontUserPasswordService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\behaviors\IdentityTrait;
use common\modules\user\enums\BlockReasonEnum;
use common\modules\user\repositories\FrontUserRepository;
use common\modules\user\scopes\FrontUserQuery;
use Yii;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property string $email
 * @property string $diasoft_id
 * @property string $password_hash
 * @property string|null $first_name
 * @property string|null $middle_name
 * @property string|null $last_name
 * @property string $phone_number
 * @property string $key_word
 * @property string $created_at
 * @property string $updated_at
 * @property Dealer[] $dealers
 * @property string $deleted_at
 * @property string $self_updated_at
 * @property string $search_name
 * @property int $failed_auth_attempt_count
 * @property int $block_reason
 * @property int $change_front_user_id
 * @property int $change_back_user_id
 * @property int $insert_back_user_id
 * @property string $validate_phone_date
 *
 * @method static FrontUserRepository getRepository()
 * @method void touch($attribute)
 */
class FrontUser extends ActiveRecord implements IdentityInterface, ModelHasRepositoryInterface, AuditInitiatorInterface
{
    use IdentityTrait;
    use ModelHasRepositoryTrait;

    /**
     * Требуемая длина пароля
     * @todo Вынести в конфиг
     */
    public const PASSWORD_LENGTH = 8;
    /**
     * Группы символов в пароле для генерации/валидации
     * @todo Вынести в конфиг
     */
    public const PASSWORD_GROUPS = PasswordGenerator::GROUP_DGT | PasswordGenerator::GROUP_LLT | PasswordGenerator::GROUP_ULT;
    /**
     * Макс. кол-во неудачных попыток аутентификаций подряд перед блокировкой
     * @todo Вынести в конфиг
     */
    public const FAILED_AUTH_ATTEMPT_LIMIT = 5;

    public static function find(): FrontUserQuery
    {
        return new FrontUserQuery(static::class);
    }

    public static function getRepositoryClass(): string
    {
        return FrontUserRepository::class;
    }

    /**
     * @param string $login
     * @return IdentityInterface|ActiveRecord|null
     */
    public static function findIdentityByLogin(string $login): ?IdentityInterface
    {
        try {
            return static::getRepository()->findOneByEmail($login);
        } catch (NotFoundModelException $ex) {
            return null;
        }
    }

    public function isActive(): bool
    {
        return true;
    }

    public function hasBlock(int $reason = null): bool
    {
        if ($reason !== null) {
            return $this->block_reason === $reason;
        }

        return $this->block_reason !== BlockReasonEnum::NO_REASON;
    }

    public function setPassword(string $password): void
    {
        $this->password_hash = FrontUserPasswordService::instance()->generatePasswordHash($password);
    }

    public function validatePassword(string $password): bool
    {
        return strcmp($this->password_hash, FrontUserPasswordService::instance()->generatePasswordHash($password)) === 0;
    }

    public function getAuditTag(): AuditTag
    {
        return new AuditTag($this->id, $this->email);
    }

    public function behaviors(): array
    {
        return [
            TimestampBehavior::class,
        ];
    }

    public function fields(): array
    {
        return [
            'id',
            'email',
            'first_name',
            'middle_name',
            'last_name',
            'phone_number',
            'key_word',
            'created_at',
            'updated_at',
            'dealers',
            'block_reason',
            'active' => static function (self $model) {
                return $model->isActive();
            },
            'phone_number',
            'validate_phone_date',
        ];
    }

    public function getFullName(): string
    {
        return implode(' ', array_filter([
            $this->last_name,
            $this->first_name,
            $this->middle_name,
        ]));
    }

    public function beforeSave($insert): bool
    {
        $result = parent::beforeSave($insert);

        if ($result) {
            $this->composeSearchName();
        }

        $identity = Yii::$app->getUser()->getIdentity();
        if ($identity != null) {
            if (is_a($identity, "common\modules\user\models\FrontUser"))
                $this->change_front_user_id = $identity->getId();
            elseif (is_a($identity, "common\modules\user\models\BackUser"))
                $this->change_back_user_id = $identity->getId();
            if ($insert)
                $this->insert_back_user_id = $this->change_back_user_id = $identity->getId();
        }
        return $result;
    }

    public function getDealers(): ActiveQuery
    {
        return $this->hasMany(Dealer::class, ['user_id' => 'id']);
    }

    protected function composeSearchName(): void
    {
        $this->search_name = mb_strtolower($this->getFullName());
        $this->search_name = str_replace('ё', 'е', $this->search_name);
    }

    /**
     * @param Dealer[] $dealers
     */
    public function setDealers(array $dealers)
    {
        // TODO surprisingly this method is being invoked with 'array of arrays' parameter, instead of 'array of Dealer'.
        // TODO so, convert each array to Dealer object manually and then set the $this->dealers property
        $dealersTmp = array();
        
        foreach ($dealers as $dealerArray) {
            $dealer = new Dealer();
            foreach ($dealerArray as $key => $value) {
                $dealer->$key = $value;
            }
            $dealersTmp[] = $dealer;
        }

        $this->dealers = $dealersTmp;
    }
    
    
    
    public function afterSave($insert, $changedAttributes)
    {
        Yii::warning('FrontUser.afterSave() BEGIN');
        $identity = Yii::$app->getUser()->getIdentity();
        Yii::warning('FrontUser.afterSave(): $identity = '.print_r($identity, true));
        if ($identity != null) {
        $currentUserId = $identity->getId();

        Yii::warning('FrontUser.afterSave(): $this->dealers = '.print_r($this->dealers, true));
        foreach ($this->dealers as $dealer) {
            Yii::warning('FrontUser.afterSave(): $dealer = '.print_r($dealer, true));

            $diasoftId = $dealer->diasoft_id;

            $dealerExisting = Dealer::find()->where(['user_id' => $this->id, 'diasoft_id' => $diasoftId])->one();

            if ($dealerExisting != null) {
                // update existing
                
                // copy all fields
                foreach ($dealer as $key => $value) {
                    $dealerExisting->$key = $value;
                }
                
                $dealerExisting->authority_begin_date = $dealer->authority_begin_date;
                $dealerExisting->authority_end_date = $dealer->authority_end_date;
                $dealerExisting->updated_at = date("Y-m-d H:i:s");

                $dealerExisting->save();
            } else {
                // create new

                $dealer->user_id = $this->id;
                $dealer->change_back_user_id = $currentUserId;
                $dealer->insert_back_user_id = $currentUserId;
                $dealer->created_at = date("Y-m-d H:i:s");
                $dealer->updated_at = date("Y-m-d H:i:s");

                $dealer->save();
            }
        }
        }
        
        parent::afterSave($insert, $changedAttributes);
        Yii::warning('FrontUser.afterSave() END');
    }
    
    public function getDealer(): ?Dealer
    {
        trace('FrontUser.getDealer() BEGIN debug_backtrace() = '.print_r(debug_backtrace(2), true));

        $userId = $this->getId();
        trace('FrontUser.getDealer() BEGIN $userId = '. print_r($userId, true));
        $diasoftId = $this->getToken()->getSession()->getDiasoftId();
        trace('FrontUser.getDealer() BEGIN $diasoftId = '. print_r($diasoftId, true));
        $dealer = Dealer::find()->where(['user_id' => $userId, 'diasoft_id' => $diasoftId])->one();
        trace('FrontUser.getDealer() END: gettype($dealer) = '.gettype($dealer));
        trace('FrontUser.getDealer() END: $dealer = '.$dealer);
        trace('FrontUser.getDealer() END: $dealer[\'name\'] = '. print_r($dealer['name'], true));

        return $dealer;

//        $dealer = new Dealer();
//        $dealer->user_code_id = 12;
//        $dealer->user_id = 186;
//        $dealer->diasoft_id = '2845QW5T0';
//        $dealer->authority_begin_date = '2021-07-08';
//        $dealer->authority_end_date = '2026-07-08';
//        $dealer->created_at = '2021-07-08 00:00:00';
//        $dealer->updated_at = '2021-07-25 18:06:50.452079';
//        $dealer->agreement_at = '2021-07-12 12:16:29';
//        $dealer->validated_at = '2021-07-12 12:16:08';
//        $dealer->insert_back_user_id = 21;
//        $dealer->date_ins = '2021-07-08 00:00:00';
//        $dealer->deleted = 0;
//        $dealer->change_number = 127;
//        $dealer->change_date = '2021-07-09 16:22:00.77692';
//        $dealer->change_back_user_id = 21;
//        $dealer->change_front_user_id = null;
//        return $dealer;
    }
}

function trace(string $message) {
    file_put_contents('/opt/backend/frontend/runtime/logs/ib4d.log', date('H:i:s')."\t".$message."\n", FILE_APPEND);
}
