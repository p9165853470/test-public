<?php

namespace common\modules\user\repositories;

use common\exceptions\NotFoundModelException;
use common\modules\user\models\BackUser;
use common\modules\user\scopes\BackUserQuery;
use common\repositories\Repository;

/**
 * @method BackUser model()
 * @method BackUser findOne($condition = null)
 * @method BackUser[] findAll($condition = null)
 * @method BackUserQuery find($condition = null)
 */
class BackUserRepository extends Repository
{
    public function getModelClass(): string
    {
        return BackUser::class;
    }

    /**
     * @param string $email
     * @return BackUser
     * @throws NotFoundModelException
     */
    public function findOneByEmail(string $email): BackUser
    {
        /** @var BackUser|null $model */
        $model = $this->find()->email($email)->one();

        if ($model === null) {
            throw new NotFoundModelException('Model not found by email: ' . $email);
        }

        return $model;
    }

    public function existsEmail(string $email, ?int $withoutId): bool
    {
        return $this->find()
            ->email($email)
            ->andFilterWhere(['!=', 'id', $withoutId])
            ->exists();
    }
}