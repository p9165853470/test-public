<?php

namespace common\modules\user\repositories;

use common\exceptions\NotFoundModelException;
use common\helpers\Date;
use common\modules\user\models\FrontUser;
use common\modules\user\scopes\FrontUserQuery;
use common\repositories\Repository;

/**
 * @method FrontUser model()
 * @method FrontUser findOne($condition = null)
 * @method FrontUser[] findAll($condition = null)
 * @method FrontUserQuery find($condition = null)
 */
class FrontUserRepository extends Repository
{
    public function getModelClass(): string
    {
        return FrontUser::class;
    }

    /**
     * @param string $email
     * @return FrontUser
     * @throws NotFoundModelException
     */
    public function findOneByEmail(string $email): FrontUser
    {
        /** @var FrontUser|null $model */
        $model = $this->find()->email($email)->one();

        if ($model === null) {
            throw new NotFoundModelException('Model not found by email: ' . $email);
        }

        return $model;
    }

    public function updateBlockAll(array $ids, int $reason): int
    {
        return FrontUser::updateAll([
            'block_reason' => $reason,
            'updated_at' => date_create()->format(Date::INTERNAL_DATETIME_FORMAT),
        ], [
            'and',
            ['id' => $ids],
            ['!=', 'block_reason', $reason]
        ]);
    }

    public function existsEmail(string $email, ?int $withoutId): bool
    {
        return $this->find()
            ->email($email)
            ->andFilterWhere(['!=', 'id', $withoutId])
            ->exists();
    }
}