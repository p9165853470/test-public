<?php

namespace common\modules\user\scopes;

use yii\db\ActiveQuery;

class BackUserQuery extends ActiveQuery
{
    public function email(string $email): self
    {
        return $this->andWhere('LOWER([[email]]) = :email', ['email' => mb_strtolower($email)]);
    }
}