<?php

namespace common\modules\variable\actions;

use common\modules\variable\behaviors\VariableFactoryInterface;
use common\modules\variable\behaviors\VariableModelInterface;
use common\modules\variable\services\VariableService;
use yii\base\Action;
use yii\base\InvalidArgumentException;
use yii\base\Model;
use yii\web\BadRequestHttpException;
use yii\web\ForbiddenHttpException;
use yii\web\Request;

class UpdateAction extends Action
{
    /**
     * @var VariableService
     */
    protected $service;
    /**
     * @var VariableFactoryInterface
     */
    protected $factory;

    public function __construct($id, $controller, VariableService $service, VariableFactoryInterface $factory, $config = [])
    {
        $this->service = $service;
        $this->factory = $factory;

        parent::__construct($id, $controller, $config);
    }

    /**
     * Изменить значение variable
     *
     * @param Request $request
     * @param string $key
     * @return VariableModelInterface|Model
     * @throws BadRequestHttpException
     * @throws ForbiddenHttpException
     */
    public function run(Request $request, string $key)
    {
        try {
            /** @var VariableModelInterface|Model $model */
            $model = $this->factory->getModel($key);
        } catch (InvalidArgumentException $ex) {
            throw new BadRequestHttpException($ex->getMessage());
        }

        $model->serVariableData(
            $this->service->get($key)
        );

        if (!$model->load($request->post())) {
            throw new ForbiddenHttpException('No input data.');
        }

        if ($model->validate()) {
            $this->service->set($key, $model->getVariableData());
        }
        return $model;
    }
}