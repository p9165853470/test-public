<?php

namespace common\modules\variable\actions;

use common\exceptions\NotFoundModelException;
use common\modules\storage\resources\FileResource;
use common\modules\variable\forms\UploadForm;
use common\modules\variable\services\UploadService;
use common\modules\variable\services\VariableService;
use yii\base\Action;
use yii\web\UploadedFile;

class UploadAction extends Action
{
    /**
     * @var VariableService
     */
    protected $service;
    /**
     * @var UploadService
     */
    protected $uploadService;

    public function __construct($id, $controller, VariableService $service, UploadService $uploadService, $config = [])
    {
        $this->service = $service;
        $this->uploadService = $uploadService;

        parent::__construct($id, $controller, $config);
    }

    public function run(string $key)
    {
        try {
            $model = $this->service->findOneByKey($key);
        } catch (NotFoundModelException $ex) {
            $model = $this->service->create($key);
        }

        $form = new UploadForm();
        $form->file = UploadedFile::getInstance($form, 'file');

        if ($form->validate()) {
            return new FileResource(
                $this->uploadService->upload($model, $form->file, $model->key)
            );
        }

        return $form;
    }
}