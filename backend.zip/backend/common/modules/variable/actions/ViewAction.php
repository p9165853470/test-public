<?php

namespace common\modules\variable\actions;

use common\modules\variable\behaviors\VariableFactoryInterface;
use common\modules\variable\behaviors\VariableModelInterface;
use common\modules\variable\services\VariableService;
use yii\base\Action;
use yii\base\InvalidArgumentException;
use yii\base\Model;
use yii\web\BadRequestHttpException;

class ViewAction extends Action
{
    /**
     * @var VariableService
     */
    protected $service;
    /**
     * @var VariableFactoryInterface
     */
    protected $factory;

    public function __construct($id, $controller, VariableService $service, VariableFactoryInterface $factory, $config = [])
    {
        $this->service = $service;
        $this->factory = $factory;

        parent::__construct($id, $controller, $config);
    }

    /**
     * Получить значение variable
     *
     * @param string $key
     * @return VariableModelInterface|Model
     * @throws BadRequestHttpException
     */
    public function run(string $key)
    {
        try {
            /** @var VariableModelInterface|Model $model */
            $model = $this->factory->getModel($key);
        } catch (InvalidArgumentException $ex) {
            throw new BadRequestHttpException($ex->getMessage());
        }

        $model->serVariableData(
            $this->service->get($key)
        );

        return $model;
    }
}