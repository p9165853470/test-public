<?php

namespace common\modules\variable\behaviors;

use yii\base\InvalidArgumentException;

interface VariableFactoryInterface
{
    /**
     * @param string $key
     * @return VariableModelInterface
     * @throws InvalidArgumentException
     */
    public function getModel(string $key): VariableModelInterface;
}