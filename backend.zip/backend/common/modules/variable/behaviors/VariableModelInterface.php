<?php

namespace common\modules\variable\behaviors;

interface VariableModelInterface
{
    /**
     * Данные для сериализации
     *
     * @return mixed
     */
    public function getVariableData();

    /**
     * Данные после сериализации
     *
     * @param mixed $data
     */
    public function serVariableData($data): void;
}