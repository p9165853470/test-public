<?php

namespace common\modules\variable\behaviors;

trait VariableModelTrait
{
    public function getVariableData()
    {
        return $this->toArray();
    }

    public function serVariableData($data): void
    {
        if (is_array($data)) {
            $this->load($data);
        }
    }
}