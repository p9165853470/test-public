<?php

namespace common\modules\variable\enums;

use common\behaviors\EnumTrait;

class VariableEnum
{
    use EnumTrait;

    public const REQUISITES = 'requisites';
    public const INSTRUCTION = 'instruction';
    public const REMINDER = 'reminder';
    public const CONTACTS = 'contacts';
    public const FEEDBACK = 'feedback';
    public const TARIFFS = 'tariffs';
    public const AGREEMENT = 'agreement';
    public const SETTINGS = 'settings';

    public static function getLabels(): array
    {
        return [
            self::REQUISITES => 'Реквизиты',
            self::INSTRUCTION => 'Инструкция',
            self::REMINDER => 'Памятка',
            self::CONTACTS => 'Контакты',
            self::FEEDBACK => 'Обратная связь',
            self::TARIFFS => 'Тарифы',
            self::AGREEMENT => 'Пользовательское соглашение',
            self::SETTINGS => 'Настройки',
        ];
    }
}