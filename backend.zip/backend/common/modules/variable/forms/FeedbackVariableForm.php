<?php

namespace common\modules\variable\forms;

use common\modules\variable\behaviors\VariableModelInterface;
use common\modules\variable\behaviors\VariableModelTrait;
use yii\base\Model;

class FeedbackVariableForm extends Model implements VariableModelInterface
{
    use VariableModelTrait;

    /**
     * @var array
     */
    public $debt_service = [];
    /**
     * @var array
     */
    public $account_maintenance = [];
    /**
     * @var array
     */
    public $technical_issue = [];
    /**
     * @var array
     */
    public $other = [];

    public function rules(): array
    {
        return [
            [
                $this->attributes(),
                function ($attribute) {
                    if (!is_array($this->{$attribute})) {
                        $this->addError($attribute, "Property '{$attribute}' must be an array.");
                    }
                }
            ],
            [$this->attributes(), 'each', 'rule' => ['email']],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}