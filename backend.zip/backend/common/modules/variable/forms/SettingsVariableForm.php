<?php

namespace common\modules\variable\forms;

use common\modules\variable\behaviors\VariableModelInterface;
use common\modules\variable\behaviors\VariableModelTrait;
use yii\base\Model;

class SettingsVariableForm extends Model implements VariableModelInterface
{
    use VariableModelTrait;

    protected const TIME_FORMAT = 'HH:mm';

    /**
     * @var string
     */
    public $work_begin_time;
    /**
     * @var string
     */
    public $work_end_time;
    /**
     * @var array|SettingsWeekDayForm
     */
    public $work_week_days;
    /**
     * @var string
     */
    public $uncheck_tranche_in_work_time;
    /**
     * @var string
     */
    public $uncheck_tranche_out_work_time;

    public function init(): void
    {
        parent::init();

        $this->initWeekDayForm();
    }

    public function beforeValidate(): bool
    {
        $result = parent::beforeValidate();

        if ($result) {
            $this->initWeekDayForm();
        }
        return $result;
    }

    public function rules(): array
    {
        return [
            [
                ['work_begin_time', 'work_end_time', 'uncheck_tranche_in_work_time', 'uncheck_tranche_out_work_time'],
                'required',
            ],
            [
                ['work_begin_time', 'work_end_time', 'uncheck_tranche_in_work_time', 'uncheck_tranche_out_work_time'],
                'date',
                'format' => self::TIME_FORMAT,
            ],
            [
                'work_week_days',
                function () {
                    if (!$this->work_week_days->validate()) {
                        $attribute = key($this->work_week_days->getErrors());
                        $error = $this->work_week_days->getFirstError($attribute);

                        $this->addError('work_week_days', $error);
                    }
                }
            ]
        ];
    }

    protected function initWeekDayForm(): void
    {
        if (!$this->work_week_days instanceof SettingsWeekDayForm) {
            $form = new SettingsWeekDayForm();

            if (is_array($this->work_week_days)) {
                $form->load($this->work_week_days);
            }
            $this->work_week_days = $form;
        }
    }

    public function formName(): string
    {
        return '';
    }
}