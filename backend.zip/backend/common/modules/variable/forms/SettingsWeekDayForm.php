<?php

namespace common\modules\variable\forms;

use yii\base\Model;

class SettingsWeekDayForm extends Model
{
    public $mon = false;
    public $tue = false;
    public $wed = false;
    public $thu = false;
    public $fri = false;
    public $sat = false;
    public $sun = false;

    public function rules(): array
    {
        return [
            [$this->attributes(), 'required'],
            [$this->attributes(), 'boolean'],
            [$this->attributes(), 'filter', 'filter' => 'boolval'],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}