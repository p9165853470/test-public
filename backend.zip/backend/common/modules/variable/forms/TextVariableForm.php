<?php

namespace common\modules\variable\forms;

use common\modules\variable\behaviors\VariableModelInterface;
use common\modules\variable\behaviors\VariableModelTrait;
use yii\base\Model;

class TextVariableForm extends Model implements VariableModelInterface
{
    use VariableModelTrait;

    /**
     * @var string
     */
    public $text;

    public function rules(): array
    {
        return [
            ['text', 'default'],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}