<?php

namespace common\modules\variable\forms;

use yii\base\Model;
use yii\web\UploadedFile;

class UploadForm extends Model
{
    /**
     * @var UploadedFile|null
     */
    public $file;

    public function rules(): array
    {
        return [
            ['file', 'required'],
            ['file', 'image'],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}