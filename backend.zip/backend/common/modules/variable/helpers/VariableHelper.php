<?php

namespace common\modules\variable\helpers;

use common\helpers\StaticInstanceHelper;
use common\modules\variable\services\VariableService;
use yii\di\Instance;

/**
 * @method static mixed get(string $key, mixed $defaultValue = null)
 * @method static bool set(string $key, mixed $value)
 * @method static bool unset(string $key)
 */
class VariableHelper extends StaticInstanceHelper
{
    protected static function getInstance(): object
    {
        return Instance::ensure(VariableService::class);
    }
}