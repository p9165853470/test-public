<?php

namespace common\modules\variable\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\behaviors\ModelHasRepositoryTrait;
use common\modules\storage\models\File;
use common\modules\variable\enums\VariableEnum;
use common\modules\variable\repositories\VariableRepository;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property string $key
 * @property string $value
 * @property string $created_at
 * @property string $updated_at
 *
 * @property-read File[] $files
 *
 * @method static VariableRepository getRepository()
 */
class Variable extends ActiveRecord implements ModelHasRepositoryInterface
{
    use ModelHasRepositoryTrait;

    public static function getRepositoryClass(): string
    {
        return VariableRepository::class;
    }

    public function behaviors(): array
    {
        return [
            TimestampBehavior::class,
        ];
    }

    public function rules(): array
    {
        return [
            ['key', 'required'],
            ['key', 'string', 'max' => 32],
            ['key', 'in', 'range' => VariableEnum::getRange()],
            ['key', 'unique'],
            ['value', 'default'],
        ];
    }

    public function getFiles(): ActiveQuery
    {
        return $this->hasMany(File::class, ['group_code' => 'key', 'owner_id' => 'id']);
    }
}