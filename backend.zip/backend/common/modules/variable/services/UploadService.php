<?php

namespace common\modules\variable\services;

use common\modules\storage\behaviors\UploadServiceInterface;
use common\modules\storage\behaviors\UploadServiceTrait;
use common\modules\storage\services\FileService;
use common\modules\variable\repositories\VariableRepository;

class UploadService implements UploadServiceInterface
{
    use UploadServiceTrait;

    /**
     * @var VariableRepository
     */
    protected $repository;

    public function __construct(VariableRepository $repository, FileService $fileService)
    {
        $this->repository = $repository;
        $this->fileService = $fileService;
    }
}