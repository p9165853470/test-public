<?php

namespace common\modules\variable\services;

use common\modules\variable\behaviors\VariableSerializerInterface;
use DateTimeInterface;

class VariableSerializer implements VariableSerializerInterface
{

    public function serialize($data)
    {
        return serialize($data);
    }

    public function deserialize($data)
    {
        try {
            return unserialize($data, ['allow_classes' => false]);
        } catch (\Throwable $ex) {
            \Yii::error($ex);
            return null;
        }
    }
}