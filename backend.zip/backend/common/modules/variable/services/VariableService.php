<?php

namespace common\modules\variable\services;

use common\behaviors\EventSenderTrait;
use common\exceptions\NotFoundModelException;
use common\exceptions\SaveModelException;
use common\modules\variable\behaviors\VariableFactoryInterface;
use common\modules\variable\behaviors\VariableSerializerInterface;
use common\modules\variable\events\VariableServiceEvent;
use common\modules\variable\models\Variable;
use common\modules\variable\repositories\VariableRepository;

class VariableService
{
    public const EVENT_AFTER_SET = 'afterSet';
    public const EVENT_AFTER_UNSET = 'afterUnset';

    use EventSenderTrait;

    /**
     * @var VariableRepository
     */
    protected $repository;
    /**
     * @var VariableSerializerInterface
     */
    protected $serializer;
    /**
     * @var VariableFactoryInterface
     */
    protected $factory;

    public function __construct(VariableRepository $repository, VariableSerializerInterface $serializer, VariableFactoryInterface $factory)
    {
        $this->repository = $repository;
        $this->serializer = $serializer;
        $this->factory = $factory;
    }

    public function getFactory(): VariableFactoryInterface
    {
        return $this->factory;
    }

    public function findOneByKey(string $key): Variable
    {
        return $this->repository->findOneByKey($key);
    }

    public function create(string $key): Variable
    {
        $model = $this->repository->model();
        $model->key = $key;
        $model->value = null;

        $this->repository->save($model);

        return $model;
    }

    public function get(string $key, $defaultValue = null)
    {
        try {
            return $this->serializer->deserialize($this->repository->findOneByKey($key)->value);
        } catch (NotFoundModelException $ex) {
            return $defaultValue;
        }
    }

    public function set(string $key, $value): bool
    {
        try {
            $model = $this->repository->findOneByKey($key);
        } catch (NotFoundModelException $ex) {
            $model = $this->repository->model();
            $model->key = $key;
        }
        $model->value = $this->serializer->serialize($value);

        try {
            $this->repository->save($model);
        } catch (SaveModelException $ex) {
            \Yii::error($ex);
            return false;
        }

        $this->trigger(self::EVENT_AFTER_SET, new VariableServiceEvent(['model' => $model]));

        return true;
    }

    public function unset(string $key): bool
    {
        try {
            $model = $this->repository->findOneByKey($key);
        } catch (NotFoundModelException $ex) {
            return false;
        }

        $this->repository->delete($model);

        $this->trigger(self::EVENT_AFTER_UNSET, new VariableServiceEvent(['model' => $model]));

        return true;
    }
}