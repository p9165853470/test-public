<?php

namespace common\repositories;

use common\behaviors\SoftDeleteInterface;
use common\exceptions\DeleteModelException;
use common\exceptions\NotFoundModelException;
use common\exceptions\SaveModelException;
use ProxyManager\Proxy\ProxyInterface;
use Yii;
use yii\base\InvalidArgumentException;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;
use yii\helpers\ArrayHelper;

abstract class Repository
{
    /**
     * @return string|ActiveRecord
     */
    abstract public function getModelClass(): string;

    /**
     * @return ActiveRecord|object
     */
    public function model()
    {
        return Yii::createObject($this->getModelClass());
    }

    /**
     * @return ActiveQuery
     */
    protected function query()
    {
        return $this->getModelClass()::find();
    }

    /**
     * @param $condition
     * @return ActiveQuery
     */
    protected function findByCondition($condition)
    {
        $query = $this->query();

        if (!ArrayHelper::isAssociative($condition)) {
            $primaryKey = $this->getModelClass()::primaryKey();
            $condition = [$primaryKey[0] => is_array($condition) ? array_values($condition) : $condition];
        }
        return $query->andWhere($condition);
    }

    /**
     * @param $condition
     * @return ActiveQuery
     */
    public function find($condition = null)
    {
        $query = $this->query();

        if ($condition !== null) {
            $query->andWhere($condition);
        }
        return $query;
    }

    /**
     * @param $condition
     * @return ActiveRecord
     * @throws NotFoundModelException
     */
    public function findOne($condition = null)
    {
        if ($condition === null) {
            $query = $this->query();
        } else {
            $query = $this->findByCondition($condition);
        }
        $model = $query->one();

        if ($model === null) {
            throw new NotFoundModelException('Model not found.');
        }
        return $model;
    }

    /**
     * @param $condition
     * @return ActiveRecord[]
     */
    public function findAll($condition = null)
    {
        if ($condition === null) {
            $query = $this->query();
        } else {
            $query = $this->findByCondition($condition);
        }
        return $query->all();
    }

    /**
     * @param ActiveRecord $model
     * @throws SaveModelException
     */
    public function save($model): void
    {
        $this->validateModel($model);

        if (!$model->save()) {
            if ($model->hasErrors()) {
                $message = $model->getFirstError(key($model->getErrors()));
            } else {
                $message = 'Unable to save the model.';
            }
            throw new SaveModelException($message);
        }
    }

    /**
     * @param ActiveRecord $model
     * @throws DeleteModelException
     */
    public function delete($model): void
    {
        $this->validateModel($model);

        if (!$model->delete() && !($model instanceof SoftDeleteInterface && $model->isSoftDeleted())) {
            throw new DeleteModelException('Unable to delete the model.');
        }
    }

    /**
     * @param ActiveRecord $model
     * @throws InvalidArgumentException
     */
    protected function validateModel($model): void
    {
        $expectModelClass = $this->getModelClass();

        if ($model instanceof ProxyInterface) {
            $modelClass = get_parent_class($model);
        } else {
            $modelClass = get_class($model);
        }

        if ($modelClass !== $expectModelClass) {
            throw new InvalidArgumentException('Model must be instance of "' . $expectModelClass . '".');
        }
    }
}