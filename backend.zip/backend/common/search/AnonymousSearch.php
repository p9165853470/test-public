<?php

namespace common\search;

use yii\db\ActiveQuery;

class AnonymousSearch extends Search
{
    /**
     * @var ActiveQuery
     */
    protected $query;

    public function __construct(ActiveQuery $query, $config = [])
    {
        $this->query = $query;

        parent::__construct($config);
    }

    /**
     * @inheritDoc
     */
    protected function query()
    {
        return $this->query;
    }
}