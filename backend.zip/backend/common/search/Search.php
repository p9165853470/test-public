<?php

namespace common\search;

use common\data\ActiveDataProvider;
use yii\base\Model;
use yii\data\DataProviderInterface;
use yii\data\Pagination;
use yii\data\Sort;
use yii\db\ActiveQuery;

abstract class Search extends Model
{
    public function rules(): array
    {
        return [
            [$this->attributes(), 'safe'],
        ];
    }

    public function search(array $params = []): DataProviderInterface
    {
        $this->load($params);
        $this->validate();

        $query = $this->query();
        $this->applyFilter($query);

        return $this->dataProvider($query);
    }

    /**
     * @return ActiveQuery
     */
    abstract protected function query();

    /**
     * @return array|false|Sort
     */
    protected function sort()
    {
        return [];
    }

    /**
     * @return array|false|Pagination
     */
    public function pagination()
    {
        return [];
    }

    /**
     * @param ActiveQuery $query
     * @return DataProviderInterface
     */
    protected function dataProvider($query): DataProviderInterface
    {
        return new ActiveDataProvider([
            'query' => $query,
            'sort' => $this->sort(),
            'pagination' => $this->pagination(),
            'resourceClass' => $this->resourceClass(),
        ]);
    }

    /**
     * @param ActiveQuery $query
     */
    protected function applyFilter($query): void
    {

    }

    protected function resourceClass(): ?string
    {
        return null;
    }

    public function formName(): string
    {
        return '';
    }
}