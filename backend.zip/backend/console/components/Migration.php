<?php

namespace console\components;

class Migration extends \yii\db\Migration
{
    public function createIndexNamed(string $table, $columns, bool $unique = false): void
    {
        $this->createIndex(
            $this->makeIndexName($table, $columns, $unique), $table, $columns, $unique
        );
    }

    public function dropIndexNamed(string $table, $columns, bool $unique = false): void
    {
        $this->dropIndex(
            $this->makeIndexName($table, $columns, $unique), $table
        );
    }

    public function addForeignKeyNamed(string $table, $columns, string $refTable, $refColumns, string $delete = null, string $update = null): void
    {
        $this->addForeignKey(
            $this->makeForeignKeyName($table, $columns, $refTable, $refColumns),
            $table,
            $columns,
            $refTable,
            $refColumns,
            $delete,
            $update
        );
    }

    public function dropForeignKeyNamed(string $table, $columns, string $refTable, $refColumns): void
    {
        $this->dropForeignKey(
            $this->makeForeignKeyName($table, $columns, $refTable, $refColumns),
            $table
        );
    }

    protected function makeForeignKeyName(string $table, $columns, string $refTable, $refColumns): string
    {
        return $this->makeName(array_merge(
            ['fk', $table], (array)$columns, [$refTable], (array)$refColumns
        ));
    }

    protected function makeIndexName(string $table, $columns, bool $unique = false): string
    {
        return $this->makeName(array_merge(
            [$unique ? 'unq' : 'idx', $table], (array)$columns
        ));
    }

    protected function makeName(array $params): string
    {
        return implode('-', array_map(static function (string $param) {
            return preg_replace('/\W+/', '', $param);
        }, $params));
    }
}