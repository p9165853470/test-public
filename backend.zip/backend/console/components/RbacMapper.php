<?php

namespace console\components;

use yii\rbac\Permission;
use yii\rbac\Role;
use yii\rbac\Rule;

/**
 * Список и иерархия ролей для их добавления в систему RBAC
 */
abstract class RbacMapper
{
    /**
     * Список/иерархия ролей и прав
     *
     * @return array
     */
    abstract public function items(): array;

    /**
     * Список правли для роей/прав
     *
     * @return Rule[]
     */
    abstract public function rules(): array;

    /**
     * Добавить роль в список
     *
     * @param string|array $data
     * @return Role
     */
    protected function role($data): Role
    {
        if (!is_array($data)) {
            $data = ['name' => $data];
        }
        return new Role($data);
    }

    /**
     * Добавить право в список
     *
     * @param string|array $data
     * @return Permission
     */
    protected function permission($data): Permission
    {
        if (!is_array($data)) {
            $data = ['name' => $data];
        }
        return new Permission($data);
    }
}