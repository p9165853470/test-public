<?php

namespace console\controllers;

use console\controllers\password\CollectGarbageAction;
use yii\console\Controller;

class PasswordController extends Controller
{
    public function actions(): array
    {
        return [
            'collect-garbage' => CollectGarbageAction::class,
        ];
    }
}