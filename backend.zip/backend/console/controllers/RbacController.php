<?php

namespace console\controllers;

use console\controllers\rbac\RemoveAction;
use console\controllers\rbac\SyncAction;
use yii\console\Controller;

class RbacController extends Controller
{
    public function actions(): array
    {
        return [
            'sync' => SyncAction::class,
            'remove' => RemoveAction::class,
        ];
    }
}