<?php

namespace console\controllers;

use console\controllers\session\CollectGarbageAction;
use yii\console\Controller;

class SessionController extends Controller
{
    public function actions(): array
    {
        return [
            'collect-garbage' => CollectGarbageAction::class,
        ];
    }
}