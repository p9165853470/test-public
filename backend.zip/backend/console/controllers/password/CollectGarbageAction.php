<?php

namespace console\controllers\password;

use common\modules\password\behaviors\PasswordServiceInterface;
use yii\base\Action;
use yii\console\ExitCode;

class CollectGarbageAction extends Action
{
    /**
     * @var PasswordServiceInterface
     */
    protected $service;

    public function __construct($id, $controller, PasswordServiceInterface $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(): int
    {
        $result = $this->service->collectGarbage();

        $this->controller->stdout("Removed passwords: {$result}\n");

        return ExitCode::OK;
    }
}