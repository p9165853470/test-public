<?php

namespace console\controllers\rbac;

use console\services\RbacService;
use yii\base\Action;
use yii\console\Exception;

class RemoveAction extends Action
{
    /**
     * @var RbacService
     */
    protected $service;

    public function __construct($id, $controller, RbacService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(): void
    {
        try {
            $this->service->remove();
        } catch (\Throwable $ex) {
            throw new Exception($ex->getMessage());
        }
    }
}