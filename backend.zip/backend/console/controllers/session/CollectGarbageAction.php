<?php

namespace console\controllers\session;

use common\modules\session\behaviors\SessionServiceInterface;
use yii\base\Action;
use yii\console\ExitCode;

class CollectGarbageAction extends Action
{
    /**
     * @var SessionServiceInterface
     */
    protected $service;

    public function __construct($id, $controller, SessionServiceInterface $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(): int
    {
        $result = $this->service->collectGarbage();

        $this->controller->stdout("Removed sessions: {$result}\n");

        return ExitCode::OK;
    }
}