<?php

namespace console\controllers\tranche;

use console\services\TrancheService;
use yii\base\Action;
use yii\console\ExitCode;

class UncheckAction extends Action
{
    /**
     * @var TrancheService
     */
    protected $service;

    public function __construct($id, $controller, TrancheService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(): int
    {
        $result = $this->service->uncheck();

        $this->controller->stdout("Unchecked tranches: {$result}\n");

        return ExitCode::OK;
    }
}