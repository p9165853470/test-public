<?php

use yii\db\Migration;

/**
 * Handles adding columns to table `{{%rf_info_tranche}}`.
 */
class m210429_170900_add_repayment_amount_column_to_rf_info_tranche_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%rf_info_tranche}}', 'repayment_amount', $this->float(2));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%rf_info_tranche}}', 'repayment_amount');
    }
}
