<?php

use yii\db\Migration;

/**
 * Class m210615_122402_alter_front_user
 */
class m210615_122402_alter_front_user extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropColumn('front_user', 'authority_begin_date');
        $this->dropColumn('front_user', 'authority_end_date');
        $this->dropColumn('front_user', 'agreement_at');
        $this->dropColumn('front_user', 'validated_at');

        $this->addColumn('front_user', 'phone_number', $this->string(30));
        $this->addColumn('front_user', 'key_word', $this->string(30));
        $this->addColumn('front_user', 'insert_back_user_id', $this->integer()->notNull()->defaultValue(0));

        $this->dropIndex('unq-front_user-email-diasoft_id', 'front_user');

        $this->createIndex('front_user_ux_email', 'front_user', 'email', true);

        $this->alterColumn('front_user', 'diasoft_id', $this->string(16));

        // Добавление служебного пользователя
        $this->execute(file_get_contents(__DIR__ . '/m210615_122402_alter_front_user__createBackUser.sql'));
        // Установим insert_back_user_id служебного пользователя
        $this->execute(file_get_contents(__DIR__ . '/m210615_122402_alter_front_user__insertBackUserId.sql'));

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->alterColumn('front_user', 'diasoft_id', $this->string(16)->notNull());
        
        $this->dropIndex('front_user_ux_email', 'front_user');

        $this->createIndex('unq-front_user-email-diasoft_id', 'front_user', ['email', 'diasoft_id'], true);

        $this->dropColumn('front_user', 'phone_number');
        $this->dropColumn('front_user', 'key_word');
        $this->dropColumn('front_user', 'insert_back_user_id');

        $this->addColumn('front_user', 'authority_begin_date', $this->date());
        $this->addColumn('front_user', 'authority_end_date', $this->date());
        $this->addColumn('front_user', 'agreement_at', $this->timestamp(0));
        $this->addColumn('front_user', 'validated_at', $this->timestamp(0));

        // Удаление служебного пользователя
        $this->execute(file_get_contents(__DIR__ . '/m210615_122402_alter_front_user__deleteBackUser.sql'));

        return true;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210615_122402_alter_front_user cannot be reverted.\n";

        return false;
    }
    */
}
