INSERT INTO public.back_user(
    email, password_hash, first_name, middle_name, last_name, master, created_at, updated_at, failed_auth_attempt_count, block_reason, search_name)
VALUES ('system@user.ins', '','Служебная', 'Запись', 'Для-инициализации-данных', false, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0, 0, 'Служебная Запись Для-инициализации-данных');