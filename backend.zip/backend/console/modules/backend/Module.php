<?php

namespace console\modules\backend;

use backend\rbac\Mapper;
use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\password\services\BackUserPasswordService;
use common\modules\session\behaviors\SessionServiceInterface;
use common\modules\session\services\BackUserSessionService;
use console\components\RbacMapper;
use console\controllers\PasswordController;
use console\controllers\RbacController;
use console\controllers\SessionController;
use yii\rbac\ManagerInterface;

class Module extends \yii\base\Module
{
    public function init(): void
    {
        parent::init();

        \Yii::$container->setDefinitions([
            PasswordServiceInterface::class => BackUserPasswordService::class,
            SessionServiceInterface::class => BackUserSessionService::class,
            RbacMapper::class => Mapper::class,
        ]);

        \Yii::$container->setSingleton(ManagerInterface::class, \Yii::$app->get('backAuthManager'));

        $this->controllerMap = [
            'rbac' => RbacController::class,
            'session' => SessionController::class,
            'password' => PasswordController::class,
        ];
    }
}