<?php

namespace console\modules\backend\controllers\user;

use common\exceptions\RepositoryException;
use console\modules\backend\services\UserService;
use yii\base\Action;
use yii\console\ExitCode;
use yii\helpers\Console;

class DeleteAction extends Action
{
    /**
     * @var UserService
     */
    protected $service;

    public function __construct($id, $controller, UserService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(string $email): int
    {
        try {
            $this->service->delete(
                $this->service->getRepository()->findOne(['email' => $email])
            );
        } catch (RepositoryException $ex) {
            $this->controller->stderr($ex->getMessage(), Console::BG_RED);
            $this->controller->stderr("\n");

            return ExitCode::UNSPECIFIED_ERROR;
        }

        return ExitCode::OK;
    }
}