<?php

namespace console\modules\backend\factories;

use common\behaviors\FormProviderInterface;
use common\modules\user\models\BackUser;
use console\modules\backend\forms\UserForm;

class UserFactory implements FormProviderInterface
{
    /**
     * @param BackUser|null $model
     * @param array $config
     * @return UserForm
     */
    public function getForm($model = null, array $config = []): UserForm
    {
        return new UserForm($model, $config);
    }
}