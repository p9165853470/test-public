<?php

namespace console\modules\backend\forms;

use common\forms\Form;
use common\modules\password\helpers\PasswordGenerator;
use common\modules\password\validators\PasswordValidator;
use common\modules\user\models\BackUser;

class UserForm extends Form
{
    /**
     * @var string
     */
    public $email;
    /**
     * @var string
     */
    public $password;
    /**
     * @var bool
     */
    public $master = true;

    public function rules(): array
    {
        return [
            ['email', 'required'],
            ['email', 'string', 'max' => 128],
            ['email', 'unique', 'targetClass' => BackUser::class, 'targetAttribute' => 'email'],
            ['master', 'boolean'],
            [
                'password',
                'filter',
                'filter' => static function () {
                    return PasswordGenerator::generate(
                        BackUser::PASSWORD_LENGTH,
                        BackUser::PASSWORD_GROUPS,
                    );
                }
            ]
        ];
    }
}