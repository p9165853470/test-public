<?php

require __DIR__ . '/../../../../vendor/yiisoft/yii2/rbac/migrations/m170907_052038_rbac_add_index_on_auth_assignment_user_id.php';

class m170907_052038_back_rbac_add_index_on_auth_assignment_user_id extends \m170907_052038_rbac_add_index_on_auth_assignment_user_id
{
    public $index = 'auth_assignment_user_id_idx';

    protected function getAuthManager(): \yii\rbac\DbManager
    {
        /** @var \yii\rbac\DbManager $authManager */
        $authManager = Yii::$app->get('backAuthManager');

        return $authManager;
    }
}