<?php

namespace console\modules\backend\services;

use common\modules\user\models\BackUser;
use common\modules\user\repositories\BackUserRepository;
use common\services\CrudService;
use console\modules\backend\factories\UserFactory;
use console\modules\backend\forms\UserForm;

/**
 * @method UserFactory getFactory()
 * @method BackUserRepository getRepository()
 * @method BackUser create(UserForm $form)
 * @method UserForm form($model = null)
 */
class UserService extends CrudService
{
    /**
     * @var BackUserRepository
     */
    protected $repository;
    /**
     * @var UserFactory
     */
    protected $factory;

    public function __construct(
        BackUserRepository $repository,
        UserFactory $factory
    ) {
        $this->repository = $repository;
        $this->factory = $factory;
    }
}