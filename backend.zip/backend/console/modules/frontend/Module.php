<?php

namespace console\modules\frontend;

use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\password\services\FrontUserPasswordService;
use common\modules\session\behaviors\SessionServiceInterface;
use common\modules\session\services\FrontUserSessionService;
use console\controllers\PasswordController;
use console\controllers\SessionController;

class Module extends \yii\base\Module
{
    public function init(): void
    {
        parent::init();

        \Yii::$container->setDefinitions([
            SessionServiceInterface::class => FrontUserSessionService::class,
            PasswordServiceInterface::class => FrontUserPasswordService::class,
        ]);

        $this->controllerMap = [
            'session' => SessionController::class,
            'password' => PasswordController::class,
        ];
    }
}