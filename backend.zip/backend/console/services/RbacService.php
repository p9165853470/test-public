<?php

namespace console\services;

use console\components\RbacMapper;
use yii\base\Exception;
use yii\rbac\Item;
use yii\rbac\ManagerInterface;
use yii\rbac\Permission;
use yii\rbac\Role;
use yii\rbac\Rule;

class RbacService
{
    /**
     * @var ManagerInterface
     */
    protected $authManager;
    /**
     * @var Role[]
     */
    private $roles = [];
    /**
     * @var Permission[]
     */
    private $permissions = [];
    /**
     * @var Rule[]
     */
    private $rules = [];

    public function __construct(ManagerInterface $authManager)
    {
        $this->authManager = $authManager;
    }

    /**
     * Синхронизировать роли/права/правила из карты с хранилищем RBAC
     *
     * @param RbacMapper $mapper
     * @throws Exception
     */
    public function sync(RbacMapper $mapper): void
    {
        $this->load();
        $this->syncRules($mapper->rules());
        $this->syncItems($mapper->items());
        $this->removeUnused();
    }

    /**
     * Очистить хранилище RBAC
     */
    public function remove(): void
    {
        $this->authManager->removeAll();
    }

    /**
     * Очистить и синхронизировать хранилище RBAC
     *
     * @param RbacMapper $mapper
     * @throws Exception
     */
    public function init(RbacMapper $mapper): void
    {
        $this->remove();
        $this->sync($mapper);
    }

    protected function load(): void
    {
        $this->rules = $this->authManager->getRules();
        $this->roles = $this->authManager->getRoles();
        $this->permissions = $this->authManager->getPermissions();
    }

    /**
     * Синхронизировать правила
     *
     * @param Rule[] $items
     */
    protected function syncRules(array $items): void
    {
        foreach ($items as $item) {
            if (isset($this->rules[$item->name])) {
                $this->authManager->update($item->name, $item);
                unset($this->rules[$item->name]);
            } else {
                $this->authManager->add($item);
            }
        }
    }

    /**
     * Синхронизировать роли/права
     *
     * @param Item[]|array $items
     * @param Item|null $parent
     * @throws Exception
     */
    protected function syncItems(array $items, Item $parent = null): void
    {
        foreach ($items as $item) {
            if ($item instanceof Item) {
                $subs = [];
            } elseif (is_array($item) && $item[0] instanceof Item && is_array($item[1])) {
                [$item, $subs] = $item;
            } else {
                continue;
            }

            if ($item instanceof Role) {
                $list = &$this->roles;
            } else {
                $list = &$this->permissions;
            }

            if (isset($list[$item->name])) {
                $this->authManager->update($item->name, $item);
                unset($list[$item->name]);
            } else {
                $this->authManager->add($item);
            }

            if ($parent instanceof Item && $this->authManager->canAddChild($parent, $item)) {
                $this->authManager->addChild($parent, $item);
            }

            $this->authManager->removeChildren($item);

            $this->syncItems($subs, $item);
        }
    }

    /**
     * Удалить роли/права/правила, которые есть в хранилище RBAC, но нет в карте
     */
    protected function removeUnused(): void
    {
        $items = array_merge(
            array_values($this->permissions),
            array_values($this->roles),
            array_values($this->rules),
        );

        foreach ($items as $item) {
            $this->authManager->remove($item);
        }
    }
}