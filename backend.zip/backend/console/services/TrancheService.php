<?php

namespace console\services;

use common\modules\tranche\services\TranchePaymentService;
use common\modules\variable\enums\VariableEnum;
use common\modules\variable\services\VariableService;
use DateTimeInterface;
use DateTimeZone;
use yii\base\InvalidArgumentException;

class TrancheService
{
    /**
     * @var VariableService
     */
    protected $variableService;
    /**
     * @var TranchePaymentService
     */
    protected $paymentService;

    public function __construct(VariableService $variableService, TranchePaymentService $paymentService)
    {
        $this->variableService = $variableService;
        $this->paymentService = $paymentService;
    }

    /**
     * Снять метки выбранных траншей на погашение
     *
     * @return int
     */
    public function uncheck(): int
    {
        /** @var array|null $data */
        $data = $this->variableService->get(VariableEnum::SETTINGS);

        if ($data === null) {
            return 0;
        }
        $now = date_create_immutable(null, new DateTimeZone('Europe/Moscow'));

        if (!$this->isWorkDay($data, $now)) {
            return 0;
        }
        $result = 0;

        foreach ($this->paymentService->getAllExported() as $payment) {
            $paymentDate = date_create_immutable($payment->created_at)->setTimezone($now->getTimezone());

            if ($this->isWorkDate($data, $paymentDate)) {
                [$hour, $minute] = $this->parseTime($data['uncheck_tranche_in_work_time']);
                $date = $paymentDate->setTime($hour, $minute);
            } else {
                [$hour, $minute] = $this->parseTime($data['uncheck_tranche_out_work_time']);
                $paymentTime = $paymentDate->format('H:i');

                if ($data['work_end_time'] < $paymentTime && $paymentTime <= '23:59') {
                    $date = $paymentDate->modify('+1 day')->setTime($hour, $minute);
                } else {
                    $date = $paymentDate->setTime($hour, $minute);
                }
            }

            if ($now >= $date) {
                $this->paymentService->delete($payment);

                $result++;
            }
        }

        return $result;
    }

    protected function parseTime(string $time): array
    {
        if (preg_match('/^0?(\d+):0?(\d+)(?::0?(\d+))?$/', $time, $match)) {
            return array_map('intval', array_values(array_slice($match, 1)));
        }

        throw new InvalidArgumentException("Invalid time: {$time}");
    }

    protected function isWorkDate(array $data, DateTimeInterface $dateTime): bool
    {
        return $this->isWorkDay($data, $dateTime) && $this->isWorkTime($data, $dateTime);
    }

    protected function isWorkDay(array $data, DateTimeInterface $dateTime): bool
    {
        return $data['work_week_days'][strtolower($dateTime->format('D'))];
    }

    protected function isWorkTime(array $data, DateTimeInterface $dateTime): bool
    {
        $time = $dateTime->format('H:i');

        return $data['work_begin_time'] <= $time && $time <= $data['work_end_time'];
    }
}