<?php
return [
    'components' => [
        'mailer' => [
            'class' => \yii\swiftmailer\Mailer::class,
            'viewPath' => '@common/mail',
            'messageConfig' => [
                'charset' => 'UTF-8',
                'from' => getenv('mail_from'),
            ],
            'useFileTransport' => true,
        ],
    ],
];
