<?php

namespace frontend\behaviors;

use common\enums\ErrorEnum;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;

use Yii;

class IdentityRestrictBehavior extends \common\modules\user\behaviors\IdentityRestrictBehavior
{
    public const RULE_IDENTITY_VALIDATE = 'identity-validate';
    public const RULE_IDENTITY_AGREEMENT = 'identity-agreement';
    public const RULE_IDENTITY_VALIDATE_PHONE = 'identity-phone-validate';
    public const RULE_IDENTITY_CONFIRM = 'identity-confirm';
    public const RULE_IDENTITY_CHECK_DIASOFT_ID = 'check-diasoft-id';

    /**
     * @param IdentityInterface|FrontUser $identity
     * @param string $rule
     * @return bool
     */
    protected function validate(IdentityInterface $identity, string $rule): bool
    {
        trace('IdentityRestrictBehavior.validate() BEGIN');

        switch ($rule) {
            case self::RULE_IDENTITY_CONFIRM:
                return !$identity->getToken()->getSession()->isConfirmed();
            case self::RULE_IDENTITY_VALIDATE_PHONE:
                return $identity->validate_phone_date === null;
            case self::RULE_IDENTITY_VALIDATE:
                $dealer = $identity->getDealer();
                trace('IdentityRestrictBehavior.validate(): get_debug_type($dealer) = '.get_debug_type($dealer));
                trace('IdentityRestrictBehavior.validate(): $dealer[0] = '.$dealer[0]);
                trace('IdentityRestrictBehavior.validate() $dealer= '.print_r($dealer, true));
                $result = $dealer === null ? false : $dealer->validated_at === null;
                trace('IdentityRestrictBehavior.validate(): $result = '.$result);
                trace('IdentityRestrictBehavior.validate(): get_debug_type($result) = '.get_debug_type($result));
                if($dealer === null) {
                    trace('IdentityRestrictBehavior.validate(): null');
                } else {
                    trace('IdentityRestrictBehavior.validate(): !null');
                }
                if($dealer == null) {
                    trace('IdentityRestrictBehavior.validate(): === null');
                } else {
                    trace('IdentityRestrictBehavior.validate(): === TRUE');
                }
                return $result;
            case self::RULE_IDENTITY_AGREEMENT:
                $dealer = $identity->getDealer();
                return $dealer === null ? false : $dealer->agreement_at === null;
            case self::RULE_IDENTITY_CHECK_DIASOFT_ID:
                return $identity->getToken()->getSession()->getDiasoftId() === null;
        }

        $result = parent::validate($identity, $rule);
        trace('IdentityRestrictBehavior.validate() END: $result = '.print_r($result, true));
        return $result;
    }

    protected function ruleErrors(): array
    {
        return array_merge(parent::ruleErrors(), [
            self::RULE_IDENTITY_VALIDATE => ErrorEnum::IDENTITY_IS_NOT_VALIDATED,
            self::RULE_IDENTITY_AGREEMENT => ErrorEnum::IDENTITY_DID_NOT_ACCEPT_AGREEMENT,
            self::RULE_IDENTITY_VALIDATE_PHONE => ErrorEnum::IDENTITY_PHONE_IS_NOT_VALIDATED,
            self::RULE_IDENTITY_CONFIRM => ErrorEnum::IDENTITY_IDENTITY_IS_NOT_CONFIRMED,
            self::RULE_IDENTITY_CHECK_DIASOFT_ID => ErrorEnum::IDENTITY_IDENTITY_MISSING_DIASOFT_ID,
        ]);
    }
}

function trace(string $message) {
    file_put_contents('/opt/backend/frontend/runtime/logs/ib4d.log', date('H:i:s')."\t".$message."\n", FILE_APPEND);
}
