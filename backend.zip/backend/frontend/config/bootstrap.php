<?php
Yii::$container->setDefinitions([
    \common\modules\session\behaviors\SessionServiceInterface::class => \common\modules\session\services\FrontUserSessionService::class,
    \common\modules\password\behaviors\PasswordServiceInterface::class => \common\modules\password\services\FrontUserPasswordService::class,
    \common\modules\password\forms\ChangePasswordForm::class => \frontend\forms\ChangePasswordForm::class,
    \common\modules\password\forms\ResetPasswordForm::class => \frontend\forms\ResetPasswordForm::class,
    \common\modules\rfinfo\behaviors\RequestCacheServiceInterface::class => \common\modules\rfinfo\services\RequestCacheService::class,
]);