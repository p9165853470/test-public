<?php
return [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'QOfM-DNxuvX0iHy7MFGtma7sHzaJezCG',
        ],
        'jwt' => [
            'key' => '6Y3rjWHnayEKahHHCRCeEHjg5Rrcabn5M32hFEhsM3BjdD6hueKYTzbb6ZsY62LX'
        ]
    ],
];
