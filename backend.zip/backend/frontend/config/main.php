<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

return [
    'id' => 'app-frontend',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'controllerNamespace' => 'frontend\controllers',
    'components' => [
        'request' => [
            'parsers' => [
                'application/json' => \yii\web\JsonParser::class,
            ]
        ],
        'response' => [
            'format' => \yii\web\Response::FORMAT_JSON,
            'formatters' => [
                'json' => [
                    'class' => \yii\web\JsonResponseFormatter::class,
                    'prettyPrint' => YII_DEBUG,
                    'encodeOptions' => JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE,
                ],
            ],
        ],
        'errorHandler' => [
            'class' => \common\components\ErrorHandler::class
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => \yii\log\FileTarget::class,
                    'levels' => ['error', 'warning'],
                ],
                [
                    'class' => \common\modules\audit\components\AuditLogTarget::class,
                    'levels' => ['error'],
                    'except' => [
                        'yii\web\HttpException:4*',
                    ],
                ],
            ],
        ],
        'jwt' => [
            'class' => \common\modules\authentication\components\Jwt::class,
        ],
        'user' => [
            'identityClass' => \common\modules\user\models\FrontUser::class,
            'enableAutoLogin' => false,
            'enableSession' => false,
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            'rules' => [
                'docs/<file>' => 'swagger/file',
                'docs' => 'swagger/index',
                'variable/<key>' => 'variable/view',
                'rf-info/tranches' => 'rf-info/tranches',
                'rf-info/tranches/payment' => 'rf-info/tranches-payment',
                'rf-info/tranches/export' => 'rf-info/tranches-export',
                'rf-info/tranches/doc-request' => 'rf-info/tranches-doc-request',
                'rf-info/account-statements/export' => 'rf-info/account-statements-export',
                'rf-info/account-transactions/export' => 'rf-info/account-transactions-export',
//                'rf-info/send-sms' => 'rf-info/send-sms',
                'rf-info/<method>' => 'rf-info/request',
            ],
        ],
    ],
    'controllerMap' => [
        'swagger' => [
            'class' => \common\modules\swagger\controllers\SwaggerController::class,
            'fileUrl' => '/docs/swagger.yaml',
            'filePath' => '@frontend/swagger',
        ]
    ],
    'params' => $params,
];
