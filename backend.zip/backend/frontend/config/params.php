<?php
return [
    'audit.logPath' => getenv('audit_frontend_log_path'),
];
