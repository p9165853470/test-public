<?php

namespace frontend\controllers;

use frontend\behaviors\IdentityRestrictBehavior;

abstract class Controller extends \common\controllers\Controller
{
    public function behaviors(): array
    {
        $behaviors = parent::behaviors();

        $behaviors[self::BEHAVIOR_IDENTITY_RESTRICT_KEY] = [
            'class' => IdentityRestrictBehavior::class,
            'rules' => [
                IdentityRestrictBehavior::RULE_IDENTITY_BLOCK,
                IdentityRestrictBehavior::RULE_IDENTITY_ACTIVE,
                IdentityRestrictBehavior::RULE_IDENTITY_VALIDATE_PHONE,
                IdentityRestrictBehavior::RULE_IDENTITY_VALIDATE,
                IdentityRestrictBehavior::RULE_IDENTITY_HAS_UNSAFE_PASSWORD,
                IdentityRestrictBehavior::RULE_IDENTITY_AGREEMENT,
                IdentityRestrictBehavior::RULE_IDENTITY_CONFIRM,
                IdentityRestrictBehavior::RULE_IDENTITY_CHECK_DIASOFT_ID,
            ]
        ];

        return $behaviors;
    }
}