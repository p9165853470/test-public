<?php

namespace frontend\controllers;

use frontend\controllers\document\CreateAction;

class DocumentController extends Controller
{
    public function actions(): array
    {
        return [
            'create' => CreateAction::class
        ];
    }

    protected function verbs(): array
    {
        return [
            'create' => ['POST']
        ];
    }
}