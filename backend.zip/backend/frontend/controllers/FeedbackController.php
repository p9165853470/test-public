<?php

namespace frontend\controllers;

use frontend\controllers\feedback\CreateAction;

class FeedbackController extends Controller
{
    public function actions(): array
    {
        return [
            'create' => CreateAction::class,
        ];
    }

    protected function verbs(): array
    {
        return [
            'create' => ['POST'],
        ];
    }
}