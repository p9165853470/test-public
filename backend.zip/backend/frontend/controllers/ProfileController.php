<?php

namespace frontend\controllers;

use frontend\behaviors\IdentityRestrictBehavior;
use frontend\controllers\profile\AgreementAction;
use frontend\controllers\profile\ChangeKeyWordAction;
use frontend\controllers\profile\ValidateAction;
use frontend\controllers\profile\ValidatePhoneAction;
use frontend\controllers\profile\ViewAction;
use frontend\controllers\profile\ChooseDealerAction;
use frontend\controllers\profile\ChangePhoneNumberAction;

class ProfileController extends Controller
{

    public function beforeAction($action): bool
    {
        /** @var IdentityRestrictBehavior $behavior */
        $behavior = $this->getBehavior(self::BEHAVIOR_IDENTITY_RESTRICT_KEY);

        switch ($action->id) {
            case 'choose-dealer':
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_CHECK_DIASOFT_ID);
                break;
            case 'phone-validate':
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_VALIDATE_PHONE);
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_VALIDATE);
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_AGREEMENT);
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_HAS_UNSAFE_PASSWORD);
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_CONFIRM);
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_CHECK_DIASOFT_ID);
                break;
            case 'validate':
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_VALIDATE);
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_AGREEMENT);
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_HAS_UNSAFE_PASSWORD);
                break;
            case 'agreement':
                $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_AGREEMENT);
                break;
        }

        return parent::beforeAction($action);
    }

    public function actions(): array
    {
        return [
            'view' => ViewAction::class,
            'validate' => ValidateAction::class,
            'agreement' => AgreementAction::class,
            'phone-validate' => ValidatePhoneAction::class,
            'choose-dealer' => ChooseDealerAction::class,
            'phone-number-change' => ChangePhoneNumberAction::class,
            'key-word-change' => ChangeKeyWordAction::class,
        ];
    }

    protected function verbs(): array
    {
        return [
            'view' => ['GET'],
            'validate' => ['POST'],
            'agreement' => ['POST'],
            'choose-dealer' => ['POST'],
            'phone-validate' => ['POST'],
        ];
    }
}