<?php

namespace frontend\controllers\document;

use common\modules\audit\enum\ActionEnum;
use common\modules\audit\services\AuditService;
use yii\base\Action;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class CreateAction extends Action
{
    /**
     * @var DocumentService
     */
    protected $service;

    /**
     * @var AuditService
     */
    protected $auditService;

    public function __construct($id, $controller, DocumentService $service, AuditService $auditService, $config = [])
    {
        $this->service = $service;
        $this->auditService = $auditService;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param Request $request
     * @param Response $response
     * @param IdentityInterface $identity
     * @return FeedbackForm|void
     * @throws BadRequestHttpException
     */
    public function run(Request $request, Response $response, IdentityInterface $identity)
    {
        $form = $this->service->form();

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $response->on(Response::EVENT_AFTER_SEND, function () use ($form) {
                $this->service->send($form);
            });

            $this->auditService->audit(new IdentityAuditMessage(ActionEnum::CREATE_DOCUMENT, $identity));

            $response->setStatusCode(201);
        } else {
            return $form;
        }
    }
}