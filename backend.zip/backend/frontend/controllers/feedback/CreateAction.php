<?php

namespace frontend\controllers\feedback;

use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\user\behaviors\IdentityInterface;
use frontend\forms\FeedbackForm;
use frontend\services\FeedbackService;
use yii\base\Action;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class CreateAction extends Action
{
    /**
     * @var FeedbackService
     */
    protected $service;
    /**
     * @var AuditService
     */
    protected $auditService;

    public function __construct($id, $controller, FeedbackService $service, AuditService $auditService, $config = [])
    {
        $this->service = $service;
        $this->auditService = $auditService;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param Request $request
     * @param Response $response
     * @param IdentityInterface $identity
     * @return FeedbackForm|void
     * @throws BadRequestHttpException
     */
    public function run(Request $request, Response $response, IdentityInterface $identity)
    {
        $form = $this->service->form();

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $response->on(Response::EVENT_AFTER_SEND, function () use ($form) {
                $this->service->send($form);
            });

            $this->auditService->audit(new IdentityAuditMessage(ActionEnum::SEND_FEEDBACK, $identity));

            $response->setStatusCode(204);
        } else {
            return $form;
        }
    }
}