<?php

namespace frontend\controllers\profile;

use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use frontend\services\FrontUserService;
use yii\base\Action;
use yii\web\Response;

class AgreementAction extends Action
{
    /**
     * @var FrontUserService
     */
    protected $service;
    /**
     * @var AuditService
     */
    protected $auditService;

    public function __construct($id, $controller, FrontUserService $service, AuditService $auditService, $config = [])
    {
        $this->service = $service;
        $this->auditService = $auditService;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param IdentityInterface|FrontUser $identity
     * @param Response $response
     */
    public function run(IdentityInterface $identity, Response $response): void
    {
        $this->service->acceptAgreement($identity);

        $this->auditService->audit(new IdentityAuditMessage(ActionEnum::ACCEPT_AGREEMENT, $identity));

        $response->setStatusCode(204);
    }
}