<?php

namespace frontend\controllers\profile;

use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\rfinfo\behaviors\RequestServiceInterface;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\factories\RequestFactory;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use frontend\forms\ChangeKeyWordForm;
use frontend\services\FrontUserService;
use yii\base\Action;
use yii\di\Instance;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class ChangeKeyWordAction extends Action
{
    /**
     * @var FrontUserService
     */
    protected $service;
    /**
     * @var AuditService
     */
    protected $auditService;

    public function __construct($id, $controller, FrontUserService $service, AuditService $auditService, $config = [])
    {
        $this->service = $service;
        $this->auditService = $auditService;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param IdentityInterface|FrontUser $identity
     * @param Request $request
     * @param Response $response
     * @return ChangeKeyWordForm|void
     * @throws BadRequestHttpException
     */
    public function run(IdentityInterface $identity, Request $request, Response $response)
    {
        $form = new ChangeKeyWordForm($identity);

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $this->service->changeKeyWord($identity, $form->key_word);

            $this->auditService->audit(new IdentityAuditMessage(ActionEnum::CHANGE_KEY_WORD, $identity));
            /** @var RequestServiceInterface $service */
            $service = Instance::ensure(RequestServiceInterface::class);
            /** @var RequestFactory $factory */
            $factory = Instance::ensure(RequestFactory::class);
            $context = $factory->getContext(RequestMethodEnum::CONTACT,
                ['email' => $identity->email,
                    'type' => '1',
                    'value' => $form->key_word,
                ]);
            try {
                $service->postContact($context);
            } catch (RequestServiceException $ex) {
                throw new BadRequestHttpException($ex->getMessage());
            }

            $response->setStatusCode(204);
        } else {
            return $form;
        }
    }
}