<?php

namespace frontend\controllers\profile;

use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use frontend\forms\ChooseDealerForm;
use frontend\services\FrontUserService;
use yii\base\Action;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class ChooseDealerAction extends Action
{
    /**
     * @var FrontUserService
     */
    protected $service;
    /**
     * @var AuditService
     */
    protected $auditService;

    public function __construct($id, $controller, FrontUserService $service, AuditService $auditService, $config = [])
    {
        $this->service = $service;
        $this->auditService = $auditService;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param IdentityInterface|FrontUser $identity
     * @param Request $request
     * @param Response $response
     * @return ChooseDealerForm|void
     * @throws BadRequestHttpException
     */
    public function run(IdentityInterface $identity, Request $request, Response $response)
    {
        $form = new ChooseDealerForm($identity);

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $this->service->chooseDealer($identity, $form->diasoft_id);

            $this->auditService->audit(new IdentityAuditMessage(ActionEnum::CHOOSE_DEALER, $identity));

            $response->setStatusCode(204);
        } else {
            return $form;
        }
    }
}