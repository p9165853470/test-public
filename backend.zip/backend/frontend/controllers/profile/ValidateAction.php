<?php

namespace frontend\controllers\profile;

use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use frontend\forms\ValidateForm;
use frontend\services\FrontUserService;
use yii\base\Action;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class ValidateAction extends Action
{
    /**
     * @var FrontUserService
     */
    protected $service;
    /**
     * @var AuditService
     */
    protected $auditService;

    public function __construct($id, $controller, FrontUserService $service, AuditService $auditService, $config = [])
    {
        $this->service = $service;
        $this->auditService = $auditService;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param IdentityInterface|FrontUser $identity
     * @param Request $request
     * @param Response $response
     * @return ValidateForm|void
     * @throws BadRequestHttpException
     */
    public function run(IdentityInterface $identity, Request $request, Response $response)
    {
        $form = new ValidateForm($identity);

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $this->service->validate($identity);

            $this->auditService->audit(new IdentityAuditMessage(ActionEnum::PROFILE_VALIDATE, $identity));

            $response->setStatusCode(204);
        } else {
            return $form;
        }
    }
}