<?php

namespace frontend\controllers\profile;

use common\modules\user\behaviors\IdentityInterface;
use common\resources\Resource;
use frontend\resources\ProfileResource;
use yii\base\Action;

use Yii;

class ViewAction extends Action
{
    public function run(IdentityInterface $identity): ProfileResource
    {
        Yii::warning('frontend\controllers\profile\ViewAction.run() BEGIN');
        $result = new ProfileResource($identity);
        Yii::warning('frontend\controllers\profile\ViewAction.run() END');
        return $result;
    }
}