# Правила именования переменных и функций:
- [Общие правила](https://hackernoon.com/the-art-of-naming-variables-52f44de00aad)

# Правила именования сущностей:
- Названия компонентов - *PascalCase*
- Классы (class) - *PascalCase*
- Интерфейсы (interface) - *PascalCase*, с префиксом I
- Типы (type) - *PascalCase*, с префиксом T

# Правила именования директорий и файлов:
- Директории компонентов - *PascalCase*
- Файлы компонентов - *kebab-case*
- Прочие - *kebab-case*