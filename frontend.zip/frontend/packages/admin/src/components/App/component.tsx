import React from 'react';

import AppGuest from './components/AppGuest';
import AppAdmin from './components/AppAdmin';

import '@rfb/common/assets/styles/index.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

export interface IAppProps {
  state: TODO_ANY;
  token: string;
}

const App = (props: IAppProps) => (props.token ? <AppAdmin /> : <AppGuest />);

export default App;
