import React, { useEffect } from 'react';

import { Routing } from '@rfb/ui-kit';
import { Roles, getAvailableRouteList } from '@rfb/common';

import history from 'utils/history';

import routingConfig from 'configs/routing';

import AppLoader from '../AppLoader';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

export interface IAppAdminProps {
  state: TODO_ANY;
  apiErrorCode: number;
  isMasterAdmin: boolean;
  isLoading: boolean;
}

export interface IAppAdminActions {
  appActions: {
    init: Function,
  };
}

const AppAdmin = (props: IAppAdminProps & IAppAdminActions) => {
  const withoutApiError: boolean = !props.apiErrorCode;

  useEffect(() => {
    if (withoutApiError) {
      props.appActions.init();
    }
  }, [props.apiErrorCode, props.appActions, withoutApiError]);

  if (props.isLoading) {
    return <AppLoader />;
  }

  const currentRoutingList = getAvailableRouteList(
    routingConfig,
    props.state,
    props.isMasterAdmin ? Roles.MASTER_ADMIN : Roles.ADMIN
  );

  return (
    <>
      <Routing history={history} config={currentRoutingList} />
    </>
  );
};

export default AppAdmin;
