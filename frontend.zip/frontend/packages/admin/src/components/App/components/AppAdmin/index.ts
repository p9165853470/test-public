import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { actions as appActions, selectors as appSelectors } from 'modules/app/store';
import { selectors as userSelectors } from 'modules/user/store';

import Component, { IAppAdminProps, IAppAdminActions } from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (state: TODO_ANY): IAppAdminProps => ({
  state,
  apiErrorCode: appSelectors.selectApiErrorCode(state),
  isMasterAdmin: userSelectors.selectProfile(state).master,
  isLoading: appSelectors.selectIsLoading(state),
});

const mapDispatchToProps = (dispatch: any): IAppAdminActions => ({
  appActions: bindActionCreators(appActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
