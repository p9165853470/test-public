import React from 'react';

import { Routing } from '@rfb/ui-kit';
import { Roles, getAvailableRouteList } from '@rfb/common';

import history from 'utils/history';

import routingConfig from 'configs/routing';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

export interface IAppGuestProps {
  state: TODO_ANY;
}

const AppGuest = (props: IAppGuestProps) => {
  const currentRoutingList = getAvailableRouteList(routingConfig, props.state, Roles.GUEST);

  return <Routing history={history} config={currentRoutingList} />;
};

export default AppGuest;
