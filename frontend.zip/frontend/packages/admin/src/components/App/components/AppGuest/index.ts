import { connect } from 'react-redux';

import Component, { IAppGuestProps } from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (state: TODO_ANY): IAppGuestProps => ({
  state,
});

const mapDispatchToProps = () => ({});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
