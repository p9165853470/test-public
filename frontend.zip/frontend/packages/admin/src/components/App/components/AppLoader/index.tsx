import React from 'react';

import { Loader } from '@rfb/ui-kit';

import styles from './assets/styles/index.module.css';

const AppLoader = () => <Loader wrapperClassName={styles.main} />;

export default AppLoader;
