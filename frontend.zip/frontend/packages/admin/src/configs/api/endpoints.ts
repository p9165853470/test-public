export default {
  auth: {
    tokenCreate: '/authentication/create-token',
    tokenRefresh: '/authentication/refresh-token',
    tokenDestroy: '/authentication/destroy-token',
  },

  backUser: {
    get: '/back-user/index',
    block: '/back-user/block-all',
    unblock: '/back-user/unblock-all',
    remove: '/back-user/delete-all',
    getById: '/back-user/:id/view',
    removeById: '/back-user/:id/delete',
    updateUser: '/back-user/:id/update',
    createUser: '/back-user/create',
  },

  frontUser: {
    get: '/front-user/index',
    block: '/front-user/block-all',
    unblock: '/front-user/unblock-all',
    remove: '/front-user/delete-all',
    getById: '/front-user/:id/view',
    removeById: '/front-user/:id/delete',
    updateUser: '/front-user/:id/update',
    createUser: '/front-user/create',
    organization: '/front-user/rf-info',
  },

  profile: {
    view: '/profile/view',
  },

  security: {
    passwordReset: '/security/reset-password',
    passwordChange: '/security/change-password',
  },

  variable: {
    getVariable: '/variable/:key/get',
    setVariable: '/variable/:key/set',
    uploadVariable: '/variable/:key/upload',
  },

  feedback: {
    getFeedback: '/variable/feedback/get',
    setFeedback: '/variable/feedback/set',
  },

  settings: {
    getSettings: '/variable/settings/get',
    setSettings: '/variable/settings/set',
  },

  rfInfo: {
    user: '/front-user/rf-info',
  },
};
