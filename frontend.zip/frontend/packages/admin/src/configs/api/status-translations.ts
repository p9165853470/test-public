import ApiErrors from './errors';

export default {
  [ApiErrors.EMAIL_ALREADY_EXISTS]: 'Такой пользователь уже существует',
  [ApiErrors.EMAIL_BACK_ALREADY_EXISTS]: 'Такой пользователь уже существует',
  [ApiErrors.EMAIL_DIASOFT_ID_ALREADY_EXISTS]: 'Такой пользователь уже существует',
};
