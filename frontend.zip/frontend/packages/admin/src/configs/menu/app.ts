import { IMenuElement, IMenuSubMenu } from '@rfb/ui-kit';

import { Roles } from '@rfb/common';

/**
 * TODO
 * Разобраться, почему при импорте routingConfig
 * в значении содержится undefined
 * После решения это проблемы, все ссылки должны
 * использоваться из этого конфига
 */
// import routingConfig from 'configs/routing';

type TConfigMenuElement = IMenuElement & { accessList: (Roles.ADMIN | Roles.MASTER_ADMIN)[] };
type TConfigMenuSubMenu = IMenuSubMenu & { accessList: (Roles.ADMIN | Roles.MASTER_ADMIN)[] };

export const appMenuConfig: (TConfigMenuElement | TConfigMenuSubMenu)[] = [
  {
    title: 'Пользователи ЛК',
    link: '/',
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
    isExact: true,
  },
  {
    title: 'Справочники',
    items: [
      { title: 'Свяжитесь с нами', link: '/feedback' },
      { title: 'Контакты банка', link: '/bank-contacts' },
      { title: 'Памятка', link: '/memo' },
      { title: 'Реквизиты', link: '/requisites' },
      { title: 'Условия обслуживания', link: '/service-terms' },
      { title: 'Тарифы', link: '/tariffs' },
      { title: 'Инструкция пользователя', link: '/user-manual' },
    ],
    accessList: [Roles.MASTER_ADMIN],
  },
  {
    title: 'Пользователи системы',
    link: '/back-office',
    accessList: [Roles.MASTER_ADMIN],
  },
  {
    title: 'Настройки',
    link: '/settings',
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },
];
