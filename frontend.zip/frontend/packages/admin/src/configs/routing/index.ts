import { ApiErrors, Roles, IRouteConfig } from '@rfb/common';

import fp from 'lodash/fp';

import { selectors as appSelectors } from 'modules/app/store';
import { selectors as authSelectors } from 'modules/auth/store';

import AuthLoginPage from 'pages/auth/login';
import AuthPasswordRestorePage from 'pages/auth/password-restore';
import AuthPasswordRestoreSentPage from 'pages/auth/password-restore-sent';
import AuthPasswordExpiredPage from 'pages/auth/password-expired';

import AppMainPage from 'pages/app/main';

import EditFrontendUserPage from 'pages/front-user/edit';
import AddFrontendUserPage from 'pages/front-user/add';
import EditBackendUserPage from 'pages/back-office/edit';

import BackOfficeListPage from 'pages/back-office/list';

import ProfileMainPage from 'pages/profile/main';
import ProfilePasswordChangePage from 'pages/profile/password-change';

import ReferencesBankContactsPage from 'pages/references/bankContacts';
import ReferencesMemoPage from 'pages/references/memo';
import ReferencesRequisitesPage from 'pages/references/requisites';
import ReferencesServiceTermsPage from 'pages/references/serviceTerms';
import ReferencesTariffsPage from 'pages/references/tariffs';
import ReferencesUserManualPage from 'pages/references/userManual';
import ReferencesFeedbackPage from 'pages/references/feedback';

import SettingsPage from 'pages/settings';

import Error404Page from 'pages/errors/404';
import Error422Page from 'pages/errors/422';
import Error500Page from 'pages/errors/500';

const prefix: { [key: string]: string } = {
  auth: '/auth',
  backOffice: '/back-office',
  frontOffice: '/front-office',
  profile: '/profile',
};

const config: IRouteConfig = {
  login: {
    path: '/',
    component: AuthLoginPage,
    accessList: [Roles.GUEST],
    isExact: true,
  },

  passwordRestore: {
    path: prefix.auth + '/password-restore',
    component: AuthPasswordRestorePage,
    accessList: [Roles.GUEST],
  },

  passwordRestoreSent: {
    path: prefix.auth + '/password-restore-sent',
    component: AuthPasswordRestoreSentPage,
    accessList: [Roles.GUEST],
    check: fp.pipe(authSelectors.selectIsPasswordRestoreSent, fp.isEqual(true)),
  },

  passwordExpired: {
    path: '/',
    component: AuthPasswordExpiredPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
    check: fp.pipe(appSelectors.selectApiErrorCode, fp.isEqual(ApiErrors.PASSWORD_EXPIRED)),
    isExact: true,
  },

  main: {
    path: '/',
    component: AppMainPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
    check: fp.pipe(appSelectors.selectIsAppInit, fp.isEqual(true)),
    isExact: true,
  },

  profile: {
    path: prefix.profile,
    component: ProfileMainPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
    isExact: true,
  },

  profilePasswordChange: {
    path: prefix.profile + '/password-change',
    component: ProfilePasswordChangePage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  frontOfficeProfileEdit: {
    path: prefix.frontOffice + '/profile/:id/edit',
    component: EditFrontendUserPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  frontOfficeProfileAdd: {
    path: prefix.frontOffice + '/profile/add',
    component: AddFrontendUserPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  backOfficeListPage: {
    path: prefix.backOffice,
    component: BackOfficeListPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
    isExact: true,
  },

  backOfficeProfileEdit: {
    path: prefix.backOffice + '/profile/:id/edit',
    component: EditBackendUserPage,
    accessList: [Roles.MASTER_ADMIN],
  },

  backOfficeProfileAdd: {
    path: prefix.backOffice + '/profile/add',
    component: EditBackendUserPage,
    accessList: [Roles.MASTER_ADMIN],
  },

  bankContacts: {
    path: '/bank-contacts',
    component: ReferencesBankContactsPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  memo: {
    path: '/memo',
    component: ReferencesMemoPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  requisites: {
    path: '/requisites',
    component: ReferencesRequisitesPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  serviceTerms: {
    path: '/service-terms',
    component: ReferencesServiceTermsPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  tariffs: {
    path: '/tariffs',
    component: ReferencesTariffsPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  userManual: {
    path: '/user-manual',
    component: ReferencesUserManualPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  feedback: {
    path: '/feedback',
    component: ReferencesFeedbackPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  settings: {
    path: '/settings',
    component: SettingsPage,
    accessList: [Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  error422: {
    path: '/422',
    component: Error422Page,
    accessList: [Roles.GUEST, Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  error500: {
    path: '/500',
    component: Error500Page,
    accessList: [Roles.GUEST, Roles.ADMIN, Roles.MASTER_ADMIN],
  },

  error404: {
    path: '*',
    component: Error404Page,
    accessList: [Roles.GUEST, Roles.ADMIN, Roles.MASTER_ADMIN],
  },
};

export default config;
