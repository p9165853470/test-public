import validator from 'utils/validator';

import fp from 'lodash/fp';

import { validationMessages } from '@rfb/common';

export const passwordRules = validator
  .string()
  .required()
  .min(16)
  .test('password-validation-rule', validationMessages.app.password, (value: string | null | undefined): boolean => {
    const minGroupCount: number = 3;

    const typesRules: { [name: string]: RegExp } = {
      lower: /^(?=.*[a-zа-я])/,
      upper: /^(?=.*[A-ZА-Я])/,
      number: /^(?=.*[\d])/,
      symbols: /^(?=.*[@$!%*#?&])/,
    };

    const successfulResultList: boolean[] = fp.pipe(
      fp.values,
      fp.map((typeRule: RegExp): boolean => typeRule.test(value!)),
      fp.filter(Boolean)
    )(typesRules);

    return fp.gte(fp.size(successfulResultList), minGroupCount);
  });

export const passwordRepeatRules = (password: string) =>
  validator
    .string()
    .required()
    .test('password-repeat-rule', validationMessages.app.passwordRepeat, fp.isEqual(password));
