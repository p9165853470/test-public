import { BlockReasons } from '@rfb/common';

export type TDTOBackUser = {
  id: number,
  email: string,
  first_name: string,
  middle_name: string,
  last_name: string,
  created_at: string,
  updated_at: string,
  block_reason?: BlockReasons,
  active: boolean,
  master: boolean,
};

export type TDTOBackUserGetResponse = TDTOBackUser[];

export type IDTOBackUserCreateRequest = {
  email: string,
  name: string,
};

export interface IDTOBackUserGetResponseHeaders {
  'x-pagination-page-count': string;
  'x-pagination-per-page': string;
}

export interface IDTOBackUserBlockRequest {
  ids: number[];
}

export interface IDTOBackUserUnblockRequest {
  ids: number[];
}

export interface IDTOBackUserRemoveRequest {
  ids: number[];
}
