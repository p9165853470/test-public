import { BlockReasons } from '@rfb/common';

export type IDealer = {
  diasoft_id: string;
  authority_begin_date: string;
  authority_end_date: string;
  agreement_at: string;
  validated_at: string;
  name: string;
  inn: string;
  kpp: string;
};

export type TDTOFrontUser = {
  id: number;
  email: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  created_at: string;
  updated_at: string;
  block_reason?: BlockReasons;
  phone_number: string;
  key_word: string;
  active: boolean;
  dealers: IDealer[];
};

export type DTOFrontUserRequestDealer = {
  diasoft_id: string;
  authority_begin_date: string;
  authority_end_date: string;
};

export type IDTOFrontUserCreateRequest = {
  email: string;
  name: string;
  phone_number: string;
  key_word: string;
  dealers: DTOFrontUserRequestDealer[];
};

export type IDTOFrontUserUpdateRequest = {
  email: string;
  name: string;
  phone_number: string;
  key_word: string;
  dealers: DTOFrontUserRequestDealer[];
};

export type TDTOFrontUserGetResponse = TDTOFrontUser[];

export interface IDTOFrontUserGetResponseHeaders {
  'x-pagination-page-count': string;
  'x-pagination-per-page': string;
}

export interface IDTOFrontUserGetResponseError {
  field: string;
  message: string;
  code: number;
}

export interface IDTOFrontUserBlockRequest {
  ids: number[];
}

export interface IDTOFrontUserUnblockRequest {
  ids: number[];
}

export interface IDTOFrontUserRemoveRequest {
  ids: number[];
}
