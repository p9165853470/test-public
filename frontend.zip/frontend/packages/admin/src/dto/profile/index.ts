import { BlockReasons } from '@rfb/common';

export interface IDTOProfileViewResponse {
  id: number;
  email: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  created_at: string;
  updated_at: string;
  block_reason: BlockReasons;
  active: boolean;
  master: boolean;
  password_unsafe_at: string;
}
