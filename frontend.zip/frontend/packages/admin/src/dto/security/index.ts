export interface IDTOPasswordChangeRequest {
  old_password: string;
  new_password: string;
  new_password_retry: string;
}

export interface IDTOPasswordResetRequest {
  login: string;
}
