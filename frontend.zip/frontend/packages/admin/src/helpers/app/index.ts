import fp from 'lodash/fp';

import statusTranslationsConfig from 'configs/api/status-translations';

interface IError {
  [key: string]: string[]
};

export const convertApiErrorCodesToFieldMessages = (errorList: { field: string, code: number }[]) =>
  errorList.reduce((accum: IError, curr) => {
    accum[curr.field] = [fp.path<string>(curr.code, statusTranslationsConfig)];
    return accum;
  }, {});
