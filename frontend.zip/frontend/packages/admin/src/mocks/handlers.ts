import { rest } from 'msw';
import storage from 'utils/storage';

const frontUsers = [
  {
    id: 1,
    email: 'TverdovaNM@rusfinance.ru',
    first_name: 'Natalya',
    middle_name: 'Mikhaylovna',
    last_name: 'Tverdova',
    phone_number: '79151234567',
    key_word: 'Мурка',
    created_at: '2020-11-13 06:15:24',
    updated_at: '2021-02-16 12:19:26',
    block_reason: 0,
    active: true,
    dealers: [
      {
        diasoft_id: '2845QW5T',
        authority_begin_date: '2020-11-12',
        authority_end_date: '2021-11-19',
        agreement_at: '2020-11-16 11:39:34',
        validated_at: '2020-11-16 11:39:04',
        name: 'ООО Яркий свет',
        inn: '1641253999',
        kpp: '154364179',
      },
      {
        diasoft_id: '12345678',
        authority_begin_date: '2020-11-13',
        authority_end_date: '2021-11-20',
        agreement_at: '2020-11-17 11:39:34',
        validated_at: '2020-11-17 11:39:04',
        name: 'ПАО Росбанк',
        inn: '1641253999',
        kpp: '154364179',
      },
      {
        diasoft_id: '87654321',
        authority_begin_date: '2020-11-14',
        authority_end_date: '2021-11-21',
        agreement_at: '2020-11-18 11:39:34',
        validated_at: '2020-11-18 11:39:04',
        name: 'Общество с ограниченной ответственностью МУСА МОТОРС Джей Эл Эр',
        inn: '1641253999',
        kpp: '154364179',
      },
    ],
  },
  {
    id: 1,
    email: 'IvanovII@rusfinance.ru',
    first_name: 'Ivan',
    middle_name: 'Ivanovich',
    last_name: 'Ivanov',
    phone_number: '79159876543',
    key_word: 'Алладин',
    created_at: '2020-11-13 06:15:24',
    updated_at: '2021-02-16 12:19:26',
    block_reason: 0,
    active: true,
    dealers: [
      {
        diasoft_id: '12345678',
        authority_begin_date: '2020-11-13',
        authority_end_date: '2021-11-20',
        agreement_at: '2020-11-17 11:39:34',
        validated_at: '2020-11-17 11:39:04',
        name: 'ПАО Росбанк',
        inn: '1641253999',
        kpp: '154364179',
      },
      {
        diasoft_id: '87654321',
        authority_begin_date: '2020-11-14',
        authority_end_date: '2021-11-21',
        agreement_at: '2020-11-18 11:39:34',
        validated_at: '2020-11-18 11:39:04',
        name: 'Общество с ограниченной ответственностью МУСА МОТОРС Джей Эл Эр',
        inn: '1641253999',
        kpp: '154364179',
      },
    ],
  },
];

const dealers = [
  {
    user_name: 'Жук Александр Валерьевич',
    authority_begin_date: '2020-12-18',
    authority_end_date: '2021-12-31',
    phone_number: '79163367069',
    key_word: 'TESTWORD',
    diasoft_id: '10037810768',
    name: 'Тестовая организация',
    inn: '1641153999',
    kpp: '154364179',
  },
  {
    user_name: 'Жук Александр Валерьевич',
    authority_begin_date: '2020-12-20',
    authority_end_date: '2022-12-31',
    phone_number: '79163367069',
    key_word: 'TESTWORD',
    diasoft_id: '10032340768',
    name: 'Тестовая организация2',
    inn: '1635653999',
    kpp: '153424179',
  },
];

export const handlers = [
  rest.get(`http://api-back.localhost/front-user/index`, (req, res, ctx) => {
    console.log('/front-user/index');
    const params = new URLSearchParams(req.url.search);
    return res(
      ctx.status(200),
      ctx.json(
        frontUsers.filter(
          (user) =>
            user.email.startsWith(!params.get('email') ? '' : (params.get('email') as string)) &&
            `${user.last_name} ${user.first_name} ${user.middle_name}`.startsWith(
              !params.get('name') ? '' : (params.get('name') as string)
            ) &&
            user.phone_number.startsWith(
              !params.get('phone_number') ? '' : (params.get('phone_number') as string)
            )
        )
      )
    );
  }),
  rest.post(`http://api-back.localhost/front-user/create`, (req, res, ctx) => {
    console.log(`/front-user/create`);
    console.log(req.body);
    const fio = (req.body as any).name.split();
    (req.body as any).dealers = (req.body as any).dealers?.map((dealer: any) => ({
      ...dealer,
      name: 'Test',
      inn: '1231231231',
      kpp: '12344333',
    }));
    frontUsers.push({
      ...frontUsers[0],
      ...(req.body as any),
      last_name: fio[0],
      middle_name: fio[1],
      first_name: fio[2],
      id: frontUsers.length + 1,
    });
    return res(ctx.status(200));
  }),
  rest.post(`http://api-back.localhost/front-user/:userId/update`, (req, res, ctx) => {
    const { userId } = req.params;
    console.log(`/front-user/${userId}/update`);
    console.log(req.body);
    const index = frontUsers.findIndex((user) => String(user.id) === userId);
    frontUsers[index] = { ...frontUsers[index], ...(req.body as any) };
    return res(ctx.status(200));
  }),
  rest.get(`http://api-back.localhost/front-user/:userId/view`, (req, res, ctx) => {
    const { userId } = req.params;
    console.log(`/front-user/${userId}/view`);
    return res(ctx.status(200), ctx.json(frontUsers.find((user) => String(user.id) === userId)));
  }),
  rest.get(`http://api-back.localhost/rf-info/user`, (req, res, ctx) => {
    console.log('/rf-info/user');
    return res(ctx.status(200), ctx.json(dealers));
  }),
];
