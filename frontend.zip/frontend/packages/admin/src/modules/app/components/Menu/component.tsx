import React from 'react';

import { MenuHorizontal, IMenuElement, IMenuSubMenu } from '@rfb/ui-kit';

export interface IAppMenuProps {
  config: (IMenuElement | IMenuSubMenu)[];
}

const Menu = (props: IAppMenuProps) => <MenuHorizontal config={props.config} />;

export default Menu;
