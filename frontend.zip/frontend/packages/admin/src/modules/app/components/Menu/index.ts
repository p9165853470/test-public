import { connect } from 'react-redux';

import fp from 'lodash/fp'

import { Roles } from '@rfb/common';

import { appMenuConfig } from 'configs/menu';

import { name as userName, selectors as userSelectors, IUserState } from 'modules/user/store';

import Component, { IAppMenuProps } from './component';

const mapStateToProps = (state: {[userName]: IUserState}): IAppMenuProps => {
  const user: IUserState['profile'] = userSelectors.selectProfile(state);
  const role: Roles = user!.master ? Roles.MASTER_ADMIN : Roles.ADMIN;

  return {
    config: fp.pipe(
      fp.filter(fp.pipe(fp.path('accessList'), fp.contains(role))),
      fp.map(fp.unset('accessList')),
    )(appMenuConfig),
  }
};

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Component);
