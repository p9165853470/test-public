import { put, takeEvery } from 'redux-saga/effects';

import api from 'utils/api';

import apiEndpoints from 'configs/api/endpoints';

import { actions } from './index';
import { actions as userActions } from 'modules/user/store';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* init(): TODO_ANY {
  yield put(actions.set({ isLoading: true }));
  try {
    const profile = yield api.get(apiEndpoints.profile.view);

    yield put(userActions.set({ profile: profile.data }));
    yield put(actions.initSuccessful());
  } catch (error) {
    yield put(actions.initFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* initSuccessful() {
  yield put(actions.set({ isAppInit: true }));
}

function* initFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
  yield put(actions.set({ apiErrorCode: action.payload.code }));
}

export default function* () {
  yield takeEvery(actions.init, init);
  yield takeEvery(actions.initSuccessful, initSuccessful);
  yield takeEvery(actions.initFailure, initFailure);
}
