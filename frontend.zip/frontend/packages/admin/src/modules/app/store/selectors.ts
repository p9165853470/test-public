import { createSelector } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { name } from './index';

export const selectState = fp.path(name);

export default {
  selectIsAppInit: createSelector(selectState, fp.path('isAppInit')),
  selectIsLoading: createSelector(selectState, fp.path('isLoading')),
  selectApiErrorCode: createSelector(selectState, fp.path('apiErrorCode')),
};
