import { createSlice } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getStateFromParams } from '@rfb/common';

export interface IAppState {
  apiErrorCode: number;
  isAppInit: boolean;
  isLoading: boolean;
  errors: { [key: string]: string[] };
}

const initialState: IAppState = {
  apiErrorCode: 0,
  isAppInit: false,
  isLoading: true,
  errors: {},
};

const appSlice = createSlice({
  name: 'app',

  initialState,

  reducers: {
    set: (state, action) => ({ ...state, ...action.payload }),
    setError: (state, action) => ({
      ...state,
      errors: { ...state.errors, ...action.payload },
    }),

    init: getStateFromParams,
    initSuccessful: fp.identity,
    initFailure: getStateFromParams,
  },
});

export const { name, actions, reducer } = appSlice;
