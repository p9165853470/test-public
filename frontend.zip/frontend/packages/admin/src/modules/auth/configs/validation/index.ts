import validator from 'utils/validator';

import { validationMessages } from '@rfb/common';

export { passwordRules, passwordRepeatRules } from 'configs/validation/rules';

export const loginRules = validator
  .string()
  .required()
  .email()
  .min(1)
  .max(256)
  .test('not-cyrillic', 'Некорректный email', (value) => !/[а-яёА-ЯЁ]+/.test(value || ''));

export const passwordAuthRules = validator
  .string()
  .required()
  .min(16)
  .matches(/^(?=.*[a-z а-я])(?=.*[A-Z А-Я])(?=.*[0-9])/, validationMessages.app.passwordAuth);
