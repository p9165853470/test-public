import { put, takeEvery } from 'redux-saga/effects';

import api from 'utils/api';
import storage from 'utils/storage';

import { convertApiErrorCodesToMessages } from '@rfb/common';

import apiEndpoints from 'configs/api/endpoints';
import routingConfig from 'configs/routing';

import { actions as appActions } from 'modules/app/store';
import { actions } from './index';

import { IDTOTokenCreateResponse } from 'dto/auth';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* login(action: TODO_ANY) {
  try {
    yield put(actions.set({ isSending: true }));
    const result: { data: IDTOTokenCreateResponse } = yield api.post(
      apiEndpoints.auth.tokenCreate,
      action.payload.data
    );
    yield put(actions.loginSuccessful({
      token: result.data.token,
      email: action.payload.data.login,
      history: action.payload.history
    }));
  } catch (error) {
    yield put(actions.loginFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isSending: false }));
  }
}

function* loginSuccessful(action: TODO_ANY) {
  (storage as TODO_ANY).set('token', action.payload.token);
  yield put(actions.set({ token: action.payload.token }))
  action.payload.history.push(routingConfig.main.path);
}

function* loginFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
}

function* logout() {
  try {
    yield api.post(apiEndpoints.auth.tokenDestroy, {});
    yield put(actions.logoutSuccessful({}));
  } catch (error) {
    yield put(actions.logoutFailure(error.response?.data));
  }
}

function* logoutSuccessful() {
  storage.clearAll();
  window.location.replace(routingConfig.login.path);
  yield;
}

function* logoutFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
}

function* restorePassword(action: TODO_ANY) {
  try {
    yield put(actions.set({ isSending: true }));
    yield api.post(apiEndpoints.security.passwordReset, action.payload.data)
    yield put(actions.restorePasswordSuccessful({ data: action.payload.data, history: action.payload.history }));
  } catch(error) {
    yield put(actions.restorePasswordFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isSending: false }));
  }
}

function* restorePasswordSuccessful(action: TODO_ANY) {
  action.payload.history.push(routingConfig.passwordRestoreSent.path);
  storage.set('restore-password-email', action.payload.data.login);
  yield put(actions.set({ isPasswordRestoreSent: true }));
}

function* restorePasswordFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
}

function* changePassword(action: TODO_ANY) {
  try {
    yield api.post(apiEndpoints.security.passwordChange, action.payload.data);
    yield put(actions.changePasswordSuccessful({ history: action.payload.history }));
  } catch (error) {
    yield put(actions.changePasswordFailure(error.response?.data));
  }
}

function* changePasswordSuccessful(action: TODO_ANY) {
  action.payload.history.push(routingConfig.main.path);
  yield put(appActions.set({ apiErrorCode: 0 }));
}

function* changePasswordFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
}

export default function* () {
  yield takeEvery(actions.login, login);
  yield takeEvery(actions.loginSuccessful, loginSuccessful);
  yield takeEvery(actions.loginFailure, loginFailure);

  yield takeEvery(actions.logout, logout);
  yield takeEvery(actions.logoutSuccessful, logoutSuccessful);
  yield takeEvery(actions.logoutFailure, logoutFailure);

  yield takeEvery(actions.restorePassword, restorePassword);
  yield takeEvery(actions.restorePasswordSuccessful, restorePasswordSuccessful);
  yield takeEvery(actions.restorePasswordFailure, restorePasswordFailure);

  yield takeEvery(actions.changePassword, changePassword);
  yield takeEvery(actions.changePasswordSuccessful, changePasswordSuccessful);
  yield takeEvery(actions.changePasswordFailure, changePasswordFailure);
}
