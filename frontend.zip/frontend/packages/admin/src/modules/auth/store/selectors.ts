import { createSelector } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { name } from './index';

export const selectState = fp.path(name);
const selectForm = createSelector(selectState, fp.path('form'));

export default {
  selectFormValueByField: createSelector(selectForm, (state) => (field: string) =>
    fp.path(field, state)
  ),
  selectErrorListByField: createSelector(selectState, (state) => (field: string) =>
    fp.pathOr([], ['errors', field], state)
  ),
  selectIsPasswordRestoreSent: createSelector(selectState, fp.path('isPasswordRestoreSent')),
  selectIsSending: createSelector(selectState, fp.path('isSending')),
};
