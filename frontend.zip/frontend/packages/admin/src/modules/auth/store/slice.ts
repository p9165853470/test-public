import { createSlice } from '@reduxjs/toolkit';

import { getStateFromParams } from '@rfb/common';

export interface IAuthState {
  form: {
    login: string,
    password: string,
    passwordOld: string,
    passwordRepeat: string,
  };
  isPasswordRestoreSent: boolean;
  isSending: boolean;
  errors: { [key: string]: string[] };
}

const initialState: IAuthState = {
  form: {
    login: '',
    password: '',
    passwordOld: '',
    passwordRepeat: '',
  },
  isPasswordRestoreSent: false,
  isSending: false,
  errors: {},
};

const authSlice = createSlice({
  name: 'auth',

  initialState,

  reducers: {
    set: (state, action) => ({ ...state, ...action.payload }),
    setForm: (state, action) => ({ ...state, form: { ...state.form, ...action.payload } }),
    setError: (state, action) => ({
      ...state,
      errors: { ...state.errors, ...action.payload },
    }),
    reset: () => ({ ...initialState }),
    resetForm: (state) => ({ ...state, form: { ...initialState.form } }),
    resetErrors: (state) => ({ ...state, errors: { ...initialState.errors } }),

    login: getStateFromParams,
    loginSuccessful: getStateFromParams,
    loginFailure: getStateFromParams,

    logout: getStateFromParams,
    logoutSuccessful: getStateFromParams,
    logoutFailure: getStateFromParams,

    restorePassword: getStateFromParams,
    restorePasswordSuccessful: getStateFromParams,
    restorePasswordFailure: getStateFromParams,

    changePassword: getStateFromParams,
    changePasswordSuccessful: getStateFromParams,
    changePasswordFailure: getStateFromParams,
  },
});

export const { name, actions, reducer } = authSlice;
