import React, { useEffect, useState } from 'react';
import fp from 'lodash/fp';

import styles from './assets/styles/index.module.css';
import SettingsUserForm from '../components/Settings';
import { Button, Input, MessageList } from '@rfb/ui-kit';
import { configureValidator, runRulesChain } from '@rfb/common';
import { emailRules, nameRules } from '../../../configs/validation';
import { IDTOBackUserCreateRequest } from 'dto/back-user';

export interface IBackOfficeEditUserProps {
  isLoading: boolean,
  isSuccessSaved: boolean,
  email: string,
  name: string,
  emailErrorList: string[];
  nameErrorList: string[];
  apiErrorList: string[];
}
export interface IBackOfficeEditUserActions {
  actions: {
    set: Function;
    setForm: Function;
    getUserById: Function;
    saveUser: Function;
    reset: Function;
    setError: Function;
  }
}
export interface IBackOfficeEditUserPropsExternal {
  id?: number;
}

const EditUserForm = (props: IBackOfficeEditUserProps & IBackOfficeEditUserActions & IBackOfficeEditUserPropsExternal) => {
  const [key, setKey] = useState(0);

  useEffect(() => {
    if(!props.id && props.isSuccessSaved) {
      props.actions.set({ isSuccessSaved: false });
      setKey(key + 1);
    }
  }, [props.id, props.actions, props.isSuccessSaved, key]);

  useEffect(() => {
    if(props.id) {
      props.actions.getUserById({ id: props.id });
    } else {
      props.actions.reset();
    }

    return () => {
      props.actions.reset();
    };
    // ESLINT Необходимо выполнение только в момент размонтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const validators = {
    email: configureValidator({
      name: 'email',
      rule: emailRules,
      setError: props.actions.setError,
    }),
    name: configureValidator({
      name: 'name',
      rule: nameRules,
      setError: props.actions.setError,
    }),
  };

  const handleSubmit = () => {
    const sendData: IDTOBackUserCreateRequest = {
      email: props.email,
      name: props.name,
    };
    const rules = [
      validators.email(sendData.email),
      validators.name(sendData.name),
    ];

    runRulesChain(rules)
      .then((data) => (props.actions.saveUser({ id: props.id, data: sendData })))
      .catch(fp.noop);
  };
  const handleEmailChange = (email: string) => {
    validators.email(email).finally((): void => props.actions.setForm({ email }));
  }
  const handleNameChange = (name: string) => {
    validators.name(name).finally((): void => props.actions.setForm({ name }));
  };

  const hasErrors = !fp.isEmpty(props.emailErrorList) || !fp.isEmpty(props.nameErrorList);

  return <div>
    <h1 className={styles.title}>
      {props.id ? 'Редактирование пользователя' : 'Создание пользователя'}
    </h1>
    <div className={styles.form}>
      {props.id && <SettingsUserForm />}
      <Input
        keyUnique={key.toString()}
        wrapperClassName={styles.email}
        label="Логин"
        name="email"
        value={props.email}
        hasError={!fp.isEmpty(props.emailErrorList)}
        onChange={handleEmailChange}
      />
      <MessageList type="error" messages={props.emailErrorList} />
      <Input
        keyUnique={key.toString()}
        wrapperClassName={styles.name}
        label="ФИО администратора"
        name="name"
        value={props.name}
        hasError={!fp.isEmpty(props.nameErrorList)}
        onChange={handleNameChange}
      />
      <MessageList type="error" messages={props.nameErrorList} />
      <Button
        isDisabled={props.isLoading || hasErrors}
        wrapperClassName={styles.button}
        type="submit"
        text="Сохранить"
        onClick={handleSubmit}
      />
    </div>
  </div>
}

export default EditUserForm;
