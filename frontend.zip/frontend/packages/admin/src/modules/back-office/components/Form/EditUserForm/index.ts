import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IBackOfficeState } from '../../../store';

import Component, {
  IBackOfficeEditUserProps,
  IBackOfficeEditUserActions,
  IBackOfficeEditUserPropsExternal,
} from './component';

import { TODO_ANY } from '@rfb/common/lib/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: IBackOfficeState },
  props: IBackOfficeEditUserPropsExternal,
  ): IBackOfficeEditUserPropsExternal & IBackOfficeEditUserProps => {
  const user = selectors.selectForm(state);

  return {
    id: props.id,
    isLoading: selectors.selectIsLoading(state),
    isSuccessSaved: selectors.selectIsSuccessSaved(state),
    email: user.email,
    name: user.name,
    emailErrorList: selectors.selectErrorListByField(state)('email'),
    nameErrorList: selectors.selectErrorListByField(state)('name'),
    apiErrorList: selectors.selectErrorListByField(state)('api'),
  };
};

const mapDispatchToProps = (dispatch: TODO_ANY): IBackOfficeEditUserActions => ({
  actions: bindActionCreators(actions,dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
