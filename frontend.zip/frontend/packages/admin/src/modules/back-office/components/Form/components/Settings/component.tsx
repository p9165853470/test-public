import React from 'react';

import styles from './assets/styles/index.module.css';
import { Button, ButtonWithIcon, Switch } from '@rfb/ui-kit';
import fp from 'lodash/fp';
import notification from 'utils/notification';

export interface IBackOfficeEditUserSettingsProps {
  isLoading: boolean,
  isUserBlocked: boolean;
  id: number;
}
export interface IBackOfficeEditUserSettingsActions {
  actions: {
    setFilter: Function;
    blockById: Function;
    unblockById: Function;
    removeById: Function;
  }
}

const SettingsUserForm = (props: IBackOfficeEditUserSettingsProps & IBackOfficeEditUserSettingsActions) => {
  const handleSwitchChange = (value: boolean) => {
      value
      ? notification.confirm('Подтвердить разблокировку учётной записи', () => {
          props.actions.unblockById({ id: props.id });
        })
      : notification.confirm('Подтвердить блокировку учётной записи', () => {
        props.actions.blockById({ id: props.id });
      });
  };
  const handleRemove = () => {
    notification.confirm('Подтвердить удаление учётной записи', () => {
      props.actions.removeById({ id: props.id });
    });
  };

  return <div className={styles.body}>
    <div className={styles.switch}>
      <Switch
        prefix="заблокировать"
        postfix="Разблокировать"
        isChecked={!props.isUserBlocked}
        onChange={handleSwitchChange}
      />
    </div>
    <div className={styles.button}>
      <Button
        wrapperClassName={styles.button}
        text={<ButtonWithIcon
          type="remove"
          text="Удалить"
          isActive
          wrapperClassName={styles.iconButton}
          iconClassName={styles.icon}
          onClick={fp.noop}
        />}
        onClick={handleRemove}
      />
    </div>
  </div>
}

export default SettingsUserForm;
