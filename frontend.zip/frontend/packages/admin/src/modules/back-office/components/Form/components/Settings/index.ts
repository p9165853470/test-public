import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IBackOfficeState } from '../../../../store';

import Component, {
  IBackOfficeEditUserSettingsProps,
  IBackOfficeEditUserSettingsActions,
} from './component';

import { TODO_ANY } from '@rfb/common/lib/types/TODO_ANY';

const mapStateToProps = (state: { [name]: IBackOfficeState }): IBackOfficeEditUserSettingsProps => {
  const user = selectors.selectCurrentUser(state);
  return {
    isLoading: false,
    isUserBlocked: user.block_reason > 0,
    id: user.id,
  };
};

const mapDispatchToProps = (dispatch: TODO_ANY): IBackOfficeEditUserSettingsActions => ({
  actions: bindActionCreators(actions,dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
