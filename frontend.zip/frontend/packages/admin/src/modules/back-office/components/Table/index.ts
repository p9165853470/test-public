import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getTransformedDate, convertPathUsingParams } from '@rfb/common';

import { ITable } from '@rfb/ui-kit';

import { store } from 'root-store';

import routingConfig from 'configs/routing';

import { name, actions, selectors, IBackOfficeState } from '../../store';

import Component, { IBackOfficeTableProps, IBackOfficeTableActions } from './component';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

type TBackOfficeTableColumn = {
  header: ITable['headers'][number];
  transform?: (value: any, user?: IBackOfficeState['userList'][number]) => void;
};

const mapStateToProps = (state: { [name]: IBackOfficeState }): IBackOfficeTableProps => {
  const backUserList: IBackOfficeState['userList'] = selectors.selectUserList(state);
  const selectedList: IBackOfficeState['selectedList'] = selectors.selectSelectedList(state);
  const filter: IBackOfficeState['filter'] = selectors.selectFilter(state);

  const columns: TBackOfficeTableColumn[] = [
    { header: { title: '', value: 'check', columnClassName: styles.checkbox } },
    { header: { title: '', value: 'lock', columnClassName: styles.lock } },
    {
      header: {
        type: 'input',
        title: 'Логин',
        value: 'email',
        filterValue: filter.login,
        onFilterChange: (login) => store.dispatch(actions.setFilter({ login })),
      },
    },
    {
      header: {
        type: 'input',
        title: 'ФИО администратора',
        value: 'name',
        filterValue: filter.name,
        onFilterChange: (name) => store.dispatch(actions.setFilter({ name })),
      },
      transform: fp.pipe(
        fp.nthArg(1),
        fp.paths(['last_name', 'first_name', 'middle_name']),
        fp.join(' ')
      ),
    },
    {
      header: { title: 'Дата создания', value: 'created_at' },
      transform: getTransformedDate,
    },
    {
      header: { title: 'Дата изменения', value: 'updated_at' },
      transform: getTransformedDate,
    },
  ];

  const checkboxList = fp.map(
    (user: IBackOfficeState['userList'][number]) => [
      {
        isCheckbox: true,
        isChecked: fp.contains(user.id, selectedList),
        onChange: () => {
          store.dispatch(actions.toggleSelected(user.id));
        },
      },
      {
        isCheckbox: true,
        type: 'lock',
        isChecked: user.block_reason,
        onChange: fp.noop,
      },
    ],
    backUserList
  );

  const rowDataList = fp.pipe(
    fp.map((user: IBackOfficeState['userList'][number]) =>
      fp.map(
        (column: TBackOfficeTableColumn) =>
          fp.isFunction(column.transform)
            ? column.transform(fp.path(column.header.value, user), user)
            : fp.path(column.header.value, user),
        columns
      )
    ),
    fp.zip(checkboxList),
    fp.map(([checkboxList, row]: [any, any]) => [
      ...checkboxList,
      ...fp.drop(fp.size(checkboxList), row),
    ]),
    fp.map((data) => ({ data }))
  )(backUserList);

  const rowConfigList = fp.pipe(
    fp.map((user: IBackOfficeState['userList'][number]) => ({
      link: convertPathUsingParams(routingConfig.backOfficeProfileEdit.path, { id: user.id }),
    })),
    fp.map((config) => ({ config }))
  )(backUserList);

  return {
    headers: fp.map(fp.path('header'), columns),
    rows: fp.pipe(fp.zip(rowConfigList), fp.map(fp.mergeAll))(rowDataList),
    page: filter.page,
    pageCount: selectors.selectPageCount(state),
    filter,
    isLoading: selectors.selectIsLoading(state),
  };
};

const mapDispatchToProps = (dispatch: TODO_ANY): IBackOfficeTableActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
