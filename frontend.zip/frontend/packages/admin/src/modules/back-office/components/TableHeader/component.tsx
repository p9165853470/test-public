import React from 'react';

import fp from 'lodash/fp';

import { AdminActions } from '@rfb/common';

import { ButtonWithIcon, LinkWithContent } from '@rfb/ui-kit';

import notification from 'utils/notification';

import {
  IDTOBackUserBlockRequest,
  IDTOBackUserUnblockRequest,
  IDTOBackUserRemoveRequest,
} from 'dto/back-user';

import { IBackOfficeState } from '../../store';

import styles from './assets/styles/index.module.css';
import routingConfig from '../../../../configs/routing';

export interface IBackOfficeTableHeaderProps {
  actionType: AdminActions;
  selectedList: number[];
  filter: IBackOfficeState['filter'];
}

export interface IBackOfficeTableHeaderActions {
  actions: {
    block: Function,
    unblock: Function,
    remove: Function,
  };
}

const TableHeader = (props: IBackOfficeTableHeaderProps & IBackOfficeTableHeaderActions) => {
  const onBlockClick = () => {
    notification.confirm('Подтвердить блокировку учётных записей', () => {
      const data: IDTOBackUserBlockRequest = { ids: props.selectedList };
      props.actions.block({ data, filter: props.filter });
    });
  };
  const onUnblockClick = () => {
    notification.confirm('Подтвердить разблокировку учётных записей', () => {
      const data: IDTOBackUserUnblockRequest = { ids: props.selectedList };
      props.actions.unblock({ data, filter: props.filter });
    });
  };
  const onRemoveClick = () => {
    notification.confirm('Подтвердить удаление учётных записей', () => {
      const data: IDTOBackUserRemoveRequest = { ids: props.selectedList };
      props.actions.remove({ data, filter: props.filter });
    });
  };

  return (
    <div className={styles.main}>
      <h1 className={styles.title}>Пользователи системы</h1>

      <div className={styles.buttonGroup}>
        <ButtonWithIcon
          wrapperClassName={styles.button}
          type="block"
          text="Заблокировать"
          isActive={fp.isEqual(props.actionType, AdminActions.BLOCK)}
          onClick={onBlockClick}
        />
        <ButtonWithIcon
          wrapperClassName={styles.button}
          type="unblock"
          text="Разблокировать"
          isActive={fp.isEqual(props.actionType, AdminActions.UNBLOCK)}
          onClick={onUnblockClick}
        />
        <ButtonWithIcon
          wrapperClassName={styles.button}
          type="remove"
          text="Удалить"
          isActive={!fp.isEmpty(props.selectedList)}
          onClick={onRemoveClick}
        />

        <LinkWithContent wrapperClassName={styles.buttonAdd} to={routingConfig.backOfficeProfileAdd.path}>
          <ButtonWithIcon type="add" text="Добавить пользователя" isActive onClick={fp.noop} />
        </LinkWithContent>
      </div>
    </div>
  );
};

export default TableHeader;
