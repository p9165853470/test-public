import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IBackOfficeState } from '../../store';

import Component, { IBackOfficeTableHeaderProps, IBackOfficeTableHeaderActions } from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (state: { [name]: IBackOfficeState }): IBackOfficeTableHeaderProps => ({
  actionType: selectors.selectActionType(state),
  selectedList: selectors.selectSelectedList(state),
  filter: selectors.selectFilter(state),
});

const mapDispatchToProps = (dispatch: TODO_ANY): IBackOfficeTableHeaderActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
