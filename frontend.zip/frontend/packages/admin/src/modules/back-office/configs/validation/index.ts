import validator from 'utils/validator';

import fp from 'lodash/fp';

export const emailRules = validator
  .string()
  .required()
  .email()
  .min(1)
  .max(256)
  .test('not-cyrillic', 'Некорректный email', (value) => !/[а-яёА-ЯЁ]+/.test(value || ''));

export const nameRules = validator
  .string()
  .required('Заполните ФИО администратора')
  .test(
    'last-first-middle-names',
    'ФИО администратора должна содержать фамилию, имя и отчество',
    fp.pipe(fp.split(' '), fp.nth(2), fp.trim, fp.negate(fp.isEmpty))
  );
