import { createSlice } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getStateFromParams, AdminActions } from '@rfb/common';

import { TDTOBackUserGetResponse, TDTOBackUser } from 'dto/back-user';

export interface IBackOfficeState {
  userList: TDTOBackUserGetResponse;
  selectedList: number[];
  filter: {
    login: string,
    name: string,
    page: number,
  };
  actionType: AdminActions | null;
  pageCount: number;
  errors: { [key: string]: string[] };
  isLoading: boolean;
  isSuccessSaved: boolean;
  currentUser: TDTOBackUser;
  form: {
    email: string,
    name: string,
  },
}

const initialState: IBackOfficeState = {
  userList: [],
  selectedList: [],
  filter: {
    login: '',
    name: '',
    page: 1,
  },
  actionType: null,
  pageCount: 0,
  errors: {},
  isLoading: false,
  isSuccessSaved: false,
  currentUser: {
    id: 0,
    email: '',
    first_name: '',
    middle_name: '',
    last_name: '',
    created_at: '',
    updated_at: '',
    active: true,
    master: false,
  },
  form: {
    email: '',
    name: '',
  },
};

const backOfficeSlice = createSlice({
  name: 'back-office',

  initialState,

  reducers: {
    set: (state, action) => ({ ...state, ...action.payload }),
    setFilter: (state, action) => ({ ...state, filter: { ...state.filter, ...action.payload } }),
    setError: (state, action) => ({
      ...state,
      errors: { ...state.errors, ...action.payload },
    }),
    setForm: (state, action) => ({ ...state, form: { ...state.form, ...action.payload } }),
    reset: () => ({ ...initialState }),
    resetForm: (state) => ({ ...state, form: { ...initialState.form } }),
    resetUser: (state) => ({ ...state, currentUser: { ...initialState.currentUser } }),
    resetFilter: (state) => ({ ...state, ...initialState.filter }),

    toggleSelected: (state, action) => {
      const selectedList: number[] = fp.xor([action.payload], state.selectedList);
      const user: IBackOfficeState['userList'][number] | undefined =
        fp.find({ id: fp.head(selectedList) }, state.userList);
      return {
        ...state,
        selectedList,
        actionType: fp.isEmpty(selectedList)
          ? null
          : (
            fp.isEmpty(user)
              ? state.actionType
              : (user?.block_reason ? AdminActions.UNBLOCK : AdminActions.BLOCK)
          ) ,
      };
    },

    getUserList: getStateFromParams,
    getUserListSuccessful: getStateFromParams,
    getUserListFailure: getStateFromParams,

    getUserById: getStateFromParams,
    getUserByIdSuccessful: getStateFromParams,
    getUserByIdFailure: getStateFromParams,

    block: getStateFromParams,
    blockSuccessful: getStateFromParams,
    blockFailure: getStateFromParams,

    unblock: getStateFromParams,
    unblockSuccessful: getStateFromParams,
    unblockFailure: getStateFromParams,

    blockById: getStateFromParams,
    blockByIdSuccessful: getStateFromParams,
    blockByIdFailure: getStateFromParams,

    unblockById: getStateFromParams,
    unblockByIdSuccessful: getStateFromParams,
    unblockByIdFailure: getStateFromParams,

    remove: getStateFromParams,
    removeSuccessful: getStateFromParams,
    removeFailure: getStateFromParams,

    removeById: getStateFromParams,
    removeByIdSuccessful: getStateFromParams,
    removeByIdFailure: getStateFromParams,

    saveUser: getStateFromParams,
    saveUserSuccessful: getStateFromParams,
    saveUserFailure: getStateFromParams,
  },
});

export const { name, actions, reducer } = backOfficeSlice;
