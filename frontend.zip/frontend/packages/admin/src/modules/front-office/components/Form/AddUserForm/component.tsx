import React, { useEffect, useState } from 'react';
import fp from 'lodash/fp';

import styles from './assets/styles/index.module.css';
import { Button, Input, MessageList, Condition, Text } from '@rfb/ui-kit';
import { configureValidator, formatPhoneNumber, runRulesChain } from '@rfb/common';
import {
  emailRules,
  datesRules,
  keyWordRules,
  nameRules,
  phoneNumberRules,
} from '../../../configs/validation';
import { IDealer, IDTOFrontUserCreateRequest } from 'dto/front-user';
import Dealer from '../components/Dealer/component';

export interface IFrontOfficeCreateUserProps {
  isLoading: boolean;
  isSuccessSaved: boolean;
  email: string;
  code: string;
  name: string;
  phone_number: string;
  key_word: string;
  dealers: IDealer[];
  emailErrorList: string[];
  nameErrorList: string[];
  phoneErrorList: string[];
  keyWordErrorList: string[];
  diasoftIdErrorList: string[];
  datesErrorList: string[];
  apiErrorList: string[];
  checkedDiasoftId: string;
}
export interface IFrontOfficeCreateUserActions {
  actions: {
    set: Function;
    setForm: Function;
    getUserById: Function;
    saveUser: Function;
    reset: Function;
    setError: Function;
    getUserDealers: Function;
  };
}
export interface IFrontOfficeCreateUserPropsExternal {
  id?: number;
}

const AddUserForm = (
  props: IFrontOfficeCreateUserProps &
    IFrontOfficeCreateUserActions &
    IFrontOfficeCreateUserPropsExternal
) => {
  const [key, setKey] = useState(0);

  useEffect(() => {
    if (props.isSuccessSaved) {
      props.actions.set({ isSuccessSaved: false });
      setKey(key + 1);
    }
  }, [props.id, props.actions, props.isSuccessSaved, key]);

  useEffect(() => {
    props.actions.reset();

    return () => {
      props.actions.reset();
    };
    // ESLINT Необходимо выполнение только в момент размонтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const validators = {
    email: configureValidator({
      name: 'email',
      rule: emailRules,
      setError: props.actions.setError,
    }),
    name: configureValidator({
      name: 'name',
      rule: nameRules,
      setError: props.actions.setError,
    }),
    phone_number: configureValidator({
      name: 'phone_number',
      rule: phoneNumberRules,
      setError: props.actions.setError,
    }),
    key_word: configureValidator({
      name: 'key_word',
      rule: keyWordRules,
      setError: props.actions.setError,
    }),
    dates: configureValidator({
      name: 'dates',
      rule: datesRules,
      setError: props.actions.setError,
    }),
  };

  const mapDealer = (dealer: IDealer) => {
    return {
      diasoft_id: dealer.diasoft_id,
      authority_begin_date: dealer.authority_begin_date,
      authority_end_date: dealer.authority_end_date,
    };
  };

  const handleSubmit = () => {
    const sendData: IDTOFrontUserCreateRequest = {
      email: props.email,
      name: props.name,
      phone_number: props.phone_number,
      key_word: props.key_word?.toUpperCase(),
      dealers: props.dealers?.map(mapDealer),
    };
    const rules = [
      validators.email(sendData.email),
      validators.name(sendData.name),
      validators.phone_number(sendData.phone_number),
      validators.key_word(sendData.key_word),
    ];

    runRulesChain(rules)
      .then((data) => props.actions.saveUser({ data: sendData }))
      .catch(fp.noop);
  };
  const handleEmailChange = (email: string) => {
    validators.email(email).finally((): void => props.actions.setForm({ email }));
  };
  const handleDealerChange = (newDealer: IDealer) => {
    validators
      .dates({
        start: newDealer.authority_begin_date,
        end: newDealer.authority_end_date,
      })
      .finally((): void => {
        const dealers = [...props.dealers];
        dealers[dealers.findIndex((dealer) => dealer.diasoft_id === newDealer.diasoft_id)] =
          newDealer;
        props.actions.setForm({ dealers });
      });
  };

  const hasErrors =
    !fp.isEmpty(props.nameErrorList) ||
    !fp.isEmpty(props.emailErrorList) ||
    !fp.isEmpty(props.datesErrorList) ||
    !fp.isEmpty(props.phoneErrorList) ||
    !fp.isEmpty(props.keyWordErrorList);

  const handleFindDealer = () => {
    props.actions.getUserDealers({
      data: {
        email: props.email,
      },
    });
  };

  return (
    <div>
      <h1 className={styles.title}>Создание пользователя</h1>

      <div className={styles.form}>
        <div className={styles.inputWrapper}>
          <div className={styles.row}>
            <Input
              keyUnique={key.toString()}
              wrapperClassName={styles.email}
              label="Логин"
              name="email"
              value={props.email}
              hasError={!fp.isEmpty(props.emailErrorList)}
              onChange={handleEmailChange}
            />
            <Button
              isDisabled={props.isLoading || hasErrors}
              wrapperClassName={styles.findButton}
              type="button"
              text="Найти"
              onClick={handleFindDealer}
            />
          </div>
          <MessageList type="error" messages={props.emailErrorList} />
          <Text label="ФИО представителя" content={props.name} />
          <MessageList type="error" messages={props.nameErrorList} />
          <Text
            label="Номер телефона представителя"
            content={formatPhoneNumber(props.phone_number)}
          />
          <MessageList type="error" messages={props.phoneErrorList} />
          <Text label="Кодовое слово" content={props.key_word?.toUpperCase()} />
          <MessageList type="error" messages={props.keyWordErrorList} />
        </div>

        <Condition value={props.dealers.length > 0}>
          <div className={styles.dealerList}>
            {props.dealers.map((dealer) => {
              return <Dealer {...dealer} onChange={handleDealerChange} />;
            })}
          </div>
          <MessageList type="error" messages={props.datesErrorList} />
        </Condition>

        <Button
          isDisabled={props.isLoading || hasErrors}
          wrapperClassName={styles.button}
          type="submit"
          text="Сохранить"
          onClick={handleSubmit}
        />
      </div>
    </div>
  );
};

export default AddUserForm;
