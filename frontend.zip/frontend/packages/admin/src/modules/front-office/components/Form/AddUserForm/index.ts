import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';
import fp from 'lodash/fp';

import { name, actions, selectors, IFrontOfficeState } from '../../../store';

import Component, {
  IFrontOfficeCreateUserProps,
  IFrontOfficeCreateUserActions,
  IFrontOfficeCreateUserPropsExternal,
} from './component';

import { TODO_ANY } from '@rfb/common/lib/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: IFrontOfficeState },
  props: IFrontOfficeCreateUserPropsExternal
): IFrontOfficeCreateUserPropsExternal & IFrontOfficeCreateUserProps => {
  const user = selectors.selectForm(state);

  return {
    id: props.id,
    isLoading: selectors.selectIsLoading(state),
    isSuccessSaved: selectors.selectIsSuccessSaved(state),
    email: user.email,
    code: user.diasoft_id,
    name: user.name,
    phone_number: user.phone_number,
    key_word: user.key_word,
    dealers: user.dealers,
    emailErrorList: selectors.selectErrorListByField(state)('email'),
    nameErrorList: selectors.selectErrorListByField(state)('name'),
    phoneErrorList: selectors.selectErrorListByField(state)('phone_number'),
    keyWordErrorList: selectors.selectErrorListByField(state)('key_word'),
    diasoftIdErrorList: selectors.selectErrorListByField(state)('diasoft_id'),
    datesErrorList: selectors.selectErrorListByField(state)('dates'),
    apiErrorList: selectors.selectErrorListByField(state)('api'),
    checkedDiasoftId: selectors.selectCurrentOrganization(state).diasoft_id,
  };
};

const mapDispatchToProps = (dispatch: TODO_ANY): IFrontOfficeCreateUserActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
