import React, { useEffect, useMemo, useState } from 'react';
import fp from 'lodash/fp';

import styles from './assets/styles/index.module.css';
import SettingsUserForm from '../components/Settings';
import {
  Button,
  DatePickerRange,
  Input,
  MessageList,
  ButtonWithIcon,
  Condition,
} from '@rfb/ui-kit';
import { configureValidator, runRulesChain } from '@rfb/common';
import {
  emailRules,
  nameRules,
  datesRules,
  diasoftIdRules,
  phoneNumberRules,
  keyWordRules,
} from '../../../configs/validation';
import { IDealer, IDTOFrontUserCreateRequest, IDTOFrontUserUpdateRequest } from 'dto/front-user';
import Dealer from '../components/Dealer/component';

export interface IFrontOfficeEditUserProps {
  isLoading: boolean;
  isSuccessSaved: boolean;
  email: string;
  code: string;
  name: string;
  phone_number: string;
  key_word: string;
  dealers: IDealer[];
  emailErrorList: string[];
  nameErrorList: string[];
  phoneErrorList: string[];
  keyWordErrorList: string[];
  diasoftIdErrorList: string[];
  datesErrorList: string[];
  apiErrorList: string[];
  checkedDiasoftId: string;
}
export interface IFrontOfficeEditUserActions {
  actions: {
    set: Function;
    setForm: Function;
    getUserById: Function;
    saveUser: Function;
    reset: Function;
    setError: Function;
    updateDealers: Function;
  };
}
export interface IFrontOfficeEditUserPropsExternal {
  id?: number;
}

const EditUserForm = (
  props: IFrontOfficeEditUserProps & IFrontOfficeEditUserActions & IFrontOfficeEditUserPropsExternal
) => {
  useEffect(() => {
    props.actions.getUserById({ id: props.id });
    return () => {
      props.actions.reset();
    };
    // ESLINT Необходимо выполнение только в момент размонтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const validators = {
    email: configureValidator({
      name: 'email',
      rule: emailRules,
      setError: props.actions.setError,
    }),
    name: configureValidator({
      name: 'name',
      rule: nameRules,
      setError: props.actions.setError,
    }),
    phone_number: configureValidator({
      name: 'phone_number',
      rule: phoneNumberRules,
      setError: props.actions.setError,
    }),
    key_word: configureValidator({
      name: 'key_word',
      rule: keyWordRules,
      setError: props.actions.setError,
    }),
    dates: configureValidator({
      name: 'dates',
      rule: datesRules,
      setError: props.actions.setError,
    }),
  };

  const mapDealer = (dealer: IDealer) => {
    return {
      diasoft_id: dealer.diasoft_id,
      authority_begin_date: dealer.authority_begin_date,
      authority_end_date: dealer.authority_end_date,
    };
  };

  const handleSubmit = () => {
    const sendData: IDTOFrontUserUpdateRequest = {
      email: props.email,
      name: props.name,
      phone_number: props.phone_number,
      key_word: props.key_word,
      dealers: props.dealers.map(mapDealer),
    };
    const rules = [
      validators.email(sendData.email),
      validators.name(sendData.name),
      validators.phone_number(sendData.phone_number),
      validators.key_word(sendData.key_word),
    ];

    runRulesChain(rules)
      .then((data) => props.actions.saveUser({ id: props.id, data: sendData }))
      .catch(fp.noop);
  };
  const handleNameChange = (name: string) => {
    validators.name(name).finally((): void => props.actions.setForm({ name }));
  };
  const handlePhoneNumberChange = (phone_number: string) => {
    validators
      .phone_number(phone_number)
      .finally((): void => props.actions.setForm({ phone_number }));
  };
  const handleKeyWordChange = (key_word: string) => {
    validators
      .key_word(key_word)
      .finally((): void => props.actions.setForm({ key_word: key_word?.toUpperCase() }));
  };
  const handleDealerChange = (newDealer: IDealer) => {
    validators
      .dates({
        start: newDealer.authority_begin_date,
        end: newDealer.authority_end_date,
      })
      .finally((): void => {
        const dealers = [...props.dealers];
        dealers[dealers.findIndex((dealer) => dealer.diasoft_id === newDealer.diasoft_id)] =
          newDealer;
        props.actions.setForm({ dealers });
      });
  };

  const hasErrors =
    !fp.isEmpty(props.nameErrorList) ||
    !fp.isEmpty(props.emailErrorList) ||
    !fp.isEmpty(props.datesErrorList) ||
    !fp.isEmpty(props.phoneErrorList) ||
    !fp.isEmpty(props.keyWordErrorList);

  const handleAddDealer = () => {
    props.actions.updateDealers({
      data: {
        email: props.email,
      },
    });
  };

  return (
    <div>
      <h1 className={styles.title}>Редактирование пользователя</h1>
      <div className={styles.login}>{props.email}</div>

      <div className={styles.form}>
        <div className={styles.inputWrapper}>
          <SettingsUserForm />
          <Input
            wrapperClassName={styles.name}
            label="ФИО представителя"
            name="name"
            value={props.name}
            hasError={!fp.isEmpty(props.nameErrorList)}
            onChange={handleNameChange}
          />
          <MessageList type="error" messages={props.nameErrorList} />

          <Input
            name="phone_number"
            type="phone"
            wrapperClassName={styles.phoneNumber}
            value={props.phone_number}
            label="Номер телефона представителя"
            hasError={!fp.isEmpty(props.phoneErrorList)}
            onChange={handlePhoneNumberChange}
          />
          <MessageList type="error" messages={props.phoneErrorList} />

          <Input
            name="key_word"
            wrapperClassName={styles.keyWord}
            value={props.key_word?.toUpperCase()}
            label="Кодовое слово"
            hasError={!fp.isEmpty(props.keyWordErrorList)}
            onChange={handleKeyWordChange}
          />
          <MessageList type="error" messages={props.keyWordErrorList} />
        </div>

        <ButtonWithIcon
          wrapperClassName={styles.addDealer}
          iconClassName={styles.addDealerIcon}
          type="add"
          text="Добавить организацию"
          isActive
          onClick={handleAddDealer}
        />

        <Condition value={props.dealers.length > 0}>
          <div className={styles.dealerList}>
            {props.dealers.map((dealer) => {
              return <Dealer {...dealer} onChange={handleDealerChange} />;
            })}
          </div>
          <MessageList type="error" messages={props.datesErrorList} />
        </Condition>

        <Button
          isDisabled={props.isLoading || hasErrors}
          wrapperClassName={styles.button}
          type="submit"
          text="Сохранить"
          onClick={handleSubmit}
        />
      </div>
    </div>
  );
};

export default EditUserForm;
