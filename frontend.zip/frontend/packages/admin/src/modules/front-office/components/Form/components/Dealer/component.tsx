import { IDealer } from 'dto/front-user';
import React from 'react';
import { DatePickerRange } from '@rfb/ui-kit';

import styles from './assets/styles/index.module.css';

export interface IFrontOfficeEditUserDealerProps extends IDealer {
  onChange: Function;
}

const Dealer = ({ onChange, ...props }: IFrontOfficeEditUserDealerProps) => {
  return (
    <div className={styles.body}>
      <div>Код: {props.diasoft_id}</div>
      <div>Название: {props.name}</div>
      <div>ИНН: {props.inn}</div>
      <div>КПП: {props.kpp}</div>
      <DatePickerRange
        wrapperClassName={styles.datePicker}
        start={props.authority_begin_date}
        end={props.authority_end_date}
        onChange={(value) => {
          onChange({ ...props, authority_begin_date: value[0], authority_end_date: value[1] });
        }}
      />
    </div>
  );
};

export default Dealer;
