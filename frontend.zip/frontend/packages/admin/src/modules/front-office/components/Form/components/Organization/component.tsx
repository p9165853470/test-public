import React, { useEffect } from 'react';

import styles from './assets/styles/index.module.css';

import { MessageList, SearchInput } from '@rfb/ui-kit';
import Info from './components/Info';
import fp from 'lodash/fp';

export interface IFrontOfficeEditUserInfoProps {
  isLoading: boolean,
  code: string,
  diasoftId: string,
}
export interface IFrontOfficeEditUserInfoActions {
  actions: {
    getOrganization: Function;
    setForm: Function;
    setError: Function;
  }
}
export interface IFrontOfficeEditUserInfoPropsExternal {
  errorList: string[],
  onChange: Function,
  key: string,
}

const InfoUserForm = (props: IFrontOfficeEditUserInfoProps & IFrontOfficeEditUserInfoActions & IFrontOfficeEditUserInfoPropsExternal) => {
  useEffect(() => {
    if (props.code) {
      props.actions.getOrganization({ id: props.code });
    }
  }, [props.code, props.actions]);

  const handleOrganizationSearch = (value: string) => {
    if (value) {
      props.actions.getOrganization({ id: value });
    }
    props.onChange(value);
  };

  const handleChange = (value: string) => {
    props.actions.setForm({ diasoft_id: value });
    props.onChange(value);
  };

  return <div className={styles.body}>
    {!props.code && <SearchInput
      keyUnique={props.key}
      wrapperClassName={styles.search}
      value={props.diasoftId}
      onChange={handleChange}
      onSearch={handleOrganizationSearch}
      hasError={!fp.isEmpty(props.errorList)}
    />
    }
    <MessageList type='error' messages={props.errorList} wrapperClassName={styles.message} />
    <Info />
  </div>
}

export default InfoUserForm;
