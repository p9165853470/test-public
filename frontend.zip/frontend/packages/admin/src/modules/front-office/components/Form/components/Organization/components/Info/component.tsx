import React from 'react';

import styles from './assets/styles/index.module.css';

export interface IFrontOfficeEditUserInfoProps {
  isLoading: boolean,
  code: string,
  name: string,
  inn: string,
  kpp: string,
}
export interface IFrontOfficeEditUserInfoActions {
  actions: {
    setFilter: Function;
  }
}

const InfoUserForm = (props: IFrontOfficeEditUserInfoProps & IFrontOfficeEditUserInfoActions) => {
  return <div className={styles.body}>
    <div>Код: {props.code}</div>
    <div>Название: {props.name}</div>
    <div>ИНН: {props.inn}</div>
    <div>КПП: {props.kpp}</div>
  </div>
}

export default InfoUserForm;
