import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IFrontOfficeState } from '../../../../../../store';

import Component, {
  IFrontOfficeEditUserInfoProps,
  IFrontOfficeEditUserInfoActions,
} from './component';

import { TODO_ANY } from '@rfb/common/lib/types/TODO_ANY';

const mapStateToProps = (state: { [name]: IFrontOfficeState }): IFrontOfficeEditUserInfoProps => {
  const organization = selectors.selectCurrentOrganization(state);
  return {
    isLoading: false,
    code: organization.diasoft_id,
    name: organization.name,
    inn: organization.inn,
    kpp: organization.kpp,
  };
};

const mapDispatchToProps = (dispatch: TODO_ANY): IFrontOfficeEditUserInfoActions => ({
  actions: bindActionCreators(actions,dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
