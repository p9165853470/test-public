import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IFrontOfficeState } from '../../../../store';

import Component, {
  IFrontOfficeEditUserInfoProps,
  IFrontOfficeEditUserInfoActions,
} from './component';

import { TODO_ANY } from '@rfb/common/lib/types/TODO_ANY';

const mapStateToProps = (state: { [name]: IFrontOfficeState }): IFrontOfficeEditUserInfoProps => {
  return {
    isLoading: false,
    code: selectors.selectCurrentUser(state).diasoft_id,
    diasoftId: selectors.selectForm(state).diasoft_id,
  };
};

const mapDispatchToProps = (dispatch: TODO_ANY): IFrontOfficeEditUserInfoActions => ({
  actions: bindActionCreators(actions,dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
