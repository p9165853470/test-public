import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IFrontOfficeState } from '../../../../store';

import Component, {
  IFrontOfficeEditUserSettingsProps,
  IFrontOfficeEditUserSettingsActions,
} from './component';

import { TODO_ANY } from '@rfb/common/lib/types/TODO_ANY';

const mapStateToProps = (state: { [name]: IFrontOfficeState }): IFrontOfficeEditUserSettingsProps => {
  const user = selectors.selectCurrentUser(state);
  return {
    isLoading: false,
    isUserBlocked: user.block_reason > 0,
    id: user.id,
  };
};

const mapDispatchToProps = (dispatch: TODO_ANY): IFrontOfficeEditUserSettingsActions => ({
  actions: bindActionCreators(actions,dispatch)
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
