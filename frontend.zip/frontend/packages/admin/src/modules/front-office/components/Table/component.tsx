import React, { useEffect } from 'react';

import fp from 'lodash/fp';

import { Table as UIKitTable, ITable } from '@rfb/ui-kit';

import { IFrontOfficeState } from '../../store'

export interface IFrontOfficeTableProps {
  headers: ITable['headers'],
  rows: ITable['rows'],
  filter: IFrontOfficeState['filter'],
  page: number,
  pageCount: number,
  isLoading: boolean,
}

export interface IFrontOfficeTableActions {
  actions: {
    getUserList: Function;
    setFilter: Function;
    reset: Function;
  }
}

const Table = (props: IFrontOfficeTableProps & IFrontOfficeTableActions) => {
  useEffect(() => {
    props.actions.getUserList(props.filter);
  }, [props.filter, props.actions]);

  useEffect(() => {
    return () => props.actions.reset(); 
    // ESLINT Необходимо выполнение только в момент размонтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <UIKitTable
    headers={props.headers}
    rows={props.rows}
    pageCount={props.pageCount}
    page={props.page}
    isLoading={props.isLoading}
    onSortingChange={fp.noop}
    onPageChange={(page: number) => props.actions.setFilter({ page })}
  />
}

export default Table;
