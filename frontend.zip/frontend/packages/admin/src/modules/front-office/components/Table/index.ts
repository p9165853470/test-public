import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getTransformedDate, formatPhoneNumber, convertPathUsingParams } from '@rfb/common';

import { ITable } from '@rfb/ui-kit';

import { store } from 'root-store';

import routingConfig from 'configs/routing';

import { name, actions, selectors, IFrontOfficeState } from '../../store';

import Component, { IFrontOfficeTableProps, IFrontOfficeTableActions } from './component';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

type TFrontOfficeTableColumn = {
  header: ITable['headers'][number];
  transform?: (value: any, user?: IFrontOfficeState['userList'][number]) => void;
};

const mapStateToProps = (state: { [name]: IFrontOfficeState }): IFrontOfficeTableProps => {
  const frontUserList: IFrontOfficeState['userList'] = selectors.selectUserList(state);
  const selectedList: IFrontOfficeState['selectedList'] = selectors.selectSelectedList(state);
  const filter: IFrontOfficeState['filter'] = selectors.selectFilter(state);

  const columns: TFrontOfficeTableColumn[] = [
    { header: { title: '', value: 'check', columnClassName: styles.checkbox } },
    { header: { title: '', value: 'lock', columnClassName: styles.lock } },
    {
      header: {
        type: 'input',
        title: 'Логин',
        value: 'email',
        filterValue: filter.login,
        onFilterChange: (login) => store.dispatch(actions.setFilter({ login })),
      },
    },
    {
      header: {
        type: 'input',
        title: 'ФИО представителя',
        value: 'name',
        filterValue: filter.name,
        onFilterChange: (name) => store.dispatch(actions.setFilter({ name })),
      },
      transform: fp.pipe(
        fp.nthArg(1),
        fp.paths(['last_name', 'first_name', 'middle_name']),
        fp.join(' ')
      ),
    },
    {
      header: {
        type: 'phone',
        title: 'Номер телефона',
        value: 'phone_number',
        filterValue: filter.phoneNumber,
        onFilterChange: (phoneNumber) =>
          store.dispatch(actions.setFilter(phoneNumber ? { phoneNumber } : { phoneNumber: '' })),
      },
      transform: formatPhoneNumber,
    },
    {
      header: { title: 'Дата создания УЗ', value: 'created_at' },
      transform: getTransformedDate,
    },
    {
      header: { title: 'Дата последнего изменения', value: 'updated_at' },
      transform: getTransformedDate,
    },
  ];

  const checkboxList = fp.map(
    (user: IFrontOfficeState['userList'][number]) => [
      {
        isCheckbox: true,
        isChecked: fp.contains(user.id, selectedList),
        onChange: () => {
          store.dispatch(actions.toggleSelected(user.id));
        },
      },
      {
        isCheckbox: true,
        type: 'lock',
        isChecked: user.block_reason,
        onChange: fp.noop,
      },
    ],
    frontUserList
  );

  const rowDataList = fp.pipe(
    fp.map((user: IFrontOfficeState['userList'][number]) =>
      fp.map(
        (column: TFrontOfficeTableColumn) =>
          fp.isFunction(column.transform)
            ? column.transform(fp.path(column.header.value, user), user)
            : fp.path(column.header.value, user),
        columns
      )
    ),
    fp.zip(checkboxList),
    fp.map(([checkboxList, row]: [any, any]) => [
      ...checkboxList,
      ...fp.drop(fp.size(checkboxList), row),
    ]),
    fp.map((data) => ({ data }))
  )(frontUserList);

  const rowConfigList = fp.pipe(
    fp.map((user: IFrontOfficeState['userList'][number]) => ({
      link: convertPathUsingParams(routingConfig.frontOfficeProfileEdit.path, { id: user.id }),
    })),
    fp.map((config) => ({ config }))
  )(frontUserList);

  return {
    headers: fp.map(fp.path('header'), columns),
    rows: fp.pipe(fp.zip(rowConfigList), fp.map(fp.mergeAll))(rowDataList),
    page: filter.page,
    pageCount: selectors.selectPageCount(state),
    filter,
    isLoading: selectors.selectIsLoading(state),
  };
};

const mapDispatchToProps = (dispatch: TODO_ANY): IFrontOfficeTableActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
