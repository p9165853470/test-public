import React from 'react';

import fp from 'lodash/fp';

import { AdminActions } from '@rfb/common';
import { ButtonWithIcon, LinkWithContent } from '@rfb/ui-kit';

import routingConfig from 'configs/routing';
import notification from 'utils/notification';

import {
  IDTOFrontUserBlockRequest,
  IDTOFrontUserUnblockRequest,
  IDTOFrontUserRemoveRequest,
} from 'dto/front-user';

import { IFrontOfficeState } from '../../store';

import styles from './assets/styles/index.module.css';

export interface IFrontOfficeTableHeaderProps {
  actionType: AdminActions;
  selectedList: number[];
  filter: IFrontOfficeState['filter'];
}

export interface IFrontOfficeTableHeaderActions {
  actions: {
    block: Function,
    unblock: Function,
    remove: Function,
  };
}

const TableHeader = (props: IFrontOfficeTableHeaderProps & IFrontOfficeTableHeaderActions) => {
  const onBlockClick = () => {
    notification.confirm('Подтвердить блокировку учётных записей', () => {
      const data: IDTOFrontUserBlockRequest = { ids: props.selectedList };
      props.actions.block({ data, filter: props.filter });
    });
  };
  const onUnblockClick = () => {
    notification.confirm('Подтвердить разблокировку учётных записей', () => {
      const data: IDTOFrontUserUnblockRequest = { ids: props.selectedList };
      props.actions.unblock({ data, filter: props.filter });
    });
  };
  const onRemoveClick = () => {
    notification.confirm('Подтвердить удаление учётных записей', () => {
      const data: IDTOFrontUserRemoveRequest = { ids: props.selectedList };
      props.actions.remove({ data, filter: props.filter });
    });
  };

  return (
    <div className={styles.main}>
      <h1 className={styles.title}>Пользователи ЛК</h1>

      <div className={styles.buttonGroup}>
        <ButtonWithIcon
          wrapperClassName={styles.button}
          type="block"
          text="Заблокировать"
          isActive={fp.isEqual(props.actionType, AdminActions.BLOCK)}
          onClick={onBlockClick}
        />
        <ButtonWithIcon
          wrapperClassName={styles.button}
          type="unblock"
          text="Разблокировать"
          isActive={fp.isEqual(props.actionType, AdminActions.UNBLOCK)}
          onClick={onUnblockClick}
        />
        <ButtonWithIcon
          wrapperClassName={styles.button}
          type="remove"
          text="Удалить"
          isActive={!fp.isEmpty(props.selectedList)}
          onClick={onRemoveClick}
        />

        <LinkWithContent wrapperClassName={styles.buttonAdd} to={routingConfig.frontOfficeProfileAdd.path}>
          <ButtonWithIcon type="add" text="Добавить пользователя" isActive onClick={fp.noop} />
        </LinkWithContent>
      </div>
    </div>
  );
};

export default TableHeader;
