import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IFrontOfficeState } from '../../store';

import Component, {
  IFrontOfficeTableHeaderProps,
  IFrontOfficeTableHeaderActions,
} from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (state: { [name]: IFrontOfficeState }): IFrontOfficeTableHeaderProps => ({
  actionType: selectors.selectActionType(state),
  selectedList: selectors.selectSelectedList(state),
  filter: selectors.selectFilter(state),
});

const mapDispatchToProps = (dispatch: TODO_ANY): IFrontOfficeTableHeaderActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
