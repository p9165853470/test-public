import validator from 'utils/validator';
import fp from 'lodash/fp';
import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

export const emailRules = validator
  .string()
  .required()
  .email()
  .min(1)
  .max(256)
  .test('not-cyrillic', 'Некорректный email', (value) => !/[а-яёА-ЯЁ]+/.test(value || ''));

export const nameRules = validator
  .string()
  .required('Заполните ФИО представителя')
  .test(
    'last-first-middle-names',
    'ФИО представителя должна содержать фамилию, имя и отчество',
    fp.pipe(fp.split(' '), fp.nth(2), fp.trim, fp.negate(fp.isEmpty))
  );

export const phoneNumberRules = validator
  .string()
  .required('Поле обязательно для заполнения')
  .test(
    'phone-format',
    'Номер телефона должен иметь формат +7(999)999-99-99',
    (value) => fp.size(value) === 11
  );

export const keyWordRules = validator
  .string()
  .required('Поле обязательно для заполнения')
  .uppercase()
  .test(
    'is-kew-word',
    'Длина кодового слова должна быть от 5 до 30',
    (value) => fp.size(value) > 4 && fp.size(value) <= 30
  );

export const diasoftIdRules = (checkedId: string) =>
  validator
    .string()
    .required()
    .test('checked-already', 'Код не проверен', (value) => checkedId === value);

const isCorrectDate = (value: string | null | undefined) =>
  value === '__.__.____' || /^\d\d\d\d-\d\d-\d\d$/.test(value || '');

export const datesRules = validator.object().shape({
  start: validator
    .string()
    .required('Нужно задать дату начала и окончания полномочий')
    .test('invalid-date-rule', 'Некорректная дата', isCorrectDate),
  end: validator
    .string()
    .required('Нужно задать дату начала и окончания полномочий')
    .test('invalid-date-rule', 'Некорректная дата', isCorrectDate)
    .when('start', (start: string, schema: TODO_ANY) => {
      return schema.test({
        test: (end: string) => !!start && end > start,
        message: 'Дата окончания полномочий должна быть позже начала',
      });
    }),
});
