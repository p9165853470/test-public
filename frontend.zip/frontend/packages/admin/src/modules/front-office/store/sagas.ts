import { put, takeEvery } from 'redux-saga/effects';

import fp from 'lodash/fp';

import api from 'utils/api';
import history from 'utils/history';
import notification from 'utils/notification';

import apiEndpoints from 'configs/api/endpoints';
import routingConfig from 'configs/routing';

import { convertApiErrorCodesToFieldMessages } from 'helpers/app';

import { TDTOFrontUserGetResponse, IDTOFrontUserGetResponseHeaders, IDealer } from 'dto/front-user';

import { actions } from './index';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

import { convertPathUsingParams } from '@rfb/common';
import endpoints from 'configs/api/endpoints';

function* getUserList(action: TODO_ANY) {
  try {
    yield put(actions.set({ isLoading: true }));
    const url: string =
      apiEndpoints.frontUser.get +
      `?page=${action.payload.page}&email=${action.payload.login}` +
      `&phone_number=${action.payload.phoneNumber}&name=${action.payload.name}`;
    const result: {
      data: TDTOFrontUserGetResponse;
      headers: IDTOFrontUserGetResponseHeaders;
    } = yield api.get(url);
    yield put(actions.getUserListSuccessful({ data: result.data, headers: result.headers }));
  } catch (error) {
    yield put(actions.getUserListFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* getUserListSuccessful(action: TODO_ANY) {
  yield put(
    actions.set({
      userList: action.payload.data,
      pageCount: fp.toNumber(action.payload.headers['x-pagination-page-count']),
    })
  );
}

function* getUserListFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* getUserById(action: TODO_ANY) {
  try {
    yield put(actions.set({ isLoading: true }));
    yield put(actions.set({ isSuccessSaved: false }));
    const url: string = action.payload.id
      ? convertPathUsingParams(apiEndpoints.frontUser.getById, { id: action.payload.id })
      : '';
    const result: {
      data: TDTOFrontUserGetResponse;
      headers: IDTOFrontUserGetResponseHeaders;
    } = yield api.get(url);
    yield put(actions.getUserByIdSuccessful({ data: result.data, headers: result.headers }));
  } catch (error) {
    yield put(actions.getUserByIdFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* getUserByIdSuccessful(action: TODO_ANY) {
  yield put(actions.set({ currentUser: action.payload.data }));
  const user = action.payload.data;
  const userForm = {
    name: [
      fp.path('last_name', user),
      fp.path('first_name', user),
      fp.path('middle_name', user),
    ].join(' '),
    email: user.email,
    phone_number: user.phone_number,
    key_word: user.key_word,
    dealers: user.dealers,
  };
  yield put(actions.setForm(userForm));
}

function* getUserByIdFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* updateDealers(action: TODO_ANY) {
  try {
    yield put(actions.set({ isLoading: true }));
    const result: { data: IDealer } = yield api.get(endpoints.rfInfo.user, {
      params: {
        email: action.payload.data.email,
        method: 'user',
      },
    });
    yield put(actions.updateDealersSuccessful({ data: result.data }));
  } catch (error) {
    yield put(actions.updateDealersFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* updateDealersSuccessful(action: TODO_ANY) {
  yield put(actions.setForm({ dealers: action.payload.data }));
}

function* updateDealersFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* getUserDealers(action: TODO_ANY) {
  try {
    yield put(actions.set({ isLoading: true }));
    const result: { data: IDealer } = yield api.get(endpoints.rfInfo.user, {
      params: {
        email: action.payload.data.email,
        method: 'user',
      },
    });
    yield put(actions.getUserDealersSuccessful({ data: result.data }));
  } catch (error) {
    yield put(
      actions.getUserDealersFailure({
        email: action.payload.data.email,
        data: error.response?.data,
      })
    );
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* getUserDealersSuccessful(action: TODO_ANY) {
  if (action.payload.data.length > 0) {
    const user = action.payload.data[0];
    const userForm = {
      name: user.user_name,
      phone_number: user.phone_number,
      key_word: user.key_word,
      dealers: action.payload.data,
    };
    yield put(actions.setForm(userForm));
  }
}

function* getUserDealersFailure(action: TODO_ANY) {
  if (action.payload.data?.code === 2010) {
    yield put(actions.setError({ email: ['Не найден пользователь с таким адресом'] }));
  }
  const userForm = {
    name: undefined,
    phone_number: undefined,
    key_word: undefined,
    dealers: [],
  };
  yield put(actions.setForm(userForm));
}

function* block(action: TODO_ANY) {
  try {
    yield api.post(apiEndpoints.frontUser.block, action.payload.data);
    yield put(
      actions.blockSuccessful({
        filter: action.payload.filter,
        isSingleUser: fp.isEqual(fp.size(action.payload.data.ids), 1),
      })
    );
  } catch (error) {
    yield put(actions.blockFailure(error.response?.data));
  }
}

function* blockSuccessful(action: TODO_ANY) {
  notification.info(
    action.payload.isSingleUser ? 'Пользователь заблокирован' : 'Пользователи заблокированы'
  );
  yield put(actions.set({ selectedList: [], actionType: null }));
  yield put(actions.getUserList(action.payload.filter));
}

function* blockFailure(action: TODO_ANY) {
  yield put(actions.set({ api: action.payload?.message }));
}

function* blockById(action: TODO_ANY) {
  try {
    const ids = [action.payload.id];
    yield api.post(apiEndpoints.frontUser.block, { ids });
    yield put(actions.blockByIdSuccessful(action.payload.id));
  } catch (error) {
    yield put(actions.blockByIdFailure(error.response?.data));
  }
}

function* blockByIdSuccessful(action: TODO_ANY) {
  notification.info('Пользователь заблокирован');
  yield put(actions.getUserById({ id: action.payload }));
}

function* blockByIdFailure(action: TODO_ANY) {
  yield put(actions.set({ api: action.payload?.message }));
}

function* unblock(action: TODO_ANY) {
  try {
    yield api.post(apiEndpoints.frontUser.unblock, action.payload.data);
    yield put(
      actions.unblockSuccessful({
        filter: action.payload.filter,
        isSingleUser: fp.isEqual(fp.size(action.payload.data.ids), 1),
      })
    );
  } catch (error) {
    yield put(actions.unblockFailure(error.response?.data));
  }
}

function* unblockSuccessful(action: TODO_ANY) {
  notification.info(
    action.payload.isSingleUser ? 'Пользователь разблокирован' : 'Пользователи разблокированы'
  );
  yield put(actions.set({ selectedList: [], actionType: null }));
  yield put(actions.getUserList(action.payload.filter));
}

function* unblockFailure(action: TODO_ANY) {
  yield put(actions.set({ api: action.payload?.message }));
}

function* unblockById(action: TODO_ANY) {
  try {
    const ids = [action.payload.id];
    yield api.post(apiEndpoints.frontUser.unblock, { ids });
    yield put(actions.unblockByIdSuccessful(action.payload.id));
  } catch (error) {
    yield put(actions.unblockByIdFailure(error.response?.data));
  }
}

function* unblockByIdSuccessful(action: TODO_ANY) {
  notification.info('Пользователь разблокирован');
  yield put(actions.getUserById({ id: action.payload }));
}

function* unblockByIdFailure(action: TODO_ANY) {
  yield put(actions.set({ api: action.payload?.message }));
}

function* remove(action: TODO_ANY) {
  try {
    yield api.post(apiEndpoints.frontUser.remove, action.payload.data);
    yield put(
      actions.removeSuccessful({
        filter: action.payload.filter,
        isSingleUser: fp.isEqual(fp.size(action.payload.data.ids), 1),
      })
    );
  } catch (error) {
    yield put(actions.removeFailure(error.response?.data));
  }
}

function* removeSuccessful(action: TODO_ANY) {
  notification.info(action.payload.isSingleUser ? 'Пользователь удалён' : 'Пользователи удалены');
  yield put(actions.set({ selectedList: [], actionType: null }));
  yield put(actions.getUserList(action.payload.filter));
}

function* removeFailure(action: TODO_ANY) {
  yield put(actions.set({ api: action.payload?.message }));
}

function* removeById(action: TODO_ANY) {
  try {
    const url: string = action.payload.id
      ? convertPathUsingParams(apiEndpoints.frontUser.removeById, { id: action.payload.id })
      : '';
    yield api.post(url, {});
    yield put(actions.removeByIdSuccessful(action.payload.filter));
  } catch (error) {
    yield put(actions.removeByIdFailure(error.response?.data));
  }
}

function* removeByIdSuccessful(action: TODO_ANY) {
  notification.info('Пользователь удален');
  history.push(routingConfig.main.path);
  yield put(actions.resetUser());
}

function* removeByIdFailure(action: TODO_ANY) {
  yield put(actions.set({ api: action.payload?.message }));
}

function* saveUser(action: TODO_ANY) {
  try {
    const id = action.payload.id;
    const url: string = id
      ? convertPathUsingParams(apiEndpoints.frontUser.updateUser, { id })
      : apiEndpoints.frontUser.createUser;
    const data = action.payload.data;
    yield api.post(url, data);
    yield put(actions.saveUserSuccessful({ id, data }));
  } catch (error) {
    yield put(actions.saveUserFailure(error.response?.data));
  }
}

function* saveUserSuccessful(action: TODO_ANY) {
  const id = action.payload.id;
  if (!id) {
    yield put(actions.reset());
  }
  yield put(actions.set({ isSuccessSaved: true }));
  notification.info(id ? 'Пользователь отредактирован' : 'Пользователь создан');
}

function* saveUserFailure(action: TODO_ANY) {
  if (action.payload instanceof Array) {
    yield put(actions.setError(convertApiErrorCodesToFieldMessages(action.payload)));
  }
  yield put(actions.set({ api: action.payload?.message }));
}

function* getOrganization(action: TODO_ANY) {
  try {
    yield put(actions.set({ isLoading: true }));
    const url: string =
      apiEndpoints.frontUser.organization + `?method=info&diasoft_id=${action.payload.id}`;
    const result: {
      data: TDTOFrontUserGetResponse;
      headers: IDTOFrontUserGetResponseHeaders;
    } = yield api.get(url);
    yield put(actions.getOrganizationSuccessful({ data: result.data, headers: result.headers }));
  } catch (error) {
    yield put(actions.getOrganizationFailure(error.response?.data));
  } finally {
    yield put(actions.setForm({ diasoft_id: action.payload.id }));
    yield put(actions.set({ isLoading: false }));
  }
}

function* getOrganizationSuccessful(action: TODO_ANY) {
  const currentOrganization = action.payload.data;
  yield put(actions.set({ currentOrganization }));
  yield put(
    actions.setOrganization(fp.pick(['diasoft_id', 'name', 'inn', 'kpp'], currentOrganization))
  );
}

function* getOrganizationFailure(action: TODO_ANY) {
  if (action.payload.status === 400) {
    yield put(actions.setError({ diasoft_id: ['Данный код юр лица отсутствует в базе данных'] }));
  } else {
    yield put(actions.setError({ api: action.payload?.message }));
  }
  yield put(actions.resetOrganization());
}

export default function* () {
  yield takeEvery(actions.getUserList, getUserList);
  yield takeEvery(actions.getUserListSuccessful, getUserListSuccessful);
  yield takeEvery(actions.getUserListFailure, getUserListFailure);

  yield takeEvery(actions.getUserById, getUserById);
  yield takeEvery(actions.getUserByIdSuccessful, getUserByIdSuccessful);
  yield takeEvery(actions.getUserByIdFailure, getUserByIdFailure);

  yield takeEvery(actions.updateDealers, updateDealers);
  yield takeEvery(actions.updateDealersSuccessful, updateDealersSuccessful);
  yield takeEvery(actions.updateDealersFailure, updateDealersFailure);

  yield takeEvery(actions.getUserDealers, getUserDealers);
  yield takeEvery(actions.getUserDealersSuccessful, getUserDealersSuccessful);
  yield takeEvery(actions.getUserDealersFailure, getUserDealersFailure);

  yield takeEvery(actions.block, block);
  yield takeEvery(actions.blockSuccessful, blockSuccessful);
  yield takeEvery(actions.blockFailure, blockFailure);

  yield takeEvery(actions.unblock, unblock);
  yield takeEvery(actions.unblockSuccessful, unblockSuccessful);
  yield takeEvery(actions.unblockFailure, unblockFailure);

  yield takeEvery(actions.blockById, blockById);
  yield takeEvery(actions.blockByIdSuccessful, blockByIdSuccessful);
  yield takeEvery(actions.blockByIdFailure, blockByIdFailure);

  yield takeEvery(actions.unblockById, unblockById);
  yield takeEvery(actions.unblockByIdSuccessful, unblockByIdSuccessful);
  yield takeEvery(actions.unblockByIdFailure, unblockByIdFailure);

  yield takeEvery(actions.remove, remove);
  yield takeEvery(actions.removeSuccessful, removeSuccessful);
  yield takeEvery(actions.removeFailure, removeFailure);

  yield takeEvery(actions.removeById, removeById);
  yield takeEvery(actions.removeByIdSuccessful, removeByIdSuccessful);
  yield takeEvery(actions.removeByIdFailure, removeByIdFailure);

  yield takeEvery(actions.saveUser, saveUser);
  yield takeEvery(actions.saveUserSuccessful, saveUserSuccessful);
  yield takeEvery(actions.saveUserFailure, saveUserFailure);

  yield takeEvery(actions.getOrganization, getOrganization);
  yield takeEvery(actions.getOrganizationSuccessful, getOrganizationSuccessful);
  yield takeEvery(actions.getOrganizationFailure, getOrganizationFailure);
}
