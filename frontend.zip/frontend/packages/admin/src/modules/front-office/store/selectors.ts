import { createSelector } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { name } from './index';

export const selectState = fp.path(name);
const selectFilter = createSelector(selectState, fp.path('filter'));

export default {
  selectFilter,
  selectUserList: createSelector(selectState, fp.path('userList')),
  selectSelectedList: createSelector(selectState, fp.path('selectedList')),
  selectPageCount: createSelector(selectState, fp.path('pageCount')),
  selectActionType: createSelector(selectState, fp.path('actionType')),
  selectIsLoading: createSelector(selectState, fp.path('isLoading')),
  selectCurrentUser: createSelector(selectState, fp.path('currentUser')),
  selectForm: createSelector(selectState, fp.path('form')),
  selectCurrentOrganization: createSelector(selectState, fp.path('currentOrganization')),
  selectIsSuccessSaved: createSelector(selectState, fp.path('isSuccessSaved')),
  selectErrorListByField: createSelector(selectState, (state) => (field: string) =>
    fp.pathOr([], ['errors', field], state)
  ),
};
