import { createSlice } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getStateFromParams, AdminActions, getTransformedApiDate } from '@rfb/common';

import { TDTOFrontUserGetResponse, TDTOFrontUser, IDealer } from 'dto/front-user';

export interface IFrontOfficeState {
  userList: TDTOFrontUserGetResponse;
  selectedList: number[];
  filter: {
    login: string;
    name: string;
    page: number;
    phoneNumber: string;
  };
  actionType: AdminActions | null;
  pageCount: number;
  errors: { [key: string]: string[] };
  isLoading: boolean;
  isSuccessSaved: boolean;
  currentUser: TDTOFrontUser;
  form: {
    email: string;
    name: string;
    phone_number: string;
    key_word: string;
    dealers: IDealer[];
  };
  currentOrganization: {
    diasoft_id: string;
    name: string;
    inn: string;
    kpp: string;
  };
}

const initialState: IFrontOfficeState = {
  userList: [],
  selectedList: [],
  filter: {
    login: '',
    name: '',
    phoneNumber: '',
    page: 1,
  },
  actionType: null,
  pageCount: 0,
  errors: {},
  isLoading: false,
  isSuccessSaved: false,
  currentUser: {
    id: 0,
    email: '',
    first_name: '',
    middle_name: '',
    phone_number: '',
    key_word: '',
    last_name: '',
    created_at: '',
    updated_at: '',
    active: true,
    dealers: [],
  },
  form: {
    email: '',
    name: '',
    phone_number: '',
    key_word: '',
    dealers: [],
  },
  currentOrganization: {
    diasoft_id: '',
    name: '',
    inn: '',
    kpp: '',
  },
};

const frontOfficeSlice = createSlice({
  name: 'front-office',

  initialState,

  reducers: {
    set: (state, action) => ({ ...state, ...action.payload }),
    setFilter: (state, action) => ({ ...state, filter: { ...state.filter, ...action.payload } }),
    setError: (state, action) => ({
      ...state,
      errors: { ...state.errors, ...action.payload },
    }),
    reset: () => ({ ...initialState }),
    resetFilter: (state) => ({ ...state, ...initialState.filter }),
    setForm: (state, action) => ({ ...state, form: { ...state.form, ...action.payload } }),
    setOrganization: (state, action) => ({
      ...state,
      currentOrganization: { ...state.currentOrganization, ...action.payload },
    }),
    resetForm: (state) => ({ ...state, form: { ...initialState.form } }),
    resetUser: (state) => ({ ...state, currentUser: { ...initialState.currentUser } }),
    resetOrganization: (state) => ({
      ...state,
      currentOrganization: { ...initialState.currentOrganization },
    }),
    resetErrors: (state) => ({ ...state, errors: { ...initialState.errors } }),

    toggleSelected: (state, action) => {
      const selectedList: number[] = fp.xor([action.payload], state.selectedList);
      const user: IFrontOfficeState['userList'][number] | undefined = fp.find(
        { id: fp.head(selectedList) },
        state.userList
      );
      return {
        ...state,
        selectedList,
        actionType: fp.isEmpty(selectedList)
          ? null
          : fp.isEmpty(user)
          ? state.actionType
          : user?.block_reason
          ? AdminActions.UNBLOCK
          : AdminActions.BLOCK,
      };
    },

    getUserList: getStateFromParams,
    getUserListSuccessful: getStateFromParams,
    getUserListFailure: getStateFromParams,

    getUserById: getStateFromParams,
    getUserByIdSuccessful: getStateFromParams,
    getUserByIdFailure: getStateFromParams,

    updateDealers: getStateFromParams,
    updateDealersSuccessful: getStateFromParams,
    updateDealersFailure: getStateFromParams,

    getUserDealers: getStateFromParams,
    getUserDealersSuccessful: getStateFromParams,
    getUserDealersFailure: getStateFromParams,

    block: getStateFromParams,
    blockSuccessful: getStateFromParams,
    blockFailure: getStateFromParams,

    unblock: getStateFromParams,
    unblockSuccessful: getStateFromParams,
    unblockFailure: getStateFromParams,

    blockById: getStateFromParams,
    blockByIdSuccessful: getStateFromParams,
    blockByIdFailure: getStateFromParams,

    unblockById: getStateFromParams,
    unblockByIdSuccessful: getStateFromParams,
    unblockByIdFailure: getStateFromParams,

    remove: getStateFromParams,
    removeSuccessful: getStateFromParams,
    removeFailure: getStateFromParams,

    removeById: getStateFromParams,
    removeByIdSuccessful: getStateFromParams,
    removeByIdFailure: getStateFromParams,

    saveUser: getStateFromParams,
    saveUserSuccessful: getStateFromParams,
    saveUserFailure: getStateFromParams,

    getOrganization: getStateFromParams,
    getOrganizationSuccessful: getStateFromParams,
    getOrganizationFailure: getStateFromParams,
  },
});

export const { name, actions, reducer } = frontOfficeSlice;
