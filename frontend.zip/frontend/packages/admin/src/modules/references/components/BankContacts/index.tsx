import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IReferencesState } from '../../store';

import BankContacts, {
  IBankContactsProps,
  IBankContactsActions,
} from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: IReferencesState },
): IBankContactsProps => ({
  bankContactsData: selectors.selectBankContactsData(state),
});

const mapDispatchToProps = (dispatch: TODO_ANY): IBankContactsActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(BankContacts);
