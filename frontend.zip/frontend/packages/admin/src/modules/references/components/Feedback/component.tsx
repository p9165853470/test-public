import React, { useEffect, useState } from 'react';

import fp from 'lodash/fp';

import { Button, Form, Input, MessageList } from '@rfb/ui-kit';

import { configureValidator, runRulesChain } from '@rfb/common';

import validator from 'utils/validator';

import styles from './assets/styles/index.module.css';

export interface IFeedbackProps {
  feedbackData: {
    debtService: string,
    accountMaintenance: string,
    technicalIssue: string,
    other: string,
  },
  debtServiceErrorList: string[],
  accountMaintenanceErrorList: string[],
  technicalIssueErrorList: string[],
  otherErrorList: string[],
}

export interface IFeedbackActions {
  actions: {
    getFeedBack: Function,
    setFeedBack: Function,
    setError: Function,
  };
}

const Feedback = (props: IFeedbackProps & IFeedbackActions) => {
  const [debtService, setDebtService] = useState('');
  const [accountMaintenance, setAccountMaintenance] = useState('');
  const [technicalIssue, setTechnicalIssue] = useState('');
  const [other, setOther] = useState('');

  useEffect(() => {
    props.actions.getFeedBack();
  }, [props.actions]);
  
  useEffect(() => {
    setDebtService(props.feedbackData.debtService);
    setAccountMaintenance(props.feedbackData.accountMaintenance);
    setTechnicalIssue(props.feedbackData.technicalIssue);
    setOther(props.feedbackData.other);
  }, [props.feedbackData]);

  const emailRules = validator
    .string()
    .required('Данные не заполнены')
    .email('Неверный формат почты')
    .min(1)
    .max(256);

  const validators = {
    debtService: configureValidator ({
      name: 'debtService',
      rule: emailRules,
      setError: props.actions.setError,
    }),
    accountMaintenance: configureValidator ({
      name: 'accountMaintenance',
      rule: emailRules,
      setError: props.actions.setError,
    }),
    technicalIssue: configureValidator ({
      name: 'technicalIssue',
      rule: emailRules,
      setError: props.actions.setError,
    }),
    other: configureValidator ({
      name: 'other',
      rule: emailRules,
      setError: props.actions.setError,
    }),
  };

  const onDebtServiceChange = (debtService: string): void => {
    validators.debtService(debtService).finally((): void => setDebtService(debtService));
  };

  const onAccountMaintenanceChange = (accountMaintenance: string): void => {
    validators.accountMaintenance(accountMaintenance).finally((): void => setAccountMaintenance(accountMaintenance));
  };

  const onTechnicalIssueChange = (technicalIssue: string): void => {
    validators.technicalIssue(technicalIssue).finally((): void => setTechnicalIssue(technicalIssue));
  };

  const onOtherChange = (other: string): void => {
    validators.other(other).finally((): void => setOther(other));
  };

  const onFormSubmit = (): void => {
    const data= {
      debtService,
      accountMaintenance,
      technicalIssue,
      other,
    };

    const rules = [
      validators.debtService(data.debtService),
      validators.accountMaintenance(data.accountMaintenance),
      validators.technicalIssue(data.technicalIssue),
      validators.other(data.other),
    ];

    runRulesChain(rules).then(() => props.actions.setFeedBack(data));
  };

  return (
    <div className={styles.feedback}>
      <h2 className={styles.title}>
        Свяжитесь с нами
      </h2>

      <p className={styles.description}>
        Укажите почту, на которую будут приходить письма по заданным вопросам и пожеланиям
      </p>

      <Form onSubmit={onFormSubmit}>
        <Input
          wrapperClassName={styles.formfield}
          type='email'
          label="Задолженности*"
          value={debtService}
          hasError={!fp.isEmpty(props.debtServiceErrorList)}
          onChange={onDebtServiceChange}
        />
        <MessageList type="error" messages={props.debtServiceErrorList} />

        <Input
          wrapperClassName={styles.formfield}
          type='email'
          label="Расчетные счета*"
          value={accountMaintenance}
          hasError={!fp.isEmpty(props.accountMaintenanceErrorList)}
          onChange={onAccountMaintenanceChange}
        />
        <MessageList type="error" messages={props.accountMaintenanceErrorList} />

        <Input
          wrapperClassName={styles.formfield}
          type='email'
          label="Технические*"
          value={technicalIssue}
          hasError={!fp.isEmpty(props.technicalIssueErrorList)}
          onChange={onTechnicalIssueChange}
        />
        <MessageList type="error" messages={props.technicalIssueErrorList} />

        <Input
          wrapperClassName={styles.formfield}
          type='email'
          label="Иные*"
          value={other}
          hasError={!fp.isEmpty(props.otherErrorList)}
          onChange={onOtherChange}
        />
        <MessageList type="error" messages={props.otherErrorList} />

        <Button
          wrapperClassName={''}
          type="submit"
          text="Сохранить"
        />
      </Form>
    </div>
  );
};

export default Feedback;
