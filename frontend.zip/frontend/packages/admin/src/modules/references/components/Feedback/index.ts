import { connect } from 'react-redux';

import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IReferencesState } from '../../store';

import Feedback, {
  IFeedbackProps,
  IFeedbackActions,
} from './component';

const mapStateToProps = ( state: { [name]: IReferencesState } ): IFeedbackProps => ({
  feedbackData: selectors.selectFeedbackData(state),
  debtServiceErrorList: selectors.selectErrorListByField(state)('debtService'),
  accountMaintenanceErrorList: selectors.selectErrorListByField(state)('accountMaintenance'),
  technicalIssueErrorList: selectors.selectErrorListByField(state)('technicalIssue'),
  otherErrorList: selectors.selectErrorListByField(state)('other'),
});

const mapDispatchToProps = (dispatch: any): IFeedbackActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Feedback);
