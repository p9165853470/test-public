import React from 'react';

import { Button } from '@rfb/ui-kit';

import styles from './assets/styles/index.module.css';

interface IHeadBlockProps {
  title: string,
  buttonName: string,
  onButtonClick: (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void,
}

const HeadBlock = (props: IHeadBlockProps) => {
  return (
    <div className={styles.headBlock}>
      <h2 className={styles.title}>{props.title}</h2>
      <Button
        text={props.buttonName}
        onClick={props.onButtonClick}
      />
    </div>
  );
};

export default HeadBlock;
