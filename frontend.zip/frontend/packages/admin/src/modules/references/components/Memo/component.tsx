import React, { useEffect, useState } from 'react';

import { WysiwygEditor } from '@rfb/ui-kit';

import HeadBlock from '../HeadBlock';

import { variables } from './../../configs/variables';

import styles from './assets/styles/index.module.css';

export interface IMemoProps {
  memoData: {
    description: string,
    text: string,
  },
};

export interface IMemoActions {
  actions: {
    getVariable: Function,
    setVariable: Function,
  };
};

const Memo = (props: IMemoProps & IMemoActions) => {
  const text = props.memoData.text;

  const [changedText, setChangedText] = useState('');

  useEffect(() => {
    props.actions.getVariable({key: variables.memo.key});
  }, [props.actions]);

  const saveData = () => {
    props.actions.setVariable({key: variables.memo.key, text: changedText});
  };

  return (
    <div className={styles.memo}>
      <HeadBlock
        title={variables.memo.title}
        buttonName='Сохранить'
        onButtonClick={saveData}
      />
      <WysiwygEditor
        initText={text}
        onChangeText={setChangedText}
      />
    </div>
  );
};

export default Memo;
