import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IReferencesState } from '../../store';

import Memo, {
  IMemoProps,
  IMemoActions,
} from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: IReferencesState },
): IMemoProps => ({
  memoData: selectors.selectMemoData(state),
});

const mapDispatchToProps = (dispatch: TODO_ANY): IMemoActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Memo);
