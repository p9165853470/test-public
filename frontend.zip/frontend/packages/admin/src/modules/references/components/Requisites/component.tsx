import React, { useEffect, useState } from 'react';

import { WysiwygEditor } from '@rfb/ui-kit';

import HeadBlock from '../HeadBlock';

import { variables } from './../../configs/variables';

import styles from './assets/styles/index.module.css';

export interface IRequisitesProps {
  requisitesData: {
    description: string,
    text: string,
  },
};

export interface IRequisitesActions {
  actions: {
    getVariable: Function,
    setVariable: Function,
  };
};

const Requisites = (props: IRequisitesProps & IRequisitesActions) => {
  const text = props.requisitesData.text;

  const [changedText, setChangedText] = useState('');

  useEffect(() => {
    props.actions.getVariable({key: variables.requisites.key});
  }, [props.actions]);

  const saveData = () => {
    props.actions.setVariable({key: variables.requisites.key, text: changedText});
  };

  return (
    <div className={styles.requisites}>
      <HeadBlock
        title={variables.requisites.title}
        buttonName='Сохранить'
        onButtonClick={saveData}
      />
      <WysiwygEditor
        initText={text}
        onChangeText={setChangedText}
      />
    </div>
  );
};

export default Requisites;
