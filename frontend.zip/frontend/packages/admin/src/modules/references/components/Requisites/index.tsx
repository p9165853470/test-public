import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IReferencesState } from '../../store';

import Requisites, {
  IRequisitesProps,
  IRequisitesActions,
} from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: IReferencesState },
): IRequisitesProps => ({
  requisitesData: selectors.selectRequisitesData(state),
});

const mapDispatchToProps = (dispatch: TODO_ANY): IRequisitesActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Requisites);
