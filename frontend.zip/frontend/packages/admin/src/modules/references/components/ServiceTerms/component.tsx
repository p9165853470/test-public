import React, { useEffect, useState } from 'react';

import { WysiwygEditor } from '@rfb/ui-kit';

import HeadBlock from '../HeadBlock';

import { variables } from './../../configs/variables';

import styles from './assets/styles/index.module.css';

export interface IServiceTermsProps {
  serviceTermsData: {
    description: string,
    text: string,
  },
};

export interface IServiceTermsActions {
  actions: {
    getVariable: Function,
    setVariable: Function,
  };
};

const ServiceTerms = (props: IServiceTermsProps & IServiceTermsActions) => {
  const text = props.serviceTermsData.text;

  const [changedText, setChangedText] = useState('');

  useEffect(() => {
    props.actions.getVariable({key: variables.serviceTerms.key});
  }, [props.actions]);

  const saveData = () => {
    props.actions.setVariable({key: variables.serviceTerms.key, text: changedText});
  };

  return (
    <div className={styles.serviceTerms}>
      <HeadBlock
        title={variables.serviceTerms.title}
        buttonName='Сохранить'
        onButtonClick={saveData}
      />
      <WysiwygEditor
        initText={text}
        onChangeText={setChangedText}
      />
    </div>
  );
};

export default ServiceTerms;
