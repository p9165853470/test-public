import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IReferencesState } from '../../store';

import ServiceTerms, {
  IServiceTermsProps,
  IServiceTermsActions,
} from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: IReferencesState },
): IServiceTermsProps => ({
  serviceTermsData: selectors.selectServiceTermsData(state),
});

const mapDispatchToProps = (dispatch: TODO_ANY): IServiceTermsActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(ServiceTerms);
