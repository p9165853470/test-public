import React, { useEffect, useState } from 'react';

import { WysiwygEditor } from '@rfb/ui-kit';

import HeadBlock from '../HeadBlock';

import { variables } from './../../configs/variables';

import styles from './assets/styles/index.module.css';

export interface ITariffsProps {
  tariffsData: {
    description: string,
    text: string,
  },
};

export interface ITariffsActions {
  actions: {
    getVariable: Function,
    setVariable: Function,
  };
};

const Tariffs = (props: ITariffsProps & ITariffsActions) => {
  const text = props.tariffsData.text;

  const [changedText, setChangedText] = useState('');

  useEffect(() => {
    props.actions.getVariable({key: variables.tariffs.key});
  }, [props.actions]);

  const saveData = () => {
    props.actions.setVariable({key: variables.tariffs.key, text: changedText});
  };

  return (
    <div className={styles.tariffs}>
      <HeadBlock
        title={variables.tariffs.title}
        buttonName='Сохранить'
        onButtonClick={saveData}
      />
      <WysiwygEditor
        initText={text}
        onChangeText={setChangedText}
      />
    </div>
  );
};

export default Tariffs;
