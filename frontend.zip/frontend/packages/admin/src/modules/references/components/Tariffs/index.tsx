import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IReferencesState } from '../../store';

import Tariffs, {
  ITariffsProps,
  ITariffsActions,
} from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: IReferencesState },
): ITariffsProps => ({
  tariffsData: selectors.selectTariffsData(state),
});

const mapDispatchToProps = (dispatch: TODO_ANY): ITariffsActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Tariffs);
