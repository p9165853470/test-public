import React, { useEffect, useState } from 'react';

import { WysiwygEditor } from '@rfb/ui-kit';

import HeadBlock from '../HeadBlock';

import { variables } from './../../configs/variables';

import styles from './assets/styles/index.module.css';

export interface IUserManualProps {
  userManualData: {
    description: string,
    text: string,
  },
};

export interface IUserManualActions {
  actions: {
    getVariable: Function,
    setVariable: Function,
  };
};

const UserManual = (props: IUserManualProps & IUserManualActions) => {
  const text = props.userManualData.text;

  const [changedText, setChangedText] = useState('');

  useEffect(() => {
    props.actions.getVariable({key: variables.userManual.key});
  }, [props.actions]);

  const saveData = () => {
    props.actions.setVariable({key: variables.userManual.key, text: changedText});
  };

  return (
    <div className={styles.userManual}>
      <HeadBlock
        title={variables.userManual.title}
        buttonName='Сохранить'
        onButtonClick={saveData}
      />
      <WysiwygEditor
        initText={text}
        onChangeText={setChangedText}
      />
    </div>
  );
};

export default UserManual;
