export const variables = {
  bankContacts: {
    title: 'Контакты банка',
    key: 'contacts',
  },
  memo: {
    title: 'Памятка',
    key: 'reminder',
  },
  requisites: {
    title: 'Реквизиты',
    key: 'requisites',
  },
  serviceTerms: {
    title: 'Условия обслуживания',
    key: 'agreement',
  },
  tariffs: {
    title: 'Тарифы',
    key: 'tariffs',
  },
  userManual: {
    title: 'Инструкция пользователя',
    key: 'instruction',
  },
};
