import { put, takeEvery } from 'redux-saga/effects';

import api from 'utils/api';

import { convertPathUsingParams } from '@rfb/common';

import apiEndpoints from 'configs/api/endpoints';

import { actions } from './index';

import { variables } from './../configs/variables';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

interface IGetVariableProps {
  type: string,
  payload: {
    key: string,
  },
}

interface IGetVariableSuccessfulProps {
  type: string,
  payload: {
    key: string,
    data: {
      text: string,
    },
  },
}

interface ISetVariableProps {
  type: string,
  payload: {
    key: string,
    text: string,
  },
}

interface ISetVariableSuccessfulProps {
  type: string,
  payload: {
    key: string,
    data: {
      text: string,
    },
  },
}

function* getVariable(action: IGetVariableProps) {
  const key = action.payload.key;
  const url = convertPathUsingParams(apiEndpoints.variable.getVariable, {key});

  try {
    const result = yield api.get(url);

    result.data.text = result.data.text ? result.data.text : '';

    yield put(actions.getVariableSuccessful({
      data: result.data,
      key: key,
    }));
  } catch (error) {
    yield put(actions.getVariableFailure(error.response?.data));
  }
}

function* getVariableSuccessful (action: IGetVariableSuccessfulProps) {
  const { key, data } = action.payload;

  switch (key) {
    case variables.bankContacts.key:
      yield put(actions.set({ bankContactsData: data}));
      break;
    case variables.memo.key:
      yield put(actions.set({ memoData: data}));
      break;
    case variables.requisites.key:
      yield put(actions.set({ requisitesData: data}));
      break;
    case variables.serviceTerms.key:
      yield put(actions.set({ serviceTermsData: data}));
      break;
    case variables.tariffs.key:
      yield put(actions.set({ tariffsData: data}));
      break;
    case variables.userManual.key:
      yield put(actions.set({ userManualData: data}));
      break;
  }
}

function* getVariableFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* setVariable(action: ISetVariableProps) {
  const { key, text } = action.payload;
  const url = convertPathUsingParams(apiEndpoints.variable.setVariable, {key});

  try {
    const result = yield api.post(url, {text});

    yield put(actions.setVariableSuccessful({
      data: result.data,
      key: key,
    }));
  } catch (error) {
    yield put(actions.setVariableFailure(error.response?.data));
  }
}

function* setVariableSuccessful(action: ISetVariableSuccessfulProps) {
  const { key, data } = action.payload;

  switch (key) {
    case variables.bankContacts.key:
      yield put(actions.set({ bankContactsData: data}));
      break;
    case variables.memo.key:
      yield put(actions.set({ memoData: data}));
      break;
    case variables.requisites.key:
      yield put(actions.set({ requisitesData: data}));
      break;
    case variables.serviceTerms.key:
      yield put(actions.set({ serviceTermsData: data}));
      break;
    case variables.tariffs.key:
      yield put(actions.set({ tariffsData: data}));
      break;
    case variables.userManual.key:
      yield put(actions.set({ userManualData: data}));
      break;
  }
}

function* setVariableFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* getFeedBack() {
  try {
    const result = yield api.get(apiEndpoints.feedback.getFeedback);

    const resData = {
      debtService: result.data.debt_service[0],
      accountMaintenance: result.data.account_maintenance[0],
      technicalIssue: result.data.technical_issue[0],
      other: result.data.other[0],
    };

    yield put(actions.getFeedBackSuccessful(resData));
  } catch (error) {
    yield put(actions.getFeedBackFailure(error.response?.data));
  }
}

function* getFeedBackSuccessful(action: TODO_ANY) {
  yield put(actions.set({ feedbackData: action.payload}));
}

function* getFeedBackFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* setFeedBack(action: TODO_ANY) {
  const {debtService, accountMaintenance, technicalIssue, other} = action.payload;

  const data = {
    debt_service: [debtService],
    account_maintenance: [accountMaintenance],
    technical_issue: [technicalIssue],
    other: [other],
  };

  try {
    const result = yield api.post(apiEndpoints.feedback.setFeedback, data);

    const resData = {
      debtService: result.data.debt_service[0],
      accountMaintenance: result.data.account_maintenance[0],
      technicalIssue: result.data.technical_issue[0],
      other: result.data.other[0],
    };

    yield put(actions.setFeedBackSuccessful(resData));
  } catch (error) {
    yield put(actions.setFeedBackFailure(error.response?.data));
  }
}

function* setFeedBackSuccessful(action: TODO_ANY) {
  yield put(actions.set({ feedbackData: action.payload}));
}

function* setFeedBackFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

export default function* () {
  yield takeEvery(actions.getVariable, getVariable);
  yield takeEvery(actions.getVariableSuccessful, getVariableSuccessful);
  yield takeEvery(actions.getVariableFailure, getVariableFailure);

  yield takeEvery(actions.setVariable, setVariable);
  yield takeEvery(actions.setVariableSuccessful, setVariableSuccessful);
  yield takeEvery(actions.setVariableFailure, setVariableFailure);

  yield takeEvery(actions.getFeedBack, getFeedBack);
  yield takeEvery(actions.getFeedBackSuccessful, getFeedBackSuccessful);
  yield takeEvery(actions.getFeedBackFailure, getFeedBackFailure);

  yield takeEvery(actions.setFeedBack, setFeedBack);
  yield takeEvery(actions.setFeedBackSuccessful, setFeedBackSuccessful);
  yield takeEvery(actions.setFeedBackFailure, setFeedBackFailure);
}
