import { createSelector } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { name } from './index';

export const selectState = fp.path(name);
const selectBankContactsData = createSelector(selectState, fp.path('bankContactsData'));
const selectMemoData = createSelector(selectState, fp.path('memoData'));
const selectRequisitesData = createSelector(selectState, fp.path('requisitesData'));
const selectServiceTermsData = createSelector(selectState, fp.path('serviceTermsData'));
const selectTariffsData = createSelector(selectState, fp.path('tariffsData'));
const selectUserManualData = createSelector(selectState, fp.path('userManualData'));
const selectFeedbackData = createSelector(selectState, fp.path('feedbackData'));

export default {
  selectBankContactsData,
  selectMemoData,
  selectRequisitesData,
  selectServiceTermsData,
  selectTariffsData,
  selectUserManualData,
  selectFeedbackData,
  selectErrorListByField: createSelector(selectState, (state) => (field: string) =>
    fp.pathOr([], ['errors', field], state)
  ),
};
