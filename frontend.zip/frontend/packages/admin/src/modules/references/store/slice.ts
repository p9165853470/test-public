import { createSlice } from '@reduxjs/toolkit';

import { getStateFromParams } from '@rfb/common';

export interface IReferencesState {
  bankContactsData: {
    text: string,
  },
  memoData: {
    text: string,
  },
  requisitesData: {
    text: string,
  },
  serviceTermsData: {
    text: string,
  },
  tariffsData: {
    text: string,
  },
  userManualData: {
    text: string,
  },
  feedbackData: {
    debtService: string,
    accountMaintenance: string,
    technicalIssue: string,
    other: string,
  },
  errors: { [key: string]: string[] };
};

const initialState: IReferencesState = {
  bankContactsData: {
    text: '',
  },
  memoData: {
    text: '',
  },
  requisitesData: {
    text: '',
  },
  serviceTermsData: {
    text: '',
  },
  tariffsData: {
    text: '',
  },
  userManualData: {
    text: '',
  },
  feedbackData: {
    debtService: '',
    accountMaintenance: '',
    technicalIssue: '',
    other: '',
  },
  errors: {},
};

const referencesSlice = createSlice({
  name: 'references',

  initialState,

  reducers: {
    set: (state, action) => ({ ...state, ...action.payload }),
    setError: (state, action) => ({
      ...state,
      errors: { ...state.errors, ...action.payload },
    }),

    getVariable: getStateFromParams,
    getVariableSuccessful: getStateFromParams,
    getVariableFailure: getStateFromParams,

    setVariable: getStateFromParams,
    setVariableSuccessful: getStateFromParams,
    setVariableFailure: getStateFromParams,

    uploadVariable: getStateFromParams,
    uploadVariableSuccessful: getStateFromParams,
    uploadVariableFailure: getStateFromParams,

    getFeedBack: getStateFromParams,
    getFeedBackSuccessful: getStateFromParams,
    getFeedBackFailure: getStateFromParams,

    setFeedBack: getStateFromParams,
    setFeedBackSuccessful: getStateFromParams,
    setFeedBackFailure: getStateFromParams,
  },
});

export const { name, actions, reducer } = referencesSlice;
