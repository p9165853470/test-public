import React, { useEffect, useState } from 'react';

import fp from 'lodash/fp';

import { Button, Form, Input, MessageList } from '@rfb/ui-kit';

import { configureValidator, runRulesChain } from '@rfb/common';

import { weekDaysDefault, inputRules, workBeginTimeRules, workEndTimeRules } from './../../configs';

import styles from './assets/styles/index.module.css';

export interface ISettingsProps {
  settingsData: {
    workBeginTime: string,
    workEndTime: string,
    workWeekDays: {
      mon: boolean,
      tue: boolean,
      wed: boolean,
      thu: boolean,
      fri: boolean,
      sat: boolean,
      sun: boolean,
    },
    uncheckTrancheInWorkTime: string,
    uncheckTrancheOutWorkTime: string,
  };

  workBeginTimeErrorList: string[];
  workEndTimeErrorList: string[];
  uncheckTrancheInWorkTimeErrorList: string[];
  uncheckTrancheOutWorkTimeErrorList: string[];
}

export interface ISettingsActions {
  actions: {
    getSettings: Function,
    setSettings: Function,
    setError: Function,
  };
}

const Settings = (props: ISettingsProps & ISettingsActions) => {
  const [weekDays, setWeekDays] = useState(weekDaysDefault);

  const [workBeginTime, setWorkBeginTime] = useState('');
  const [workEndTime, setWorkEndTime] = useState('');
  const [workWeekDays, setWorkWeekDays] = useState({});
  const [uncheckTrancheInWorkTime, setUncheckTrancheInWorkTime] = useState('');
  const [uncheckTrancheOutWorkTime, setUncheckTrancheOutWorkTime] = useState('');

  const updateWeekDays = (propsData: { [key: string]: boolean }) => {
    const newWeekDays = weekDaysDefault.map((item) => {
      return {
        ...item,
        selected: propsData[item.key],
      };
    });

    setWeekDays(newWeekDays);
  };

  useEffect(() => {
    props.actions.getSettings();
  }, [props.actions]);

  useEffect(() => {
    setWorkBeginTime(props.settingsData.workBeginTime);
    setWorkEndTime(props.settingsData.workEndTime);
    setUncheckTrancheInWorkTime(props.settingsData.uncheckTrancheInWorkTime);
    setUncheckTrancheOutWorkTime(props.settingsData.uncheckTrancheOutWorkTime);
    setWorkWeekDays(props.settingsData.workWeekDays);

    updateWeekDays(props.settingsData.workWeekDays);
  }, [props.settingsData]);

  const validators = {
    workBeginTime: configureValidator({
      name: 'workBeginTime',
      rule: workBeginTimeRules(workEndTime),
      setError: props.actions.setError,
    }),
    workEndTime: configureValidator({
      name: 'workEndTime',
      rule: workEndTimeRules(workBeginTime),
      setError: props.actions.setError,
    }),
    uncheckTrancheInWorkTime: configureValidator({
      name: 'uncheckTrancheInWorkTime',
      rule: inputRules,
      setError: props.actions.setError,
    }),
    uncheckTrancheOutWorkTime: configureValidator({
      name: 'uncheckTrancheOutWorkTime',
      rule: inputRules,
      setError: props.actions.setError,
    }),
  };

  const weekDaysChange = (event: any) => {
    event.preventDefault();
    const dayIndex = event.target.value;

    const newWeekDays = weekDays.map((item, index) => {
      if (+dayIndex === +index) {
        return {
          ...item,
          selected: !item.selected,
        };
      } else {
        return item;
      }
    });

    setWeekDays(newWeekDays);

    const newWorkWeekDays = {
      ...workWeekDays,
      [newWeekDays[dayIndex].key]: newWeekDays[dayIndex].selected,
    };

    setWorkWeekDays(newWorkWeekDays);
  };

  const onWorkBeginTimeChange = (workBeginTime: string) => {
    validators.workBeginTime(workBeginTime).finally((): void => setWorkBeginTime(workBeginTime));
  };

  const onWorkEndTimeChange = (workEndTime: string) => {
    validators.workEndTime(workEndTime).finally((): void => setWorkEndTime(workEndTime));
  };

  const onUncheckTrancheInWorkTimeChange = (uncheckTrancheInWorkTime: string) => {
    validators
      .uncheckTrancheInWorkTime(uncheckTrancheInWorkTime)
      .finally((): void => setUncheckTrancheInWorkTime(uncheckTrancheInWorkTime));
  };

  const onUncheckTrancheOutWorkTimeChange = (uncheckTrancheOutWorkTime: string) => {
    validators
      .uncheckTrancheOutWorkTime(uncheckTrancheOutWorkTime)
      .finally((): void => setUncheckTrancheOutWorkTime(uncheckTrancheOutWorkTime));
  };

  const onFormSubmit = () => {
    const data = {
      workBeginTime,
      workEndTime,
      workWeekDays,
      uncheckTrancheInWorkTime,
      uncheckTrancheOutWorkTime,
    };

    const rules = [
      validators.workBeginTime(data.workBeginTime),
      validators.workEndTime(data.workEndTime),
      validators.uncheckTrancheInWorkTime(data.uncheckTrancheInWorkTime),
      validators.uncheckTrancheOutWorkTime(data.uncheckTrancheOutWorkTime),
    ];

    runRulesChain(rules).then(() => props.actions.setSettings(data));
  };

  return (
    <div className={styles.settings}>
      <h1 className={styles.title}>Настройки</h1>

      <Form onSubmit={onFormSubmit}>
        <p className={styles.description}>Время формирования файла в текущем дне</p>
        <div className={styles.inputFields}>
          <div>
            <Input
              wrapperClassName={styles.field}
              type="time"
              value={workBeginTime}
              label="Время начала операционного дня (МСК)"
              onChange={onWorkBeginTimeChange}
              minLength={4}
              hasError={!fp.isEmpty(props.workBeginTimeErrorList)}
            />
            <MessageList type="error" messages={props.workBeginTimeErrorList} />
          </div>

          <div>
            <Input
              wrapperClassName={styles.field}
              type="time"
              value={workEndTime}
              label="Время окончания операционного дня (МСК)"
              onChange={onWorkEndTimeChange}
              minLength={4}
              hasError={!fp.isEmpty(props.workEndTimeErrorList)}
            />
            <MessageList type="error" messages={props.workEndTimeErrorList} />
          </div>
        </div>

        <p className={styles.description}>Рабочие дни</p>
        <ul className={styles.daysList} onClick={weekDaysChange}>
          {weekDays.map(({ title, key, selected }, index) => {
            const daySelected = selected ? styles.selected : '';
            return (
              <li className={daySelected} value={index} key={key}>
                {title}
              </li>
            );
          })}
        </ul>

        <p className={styles.description}>Время снятия пометок, если файл сформирован...</p>
        <div className={styles.inputFields}>
          <div>
            <Input
              wrapperClassName={styles.field}
              type="time"
              value={uncheckTrancheInWorkTime}
              label="В операционное время (МСК)"
              onChange={onUncheckTrancheInWorkTimeChange}
              minLength={4}
              hasError={!fp.isEmpty(props.uncheckTrancheInWorkTimeErrorList)}
            />
            <MessageList type="error" messages={props.uncheckTrancheInWorkTimeErrorList} />
          </div>

          <div>
            <Input
              wrapperClassName={styles.field}
              type="time"
              value={uncheckTrancheOutWorkTime}
              label="Во внеоперационное время (МСК)"
              onChange={onUncheckTrancheOutWorkTimeChange}
              minLength={4}
              hasError={!fp.isEmpty(props.uncheckTrancheOutWorkTimeErrorList)}
            />
            <MessageList type="error" messages={props.uncheckTrancheOutWorkTimeErrorList} />
          </div>
        </div>

        <Button type="submit" text="Сохранить" />
      </Form>
    </div>
  );
};

export default Settings;
