import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, ISettingsState } from '../../store';

import Settings, {
  ISettingsProps,
  ISettingsActions,
} from './component';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: ISettingsState },
): ISettingsProps => ({
  settingsData: selectors.selectSettingsData(state),
  workBeginTimeErrorList: selectors.selectErrorListByField(state)('workBeginTime'),
  workEndTimeErrorList: selectors.selectErrorListByField(state)('workEndTime'),
  uncheckTrancheInWorkTimeErrorList: selectors.selectErrorListByField(state)('uncheckTrancheInWorkTime'),
  uncheckTrancheOutWorkTimeErrorList: selectors.selectErrorListByField(state)('uncheckTrancheOutWorkTime'),
});

const mapDispatchToProps = (dispatch: TODO_ANY): ISettingsActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Settings);
