import validator from 'utils/validator';

import fp from 'lodash/fp';

export const weekDaysDefault = [
  {
    title: 'Пн',
    key: 'mon',
    selected: false,
  },
  {
    title: 'Вт',
    key: 'tue',
    selected: false,
  },
  {
    title: 'Ср',
    key: 'wed',
    selected: false,
  },
  {
    title: 'Чт',
    key: 'thu',
    selected: false,
  },
  {
    title: 'Пт',
    key: 'fri',
    selected: false,
  },
  {
    title: 'Сб',
    key: 'sat',
    selected: false,
  },
  {
    title: 'Вс',
    key: 'sun',
    selected: false,
  },
];

export const inputRules = validator
  .string()
  .required('Данные не заполнены')
  .min(5);

export const workBeginTimeRules = (workEndTime: string) =>
  validator
    .string()
    .required()
    .min(5)
    .test('work-begin-time-rule', 'Время начала не может быть больше времени окончания', fp.gt(workEndTime));

export const workEndTimeRules = (workBeginTime: string) =>
  validator
    .string()
    .required()
    .min(5)
    .test('work-end-time-rule', 'Время окончания не может быть меньше времени начала', fp.lt(workBeginTime));
