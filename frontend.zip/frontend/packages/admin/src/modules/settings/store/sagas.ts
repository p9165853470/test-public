import { put, takeEvery } from 'redux-saga/effects';

import api from 'utils/api';
import notification from 'utils/notification';
import { convertApiErrorCodesToMessages } from '@rfb/common';

import apiEndpoints from 'configs/api/endpoints';

import { actions } from './index';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* getSettings() {
  try {
    const result = yield api.get(apiEndpoints.settings.getSettings);

    const resultData = {
      workBeginTime: result.data.work_begin_time || '',
      workEndTime: result.data.work_end_time || '',
      workWeekDays: result.data.work_week_days,
      uncheckTrancheInWorkTime: result.data.uncheck_tranche_in_work_time || '',
      uncheckTrancheOutWorkTime: result.data.uncheck_tranche_out_work_time || '',
    };

    yield put(actions.getSettingsSuccessful(resultData));
  } catch (error) {
    yield put(actions.getSettingsFailure(error.response?.data));
  }
}

function* getSettingsSuccessful(action: TODO_ANY) {
  yield put(actions.set({ settingsData: action.payload }));
}

function* getSettingsFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
}

function* setSettings(action: TODO_ANY) {
  const {
    workBeginTime,
    workEndTime,
    workWeekDays,
    uncheckTrancheInWorkTime,
    uncheckTrancheOutWorkTime,
  } = action.payload;

  const data = {
    work_begin_time: workBeginTime,
    work_end_time: workEndTime,
    work_week_days: workWeekDays,
    uncheck_tranche_in_work_time: uncheckTrancheInWorkTime,
    uncheck_tranche_out_work_time: uncheckTrancheOutWorkTime,
  };

  try {
    const result = yield api.post(apiEndpoints.settings.setSettings, data);

    const resultData = {
      workBeginTime: result.data.work_begin_time || '',
      workEndTime: result.data.work_end_time || '',
      workWeekDays: result.data.work_week_days,
      uncheckTrancheInWorkTime: result.data.uncheck_tranche_in_work_time || '',
      uncheckTrancheOutWorkTime: result.data.uncheck_tranche_out_work_time || '',
    };

    yield put(actions.setSettingsSuccessful(resultData));
  } catch (error) {
    yield put(actions.setSettingsFailure(error.response?.data));
  }
}

function* setSettingsSuccessful(action: TODO_ANY) {
  yield put(actions.set({ settingsData: action.payload }));
  notification.info('Изменения сохранены');
}

function* setSettingsFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
}

export default function* () {
  yield takeEvery(actions.getSettings, getSettings);
  yield takeEvery(actions.getSettingsSuccessful, getSettingsSuccessful);
  yield takeEvery(actions.getSettingsFailure, getSettingsFailure);

  yield takeEvery(actions.setSettings, setSettings);
  yield takeEvery(actions.setSettingsSuccessful, setSettingsSuccessful);
  yield takeEvery(actions.setSettingsFailure, setSettingsFailure);
}
