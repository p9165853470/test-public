import { createSelector } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { name } from './index';

export const selectState = fp.path(name);

export default {
  selectSettingsData: createSelector(selectState, fp.path('settingsData')),
  selectErrorListByField: createSelector(selectState, (state) => (field: string) =>
    fp.pathOr([], ['errors', field], state)
  ),
};
