import { createSlice } from '@reduxjs/toolkit';

import { getStateFromParams } from '@rfb/common';

export interface ISettingsState {
  settingsData: {
    workBeginTime: string,
    workEndTime: string,
    workWeekDays: {
      mon: boolean,
      tue: boolean,
      wed: boolean,
      thu: boolean,
      fri: boolean,
      sat: boolean,
      sun: boolean,
    },
    uncheckTrancheInWorkTime: string,
    uncheckTrancheOutWorkTime: string,
  },
  errors: { [key: string]: string[] };
}

const initialState: ISettingsState = {
  settingsData: {
    workBeginTime: '',
    workEndTime: '',
    workWeekDays: {
      mon: false,
      tue: false,
      wed: false,
      thu: false,
      fri: false,
      sat: false,
      sun: false,
    },
    uncheckTrancheInWorkTime: '',
    uncheckTrancheOutWorkTime: '',
  },
  errors: {},
};

const settingsSlice = createSlice({
  name: 'settings',

  initialState,

  reducers: {
    set: (state, action) => ({ ...state, ...action.payload }),
    setError: (state, action) => ({
      ...state,
      errors: { ...state.errors, ...action.payload },
    }),

    getSettings: getStateFromParams,
    getSettingsSuccessful: getStateFromParams,
    getSettingsFailure: getStateFromParams,

    setSettings: getStateFromParams,
    setSettingsSuccessful: getStateFromParams,
    setSettingsFailure: getStateFromParams,
  },
});

export const { name, actions, reducer } = settingsSlice;
