import React from 'react';

import { Text, Link } from '@rfb/ui-kit';

import routingConfig from 'configs/routing';

import styles from './assets/styles/index.module.css';

export interface IUserProfileProps {
  userName: string;
  email: string;
  passwordExpiredDate: string;
  passwordExpiredRemainDays: number;
}

const Main = (props: IUserProfileProps) => {
  const renderPasswordText = (): React.ReactNode => (
    <div className={styles.password}>
      <div className={styles.passwordText}>действителен до {props.passwordExpiredDate}</div>
      <div className={styles.passwordExplanation}>
        В целях безопасности необходимо изменять пароль каждые три месяца (дней до смены пароля - {' '}
        {props.passwordExpiredRemainDays})
      </div>
    </div>
  );

  return (
    <div className={styles.main}>
      <h1 className={styles.title}>Профиль</h1>

      <div className={styles.info}>
        <Text label="Пользователь" content={props.userName} />
        <Text label="E-mail" content={props.email} />
        <Text
          label="Пароль"
          content={renderPasswordText()}
          sidebarRight={
            <div className={styles.link}>
              <Link title="Изменить пароль" to={routingConfig.profilePasswordChange.path} />
            </div>
          }
        />
      </div>
    </div>
  );
};

export default Main;
