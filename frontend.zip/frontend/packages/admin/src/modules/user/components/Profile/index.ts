import { connect } from 'react-redux';

import { name, selectors, IUserState } from '../../store';

import Component, { IUserProfileProps } from './component';

const mapStateToProps = (state: { [name]: IUserState }): IUserProfileProps => ({
  userName: selectors.selectFullName(state),
  email: selectors.selectEmail(state),
  passwordExpiredDate: selectors.selectPasswordExpitedDate(state),
  passwordExpiredRemainDays: selectors.selectPasswordExpiredRemainDays(state),
});

const mapDispatchToProps = () => ({});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
