import React, { useEffect } from 'react';

import { UserWidget } from '@rfb/ui-kit';

export interface IUserWidgetProps {
  name: string;
  profileLink: string;
}

export interface IUserWidgetActions {
  actions: {
    getProfile: Function,
  },
  authActions: {
    logout: Function,
  };
}

const Widget = (props: IUserWidgetProps & IUserWidgetActions) => {
  useEffect(() => {
    props.actions.getProfile()
    // ESLINT Необходимо для отправки запроса только в момент монтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return <UserWidget
    name={props.name}
    email=""
    link={props.profileLink}
    onLogout={props.authActions.logout as () => void}
  />
};

export default Widget;
