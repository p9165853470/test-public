import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import routingConfig from 'configs/routing';

import { name, actions, selectors, IUserState } from '../../store';
import { actions as authActions } from 'modules/auth/store';

import Component, { IUserWidgetProps, IUserWidgetActions } from './component';

const mapStateToProps = (state: { [name]: IUserState }): IUserWidgetProps => ({
  name: selectors.selectFullName(state),
  profileLink: routingConfig.profile.path,
});

const mapDispatchToProps = (dispatch: any): IUserWidgetActions => ({
  actions: bindActionCreators(actions, dispatch),
  authActions: bindActionCreators(authActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
