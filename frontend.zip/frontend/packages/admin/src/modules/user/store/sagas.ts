import { put, takeEvery } from 'redux-saga/effects';

import { convertApiErrorCodesToMessages } from '@rfb/common';

import api from 'utils/api';
import history from 'utils/history';

import routingConfig from 'configs/routing';
import apiEndpoints from 'configs/api/endpoints';

import { actions } from './index';

import { IDTOProfileViewResponse } from 'dto/profile';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* getProfile(action: TODO_ANY) {
  try {
    const result: { data: IDTOProfileViewResponse } = yield api.get(apiEndpoints.profile.view);
    yield put(actions.getProfileSuccessful(result.data));
  } catch (error) {
    yield put(actions.getProfileFailure(error));
  }
}

function* getProfileSuccessful(action: TODO_ANY) {
  yield put(actions.set({ profile: action.payload }));
}

function* getProfileFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* changePassword(action: TODO_ANY) {
  try {
    yield api.post(apiEndpoints.security.passwordChange, action.payload);
    yield put(actions.changePasswordSuccessful(null));
  } catch (error) {
    yield put(actions.changePasswordFailure(error.response?.data));
  }
}

function* changePasswordSuccessful() {
  history.push(routingConfig.profile.path);
  yield;
}

function* changePasswordFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
}

export default function* () {
  yield takeEvery(actions.getProfile, getProfile);
  yield takeEvery(actions.getProfileSuccessful, getProfileSuccessful);
  yield takeEvery(actions.getProfileFailure, getProfileFailure);

  yield takeEvery(actions.changePassword, changePassword);
  yield takeEvery(actions.changePasswordSuccessful, changePasswordSuccessful);
  yield takeEvery(actions.changePasswordFailure, changePasswordFailure);
}
