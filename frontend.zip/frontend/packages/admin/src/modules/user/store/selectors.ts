import { createSelector } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getDayCountUntilDate, getTransformedDate } from '@rfb/common';

import { IDTOProfileViewResponse } from 'dto/profile';

import { name } from './index';

export const selectState = fp.path(name);

const selectProfile = createSelector(selectState, fp.pathOr({}, 'profile'));
const selectForm = createSelector(selectState, fp.path('form'));

export default {
  selectProfile,
  selectFullName: createSelector(
    selectProfile,
    (profile: IDTOProfileViewResponse) =>
      `${profile.last_name} ${profile.first_name} ${profile.middle_name}`
  ),
  selectEmail: createSelector(selectProfile, fp.path('email')),
  selectFormValueByField: createSelector(selectForm, (state) => (field: string) =>
    fp.path(field, state)
  ),
  selectPasswordExpitedDate: createSelector(selectProfile, (profile: IDTOProfileViewResponse) =>
    getTransformedDate(profile.password_unsafe_at)
  ),
  selectPasswordExpiredRemainDays: createSelector(
    selectProfile,
    (profile: IDTOProfileViewResponse) => getDayCountUntilDate(profile.password_unsafe_at)
  ),
  selectErrorListByField: createSelector(selectState, (state) => (field: string) =>
    fp.pathOr([], ['errors', field], state)
  ),
};
