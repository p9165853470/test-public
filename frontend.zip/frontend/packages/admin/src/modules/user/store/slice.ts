import { createSlice } from '@reduxjs/toolkit';

import { getStateFromParams } from '@rfb/common';

import { IDTOProfileViewResponse } from 'dto/profile';

export interface IUserState {
  profile?: IDTOProfileViewResponse;
  form: {
    passwordOld: string;
    passwordNew: string;
    passwordNewRepeat: string;
  }
  errors: { [key: string]: string[] };
}

const initialState: IUserState = {
  profile: undefined,
  form: {
    passwordOld: '',
    passwordNew: '',
    passwordNewRepeat: '',
  },
  errors: {},
};

const userSlice = createSlice({
  name: 'user',

  initialState,

  reducers: {
    set: (state, action) => ({ ...state, ...action.payload }),
    setForm: (state, action) => ({ ...state, form: { ...state.form, ...action.payload }}),
    setError: (state, action) => ({
      ...state,
      errors: { ...state.errors, ...action.payload },
    }),
    resetForm: (state) => ({ ...state, form: { ...initialState.form } }),
    reset: () => ({ ...initialState }),

    getProfile: getStateFromParams,
    getProfileSuccessful: getStateFromParams,
    getProfileFailure: getStateFromParams,

    changePassword: getStateFromParams,
    changePasswordSuccessful: getStateFromParams,
    changePasswordFailure: getStateFromParams,
  },
});

export const { name, actions, reducer } = userSlice;
