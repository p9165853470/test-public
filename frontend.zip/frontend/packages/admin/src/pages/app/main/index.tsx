import React from 'react';

import AppFullWidthTemplate from 'templates/AppFullWidthTemplate';

import FrontOfficeTableHeader from 'modules/front-office/components/TableHeader';
import FrontOfficeTable from 'modules/front-office/components/Table';

const Main = () => {
  const renderContent = () => (
    <div>
      <FrontOfficeTableHeader />
      <FrontOfficeTable />
    </div>
  );
  return <AppFullWidthTemplate content={renderContent()} />;
};

export default Main;
