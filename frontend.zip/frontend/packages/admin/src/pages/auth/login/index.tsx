import React from 'react';

import { AuthTemplate } from '@rfb/ui-kit';

import AuthLogin from 'modules/auth/components/Login';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const Login = (props: TODO_ANY) => {
  const renderContent = () => (
    <div className={styles.content}>
      <AuthLogin history={props.history} />
    </div>
  );

  return <AuthTemplate content={renderContent()} />;
};

export default Login;
