import React from 'react';

import { History } from '@rfb/ui-kit';

import AppTemplate from 'templates/AppTemplate';

import EditBackendUserForm from 'modules/back-office/components/Form/EditUserForm';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';
import routingConfig from 'configs/routing';

const EditBackendUser = (props: TODO_ANY) => {
  const renderContent = () => (
    <div className={styles.content}>
      <EditBackendUserForm id={props.match.params.id} />
    </div>
  );
  const renderSidebarLeft = () => <History type="back" to={routingConfig.backOfficeListPage.path} />;

  return <AppTemplate content={renderContent()} sidebarLeft={renderSidebarLeft()} />;
};

export default EditBackendUser;
