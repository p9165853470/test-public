import React from 'react';

import AppFullWidthTemplate from 'templates/AppFullWidthTemplate';

import BackOfficeTableHeader from 'modules/back-office/components/TableHeader';
import BackOfficeTable from 'modules/back-office/components/Table';

const Main = () => {
  const renderContent = () => (
    <div>
      <BackOfficeTableHeader />
      <BackOfficeTable />
    </div>
  );
  return <AppFullWidthTemplate content={renderContent()} />;
};

export default Main;
