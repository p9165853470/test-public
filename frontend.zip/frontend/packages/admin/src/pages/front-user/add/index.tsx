import React from 'react';

import { History } from '@rfb/ui-kit';

import AppTemplate from 'templates/AppTemplate';

import AddFrontendUserForm from 'modules/front-office/components/Form/AddUserForm';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';
import routingConfig from 'configs/routing';

const AddFrontendUser = (props: TODO_ANY) => {
  const renderContent = () => (
    <div className={styles.content}>
      <AddFrontendUserForm />
    </div>
  );
  const renderSidebarLeft = () => <History type="back" to={routingConfig.main.path} />;

  return <AppTemplate content={renderContent()} sidebarLeft={renderSidebarLeft()} />;
};

export default AddFrontendUser;
