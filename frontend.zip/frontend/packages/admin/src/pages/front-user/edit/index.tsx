import React from 'react';

import { History } from '@rfb/ui-kit';

import AppTemplate from 'templates/AppTemplate';

import EditFrontendUserForm from 'modules/front-office/components/Form/EditUserForm';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';
import routingConfig from 'configs/routing';

const EditFrontendUser = (props: TODO_ANY) => {
  const renderContent = () => (
    <div className={styles.content}>
      <EditFrontendUserForm id={props.match.params.id} />
    </div>
  );
  const renderSidebarLeft = () => <History type="back" to={routingConfig.main.path} />;

  return <AppTemplate content={renderContent()} sidebarLeft={renderSidebarLeft()} />;
};

export default EditFrontendUser;
