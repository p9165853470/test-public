import React from 'react';

import { History } from '@rfb/ui-kit';

import AppTemplate from 'templates/AppTemplate';

import UserPasswordChange from 'modules/user/components/PasswordChange';

import routingConfig from 'configs/routing';

import styles from './assets/styles/index.module.css';

const PasswordChange = () => {
  const renderLeftSidebar = (): JSX.Element => (
    <div className={styles.sidebarLeft}>
      <History type="back" to={routingConfig.profile.path} />
    </div>
  );

  const renderContent = () => (
    <div className={styles.content}>
      <UserPasswordChange />
    </div>
  );

  return <AppTemplate content={renderContent()} sidebarLeft={renderLeftSidebar()} />;
};

export default PasswordChange;
