import React from 'react';

import AppTemplate from 'templates/AppTemplate';

import BankContacts from 'modules/references/components/BankContacts';

const BankContactsPage = () => {
  const renderContent = () => <BankContacts />;

  return <AppTemplate content={renderContent()} />;
};

export default BankContactsPage;
