import React from 'react';

import AppTemplate from 'templates/AppTemplate';

import Feedback from 'modules/references/components/Feedback';

const FeedbackPage = () => {
  const renderContent = () => <Feedback />;

  return <AppTemplate content={renderContent()} />;
};

export default FeedbackPage;
