import React from 'react';

import AppTemplate from 'templates/AppTemplate';

import Memo from 'modules/references/components/Memo';

const MemoPage = () => {
  const renderContent = () => <Memo />;

  return <AppTemplate content={renderContent()} />;
};

export default MemoPage;
