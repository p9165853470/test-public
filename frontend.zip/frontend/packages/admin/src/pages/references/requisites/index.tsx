import React from 'react';

import AppTemplate from 'templates/AppTemplate';

import Requisites from 'modules/references/components/Requisites';

const RequisitesPage = () => {
  const renderContent = () => <Requisites />;

  return <AppTemplate content={renderContent()} />;
};

export default RequisitesPage;
