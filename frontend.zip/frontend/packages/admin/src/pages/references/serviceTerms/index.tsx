import React from 'react';

import AppTemplate from 'templates/AppTemplate';

import ServiceTerms from 'modules/references/components/ServiceTerms';

const ServiceTermsPage = () => {
  const renderContent = () => <ServiceTerms />;

  return <AppTemplate content={renderContent()} />;
};

export default ServiceTermsPage;
