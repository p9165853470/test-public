import React from 'react';

import AppTemplate from 'templates/AppTemplate';

import Tariffs from 'modules/references/components/Tariffs';

const TariffsPage = () => {
  const renderContent = () => <Tariffs />;

  return <AppTemplate content={renderContent()} />;
};

export default TariffsPage;
