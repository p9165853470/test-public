import React from 'react';

import AppTemplate from 'templates/AppTemplate';

import UserManual from 'modules/references/components/UserManual';

const UserManualPage = () => {
  const renderContent = () => <UserManual />;

  return <AppTemplate content={renderContent()} />;
};

export default UserManualPage;
