import React from 'react';

import Settings from 'modules/settings/components/Settings';

import AppTemplate from 'templates/AppTemplate';

const SettingsPage = () => {
  const renderContent = () => (
    <Settings />
  );

  return <AppTemplate content={renderContent()} />;
};

export default SettingsPage;
