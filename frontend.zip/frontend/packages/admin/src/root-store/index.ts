import { configureStore } from '@reduxjs/toolkit';

import rootMiddleware from './root-middleware';
import rootReducer from './root-reducer';
import { runAll as runAllMiddlewares } from './root-saga';

export const store = configureStore({
  reducer: rootReducer,
  middleware: rootMiddleware,
});

runAllMiddlewares();
