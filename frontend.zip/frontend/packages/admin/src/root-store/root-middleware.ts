import rootSaga from './root-saga';

export default [rootSaga];
