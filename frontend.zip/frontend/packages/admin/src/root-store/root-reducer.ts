import { reducer as appReducer, name as appName } from 'modules/app/store';
import { reducer as authReducer, name as authName } from 'modules/auth/store';
import { reducer as backOfficeReducer, name as backOfficeName } from 'modules/back-office/store';
import { reducer as frontOfficeReducer, name as frontOfficeName } from 'modules/front-office/store';
import { reducer as referencesReducer, name as referencesName } from 'modules/references/store';
import { reducer as userReducer, name as userName } from 'modules/user/store';
import { reducer as settingsReducer, name as settingsName } from 'modules/settings/store';

export default {
  [appName]: appReducer,
  [authName]: authReducer,
  [backOfficeName]: backOfficeReducer,
  [frontOfficeName]: frontOfficeReducer,
  [referencesName]: referencesReducer,
  [userName]: userReducer,
  [settingsName]: settingsReducer,
};
