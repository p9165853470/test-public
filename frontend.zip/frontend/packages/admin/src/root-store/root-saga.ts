import createSagaMiddleware from 'redux-saga';

import fp from 'lodash/fp';

import history from 'utils/history';

import routingConfig from 'configs/routing';

import { sagas as appSagas } from 'modules/app/store';
import { sagas as authSagas } from 'modules/auth/store';
import { sagas as backOfficeSagas } from 'modules/back-office/store';
import { sagas as frontOfficeSagas } from 'modules/front-office/store';
import { sagas as referencesSagas } from 'modules/references/store';
import { sagas as userSagas } from 'modules/user/store';
import { sagas as settingsSagas } from 'modules/settings/store';

const sagaMiddleware = createSagaMiddleware({
  onError: () => history.push(routingConfig.error500.path),
});

const sagaList = [
  appSagas,
  authSagas,
  backOfficeSagas,
  frontOfficeSagas,
  referencesSagas,
  userSagas,
  settingsSagas,
];

export const runAll = () => fp.forEach(sagaMiddleware.run, sagaList);

export default sagaMiddleware;
