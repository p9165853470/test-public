import React from 'react';

import { AppFullWidthTemplate as UIKiAppFullWidthtTemplate } from '@rfb/ui-kit';

import AppMenu from 'modules/app/components/Menu';
import UserWidget from 'modules/user/components/Widget';

interface IAppFullWidthTemplate {
  content: JSX.Element | JSX.Element[];
}

const AppFullWidthTemplate = (props: IAppFullWidthTemplate) => {
  const renderHeader = () => (
    <>
      <AppMenu />
      <UserWidget />
    </>
  );

  const renderContent = () => props.content;

  return <UIKiAppFullWidthtTemplate header={renderHeader()} content={renderContent()} />;
};

export default AppFullWidthTemplate;
