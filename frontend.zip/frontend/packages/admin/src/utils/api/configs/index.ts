import { IApiConfig, ApiErrors } from '@rfb/common';

import history from 'utils/history';
import storage from 'utils/storage';

import apiEndpoints from 'configs/api/endpoints';

import routingConfig from 'configs/routing';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const config: IApiConfig = {
  baseUrl: process.env.REACT_APP_ADMIN_API_URL!,
  timeout: 1000 * 60 * 3,
  tokenExpired: {
    refreshUrl: apiEndpoints.auth.tokenRefresh,
    set: (token: string) => storage.set('token', token),
    redirect: () => {
      storage.clearAll();
      window.location.replace(routingConfig.login.path);
    },
  },
  errorHandlers: {
    403: {
      availableCodeList: [0, ApiErrors.USER_BLOCKED, ApiErrors.USER_BLOCKED_BY_ADMIN],
      handler: () => {
        storage.clearAll();
        window.location.replace(routingConfig.login.path);
      }
    },
    422: {
      availableCodeList: [0],
      handler: () => history.push(routingConfig.error422.path),
    },
  },
  getToken: () => (storage as TODO_ANY).get('token'),
};

export default config;
