import { ApiAxios } from '@rfb/common';

import config from './configs';

export default ApiAxios(config);
