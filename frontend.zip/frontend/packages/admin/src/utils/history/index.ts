import { HistoryBrowser } from '@rfb/common';

export default HistoryBrowser();
