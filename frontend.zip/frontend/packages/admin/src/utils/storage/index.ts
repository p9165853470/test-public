import { StorageCookie } from '@rfb/common';

export default StorageCookie;
