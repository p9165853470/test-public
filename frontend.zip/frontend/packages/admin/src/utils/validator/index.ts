import fp from 'lodash/fp';

import { ValidatorYup, validationMessages } from '@rfb/common';

export default ValidatorYup(fp.omit('app', validationMessages));
