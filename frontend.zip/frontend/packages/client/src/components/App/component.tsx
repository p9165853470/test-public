import React from 'react';

import AppGuest from './components/AppGuest';
import AppUser from './components/AppUser';

import '@rfb/common/assets/styles/index.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

export interface IAppProps {
  state: TODO_ANY;
  token: string;
}

const App = (props: IAppProps) => {
  console.log(`App BEGIN`);
  return (props.token ? <AppUser /> : <AppGuest />);
}

export default App;
