import PhoneNumberChange from 'modules/user/components/PhoneNumberChange';

export default {
  auth: {
    tokenCreate: '/authentication/create-token',
    tokenRefresh: '/authentication/refresh-token',
    tokenDestroy: '/authentication/destroy-token',
  },

  confirmation: {
    sendSms: '/security/send-confirm-sms',
    checkCode: '/security/check-code',
  },

  feedback: {
    create: '/feedback/create',
  },

  profile: {
    agreement: '/profile/agreement',
    view: '/profile/view',
    validate: '/profile/validate',
    phoneNumber: '/profile/phone-validate',
    chooseDealer: '/profile/choose-dealer',
    phoneNumberChange: '/profile/phone-number-change',
    codeWordChange: '/profile/key-word-change',
  },

  rfInfo: {
    accounts: '/rf-info/accounts',
    arrests: '/rf-info/account-arrests',
    clientLine: '/rf-info/client-line',
    clientLines: '/rf-info/client-lines',
    info: '/rf-info/info',
    rate: '/rf-info/rate',
    transactions: '/rf-info/account-transactions',
    transactionsExport: '/rf-info/account-transactions/export',
    statements: '/rf-info/account-statements',
    statementsExport: '/rf-info/account-statements/export',
    tranches: '/rf-info/tranches',
    tranchesPayment: '/rf-info/tranches/payment',
    tranchesExport: '/rf-info/tranches/export',
    tranchesDocRequest: '/rf-info/tranches/doc-request',
    user: '/rf-info/user',
  },

  security: {
    passwordReset: '/security/reset-password',
    passwordChange: '/security/change-password',
  },

  variable: {
    agreement: '/variable/agreement',
    contacts: '/variable/contacts',
    instruction: '/variable/instruction',
    tariffs: '/variable/tariffs',
    reminder: '/variable/reminder',
    requisites: '/variable/requisites',
  },
};
