import ApiErrors from './errors';

export default {
  [ApiErrors.USER_NOT_FOUND]: 'Логин не найден в системе',
  [ApiErrors.USER_BLOCKED]: 'Пользователь заблокирован',
  [ApiErrors.USER_BLOCKED_BY_ADMIN]:
    'Логин заблокирован. Обратитесь в Банк по E-mail: rfb.it@rosbank.ru',
  [ApiErrors.USER_BLOCKED_FAILURE_AUTH]:
    'Логин заблокирован. Обратитесь в Банк по E-mail: rfb.it@rosbank.ru',
  [ApiErrors.USER_INACTIVE]:
    'Срок действия полномочий истек. Обратитесь в Банк по E-mail: rfb.it@rosbank.ru',
  [ApiErrors.PASSWORD_EXPIRED]:
    'Текущий пароль пользователя - небезопасный (устарел, нужно сменить)',
  [ApiErrors.RS_INFO_VALIDATION_ERROR]: 'Пользователь ЛК еще не прошел валидацию в системе RSInfo',
  [ApiErrors.SERVICE_TERMS_ERROR]: 'Пользователь не принял пользовательское соглашение',
  [ApiErrors.INCORRECT_LOGIN_PASSWORD]: 'Логин или пароль введены неверно',
  [ApiErrors.TEMP_PASSWORD_FAILURE_AUTH]:
    'Временный пароль введён неправильно несколько раз подряд. Необходимо сбросить пароль через форму восстановления пароля',
  [ApiErrors.PASSWORD_CHANGE_REQUIRED_TIME_NOT_PASSED]:
    'Прошло мало времени после последней ручной смены пароля',
  [ApiErrors.PASSWORD_CHANGE_SAME_VALUE]: 'Данный пароль уже использовался для этой учетной записи',
  [ApiErrors.OLD_PASSWORD_INCORRECT]: 'Неверный старый пароль',
  [ApiErrors.INN_KPP_FAILURE_CHECK]:
    'Данные введены неверно. Проверьте правильность ввода данных',
  [ApiErrors.RF_INFO_ERROR]: 'Ошибка при обработке данных. Повторите запрос',
};
