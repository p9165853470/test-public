import { IMenuElement, IMenuSubMenu } from '@rfb/ui-kit';

/**
 * TODO
 * Разобраться, почему при импорте routingConfig
 * в значении содержится undefined
 * После решения это проблемы, все ссылки должны
 * использоваться из этого конфига
 */
// import routingConfig from 'configs/routing';

export const appMenuConfig: (IMenuElement | IMenuSubMenu)[] = [
  {
    title: 'Договоры',
    items: [
      { title: 'Информация по договорам', link: '/' },
      { title: 'Информация по траншам', link: '/tranches' },
    ],
  },
  { title: 'Расчётные счета', link: '/accounts' },
  { title: 'Помощь', link: '/help' },
  { title: 'Информация', link: '/information' },
];
