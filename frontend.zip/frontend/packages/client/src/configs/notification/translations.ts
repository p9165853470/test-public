export default {
  sendPaymentSuccessful: 'Транши отправлены',
};
