import { IRouteConfig, Roles } from '@rfb/common';

import fp from 'lodash/fp';

import AuthLoginPage from 'pages/auth/login';
import AuthLoginFirstPage from 'pages/auth/login-first';
import AuthPasswordRestorePage from 'pages/auth/password-restore';
import AuthPasswordRestoreSentPage from 'pages/auth/password-restore-sent';
import AuthPasswordExpiredPage from 'pages/auth/password-expired';
import AuthServiceTermsPage from 'pages/auth/service-terms';
import LoginConfirm from 'pages/auth/login-confirm';
import OrganizationPage from 'pages/auth/organization';
import PhoneValidationPage from 'pages/auth/phone-validation';

import AppMainPage from 'pages/app/main';
import AppHelpPage from 'pages/app/help';

import ClientLinesDetailByIdPage from 'pages/client-lines/detail-by-id';

import InformationMainPage from 'pages/information/main';
import InformationContactsPage from 'pages/information/contacts';
import InformationFeedbackPage from 'pages/information/feedback';
import InformationFeedbackSentPage from 'pages/information/feedback-sent';
import InformationReminderPage from 'pages/information/reminder';
import InformationTariffsPage from 'pages/information/tariffs';

import ProfileMainPage from 'pages/profile/main';
import ProfilePasswordChangePage from 'pages/profile/password-change';
import ProfilePhoneNumberChangePage from 'pages/profile/phone-number-change';
import ProfilePhoneNumberChangeConfirmPage from 'pages/profile/phone-number-change-confirm';
import ProfileCodeWordChangePage from 'pages/profile/code-word-change';
import ProfileCodeWordChangePageConfirmPage from 'pages/profile/code-word-change-confirm';
import PersonalDataChangePage from 'pages/profile/change-personal-data';

import AccountsPage from 'pages/accounts/list';
import AccountRestrictionsByIdPage from 'pages/accounts/restrictions-by-id';
import AccauntExtendedStatementPage from 'pages/accounts/extended-statement';

import TranchesMainPage from 'pages/tranches/main';
import TranchesRepaymentPage from 'pages/tranches/repayment';
import TranchesListByClientLineIdPage from 'pages/tranches/list-by-client-line-id';

import Error404Page from 'pages/errors/404';
import Error422Page from 'pages/errors/422';
import Error500Page from 'pages/errors/500';

import { selectors as appSelectors } from 'modules/app/store';
import { selectors as authSelectors } from 'modules/auth/store';
import { selectors as informationSelectors } from 'modules/information/store';

import apiErrors from 'configs/api/errors';
import CodeWordChange from 'modules/user/components/CodeWordChange';

const prefix: { [key: string]: string } = {
  auth: '/auth',
  clientLines: '/client-lines',
  information: '/information',
  profile: '/profile',
  accounts: '/accounts',
  tranches: '/tranches',
};

const config: IRouteConfig = {
  login: {
    path: '/',
    component: AuthLoginPage,
    accessList: [Roles.GUEST],
    isExact: true,
  },

  phoneNumberValidation: {
    path: '/',
    component: PhoneValidationPage,
    accessList: [Roles.USER],
    check: fp.pipe(appSelectors.selectApiErrorCode, fp.isEqual(apiErrors.PHONE_NUMBER_ERROR)),
    isExact: true,
  },

  smsConfirm: {
    path: '/',
    component: LoginConfirm,
    accessList: [Roles.USER],
    check: fp.pipe(appSelectors.selectApiErrorCode, fp.isEqual(apiErrors.NOT_CONFIRMED_LOGIN)),
    isExact: true,
  },

  organization: {
    path: '/',
    component: OrganizationPage,
    accessList: [Roles.USER],
    check: fp.pipe(appSelectors.selectApiErrorCode, fp.isEqual(apiErrors.NOT_CHOOSED_ORGANIZATION)),
    isExact: true,
  },

  innKppValidation: {
    path: '/',
    component: AuthLoginFirstPage,
    accessList: [Roles.USER],
    check: fp.pipe(appSelectors.selectApiErrorCode, fp.isEqual(apiErrors.RS_INFO_VALIDATION_ERROR)),
    isExact: true,
  },

  serviceTerms: {
    path: '/',
    component: AuthServiceTermsPage,
    accessList: [Roles.USER],
    check: fp.pipe(appSelectors.selectApiErrorCode, fp.isEqual(apiErrors.SERVICE_TERMS_ERROR)),
    isExact: true,
  },

  passwordRestore: {
    path: prefix.auth + '/password-restore',
    component: AuthPasswordRestorePage,
    accessList: [Roles.GUEST],
  },

  passwordRestoreSent: {
    path: prefix.auth + '/password-restore-sent',
    component: AuthPasswordRestoreSentPage,
    accessList: [Roles.GUEST],
    check: fp.pipe(authSelectors.selectIsPasswordRestoreSent, fp.isEqual(true)),
  },

  passwordExpired: {
    path: '',
    component: AuthPasswordExpiredPage,
    accessList: [Roles.USER],
    check: fp.pipe(appSelectors.selectApiErrorCode, fp.isEqual(apiErrors.PASSWORD_EXPIRED)),
  },

  main: {
    path: '/',
    component: AppMainPage,
    accessList: [Roles.USER],
    isExact: true,
  },

  help: {
    path: '/help',
    component: AppHelpPage,
    accessList: [Roles.USER],
  },

  clientLinesDetailById: {
    path: prefix.clientLines + '/:id/:type/details',
    component: ClientLinesDetailByIdPage,
    accessList: [Roles.USER],
  },

  accounts: {
    path: prefix.accounts,
    component: AccountsPage,
    accessList: [Roles.USER],
    isExact: true,
  },

  accountRestrictions: {
    path: prefix.accounts + '/:id',
    component: AccountRestrictionsByIdPage,
    accessList: [Roles.USER],
    isExact: true,
  },

  extendedStatement: {
    path: prefix.accounts + '/extended-statement/:id',
    component: AccauntExtendedStatementPage,
    accessList: [Roles.USER],
    isExact: true,
  },

  information: {
    path: prefix.information,
    component: InformationMainPage,
    accessList: [Roles.USER],
    isExact: true,
  },

  contacts: {
    path: prefix.information + '/contacts',
    component: InformationContactsPage,
    accessList: [Roles.USER],
  },

  feedback: {
    path: prefix.information + '/feedback',
    component: InformationFeedbackPage,
    accessList: [Roles.USER],
  },

  feedbackSent: {
    path: prefix.information + '/feedback-sent',
    component: InformationFeedbackSentPage,
    accessList: [Roles.USER],
    check: fp.pipe(informationSelectors.selectIsFeedbackSent, fp.isEqual(true)),
  },

  reminder: {
    path: prefix.information + '/reminder',
    component: InformationReminderPage,
    accessList: [Roles.USER],
  },

  tariffs: {
    path: prefix.information + '/tariffs',
    component: InformationTariffsPage,
    accessList: [Roles.USER],
  },

  profile: {
    path: prefix.profile,
    component: ProfileMainPage,
    accessList: [Roles.USER],
    isExact: true,
  },

  profilePasswordChange: {
    path: prefix.profile + '/password-change',
    component: ProfilePasswordChangePage,
    accessList: [Roles.USER],
  },

  profilePhoneNumberChange: {
    path: prefix.profile + '/phone-number-change',
    component: ProfilePhoneNumberChangePage,
    accessList: [Roles.USER],
    isExact: true,
  },

  profilePhoneNumberChangeConfirmation: {
    path: prefix.profile + '/phone-number-change/confirm',
    component: ProfilePhoneNumberChangeConfirmPage,
    accessList: [Roles.USER],
  },

  profileCodeWordChange: {
    path: prefix.profile + '/code-word-change',
    component: ProfileCodeWordChangePage,
    accessList: [Roles.USER],
    isExact: true,
  },

  profileCodeWordChangeConfirmation: {
    path: prefix.profile + '/code-word-change/confirm',
    component: ProfileCodeWordChangePageConfirmPage,
    accessList: [Roles.USER],
  },

  profileFioChange: {
    path: prefix.profile + '/fio-change',
    component: PersonalDataChangePage,
    accessList: [Roles.USER],
  },

  tranches: {
    path: prefix.tranches,
    component: TranchesMainPage,
    accessList: [Roles.USER],
    isExact: true,
  },

  repayment: {
    path: prefix.tranches + '/repayment',
    component: TranchesRepaymentPage,
    accessList: [Roles.USER],
  },

  tranchesListByClientLineIdAndType: {
    path: prefix.tranches + '/:clientLineId/:clientLineType',
    component: TranchesListByClientLineIdPage,
    accessList: [Roles.USER],
  },

  error500: {
    path: '/500',
    component: Error500Page,
    accessList: [Roles.GUEST, Roles.USER],
  },

  error422: {
    path: '/422',
    component: Error422Page,
    accessList: [Roles.GUEST, Roles.USER],
  },

  error404: {
    path: '*',
    component: Error404Page,
    accessList: [Roles.GUEST, Roles.USER],
  },
};

export default config;
