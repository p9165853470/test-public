export interface IDTOTokenCreateRequest {
  login: string;
  password: string;
}

export interface IDTOTokenCreateResponse {
  type: 'Bearer';
  token: string;
}