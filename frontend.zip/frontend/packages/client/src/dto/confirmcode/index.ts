export type DTOCodeConfirmationRequest = {
  confirm_code: string;
  factor_url: string;
  type_confirm_code: string;
};

export type DTOCodeConfirmationResponse = {
  check_factor_result: string;
  check_factor_msg: string;
};

export type DTOGetConfirmCodeRequest = {
  type_confirm_code: string;
};

export type DTOGetConfirmCodeResponse = {
  masked_phone_number: string;
  factor_url: string;
};
