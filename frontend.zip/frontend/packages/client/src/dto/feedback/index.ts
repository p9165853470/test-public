export interface IDTOFeedbackCreateRequest {
  subject: string;
  contract_number?: string;
  phone_number?: string;
  message: string;
  dealer_name: string;
}
