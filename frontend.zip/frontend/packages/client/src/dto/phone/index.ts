export type DTOPhoneValidationRequest = {
  phone_number: string
}