export interface IDTOProfileViewResponse {
  id: 1;
  email: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  created_at: string;
  updated_at: string;
  dealers: IDealer[];
  block_reason: string;
  active: string;
  password_unsafe_at: string;
}

export interface IDealer {
  diasoft_id: string;
  authority_begin_date: string;
  authority_end_date: string;
  agreement_at: string;
  validated_at: string;
}

export interface IDTOProfileValidateRequest {
  inn: string;
  kpp: string;
}
