export interface IDTORFInfoClientLineShortResponse {
  number: string;
  type: string;
  status: string;
  name_brand: string;
  name_product: string;
}

export interface IDTORFInfoClientLineFullResponse {
  number: string;
  type: string;
  status: number;
  name_brand: string;
  name_product: string;
  start_date: string;
  real_finish_date: string;
  finish_date: string;
  limit_amount: number;
  total_main_debt: number;
  rest_limit: number;
  date_near_line_pay: string;
  flag_near_line_pay: number;
  percent_rate: string;
  date_percent_rate: string;
  comiss_type: string;
  summ_comiss_debt: number;
  line_block: number;
  overdue_debt: number;
}

export interface IDTORFInfoOrganizationResponse {
  diasoft_id: string;
  name: string;
  inn: string;
  kpp: string;
}

export interface IDTORFInfoRateResponse {
  date_rate: string;
  value: string;
}

export interface IDTORFInfoHeaders {
  'x-pagination-page-count': string;
  'x-pagination-per-page': string;
}

// Расчётные счета
export interface IDTORFInfoAccountDetailResponse {
  number: string;
  type: string;
  status: number;
  name_brand: string;
  name_product: string;
  start_date: string;
  real_finish_date: string;
  finish_date: string;
  limit_amount: number;
  total_main_debt: number;
  rest_limit: number;
  date_near_line_pay: string;
  flag_near_line_pay: number;
  percent_rate: string;
  date_percent_rate: string;
  comiss_type: string;
  summ_comiss_debt: number;
  line_block: number;
  overdue_debt: number;
}

export interface IDTORFInfoAccountsResponse {
  diasoft_id: string;
  account: string;
  rest: string;
  rko_debt: string;
  arrest: string;
  open_date: string;
  close_date: string;
}

export interface IDTORFInfoAccountArrestResponse {
  diasoft_id: string;
  account: string;
  arrest_type: string;
  arrest_date: string;
  arrest_qty: string;
  arrest_organization: string;
}

export interface IDTORFInfoAccountArrestsResponse {
  arrests: IDTORFInfoAccountArrestResponse[];
  krt_count: string;
  krt_qty: string;
}

export interface IDTORFInfoAccountTransactionResponse {
  diasoft_id: string;
  doc_date: string;
  doc_number: string;
  qty_cred: string;
  qty_debt: string;
  comment: string;
}

export interface IDTORFInfoAccountResponse {
  transactions: IDTORFInfoAccountTransactionResponse[];
  rest_in?: string;
  turn_cred?: string;
  turn_debt?: string;
  rest_out?: string;
}

export interface IDTORFInfoAccountStatementsResponse {
  diasoft_id: string,
  account: string,
  date_start: string,
  date_end: string,
  doc_date: string,
  doc_number: string,
  vo: string,
  bic_contractor: string,
  account_contractor: string,
  qty_cred: string,
  qty_debt: string,
  contractor: string,
  inn_contractor: string,
  comment: string,
}

export interface IDTORFInfoAccountExtendedStatementResponse {
  statements: IDTORFInfoAccountStatementsResponse[],
  rest_in: string,
  turn_cred: string,
  turn_debt: string,
  doc_quantity: string,
  rest_out: string,
}

export interface IDTORFInfoTranchesResponse {
  tranches: {
    vin: string,
    name_brand: string,
    model: string,
    number: string,
    type: string,
    status: number,
    sum_amount: number,
    sum_pre_pay: number,
    real_start_date: Date,
    date_beg_pay: Date,
    finish_date: Date,
    rest_main_debt: number,
    overdue_debt: number,
    flag_overdue_debt: boolean,
    percent_rate: number,
    sum_percent: number,
    sum_fin: number,
    sum_comiss: number,
    payment_type: null | 'full-repayment' | 'prepayment',
  }[];
  filters: {
    models: string[],
    brands: string[],
    contracts: string[],
  };
}

export interface IDTORFInfoTranchesPaymentRequest {
  payments: {
    vin: string,
    payment_type: 'full-repayment' | 'prepayment',
  }[];
}

export type DTOUserInfo = {
  fio: string
  dat_nach_pol: string
  dat_okon_pol: string
  phone_number: string
  code_word: string
  diasoft_id: string
  name: string
  inn: string
  kpp: string
}