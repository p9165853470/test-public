export interface IDTOVariableAgreementResponse {
  text: string;
}

export interface IDTOVariableContactsResponse {
  text: string;
}

export interface IDTOVariableInstructionResponse {
  text: string;
}

export interface IDTOVariableTariffsResponse {
  text: string;
}

export interface IDTOVariableReminderResponse {
  text: string;
}

export interface IDTOVariableRequisitesResponse {
  text: string;
}
