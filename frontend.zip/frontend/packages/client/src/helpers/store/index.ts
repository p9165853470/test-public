import fp from 'lodash/fp';

// TODO Add comment with explanation
export const getStateFromParams = fp.nthArg(0);
