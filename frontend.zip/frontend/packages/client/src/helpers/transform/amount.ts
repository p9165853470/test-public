const intlRu = new Intl.NumberFormat('ru-ru', {
  style: 'currency',
  currency: 'RUB',
});

export const getTransformedAmount = (amount: number): string => intlRu.format(amount);
