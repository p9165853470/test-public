import dayjs from 'dayjs';

const dateFormat: string = 'DD.MM.YYYY';

export const getTransformedDate = (date: string) => dayjs(date).format(dateFormat);
