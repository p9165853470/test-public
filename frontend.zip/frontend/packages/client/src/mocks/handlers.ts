import { rest } from 'msw';
import storage from 'utils/storage';

const profile = {
  id: 13,
  email: 'ZhukAV@rusfinance.ru',
  diasoft_id: storage.get('diasoft_id'),
  // diasoft_id: "10037810768",
  first_name: 'Александр',
  middle_name: 'Валерьевич',
  last_name: 'Жук',
  authority_begin_date: '2020-12-18',
  authority_end_date: '2021-12-31',
  password_unsafe_at: '2021-12-31 14:45:28',
  created_at: '2020-12-18 07:11:22',
  updated_at: '2021-06-15 14:45:28',
  agreement_at: '',
  confirmed: 0,
  validated_at: '',
  phone_number: '',
  code_word: 'TESTWORD',
  // agreement_at: '2020-11-20 06:25:08',
  // validated_at: '2022-11-20 06:25:08',
  block_reason: '',
  active: true,
};

const organization = {
  diasoft_id: '10037810768',
  name: 'kukuevo',
  inn: '123456789123',
  kpp: '123456789',
};

const userDealers = [
  {
    fio: 'Жук Александр Валерьевич',
    dat_nach_pol: '2020-12-18',
    dat_okon_pol: '2021-12-31',
    phone_number: '79163367069',
    code_word: 'TESTWORD',
    diasoft_id: '10037810768',
    name: 'kukuevo',
    inn: '123456789123',
    kpp: '123456789',
  },
  {
    fio: 'Жук Александр Валерьевич',
    dat_nach_pol: '2020-12-18',
    dat_okon_pol: '2021-12-31',
    phone_number: '79163367069',
    code_word: 'TESTWORD',
    diasoft_id: '10037810723',
    name: 'kukuevo23',
    inn: '123456789123',
    kpp: '123456789',
  },
];

export const handlers = [
  rest.get(`${process.env.REACT_APP_API_URL}/profile/view`, (req, res, ctx) => {
    console.log('/profile/view');
    if (!profile.phone_number) {
      return res(ctx.status(403), ctx.json({ code: 1031 }));
    }
    if (!profile.confirmed) {
      return res(ctx.status(403), ctx.json({ code: 1032 }));
    }
    if (!profile.validated_at) {
      return res(ctx.status(403), ctx.json({ code: 1030 }));
    }
    if (!profile.agreement_at) {
      return res(ctx.status(403), ctx.json({ code: 1040 }));
    }
    return res(ctx.status(200), ctx.json(profile));
  }),
  rest.post(`${process.env.REACT_APP_API_URL}/profile/agreement`, (req, res, ctx) => {
    console.log('/profile/agreement');
    profile.agreement_at = '2022-11-20 06:25:08';
    return res(ctx.status(200));
  }),
  rest.post(`${process.env.REACT_APP_API_URL}/profile/validate`, (req, res, ctx) => {
    console.log('/profile/validate');
    profile.validated_at = '2022-11-20 06:25:08';
    return res(ctx.status(200));
  }),
  rest.post(`${process.env.REACT_APP_API_URL}/profile/phone-validate`, (req, res, ctx) => {
    console.log('/profile/phone-validate');
    profile.phone_number = '79163367069';
    return res(ctx.status(200));
  }),
  rest.post(`${process.env.REACT_APP_API_URL}/profile/change-phone`, (req, res, ctx) => {
    console.log('/profile/change-phone');
    profile.phone_number = (req?.body as any).phone_number;
    return res(ctx.status(200));
  }),
  rest.post(`${process.env.REACT_APP_API_URL}/profile/change-code-word`, (req, res, ctx) => {
    console.log('/profile/change-code-word');
    profile.code_word = (req?.body as any).code_word;
    return res(ctx.status(200));
  }),
  rest.get(`${process.env.REACT_APP_API_URL}/rf-info/user`, (req, res, ctx) => {
    return res(ctx.status(200), ctx.json(userDealers));
  }),
  rest.get(`${process.env.REACT_APP_API_URL}/rf-info/info`, (req, res, ctx) => {
    console.log('/rf-info/info');
    if (profile.diasoft_id) {
      return res(ctx.status(200), ctx.json(organization));
    }
    return res(ctx.status(404));
  }),
  rest.post(`${process.env.REACT_APP_API_URL}/security/send-confirm-sms`, (req, res, ctx) => {
    return res(
      ctx.status(200),
      ctx.json({ masked_phone_number: '+7916*****69' }),
      ctx.set('Location', '/rf-info/check-code')
    );
  }),
  rest.post(`${process.env.REACT_APP_API_URL}/rf-info/check-code`, (req, res, ctx) => {
    profile.confirmed = 1;
    return res(ctx.status(200));
  }),
  rest.post(`${process.env.REACT_APP_API_URL}/profile/choose-dealer`, (req, res, ctx) => {
    console.log('/profile/choose-dealer');
    profile.diasoft_id = '10037810768';
    return res(ctx.status(200));
  }),
];
