import React from 'react';

import { toRuDate } from '@rfb/common/utils/format/date';

import styles from './assets/styles/index.module.css';
import { pluralize } from '@rfb/common/lib/utils/format/plural';

export interface IDetailedRestrictionHeader {
  count: number;
  sum: string;
  noRestrictions: boolean;
}

export interface IDetailedRestrictionHeaderPropsExternal {
  id: string;
}

const Header = (props: IDetailedRestrictionHeader & IDetailedRestrictionHeaderPropsExternal) => {
  const year = new Date().getFullYear();

  return (
    <div className={styles.header}>
      <h1 className={styles.title}>Ограничения по расчетному счёту {props.id}</h1>

      {props.noRestrictions ? (
        <div className={styles.description}>
          На{' '}
          <span className={styles.date}>
            {toRuDate()} {year} года
          </span>{' '}
          блокировки по расчетному счету отсутствуют.
          <br />
          На{' '}
          <span className={styles.date}>
            {toRuDate()} {year} года
          </span>{' '}
          года картотека расчетных документов по расчетному счету отсутствует.
        </div>
      ) : (
        <div className={styles.description}>
          На{' '}
          <span className={styles.date}>
            {toRuDate()} {year} года
          </span>{' '}
          картотека расчётных документов по счёту <span className={styles.account}>{props.id}</span>
          <br />
          составляет {pluralize(props.count, ['документ', 'документа', 'документов'])} на общую
          сумму {props.sum}
        </div>
      )}
    </div>
  );
};

export default Header;
