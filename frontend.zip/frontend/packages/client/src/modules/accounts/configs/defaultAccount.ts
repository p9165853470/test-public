import { getTransformedApiDate } from '@rfb/common';

const daysBackCount = 7;
export const dates = {
  start: getTransformedApiDate(new Date(Date.now() - daysBackCount * 3600 * 24 * 1000).toString()),
  end: getTransformedApiDate(new Date().toString()),
};
