import { put, takeLatest } from 'redux-saga/effects';

import fp from 'lodash/fp';

import { convertApiErrorCodesToMessages } from 'helpers/app';

import api from 'utils/api';

import { download } from 'helpers/file';

import apiEndpoints from 'configs/api/endpoints';

import { actions, IAccountsState } from './index';

import {
  IDTORFInfoHeaders,
  IDTORFInfoAccountsResponse,
  IDTORFInfoAccountTransactionResponse,
  IDTORFInfoAccountArrestsResponse,
  IDTORFInfoAccountExtendedStatementResponse,
} from 'dto/rf-info';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* getAccounts() {
  yield put(actions.set({ isLoading: true }));
  yield put(actions.setError({ rfInfo: [] }));
  try {
    // Все расчётные счета
    const url: string = apiEndpoints.rfInfo.accounts;
    const result: {
      data: IDTORFInfoAccountsResponse[],
      headers: IDTORFInfoHeaders,
    } = yield api.get(url);
    yield put(actions.getAccountsSuccessful(result.data));
  } catch (error) {
    yield put(actions.getAccountsFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* getAccountsSuccessful(action: TODO_ANY) {
  yield put(actions.setAccounts(action.payload));
}

function* getAccountsFailure(action: TODO_ANY) {
  yield put(actions.setError({ rfInfo: convertApiErrorCodesToMessages(action.payload) }));
}

function* getAccount(action: TODO_ANY) {
  yield put(actions.set({ isLoading: true }));
  yield put(actions.setError({ rfInfo: [] }));

  try {
    const account = action.payload.account;
    const startDate = action.payload.start;
    const endDate = action.payload.end;
    const page = action.payload.pageTransactions;

    const params = `?account=${account}&start_date=${startDate}&end_date=${endDate}&page=${page}`;
    const urlAccount: string = apiEndpoints.rfInfo.transactions + params;

    const resultAccount: { data: IDTORFInfoAccountTransactionResponse } = yield api.get(urlAccount);

    yield put(actions.getAccountTransactionsSuccessful(resultAccount));
  } catch (error) {
    yield put(actions.getAccountTransactionsFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* getAccountSuccessful(action: TODO_ANY) {
  yield put(actions.setCurrentAccount(action.payload));
}

function* getAccountFailure(action: TODO_ANY) {
  yield put(actions.resetAccountData());
  yield put(actions.resetCurrentAccount());
  yield put(actions.setError({ rfInfo: convertApiErrorCodesToMessages(action.payload) }));
}

function* getAccountTransactions(action: TODO_ANY) {
  yield put(actions.set({ isLoading: true, pageTransactionsCount: 0 }));
  yield put(actions.setError({ rfInfo: [] }));

  try {
    yield put(actions.resetAccountData());
    const url: string = apiEndpoints.rfInfo.transactions + `?account=${action.payload}`;
    const result: { data: IDTORFInfoAccountTransactionResponse } = yield api.get(url);
    yield put(actions.getAccountTransactionsSuccessful(result));
  } catch (error) {
    yield put(actions.getAccountTransactionsFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* getAccountTransactionsSuccessful(action: TODO_ANY) {
  yield put(actions.setAccountData(action.payload.data));
  yield put(
    actions.set({
      pageTransactionsCount: fp.toNumber(action.payload.headers['x-pagination-page-count']),
    })
  );
}

function* getAccountTransactionsFailure(action: TODO_ANY) {
  yield put(actions.set({ pageTransactionsCount: 0 }));
  yield put(actions.setError({ rfInfo: convertApiErrorCodesToMessages(action.payload) }));
}

function* getAccountArrests(action: TODO_ANY) {
  yield put(actions.setError({ rfInfo: [] }));

  try {
    yield put(actions.resetCurrentArrestsData());

    const account = action.payload.account;
    const page = action.payload.page;
    const params = `?account=${account}&page=${page}`;

    const url: string = apiEndpoints.rfInfo.arrests + params;

    const result: { data: IDTORFInfoAccountArrestsResponse } = yield api.get(url);

    yield put(actions.getAccountArrestsSuccessful(result));
  } catch (error) {
    yield put(actions.getAccountArrestsFailure(error.response?.data));
  }
}

function* getAccountArrestsSuccessful(action: TODO_ANY) {
  yield put(actions.setCurrentArrests(action.payload.data));
  yield put(
    actions.set({
      pageArrestsCount: fp.toNumber(action.payload.headers['x-pagination-page-count']),
    })
  );
}

function* getAccountArrestsFailure(action: TODO_ANY) {
  yield put(actions.setError({ rfInfo: convertApiErrorCodesToMessages(action.payload) }));
}

function* getAccountExtendedStatement(action: TODO_ANY) {
  yield put(actions.set({ isLoading: true }));
  yield put(actions.setError({ rfInfo: [] }));

  try {
    const dateStart = action.payload.dateStart ? `&start_date=${action.payload.dateStart}` : '';
    const dateEnd = action.payload.dateEnd ? `&end_date=${action.payload.dateEnd}` : '';
    const page = `&page=${action.payload.page}`;

    const params = `?account=${action.payload.account}${dateStart}${dateEnd}${page}`;

    const url: string = apiEndpoints.rfInfo.statements + params;
    const result: { data: IDTORFInfoAccountExtendedStatementResponse } = yield api.get(url);

    yield put(actions.set({ isLoading: false }));
    yield put(actions.getAccountExtendedStatementSuccessful(result));
  } catch (error) {
    yield put(actions.set({ isLoading: false }));
    yield put(actions.getAccountExtendedStatementFailure(error.response?.data));
  }
}

function* getAccountExtendedStatementSuccessful(action: TODO_ANY) {
  yield put(actions.setExtendedStatementsData(action.payload.data));
  yield put(
    actions.set({
      pageStatementsCount: fp.toNumber(action.payload.headers['x-pagination-page-count']),
    })
  );
}

function* getAccountExtendedStatementFailure(action: TODO_ANY) {
  yield put(actions.setError({ rfInfo: convertApiErrorCodesToMessages(action.payload) }));
}

function* exportAccountExtendedStatement(action: TODO_ANY) {
  yield put(actions.set({ isLoading: true }));
  yield put(actions.setError({ rfInfo: [] }));

  try {
    const account = action.payload.account ? `account=${action.payload.account}` : null;
    const dateStart = action.payload.dateStart ? `start_date=${action.payload.dateStart}` : null;
    const dateEnd = action.payload.dateEnd ? `end_date=${action.payload.dateEnd}` : null;

    const params = `?${account}&${dateStart}&${dateEnd}`;

    const url: string = apiEndpoints.rfInfo.statementsExport + params;

    let acceptType = 'application/json';

    switch (action.payload.docType) {
      case 'txt':
        acceptType = 'text/plain';
        break;
      case 'xls':
        acceptType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
        break;
    }

    const config = {
      headers: { Accept: acceptType },
      responseType: 'arraybuffer',
    };

    const response = yield api.get(url, config);

    yield put(actions.exportAccountExtendedStatementSuccessful(response));
  } catch (error) {
    yield put(actions.exportAccountExtendedStatementFailure(error.response?.data));
  }
}

function* exportAccountExtendedStatementSuccessful(action: TODO_ANY) {
  yield put(actions.set({ isLoading: false }));
  download(action.payload, `report-${Date.now()}`);
}

function* exportAccountExtendedStatementFailure(action: TODO_ANY) {
  yield put(actions.set({ isLoading: false }));
  yield put(actions.setError({ rfInfo: convertApiErrorCodesToMessages(action.payload) }));
}

function* exportTransactionsData(action: TODO_ANY) {
  try {
    const filter: IAccountsState['filter'] = action.payload;
    const url: string = apiEndpoints.rfInfo.transactionsExport + 
      `?account=${filter.account}&start_date=${filter.start}&end_date=${filter.end}`;
    const config = {
      headers: { 'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' },
      responseType: 'arraybuffer',
    };
    const result = yield api.get(url, config);
    yield put(actions.exportTransactionsDataSuccessful(result));
  } catch (error) {
    yield put(actions.exportTransactionsDataFailure(error.response?.data));
  }
}

function* exportTransactionsDataSuccessful(action: TODO_ANY) {
  download(action.payload, `transactions-${Date.now()}`);
  yield;
}

function* exportTransactionsDataFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload }));
}

export default function* () {
  yield takeLatest(actions.getAccountArrests, getAccountArrests);
  yield takeLatest(actions.getAccountArrestsSuccessful, getAccountArrestsSuccessful);
  yield takeLatest(actions.getAccountArrestsFailure, getAccountArrestsFailure);

  yield takeLatest(actions.getAccountTransactions, getAccountTransactions);
  yield takeLatest(actions.getAccountTransactionsSuccessful, getAccountTransactionsSuccessful);
  yield takeLatest(actions.getAccountTransactionsFailure, getAccountTransactionsFailure);

  yield takeLatest(actions.getAccount, getAccount);
  yield takeLatest(actions.getAccountSuccessful, getAccountSuccessful);
  yield takeLatest(actions.getAccountFailure, getAccountFailure);

  yield takeLatest(actions.getAccounts, getAccounts);
  yield takeLatest(actions.getAccountsSuccessful, getAccountsSuccessful);
  yield takeLatest(actions.getAccountsFailure, getAccountsFailure);

  yield takeLatest(actions.getAccountExtendedStatement, getAccountExtendedStatement);
  yield takeLatest(
    actions.getAccountExtendedStatementSuccessful,
    getAccountExtendedStatementSuccessful
  );
  yield takeLatest(actions.getAccountExtendedStatementFailure, getAccountExtendedStatementFailure);

  yield takeLatest(actions.exportAccountExtendedStatement, exportAccountExtendedStatement);
  yield takeLatest(
    actions.exportAccountExtendedStatementSuccessful,
    exportAccountExtendedStatementSuccessful
  );
  yield takeLatest(
    actions.exportAccountExtendedStatementFailure,
    exportAccountExtendedStatementFailure
  );

  yield takeLatest(actions.exportTransactionsData, exportTransactionsData);
  yield takeLatest(actions.exportTransactionsDataSuccessful, exportTransactionsDataSuccessful);
  yield takeLatest(actions.exportTransactionsDataFailure, exportTransactionsDataFailure);
}
