import React, { useEffect } from 'react';

import { Html } from '@rfb/ui-kit';

import styles from './assets/styles/index.module.css';

export interface IAppHelpProps {
  text: string;
}

export interface IAppHelpActions {
  actions: {
    getHelpText: Function,
  };
}

const Help = (props: IAppHelpProps & IAppHelpActions) => {
  console.log(`Help BEGIN`);
  useEffect(() => {
    console.log(`Help useEffect`);
    if (props.text) return;
    props.actions.getHelpText();
    // ESLINT Необходимо для отправки запроса только в момент монтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  console.log(`Help BEFORE return`);
  return (
    <div className={styles.main}>
      <h1 className={styles.title}>Правила работы в личном кабинете</h1>
      <div className={styles.content}><Html text={props.text} /></div>
    </div>
  );
};

export default Help;
