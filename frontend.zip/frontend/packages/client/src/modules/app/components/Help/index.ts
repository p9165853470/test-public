import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IAppState } from '../../store';

import Component, { IAppHelpProps, IAppHelpActions } from './component';

const mapStateToProps = (state: { [name]: IAppState }): IAppHelpProps => ({
  text: selectors.selectHelpText(state),
});

const mapDispatchToProps = (dispatch: any): IAppHelpActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
