import { connect } from 'react-redux';

import { appMenuConfig } from 'configs/menu';

import Component, { IAppMenuProps } from './component';

const mapStateToProps = (): IAppMenuProps => ({
  config: appMenuConfig,
});

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps)(Component);
