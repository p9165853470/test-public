import { put, takeEvery } from 'redux-saga/effects';

import api from 'utils/api';

import apiEndpoints from 'configs/api/endpoints';

import { actions } from './index';
import { actions as userActions } from 'modules/user/store';

import { IDTOVariableInstructionResponse } from 'dto/variable';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* init(): TODO_ANY {
  console.log('app/store/sagas.init() BEGIN');
  yield put(actions.set({ isLoading: true }));
  try {
    console.log(`app/store/sagas.init() BEFORE "const profile = yield api.get(${JSON.stringify(apiEndpoints.profile.view)})"`);
    const profile = yield api.get(apiEndpoints.profile.view);
    console.log(`app/store/sagas.init() AFTER "const profile = yield api.get(...)"`);
    const organization = yield api.get(apiEndpoints.rfInfo.info);
    yield put(userActions.set({ profile: profile.data }));
    yield put(userActions.set({ organization: organization.data }));
    yield put(actions.initSuccessful());
  } catch (error) {
    console.log(`app/store/sagas.init() ERROR BEFORE "yield put(actions.initFailure(${JSON.stringify(error.response?.data)}))"`);
    yield put(actions.initFailure(error.response?.data));
    console.log(`app/store/sagas.init() ERROR AFTER "yield put(actions.initFailure(...))"`);
  } finally {
    console.log('app/store/sagas.init() BEFORE "yield put(actions.set({ isLoading: false }))"');
    yield put(actions.set({ isLoading: false }));
    console.log('app/store/sagas.init() AFTER "yield put(actions.set({ isLoading: false }))"');
  }
  console.log('app/store/sagas.init() END');
}

function* initSuccessful() {
  yield put(actions.set({ isAppInit: true }));
}

function* initFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
  yield put(actions.set({ apiErrorCode: action.payload?.code }));
}

function* getHelpText() {
  try {
    const result: { data: IDTOVariableInstructionResponse } = yield api.get(
      apiEndpoints.variable.instruction
    );
    yield put(actions.getHelpTextSuccessful(result.data.text));
  } catch (error) {
    yield put(actions.getHelpTextFailure(error.message));
  }
}

function* getHelpTextSuccessful(action: TODO_ANY) {
  yield put(actions.set({ helpText: action.payload }));
}

function* getHelpTextFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload }));
}

export default function* () {
  yield takeEvery(actions.init, init);
  yield takeEvery(actions.initSuccessful, initSuccessful);
  yield takeEvery(actions.initFailure, initFailure);

  yield takeEvery(actions.getHelpText, getHelpText);
  yield takeEvery(actions.getHelpTextSuccessful, getHelpTextSuccessful);
  yield takeEvery(actions.getHelpTextFailure, getHelpTextFailure);
}
