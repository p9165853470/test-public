import { createSlice } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getStateFromParams } from 'helpers/store';

export interface IAppState {
  helpText: string;
  errorList: { [key: string]: string[] };
  apiErrorCode: number;
  isAppInit: boolean;
  isLoading: boolean;
}

const initialState: IAppState = {
  helpText: '',
  errorList: {},
  apiErrorCode: 0,
  isAppInit: false,
  isLoading: true,
};

const appSlice = createSlice({
  name: 'app',

  initialState,

  reducers: {
    set: (state, action) => ({ ...state, ...action.payload }),
    setError: (state, action) => ({
      ...state,
      errorList: { ...state.errorList, ...action.payload },
    }),

    init: getStateFromParams,
    initSuccessful: fp.identity,
    initFailure: getStateFromParams,

    getHelpText: getStateFromParams,
    getHelpTextSuccessful: getStateFromParams,
    getHelpTextFailure: getStateFromParams,
  },
});

export const { name, actions, reducer } = appSlice;
