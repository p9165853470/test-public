import React, { useEffect } from 'react';

import cn from 'classnames';
import fp from 'lodash/fp';

import { Button, Loader } from '@rfb/ui-kit';

import { ReactComponent as ArrowForwardIcon } from './assets/images/arrow-right.svg';
import routingConfig from 'configs/routing';

import styles from './assets/styles/index.module.css';

export interface IOrganizationProps {
  diasoft_id?: string;
  isLoading: boolean;
  config: IOrganizationElement[];
}

export interface IOrganizationElement {
  diasoft_id: string;
  name: string;
}

export interface IOrganizationPropsExternal {
  // TODO Use a history interface
  history: {
    push: (path: string) => void;
  };
}

export interface IOrganizationActions {
  actions: {
    reset: Function;
    getUserDealer: Function;
    chooseOrganization: Function;
  };
}

const Organization = (
  props: IOrganizationProps & IOrganizationPropsExternal & IOrganizationActions
) => {
  useEffect(() => {
    console.log(`Organization/component.useEffect1: props = ${JSON.stringify(props)}`);
    return () => {
      props.actions.reset();
    };
    // ESLINT Необходимо выполнение только в момент размонтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    console.log(`Organization/component.useEffect2: props = ${JSON.stringify(props)}`);
    if (props.config.length === 0) {
      props.actions.getUserDealer({ history: props.history, autoChooseDealer: true });
    }
  }, []);

  const renderArrow = () => (
    <div className={styles.arrow}>
      <ArrowForwardIcon />
    </div>
  );

  const renderNavButton = (item: IOrganizationElement) => (
    <div
      key={item.diasoft_id}
      className={cn({
        [styles.badge]: true,
        [styles.badgeRed]: props.diasoft_id === item.diasoft_id,
      })}
    >
      <Button
        wrapperClassName={styles.button}
        view="square"
        text={item.name}
        sidebarRight={renderArrow()}
        onClick={() => {
          const data = { diasoft_id: item.diasoft_id };
          props.actions.chooseOrganization({
            data,
            onSuccess: () => {
              props.history.push(routingConfig.main.path);
            },
          });
        }}
      />
    </div>
  );

  console.log(`Organization/component BEFORE "if (props.isLoading) {...": props = ${JSON.stringify(props)}`);

  if (props.isLoading) {
    return <Loader wrapperClassName={styles.main} />;
  }

  console.log(`Organization/component BEFORE "return": props = ${JSON.stringify(props)}`);
  return <div className={styles.main}>{fp.map(renderNavButton, props.config)}</div>;
};

export default Organization;
