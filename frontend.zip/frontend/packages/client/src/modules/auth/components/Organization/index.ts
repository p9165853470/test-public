import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import Component, {
  IOrganizationProps,
  IOrganizationActions,
  IOrganizationPropsExternal,
} from './component';
import { name, actions, IAuthState, selectors } from 'modules/auth/store';
import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const mapStateToProps = (
  state: { [name]: IAuthState },
  props: { history: TODO_ANY }
): IOrganizationProps & IOrganizationPropsExternal => ({
  config: selectors.selectUserDealers(state),
  isLoading: selectors.selectIsLoading(state),
  // apiErrorList: selectors.selectErrorListByField(state)('api'),
  history: props.history,
});
const mapDispatchToProps = (dispatch: any): IOrganizationActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
