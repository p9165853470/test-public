import { put, takeEvery } from 'redux-saga/effects';

import api from 'utils/api';
import storage from 'utils/storage';
import storageDB from 'utils/storage-db';

import { convertApiErrorCodesToMessages } from 'helpers/app';

import apiEndpoints from 'configs/api/endpoints';
import routingConfig from 'configs/routing';

import { actions } from './index';
import { actions as appActions } from 'modules/app/store';

import { IDTOTokenCreateResponse } from 'dto/auth';
import { IDTOVariableAgreementResponse } from 'dto/variable';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';
import { DTOUserInfo } from 'dto/rf-info';

function* login(action: TODO_ANY) {
  console.log(`sagas.login(${JSON.stringify(action)}) BEGIN`);
  try {
    console.log(`sagas.login() BEFORE "actions.set({ isSending: true }"`);
    yield put(actions.set({ isSending: true }));
    console.log(`sagas.login() AFTER "actions.set({ isSending: true }"`);

    console.log(`sagas.login() BEFORE "const result: { data: IDTOTokenCreateResponse } = yield api.post(${JSON.stringify(apiEndpoints.auth.tokenCreate)}, ${JSON.stringify(action.payload.data)})"`);
    const result: { data: IDTOTokenCreateResponse } = yield api.post(
      apiEndpoints.auth.tokenCreate,
      action.payload.data
    );
    console.log(`sagas.login() AFTER "const result: { data: IDTOTokenCreateResponse } = yield api.post(...)" result = ${JSON.stringify(result)}`);

    console.log(`sagas.login() BEFORE "actions.loginSuccessful({..."`);
    yield put(
      actions.loginSuccessful({
        token: result.data.token,
        email: action.payload.data.login,
        history: action.payload.history,
      })
    );
  } catch (error) {
    console.log(`sagas.login() error ${error.response}`);
    yield put(actions.loginFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isSending: false }));
  }
  console.log(`sagas.login() END`);
}

function* loginSuccessful(action: TODO_ANY) {
  console.log(`sagas.loginSuccessful(${JSON.stringify(action)}) BEGIN`);
  (storage as TODO_ANY).set('token', action.payload.token);
  storage.set('email', action.payload.email);
  console.log(`sagas.loginSuccessful()) BEFORE set({ token: action.payload.token }))`);
  yield put(actions.set({ token: action.payload.token }));
  console.log(`sagas.loginSuccessful()) AFTER set({ token: action.payload.token }))`);
  action.payload.history.push(routingConfig.phoneNumberValidation.path);
  console.log(`sagas.loginSuccessful() END`);
}

function* loginFailure(action: TODO_ANY) {
  console.log(`sagas.loginFailure(${JSON.stringify(action)}) BEGIN`);
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
  console.log(`sagas.loginFailure() END`);
}

function* logout() {
  try {
    console.log(`sagas.logout() BEGIN`);
    yield api.post(apiEndpoints.auth.tokenDestroy, {});
    yield put(actions.logoutSuccessful({}));
  } catch (error) {
    console.log(`sagas.logoutFailure() ERROR`);
    yield put(actions.logoutFailure(error.response?.data));
  }
  console.log(`sagas.logout() END`);
}

function* logoutSuccessful() {
  console.log(`sagas.logoutSuccessful() BEGIN`);
  storage.clearAll();
  storageDB.clearAll();
  window.location.replace(routingConfig.login.path);
  yield;
  console.log(`sagas.logoutSuccessful() END`);
}

function* logoutFailure(action: TODO_ANY) {
  console.log(`sagas.logoutFailure() BEGIN`);
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
  console.log(`sagas.logoutFailure() END`);
}

function* sendOrganizationData(action: TODO_ANY) {
  console.log(`sagas.sendOrganizationData() BEGIN`);
  try {
    yield api.post(apiEndpoints.profile.validate, action.payload.data);
    yield put(actions.sendOrganizationDataSuccessful({ history: action.payload.history }));
  } catch (error) {
    console.log(`sagas.sendOrganizationDataFailure() ERROR`);
    yield put(actions.sendOrganizationDataFailure(error.response?.data));
  }
  console.log(`sagas.sendOrganizationData() END`);
}

function* sendOrganizationDataSuccessful(action: TODO_ANY) {
  console.log(`sagas.sendOrganizationDataSuccessful() BEGIN`);
  action.payload.history.push(routingConfig.main.path);
  yield put(appActions.set({ apiErrorCode: 0 }));
  console.log(`sagas.sendOrganizationDataSuccessful() END`);
}

function* sendOrganizationDataFailure(action: TODO_ANY) {
  console.log(`sagas.sendOrganizationDataFailure() BEGIN`);
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
  console.log(`sagas.sendOrganizationDataFailure() END`);
}

function* sendPhoneNumber(action: TODO_ANY) {
  console.log(`sagas.sendPhoneNumber() BEGIN`);
  try {
    yield api.post(apiEndpoints.profile.phoneNumber, action.payload.data);
    yield put(actions.sendPhoneNumberSuccessful({ history: action.payload.history }));
  } catch (error) {
    console.log(`sagas.sendPhoneNumberFailure() ERROR`);
    yield put(actions.sendPhoneNumberFailure(error.response?.data));
  }
  console.log(`sagas.sendPhoneNumber() END`);
}

function* sendPhoneNumberSuccessful(action: TODO_ANY) {
  console.log(`sagas.sendPhoneNumberSuccessful() BEGIN`);
  action.payload.history.push(routingConfig.smsConfirm.path);
  yield put(appActions.set({ apiErrorCode: 0 }));
  console.log(`sagas.sendPhoneNumberSuccessful() END`);
}

function* sendPhoneNumberFailure(action: TODO_ANY) {
  console.log(`sagas.sendPhoneNumberFailure() BEGIN`);
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
  console.log(`sagas.sendPhoneNumberFailure() END`);
}

function* restorePassword(action: TODO_ANY) {
  console.log(`sagas.restorePassword() BEGIN`);
  try {
    yield put(actions.set({ isSending: true }));
    yield api.post(apiEndpoints.security.passwordReset, action.payload.data);
    yield put(
      actions.restorePasswordSuccessful({
        data: action.payload.data,
        history: action.payload.history,
      })
    );
  } catch (error) {
    console.log(`sagas.restorePasswordFailure() ERROR`);
    yield put(actions.restorePasswordFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isSending: false }));
  }
  console.log(`sagas.restorePassword() END`);
}

function* restorePasswordSuccessful(action: TODO_ANY) {
  console.log(`sagas.restorePasswordSuccessful() BEGIN`);
  action.payload.history.push(routingConfig.passwordRestoreSent.path);
  storage.set('restore-password-email', action.payload.data.login);
  yield put(actions.set({ isPasswordRestoreSent: true }));
  console.log(`sagas.restorePasswordSuccessful() END`);
}

function* restorePasswordFailure(action: TODO_ANY) {
  console.log(`sagas.restorePasswordFailure() BEGIN`);
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
  console.log(`sagas.restorePasswordFailure() END`);
}

function* changePassword(action: TODO_ANY) {
  console.log(`sagas.changePassword() BEGIN`);
  try {
    yield api.post(apiEndpoints.security.passwordChange, action.payload.data);
    yield put(actions.changePasswordSuccessful({ history: action.payload.history }));
  } catch (error) {
    console.log(`sagas.changePasswordFailure() ERROR`);
    yield put(actions.changePasswordFailure(error.response?.data));
  }
  console.log(`sagas.changePassword() END`);
}

function* changePasswordSuccessful(action: TODO_ANY) {
  console.log(`sagas.changePasswordSuccessful() BEGIN`);
  action.payload.history.push(routingConfig.main.path);
  yield put(appActions.set({ apiErrorCode: 0 }));
  console.log(`sagas.changePassword() END`);
}

function* changePasswordFailure(action: TODO_ANY) {
  console.log(`sagas.changePasswordFailure() BEGIN`);
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
  console.log(`sagas.changePasswordFailure() END`);
}

function* getServiceTermsText() {
  console.log(`sagas.getServiceTermsText() BEGIN`);
  try {
    const result: { data: IDTOVariableAgreementResponse } = yield api.get(
      apiEndpoints.variable.agreement
    );
    yield put(actions.getServiceTermsTextSuccessful(result.data.text));
  } catch (error) {
    console.log(`sagas.getServiceTermsTextFailure() ERROR`);
    yield put(actions.getServiceTermsTextFailure(error.response?.data));
  }
  console.log(`sagas.getServiceTermsText() END`);
}

function* getServiceTermsTextSuccessful(action: TODO_ANY) {
  console.log(`sagas.getServiceTermsTextSuccessful() BEGIN`);
  yield put(actions.set({ serviceTermsText: action.payload }));
  console.log(`sagas.getServiceTermsTextSuccessful() END`);
}

function* getServiceTermsTextFailure(action: TODO_ANY) {
  console.log(`sagas.getServiceTermsTextFailure() BEGIN`);
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
  console.log(`sagas.getServiceTermsTextFailure() END`);
}

function* sendServiceTermsAgreement(action: TODO_ANY) {
  console.log(`sagas.getServiceTermsAgreement() BEGIN`);
  try {
    yield api.post(apiEndpoints.profile.agreement, {});
    yield put(
      actions.sendServiceTermsAgreementSuccessful({
        history: action.payload.history,
      })
    );
  } catch (error) {
    console.log(`sagas.sendServiceTermsAgreement() ERROR`);
    yield put(actions.sendServiceTermsAgreementFailure(error.response?.data));
  }
  console.log(`sagas.getServiceTermsAgreement() END`);
}

function* sendServiceTermsAgreementSuccessful(action: TODO_ANY) {
  console.log(`sagas.getServiceTermsAgreementSuccessful() BEGIN`);
  action.payload.history.push(routingConfig.main.path);
  yield put(appActions.set({ apiErrorCode: 0 }));
  console.log(`sagas.getServiceTermsAgreementSuccessful() END`);
}

function* sendServiceTermsAgreementFailure(action: TODO_ANY) {
  console.log(`sagas.getServiceTermsAgreementFailure() BEGIN`);
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
  console.log(`sagas.getServiceTermsAgreementFailure() END`);
}

function* disagreeServiceTerms(action: TODO_ANY) {
  console.log(`sagas.disagreeServiceTerms() BEGIN`);
  storage.remove('token');
  action.payload.history.push(routingConfig.login.path);
  yield put(appActions.set({ apiErrorCode: 0 }));
  console.log(`sagas.disagreeServiceTerms() END`);
}

function* getUserDealer(action: TODO_ANY) {
  console.log(`sagas.getUserDealer() BEGIN`);
  try {
    yield put(actions.set({ isLoading: true }));
    const result: { data: DTOUserInfo } = yield api.get(apiEndpoints.rfInfo.user, {
      params: {
        email: storage.get('email'),
      },
    });
    yield put(actions.getUserDealerSuccessful({ ...action.payload, data: result.data }));
  } catch (error) {
    console.log(`sagas.getUserDealer() ERROR`);
    yield put(actions.getUserDealerFailure(error));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
  console.log(`sagas.getUserDealer() END`);
}

function* getUserDealerSuccessful(action: TODO_ANY) {
  console.log(`sagas.getUserDealerSuccessful() BEGIN`);
  yield put(actions.set({ userDealers: action.payload.data }));
  if (action.payload.autoChooseDealer && action.payload.data?.length === 1) {
    const data = { diasoft_id: action.payload.data[0].diasoft_id };
    yield put(
      actions.chooseOrganization({
        data,
        onSuccess: () => {
          action.payload.history.push(routingConfig.main.path);
        },
      })
    );
  }
  console.log(`sagas.getUserDealerSuccessful() END`);
}

function* getUserDealerFailure(action: TODO_ANY) {
  console.log(`sagas.getUserDealerFailure() BEGIN`);
  yield put(actions.setError({ api: action.payload?.message }));
  console.log(`sagas.getUserDealerFailure() END`);
}

function* chooseOrganization(action: TODO_ANY) {
  console.log(`sagas.chooseOrganization() BEGIN`);
  try {
    yield put(actions.set({ isLoading: true }));
    yield api.post(apiEndpoints.profile.chooseDealer, action.payload.data);
    yield put(actions.chooseOrganizationSuccessful(action.payload));
  } catch (error) {
    console.log(`sagas.chooseOrganization() ERROR`);
    yield put(actions.chooseOrganizationFailure(error));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
  console.log(`sagas.chooseOrganization() END`);
}

function* chooseOrganizationSuccessful(action: TODO_ANY) {
  console.log(`sagas.chooseOrganizationSuccessful() BEGIN`);
  if (action.payload.onSuccess) {
    action.payload.onSuccess();
  }
  yield put(appActions.set({ apiErrorCode: 0 }));
  console.log(`sagas.chooseOrganizationSuccessful() END`);
}

function* chooseOrganizationFailure(action: TODO_ANY) {
  console.log(`sagas.chooseOrganizationFailure() BEGIN`);
  yield put(actions.setError({ api: action.payload?.message }));
  console.log(`sagas.chooseOrganizationFailure() END`);
}

const sagas = function* () {
  yield takeEvery(actions.login, login);
  yield takeEvery(actions.loginSuccessful, loginSuccessful);
  yield takeEvery(actions.loginFailure, loginFailure);

  yield takeEvery(actions.logout, logout);
  yield takeEvery(actions.logoutSuccessful, logoutSuccessful);
  yield takeEvery(actions.logoutFailure, logoutFailure);

  yield takeEvery(actions.sendOrganizationData, sendOrganizationData);
  yield takeEvery(actions.sendOrganizationDataSuccessful, sendOrganizationDataSuccessful);
  yield takeEvery(actions.sendOrganizationDataFailure, sendOrganizationDataFailure);

  yield takeEvery(actions.sendPhoneNumber, sendPhoneNumber);
  yield takeEvery(actions.sendPhoneNumberSuccessful, sendPhoneNumberSuccessful);
  yield takeEvery(actions.sendPhoneNumberFailure, sendPhoneNumberFailure);

  yield takeEvery(actions.restorePassword, restorePassword);
  yield takeEvery(actions.restorePasswordSuccessful, restorePasswordSuccessful);
  yield takeEvery(actions.restorePasswordFailure, restorePasswordFailure);

  yield takeEvery(actions.getServiceTermsText, getServiceTermsText);
  yield takeEvery(actions.getServiceTermsTextSuccessful, getServiceTermsTextSuccessful);
  yield takeEvery(actions.getServiceTermsTextFailure, getServiceTermsTextFailure);

  yield takeEvery(actions.sendServiceTermsAgreement, sendServiceTermsAgreement);
  yield takeEvery(actions.sendServiceTermsAgreementSuccessful, sendServiceTermsAgreementSuccessful);
  yield takeEvery(actions.sendOrganizationDataFailure, sendServiceTermsAgreementFailure);

  yield takeEvery(actions.changePassword, changePassword);
  yield takeEvery(actions.changePasswordSuccessful, changePasswordSuccessful);
  yield takeEvery(actions.changePasswordFailure, changePasswordFailure);

  yield takeEvery(actions.disagreeServiceTerms, disagreeServiceTerms);

  yield takeEvery(actions.chooseOrganization, chooseOrganization);
  yield takeEvery(actions.chooseOrganizationSuccessful, chooseOrganizationSuccessful);
  yield takeEvery(actions.chooseOrganizationFailure, chooseOrganizationFailure);

  yield takeEvery(actions.getUserDealer, getUserDealer);
  yield takeEvery(actions.getUserDealerSuccessful, getUserDealerSuccessful);
  yield takeEvery(actions.getUserDealerFailure, getUserDealerFailure);
};
export default sagas;
