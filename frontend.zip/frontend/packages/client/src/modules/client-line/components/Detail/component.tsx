import React, { useEffect } from 'react';

import fp from 'lodash/fp';

import { ButtonPrint, Loader } from '@rfb/ui-kit';

import { ClientLineTypes } from '../../configs/type';

import Header from './components/Header';
import Info from './components/Info';
import Data from './components/Data';

import styles from './assets/styles/index.module.css';

export interface IClientLineDetailProps {
  clientLine: object;
}

export interface IClientLineDetailPropsExternal {
  id: string;
  type: keyof typeof ClientLineTypes;
}

export interface IClientLineDetailActions {
  actions: {
    set: Function,
    setDataFull: Function,
    getDataFullById: Function,
  };
}

const Detail = (
  props: IClientLineDetailProps & IClientLineDetailPropsExternal & IClientLineDetailActions
) => {
  useEffect(() => {
    props.actions.set({ currentId: props.id });
    props.actions.getDataFullById({ number: props.id, type: props.type });
    // ESLINT Необходимо выполнение только при монтировании и размонтировании компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (fp.isEmpty(props.clientLine)) {
    return <Loader />;
  }

  return (
    <div className={styles.main}>
      <div className={styles.header}>
        <Header />
      </div>

      <div className={styles.info}>
        <Info />
        <ButtonPrint wrapperClassName={styles.print} />
      </div>

      <div className={styles.data}>
        <Data />
      </div>
    </div>
  );
};

export default Detail;
