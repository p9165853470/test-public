import React from 'react';

import fp from 'lodash/fp';

import { convertPathUsingParams } from '@rfb/common';

import { Button, Condition, LinkWithContent } from '@rfb/ui-kit';

import routingConfig from 'configs/routing';
import { ClientLineStatus } from '../../../../configs/status';

import styles from './assets/styles/index.module.css';

export interface IClientLineDetailHeader {
  clientLineId: string;
  type: string;
  number: string;
  status: number;
  rateDate: string;
  rateValue: number;
  dateBegin: string;
  dateEnd?: string;
}

const Header = (props: IClientLineDetailHeader) => {
  const isOpened: boolean = fp.isEqual(props.status, fp.toNumber(ClientLineStatus.OPENED));
  const transchesListByNumberUrl: string = convertPathUsingParams(
    routingConfig.tranchesListByClientLineIdAndType.path,
    { clientLineId: props.clientLineId, clientLineType: props.type }
  );

  return (
    <div className={styles.main}>
      <div className={styles.block}>
        <h1 className={styles.title}>
          Договор {props.number} {isOpened ? 'открыт' : 'закрыт'}
        </h1>
        <LinkWithContent wrapperClassName={styles.link} to={transchesListByNumberUrl}>
          <Button text="К траншам по этому договору" />
        </LinkWithContent>
      </div>

      <div className={styles.block}>
        <div className={styles.dates}>
          <div className={styles.date}>Дата открытия {props.dateBegin}</div>
          <Condition value={!isOpened}>
            <div className={styles.date}>Дата закрытия {props.dateBegin}</div>
          </Condition>
        </div>
        <div className={styles.financialRate}>
          Ставка MosPrime на {props.rateDate} составляет {fp.toNumber(props.rateValue).toFixed(2)}%
        </div>
      </div>
    </div>
  );
};

export default Header;
