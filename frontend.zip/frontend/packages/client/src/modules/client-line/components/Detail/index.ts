import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IClientLineState } from '../../store';

import Component, {
  IClientLineDetailProps,
  IClientLineDetailPropsExternal,
  IClientLineDetailActions,
} from './component';

const mapStateToProps = (
  state: { [name]: IClientLineState },
  props: IClientLineDetailPropsExternal
): IClientLineDetailProps & IClientLineDetailPropsExternal => ({
  id: props.id,
  type: props.type,
  clientLine: selectors.selectCurrentClientLine(state),
});

const mapDispatchToProps = (dispatch: any): IClientLineDetailActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
