import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getTransformedTableRow } from '../../helpers/transform';

import { name, actions, selectors, IClientLineState } from '../../store';

import Component, { IClientLineTableShortProps, IClientLineTableShortActions } from './component';

import styles from './assets/styles/index.module.css';

const mapStateToProps = (state: { [name]: IClientLineState }): IClientLineTableShortProps => ({
  headers: [
    { title: 'Hoмер договора', value: 'number', columnClassName: styles.columnNumber },
    { title: 'Статус договора', value: 'status', columnClassName: styles.columnStatus },
    { title: 'Бренд', value: 'name_brand' },
    { title: 'Продукт', value: 'name_product' },
  ],
  rows: fp.pipe(
    selectors.selectDataWithFieldList(state),
    fp.map(getTransformedTableRow)
  )(['number', 'status', 'type', 'name_brand', 'name_product']),
  pageCount: selectors.selectPageCount(state),
  filter: selectors.selectFilter(state),
  isLoading: selectors.selectIsLoading(state),
});

const mapDispatchToProps = (dispatch: any): IClientLineTableShortActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
