export enum ClientLineTypes {
  KL = 'KL',
  FL1 = 'FL1',
  FL2 = 'FL2',
}

export const clientLineTypeTranslations: { [key: string]: string } = {
  [ClientLineTypes.KL]: 'К/Л',
  [ClientLineTypes.FL1]: 'Ф/Л',
  [ClientLineTypes.FL2]: 'Ф/Л'
}

export const clientLineTypeTranslationsFull: { [key: string]: string } = {
  [ClientLineTypes.KL]: 'Кредитная линия',
  [ClientLineTypes.FL1]: 'Факторинговая линия',
  [ClientLineTypes.FL2]: 'Факторинговая линия'
}

export const clientLineCommissionTypeTranslations: { [key: string]: string } = {
  '': 'Комиссия отсутствует',
  1: 'Комиссия за выдачу',
  2: 'Комиссия за поддержание лимита'
}