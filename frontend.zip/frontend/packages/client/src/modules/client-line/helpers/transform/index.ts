import fp from 'lodash/fp';

import { convertPathUsingParams } from '@rfb/common';

import routingConfig from 'configs/routing';
import {
  clientLineTypeTranslations,
  clientLineTypeTranslationsFull,
  clientLineCommissionTypeTranslations,
} from '../../configs/type';
import { clientLineStatusOptions } from '../../configs/status';

export const getTransformedNumberForView = (number: string, type: string): string =>
  `${number}-${clientLineTypeTranslations[type]}`;

export const getTransformedStatus = (status: string): string => clientLineStatusOptions[status];

export const getTransformedStatusFull = (status: string): string =>
  clientLineTypeTranslationsFull[status];

export const getTransformedTableRow = (cellList: string[]) => {
  const [number, status, type, ...rest] = cellList;
  const link: string = convertPathUsingParams(routingConfig.clientLinesDetailById.path, {
    id: number,
    type,
  });
  const numberForView: string = getTransformedNumberForView(number, type);
  const statusForView: string = getTransformedStatus(status);
  return { config: { link }, data: [numberForView, statusForView, ...rest] };
};

export const getTransformedPercentRate = (value: string): string =>
  fp.pipe(fp.split(';'), fp.map(p => fp.toNumber(p).toFixed(2)), fp.join('/'))(value);

export const getTransformedCommissionTypeList = (value: string): string[] => {
  const commissionTypeList: string[] = fp.split(';', value);
  return fp.map(
    (type: string): string => fp.path(type, clientLineCommissionTypeTranslations),
    commissionTypeList
  );
};
