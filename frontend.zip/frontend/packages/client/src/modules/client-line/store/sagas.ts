import { put, takeEvery } from 'redux-saga/effects';

import fp from 'lodash/fp';

import api from 'utils/api';

import apiEndpoints from 'configs/api/endpoints';

import { actions } from './index';

import {
  IDTORFInfoClientLineShortResponse,
  IDTORFInfoClientLineFullResponse,
  IDTORFInfoRateResponse,
  IDTORFInfoHeaders,
} from 'dto/rf-info';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* getDataShort(action: TODO_ANY) {
  yield put(actions.set({ isLoading: true }));
  try {
    const url: string =
      apiEndpoints.rfInfo.clientLines +
      `?line_status=${action.payload.status}&page_number=${action.payload.page}`;
    const result: {
      data: IDTORFInfoClientLineShortResponse[],
      headers: IDTORFInfoHeaders,
    } = yield api.get(url);
    yield put(actions.getDataShortSuccessful({ data: result.data, headers: result.headers }));
  } catch (error) {
    yield put(actions.getDataShortFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* getDataShortSuccessful(action: TODO_ANY) {
  yield put(actions.setData(action.payload.data));
  yield put(
    actions.set({ pageCount: fp.toNumber(action.payload.headers['x-pagination-page-count']) })
  );
}

function* getDataShortFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* getDataFullById(action: TODO_ANY) {
  try {
    const url: string = apiEndpoints.rfInfo.clientLine +
      `?number_line=${action.payload.number}&type_line=${action.payload.type}`;
    const result: { data: IDTORFInfoClientLineFullResponse } = yield api.get(url);
    const rate: { data: IDTORFInfoRateResponse[] } = yield api.get(apiEndpoints.rfInfo.rate);
    yield put(actions.getDataFullByIdSuccessful(result.data));
    yield put(actions.set({ rate: fp.head(rate.data) }));
  } catch (error) {
    yield put(actions.getDataFullByIdFailure(error.response?.data));
  }
}

function* getDataFullByIdSuccessful(action: TODO_ANY) {
  yield put(actions.setDataFull({ [action.payload.number]: action.payload }));
}

function* getDataFullByIdFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

export default function* () {
  yield takeEvery(actions.getDataShort, getDataShort);
  yield takeEvery(actions.getDataShortSuccessful, getDataShortSuccessful);
  yield takeEvery(actions.getDataShortFailure, getDataShortFailure);

  yield takeEvery(actions.getDataFullById, getDataFullById);
  yield takeEvery(actions.getDataFullByIdSuccessful, getDataFullByIdSuccessful);
  yield takeEvery(actions.getDataFullByIdFailure, getDataFullByIdFailure);
}
