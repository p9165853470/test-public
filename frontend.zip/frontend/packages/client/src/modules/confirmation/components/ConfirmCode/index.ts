import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IConfirmState } from '../../store';
import confirmTypes from '../../configs/confirmTypes';

import Component, {
  ConfirmCodeProps,
  ConfirmCodePropsExternal,
  ConfirmCodeActions,
} from './component';

const mapStateToProps = (
  state: { [name]: IConfirmState },
  props: { header?: string; onCancel: Function; onSuccess: Function; confirmTypeCode: confirmTypes }
): ConfirmCodeProps & ConfirmCodePropsExternal => ({
  code: selectors.selectCode(state),
  factorUrl: selectors.selectFactorUrl(state),
  phoneNumber: selectors.selectPhoneNumber(state),
  codeErrorList: selectors.selectErrorListByField(state)('code'),
  apiErrorList: selectors.selectErrorListByField(state)('api'),
  isSending: selectors.selectIsSending(state),
  isLoading: selectors.selectIsLoading(state),
  isBlocked: selectors.selectIsBlocked(state),
  ...props,
});

const mapDispatchToProps = (dispatch: any): ConfirmCodeActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
