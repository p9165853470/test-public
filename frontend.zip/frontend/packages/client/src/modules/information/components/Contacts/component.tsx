import React, { useEffect } from 'react';
import { Html } from '@rfb/ui-kit';

import styles from './assets/styles/index.module.css';

export interface IInformationContactsProps {
  text: string;
}

export interface IInformationContactsActions {
  actions: {
    getContactsText: Function,
  };
}

const Contacts = (props: IInformationContactsProps & IInformationContactsActions) => {
  useEffect(() => {
    props.actions.getContactsText();
    // ESLINT Необходимо выполнение только в момент монтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={styles.main}>
      <h1 className={styles.title}>Контакты</h1>
      <div className={styles.text}><Html text={props.text} /></div>
    </div>
  );
};

export default Contacts;
