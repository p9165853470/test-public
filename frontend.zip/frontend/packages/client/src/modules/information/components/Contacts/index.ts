import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IInformationState } from '../../store';

import Component, { IInformationContactsProps, IInformationContactsActions } from './component';

const mapStateToProps = (state: { [name]: IInformationState }): IInformationContactsProps => ({
  text: selectors.selectContactsText(state),
});

const mapDispatchToProps = (dispatch: any): IInformationContactsActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
