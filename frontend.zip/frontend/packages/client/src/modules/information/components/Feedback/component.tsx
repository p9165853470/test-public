import React, { useEffect } from 'react';

import fp from 'lodash/fp';

import { Button, Condition, Dropdown, Form, Input, MessageList } from '@rfb/ui-kit';

import { configureValidator, runRulesChain } from 'helpers/validation';

import { subjectRules, messageRules, phoneRules } from '../../configs/validation';

import { IDTOFeedbackCreateRequest } from 'dto/feedback';

import styles from './assets/styles/index.module.css';

export interface IInformationFeedbackProps {
  options: { value: string, label: string }[];
  subject: string;
  optionErrorList: string[];
  email: string;
  phone: string;
  phoneErrorList: string[];
  contractNumber: string;
  message: string;
  messageErrorList: string[];
  apiErrorList: string[];
  dealerName: string;
  isFeedbackSending: boolean;
}

export interface IInformationFeedbackPropsExternal {
  // TODO Use a history interface
  history: {
    push: (path: string) => void,
  };
}

export interface IInformationFeedbackActions {
  actions: {
    setForm: Function,
    setError: Function,
    sendFeedback: Function,
    resetForm: Function,
  };
}

const Feedback = (
  props: IInformationFeedbackProps & IInformationFeedbackPropsExternal & IInformationFeedbackActions
) => {
  useEffect(() => {
    return () => props.actions.resetForm();
    // ESLINT Необходимо выполнение только в момент размонтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const validators = {
    subject: configureValidator({
      name: 'subject',
      rule: subjectRules,
      setError: props.actions.setError,
    }),
    message: configureValidator({
      name: 'message',
      rule: messageRules,
      setError: props.actions.setError,
    }),
    phone: configureValidator({
      name: 'phone',
      rule: phoneRules,
      setError: props.actions.setError,
    }),
  };

  const onSubjectChange = (subject: string): void => {
    validators.subject(subject).finally((): void => props.actions.setForm({ subject }));
  };
  const onPhoneChange = (phone: string): void => {
    validators.phone(phone).finally((): void => props.actions.setForm({ phone }));
  };
  const onContractNumberChange = (contractNumber: string): void => {
    props.actions.setForm({ contractNumber });
  };
  const onMessageChange = (message: string): void => {
    validators.message(message).finally((): void => props.actions.setForm({ message }));
  };
  const onFormSubmit = (): void => {
    const data: IDTOFeedbackCreateRequest = {
      subject: props.subject,
      phone_number: props.phone,
      contract_number: props.contractNumber,
      message: props.message,
      dealer_name: props.dealerName,
    };
    const rules = [
      validators.subject(data.subject),
      validators.message(data.message),
      validators.phone(data.phone_number),
    ];
    runRulesChain(rules).then(() => props.actions.sendFeedback({ data, history: props.history }));
  };

  return (
    <div className={styles.main}>
      <h1 className={styles.title}>
        Если у вас есть вопрос или предложение, можете отправить нам сообщение
      </h1>

      <Form onSubmit={onFormSubmit}>
        <Dropdown
          wrapperClassName={styles.subject}
          label="Тема сообщения"
          options={props.options}
          value={props.subject}
          hasError={!fp.isEmpty(props.optionErrorList)}
          onChange={onSubjectChange}
        />
        <MessageList type="error" messages={props.optionErrorList} />

        <Input
          wrapperClassName={styles.email}
          label="E-mail"
          value={props.email}
          isStatic
          onChange={fp.noop}
        />

        <Input
          wrapperClassName={styles.phone}
          type="phone"
          label="Номер телефона"
          value={props.phone}
          hasError={!fp.isEmpty(props.phoneErrorList)}
          onChange={onPhoneChange}
        />
        <MessageList type="error" messages={props.phoneErrorList} />

        <Input
          wrapperClassName={styles.contractNumber}
          label="Номер договора"
          value={props.contractNumber}
          onChange={onContractNumberChange}
        />

        <Input
          wrapperClassName={styles.message}
          type="textarea"
          label="Ваше сообщение"
          value={props.message}
          hasError={!fp.isEmpty(props.messageErrorList)}
          onChange={onMessageChange}
          maxLength={1000}
        />
        <MessageList type="error" messages={props.messageErrorList} />

        <Condition value={!fp.isEmpty(props.apiErrorList)}>
          <MessageList type="error" messages={props.apiErrorList} />
        </Condition>

        <Button
          wrapperClassName={styles.button}
          type="submit"
          text="Отправить"
          isDisabled={props.isFeedbackSending}
        />
      </Form>
    </div>
  );
};

export default Feedback;
