import { connect } from 'react-redux';

import routingConfig from 'configs/routing';

import Component, { IInformationNavigationProps } from './component';

const mapStateToProps = (): IInformationNavigationProps => ({
  config: [
    {
      link: routingConfig.contacts.path,
      text: 'Контакты',
    },
    {
      link: routingConfig.reminder.path,
      text: 'Памятка по взаимодействию с банком',
    },
    {
      link: routingConfig.tariffs.path,
      text: 'Тарифы',
    },
    {
      link: routingConfig.feedback.path,
      text: 'Связаться с банком',
      isRed: true,
    },
  ],
});

const mapDispatchToProps = () => ({});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
