import React, { useEffect } from 'react';
import { Html } from '@rfb/ui-kit';

import styles from './assets/styles/index.module.css';

export interface IInformationReminderProps {
  text: string;
}

export interface IInformationReminderActions {
  actions: {
    getReminderText: Function,
  };
}

const Reminder = (props: IInformationReminderProps & IInformationReminderActions) => {
  useEffect(() => {
    props.actions.getReminderText();
    // ESLINT Необходимо выполнение только в момент монтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={styles.main}>
      <h1 className={styles.title}>Памятка по взаимодействию с банком</h1>
      <div className={styles.text}><Html text={props.text} /></div>
    </div>
  );
};

export default Reminder;
