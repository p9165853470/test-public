import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IInformationState } from '../../store';

import Component, { IInformationReminderProps, IInformationReminderActions } from './component';

const mapStateToProps = (state: { [name]: IInformationState }): IInformationReminderProps => ({
  text: selectors.selectReminderText(state),
});

const mapDispatchToProps = (dispatch: any): IInformationReminderActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
