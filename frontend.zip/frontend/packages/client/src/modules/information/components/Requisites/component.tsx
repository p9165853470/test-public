import React, { useEffect } from 'react';
import { Html } from '@rfb/ui-kit';

import styles from './assets/styles/index.module.css';

export interface IInformationRequisitesProps {
  text: string;
}

export interface IInformationRequisitesActions {
  actions: {
    getRequisitesText: Function,
  };
}

const Requisites = (props: IInformationRequisitesProps & IInformationRequisitesActions) => {
  useEffect(() => {
    props.actions.getRequisitesText();
    // ESLINT Необходимо выполнение только в момент монтирования компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={styles.main}>
      <h1 className={styles.title}>Реквизиты банка</h1>
      <div className={styles.text}><Html text={props.text} /></div>
    </div>
  );
};

export default Requisites;
