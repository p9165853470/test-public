import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import { name, actions, selectors, IInformationState } from '../../store';

import Component, { IInformationRequisitesProps, IInformationRequisitesActions } from './component';

const mapStateToProps = (state: { [name]: IInformationState }): IInformationRequisitesProps => ({
  text: selectors.selectRequisitesText(state),
});

const mapDispatchToProps = (dispatch: any): IInformationRequisitesActions => ({
  actions: bindActionCreators(actions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
