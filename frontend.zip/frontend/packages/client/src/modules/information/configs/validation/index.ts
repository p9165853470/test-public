import validator from 'utils/validator';

import translationConfig from 'configs/validation/translations';

export const subjectRules = validator.string().required(translationConfig.app.subjectRequired);

export const messageRules = validator.string().required(translationConfig.app.messageRequired).max(1000);

export const phoneRules = validator.string().required().min(11, translationConfig.app.phoneIncorrect);
