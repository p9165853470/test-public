import { createSelector } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { name } from './index';

export const selectState = fp.path(name);
const selectForm = createSelector(selectState, fp.path('form'));

export default {
  selectContactsText: createSelector(selectState, fp.path('contactsText')),
  selectReminderText: createSelector(selectState, fp.path('reminderText')),
  selectTariffsText: createSelector(selectState, fp.path('tariffsText')),
  selectRequisitesText: createSelector(selectState, fp.path('requisitesText')),
  selectFormValueByField: createSelector(selectForm, (state) => (field: string) =>
    fp.path(field, state)
  ),
  selectIsFeedbackSending: createSelector(selectState, fp.path('isFeedbackSending')),
  selectIsFeedbackSent: createSelector(selectState, fp.path('isFeedbackSent')),
  selectErrorListByField: createSelector(selectState, (state) => (field: string) =>
    fp.pathOr([], ['errorList', field], state)
  ),
};
