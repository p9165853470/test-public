import { connect } from 'react-redux';
import { bindActionCreators } from '@reduxjs/toolkit';

import fp from 'lodash/fp';

import { getTransformedAmount } from '@rfb/common';

import { getTransformedNumberForView } from '../../helpers/transform';

import { ClientLineStatus } from 'modules/client-line/configs/status';
import { TrancheStatus } from '../../configs/status';

import {
  actions as clientLineActions,
  selectors as clientLineSelectors,
} from 'modules/client-line/store';

import { name, actions, selectors, ITrancheState } from '../../store';

import Component, {
  ITrancheFilterProps,
  ITrancheFilterPropsExternal,
  ITrancheFilterActions,
  selectedByPeriodValue,
} from './component';

const mapStateToProps = (
  state: { [name]: ITrancheState },
  props: ITrancheFilterPropsExternal
): ITrancheFilterProps & ITrancheFilterPropsExternal => {
  const clientLine = clientLineSelectors.selectCurrentClientLine(state);

  return {
    filter: selectors.selectFilter(state),
    filterTemp: selectors.selectFilterTemp(state),
    clientLineStatusOptions: [
      { value: ClientLineStatus.OPENED, label: 'По открытым договорам' },
      { value: selectedByPeriodValue, label: 'Выбранные за период' },
    ],
    clientLineName: fp.isEmpty(clientLine)
      ? ''
      : getTransformedNumberForView(clientLine.number, clientLine.type),
    clientLine,
    statusOptions: [
      { value: TrancheStatus.OPENED, label: 'Открытые транши' },
      { value: TrancheStatus.ALL, label: 'Все транши' },
    ],
    paymentListCount: selectors.selectPaymentListCount(state),
    amount: fp.pipe(selectors.selectPaymentListAmount, getTransformedAmount)(state),
    showSelected: selectors.selectShowSelected(state),
    clientLineId: props.clientLineId,
    clientLineType: props.clientLineType,
  };
};

const mapDispatchToProps = (dispatch: any): ITrancheFilterActions => ({
  actions: bindActionCreators(actions, dispatch),
  clientLineActions: bindActionCreators(clientLineActions, dispatch),
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
