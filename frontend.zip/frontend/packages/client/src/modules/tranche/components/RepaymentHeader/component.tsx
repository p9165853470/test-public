import React from 'react';

import fp from 'lodash/fp';

import { Button, ButtonReset, Condition } from '@rfb/ui-kit';

import storageDB from 'utils/storage-db';

import { IDTORFInfoTranchesPaymentRequest } from 'dto/rf-info';

import { ITrancheState } from '../../store';

import styles from './assets/styles/index.module.css';

export interface ITrancheRepaymentHeaderProps {
  paymentOrderedList: ITrancheState['paymentList'],
  paymentListCount: number;
  amount: string;
  isSending: boolean;
}

export interface ITrancheRepaymentHeaderPropsExternal {
  // TODO Use a history interface
  history: {
    push: (path: string) => void,
  };
}

export interface ITrancheRepaymentHeaderActions {
  actions: {
    set: Function,
    docRequest: Function,
    sendPaymentList: Function,
  };
}

const RepaymentHeader = (props: ITrancheRepaymentHeaderProps & ITrancheRepaymentHeaderPropsExternal & ITrancheRepaymentHeaderActions) => {
  const onSend = (): void => {
    const data: IDTORFInfoTranchesPaymentRequest = {
      payments: fp.map(
        (item: ITrancheState['paymentList'][number]) => ({ vin: item.vin, payment_type: item.payment_type }),
        props.paymentOrderedList
      ),
    };
    props.actions.docRequest({ data, history: props.history });
//    props.actions.sendPaymentList({ data, history: props.history });
  };
  const onClear = (): void => {
    storageDB.set('tranche-payment-list', []);
    props.actions.set({ paymentList: [], orderList: [] });
  }

  const hasSelectedTranches: boolean = fp.gt(props.paymentListCount, 0);

  return (
    <div className={styles.main}>
      <div className={styles.blockA}>
        <h1 className={styles.title}>Транши на погашение</h1>
        <Condition value={hasSelectedTranches}>
            <Button
              wrapperClassName={styles.buttonSend}
              text="Подтвердить приоритеты и отправить на погашение"
              isDisabled={props.isSending}
              onClick={onSend}
            />
        </Condition>
      </div>

      <div className={styles.blockB}>
        <div className={styles.trancheCount}>
          <span className={styles.trancheCountTitle}>Кол-во траншей:</span>
          <span className={styles.trancheCountValue}>{props.paymentListCount}</span>
        </div>
        <div className={styles.priceTotal}>
          <div className={styles.priceTotalTooltip} data-text="Включает сумму процентов, просроченную задолженность и комиссию(при наличии)">
            <span className={styles.priceTotalTitle}>Итоговая сумма для погашения:</span>
            <span className={styles.priceTotalValue}>{props.amount}</span>
          </div>
        </div>
        <Condition value={hasSelectedTranches}>
          <ButtonReset
            wrapperClassName={styles.reset}
            title="Сбросить все выбранные транши"
            isActive
            onClear={onClear}
          />
        </Condition>
      </div>
    </div>
  );
};

export default RepaymentHeader;
