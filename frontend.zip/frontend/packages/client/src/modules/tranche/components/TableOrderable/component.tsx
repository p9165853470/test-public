import React, { useEffect } from 'react';

import fp from 'lodash/fp';

import { TableOrderable as UIKitTableOrderable } from '@rfb/ui-kit';

import styles from './assets/styles/index.module.css';

export interface ITableOrderableProps {
  headers: { value: string, title: string }[];
  data: string[][];
  orderList: number[];
}

export interface ITableOrderableActions {
  actions: {
    set: Function,
  };
  getPaymentListFromDB: Function;
}

const TableOrderable = (props: ITableOrderableProps & ITableOrderableActions) => {
  useEffect(() => {
    props.actions.set({ paymentList: props.getPaymentListFromDB() });
    // ESLINT Необходимо выполнение только при монтировании компонента
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onOrderChange = (paymentOrderList: number[]): void =>
    props.actions.set({ paymentOrderList });

  if (fp.isEmpty(props.data)) return null;

  return (
    <div className={styles.main}>
      <UIKitTableOrderable
        headers={props.headers}
        rows={props.data}
        orderList={props.orderList}
        onOrderChange={onOrderChange}
      />
    </div>
  );
};

export default TableOrderable;
