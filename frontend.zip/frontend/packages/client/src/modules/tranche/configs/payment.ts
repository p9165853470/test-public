export enum TranchePayment {
  FULL = 'full-repayment',
  PRE = 'prepayment',
}
