export enum TrancheStatus {
  OPENED = '0',
  CLOSED = '1',
  ALL = '2'
}

export const trancheStatus: { [key: string]: string } = {
  [TrancheStatus.OPENED]: 'Открытый',
  [TrancheStatus.CLOSED]: 'Закрытый',
}
