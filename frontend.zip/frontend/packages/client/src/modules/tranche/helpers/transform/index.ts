import { trancheTypeTranslations } from '../../configs/type';
import { trancheStatus } from '../../configs/status';

export const getTransformedNumberForView = (number: string, type: string): string =>
  `${number}-${trancheTypeTranslations[type]}`;

export const getTransformedStatus = (status: string): string => trancheStatus[status];
