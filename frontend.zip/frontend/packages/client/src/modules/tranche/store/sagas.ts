import { put, select, takeEvery } from 'redux-saga/effects';

import fp from 'lodash/fp';

import { convertPathUsingParams, Directions } from '@rfb/common';

import api from 'utils/api';
import notification from 'utils/notification';
import storageDB from 'utils/storage-db';

import { convertApiErrorCodesToMessages } from 'helpers/app';
import { download } from 'helpers/file';

import apiEndpoints from 'configs/api/endpoints';
import routingConfig from 'configs/routing';
import notificationTranslationConfig from 'configs/notification/translations';

import { IDTORFInfoHeaders, IDTORFInfoTranchesResponse } from 'dto/rf-info';

import { ITrancheState } from './slice';
import { actions } from './index';
import { selectors as clientLineSelectors } from 'modules/client-line/store';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* getData(action: TODO_ANY) {
  const filter: ITrancheState['filter'] & {clientLineId?: string} = action.payload;
  try {
    yield put(actions.set({ data: [], pageCount: 0, isLoading: true }));
    yield put(actions.setError({ rfInfo: [] }));
    const url: string =
      apiEndpoints.rfInfo.tranches +
      `?number_line=${filter.clientLineId}&type_line=${filter.type}&status_tranche=${filter.status}` +
      `&start_date=${filter.dateStart}&end_date=${filter.dateEnd}` +
      `&finish_date_from=${filter.dateFinishStart}&finish_date_to=${filter.dateFinishEnd}` +
      `&page=${filter.page}` +
      `&sort=${fp.isEqual(Directions.DESC, filter.sorting?.direction) ? '-' : ''}${filter.sorting?.value}` +
      `&vin=${filter.vin}&name_brand=${filter.brand}&model=${filter.model}&number=${filter.number}` +
      `&per-page=${filter.perPage}`;
    const result: { data: IDTORFInfoTranchesResponse, headers: IDTORFInfoHeaders } = yield api.get(url);
    yield put(actions.getDataSuccessful({ data: result.data, headers: result.headers }));
  } catch (error) {
    yield put(actions.getDataFailure(error));
  } finally {
    yield put(actions.set({ isLoading: false }));
  }
}

function* getDataSuccessful(action: TODO_ANY) {
  yield put(
    actions.set({
      data: action.payload.data.tranches,
      dataFilter: action.payload.data.filters,
      pageCount: fp.toNumber(action.payload.headers['x-pagination-page-count']),
    })
  );
}

function* getDataFailure(action: TODO_ANY) {
  yield put(actions.setError({ rfInfo: convertApiErrorCodesToMessages(action.payload) }));
}


// function* docRequest(action: TODO_ANY) {
//   try {
//     const filter: ITrancheState['filter'] & {clientLineId?: string} = action.payload;
//     const url: string =
//       apiEndpoints.rfInfo.tranchesDocRequest +
//       `?number_line=${filter.clientLineId}&type_line=${filter.type}&status_tranche=${filter.status}` +
//       `&start_date=${filter.dateStart}&end_date=${filter.dateEnd}` +
//       `&finish_date_from=${filter.dateFinishStart}&finish_date_to=${filter.dateFinishEnd}` +
//       `&vin=${filter.vin}&name_brand=${filter.brand}&model=${filter.model}&number=${filter.number}`;
//     const config = {
//       headers: { 'Accept': 'application/pdf' },
//       responseType: 'arraybuffer',
//     };
//     const result: { data: IDTORFInfoTranchesResponse, headers: { 'content-type': string } } = yield api.get(url, config);
//     yield put(actions.docRequestSuccessful(result));
//   } catch (error) {
//     yield put(actions.docRequestFailure(error.response?.data));
//   }
// }
//
// function* docRequestSuccessful(action: TODO_ANY) {
//   download(action.payload, `tranches-${Date.now()}`);
//   yield;
// }
//
// function* docRequestFailure(action: TODO_ANY) {
//   yield put(actions.setError({ api: action.payload }))
// }

function* docRequest(action: TODO_ANY) {
  console.log('tranche/store/sagas/docRequest() BEGIN');
  try {
    yield put(actions.set({ isSending: true }));
    //TODO prepare PDF
    yield api.post(apiEndpoints.rfInfo.tranchesDocRequest, action.payload.data);
    yield put(actions.docRequestSuccessful({ history: action.payload.history }));
  } catch (error) {
    yield put(actions.docRequestFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isSending: false }));
  }
  console.log('tranche/store/sagas/docRequest() END');
}

function* docRequestSuccessful(action: TODO_ANY) {
  console.log('tranche/store/sagas/docRequestSuccessful() BEGIN');
  console.log('tranche/store/sagas/docRequestSuccessful() END');
}

function* docRequestFailure(action: TODO_ANY) {
  console.log('tranche/store/sagas/docRequestFailure() BEGIN');
  yield put(actions.setError({ api: action.payload }))
  console.log('tranche/store/sagas/docRequestFailure() END');
}


function* sendPaymentList(action: TODO_ANY) {
  console.log('tranche/store/sagas/sendPaymentList() BEGIN');
  try {
    yield put(actions.set({ isSending: true }));
    yield api.post(apiEndpoints.rfInfo.tranchesPayment, action.payload.data);
    yield put(actions.sendPaymentListSuccessful({ history: action.payload.history }));
  } catch (error) {
    yield put(actions.sendPaymentListFailure(error.response?.data));
  } finally {
    yield put(actions.set({ isSending: false }));
  }
  console.log('tranche/store/sagas/sendPaymentList() END');
}

function* sendPaymentListSuccessful(action: TODO_ANY) {
  console.log('tranche/store/sagas/sendPaymentListSuccessful() BEGIN');
  notification.info(notificationTranslationConfig.sendPaymentSuccessful);
  storageDB.set('tranche-payment-list', []);
  yield put(actions.set({ paymentList: [], orderList: [] }));
  const state = yield select();
  const currentClientLine = clientLineSelectors.selectCurrentClientLine(state);

  action.payload.history.push(
    currentClientLine.number
      ? convertPathUsingParams(
        routingConfig.tranchesListByClientLineIdAndType.path, {
          clientLineId: currentClientLine.number,
          clientLineType: currentClientLine.type
        })
      : routingConfig.tranches.path
    );
  console.log('tranche/store/sagas/sendPaymentListSuccessful() END');
}

function* sendPaymentListFailure(action: TODO_ANY) {
  console.log('tranche/store/sagas/sendPaymentListFailure() BEGIN');
  yield put(actions.setError({ api: action.payload }))
  console.log('tranche/store/sagas/sendPaymentListFailure() END');
}

function* exportData(action: TODO_ANY) {
  try {
    const filter: ITrancheState['filter'] & {clientLineId?: string} = action.payload;
    const url: string =
      apiEndpoints.rfInfo.tranchesExport +
      `?number_line=${filter.clientLineId}&type_line=${filter.type}&status_tranche=${filter.status}` +
      `&start_date=${filter.dateStart}&end_date=${filter.dateEnd}` +
      `&finish_date_from=${filter.dateFinishStart}&finish_date_to=${filter.dateFinishEnd}` +
      `&vin=${filter.vin}&name_brand=${filter.brand}&model=${filter.model}&number=${filter.number}`;
    const config = {
      headers: { 'Accept': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' },
      responseType: 'arraybuffer',
    };
    const result: { data: IDTORFInfoTranchesResponse, headers: { 'content-type': string } } = yield api.get(url, config);
    yield put(actions.exportDataSuccessful(result));
  } catch (error) {
    yield put(actions.exportDataFailure(error.response?.data));
  }
}

function* exportDataSuccessful(action: TODO_ANY) {
  download(action.payload, `tranches-${Date.now()}`);
  yield;
}

function* exportDataFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload }))
}

export default function* () {
  yield takeEvery(actions.getData, getData);
  yield takeEvery(actions.getDataSuccessful, getDataSuccessful);
  yield takeEvery(actions.getDataFailure, getDataFailure);

  yield takeEvery(actions.docRequest, docRequest);
  yield takeEvery(actions.docRequestSuccessful, docRequestSuccessful);
  yield takeEvery(actions.docRequestFailure, docRequestFailure);

  yield takeEvery(actions.sendPaymentList, sendPaymentList);
  yield takeEvery(actions.sendPaymentListSuccessful, sendPaymentListSuccessful);
  yield takeEvery(actions.sendPaymentListFailure, sendPaymentListFailure);

  yield takeEvery(actions.exportData, exportData);
  yield takeEvery(actions.exportDataSuccessful, exportDataSuccessful);
  yield takeEvery(actions.exportDataFailure, exportDataFailure);
}
