import React, { useEffect } from 'react';

import { UserWidget } from '@rfb/ui-kit';
import routingConfig from 'configs/routing';
import { IDTOProfileViewResponse } from 'dto/profile';
import { DTOUserInfo } from 'dto/rf-info';

export interface IUserWidgetProps {
  profile: IDTOProfileViewResponse;
  organization: object;
  organizationName: string;
  email: string;
  profileLink: string;
  userDealers?: DTOUserInfo[];
}

export interface IUserWidgetActions {
  authActions: {
    chooseOrganization: Function;
    getUserDealer: Function;
    logout: Function;
  };
}

const Widget = (props: IUserWidgetProps & IUserWidgetActions) => {
  useEffect(() => {
    props.authActions.getUserDealer({ autoChooseDealer: false });
  }, []);

  return (
    <UserWidget
      name={props.organizationName}
      email={props.email}
      link={props.profileLink}
      onLogout={() => {
        if (!props.userDealers || props.userDealers?.length <= 1) {
          props.authActions.logout();
        } else {
          props.authActions.chooseOrganization({
            data: { diasoft_id: '' },
            onSuccess: () => {
              window.location.replace(routingConfig.login.path);
            },
          });
        }
      }}
    />
  );
};

export default Widget;
