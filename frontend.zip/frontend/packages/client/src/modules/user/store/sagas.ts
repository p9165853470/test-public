import { put, takeEvery } from 'redux-saga/effects';

import api from 'utils/api';

import { convertApiErrorCodesToMessages } from 'helpers/app';

import routingConfig from 'configs/routing';
import apiEndpoints from 'configs/api/endpoints';

import { actions } from './index';

import { IDTOProfileViewResponse } from 'dto/profile';
import { IDTORFInfoOrganizationResponse } from 'dto/rf-info';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

function* getProfile(action: TODO_ANY) {
  console.log('user/store/sagas.getProfile() BEGIN');
  try {
    const result: { data: IDTOProfileViewResponse } = yield api.get(apiEndpoints.profile.view);
    yield put(actions.getProfileSuccessful(result.data));
  } catch (error) {
    console.log('user/store/sagas.getProfile() ERROR');
    yield put(actions.getProfileFailure(error));
  }
  console.log('user/store/sagas.getProfile() END');
}

function* getProfileSuccessful(action: TODO_ANY) {
  yield put(actions.set({ profile: action.payload }));
}

function* getProfileFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* getOrganization(action: TODO_ANY) {
  try {
    const result: { data: IDTORFInfoOrganizationResponse } = yield api.get(
      apiEndpoints.rfInfo.info
    );
    yield put(actions.getOrganizationSuccessful(result.data));
  } catch (error) {
    yield put(actions.getOrganizationFailure(error));
  }
}

function* getOrganizationSuccessful(action: TODO_ANY) {
  yield put(actions.set({ organization: action.payload }));
}

function* getOrganizationFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: action.payload?.message }));
}

function* changePassword(action: TODO_ANY) {
  try {
    yield api.post(apiEndpoints.security.passwordChange, action.payload.data);
    yield put(actions.changePasswordSuccessful({ history: action.payload.history }));
  } catch (error) {
    yield put(actions.changePasswordFailure(error.response.data));
  }
}

function* changePasswordSuccessful(action: TODO_ANY) {
  action.payload.history.push(routingConfig.profile.path);
  yield;
}

function* changePasswordFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload) }));
}

function* changePhoneNumber(action: TODO_ANY) {
  try {
    yield api.post(apiEndpoints.profile.phoneNumberChange, action.payload.data);
    yield put(actions.changePhoneNumberSuccessful({ history: action.payload.history }));
  } catch (error) {
    yield put(
      actions.changePhoneNumberFailure({
        data: error.response.data,
        history: action.payload.history,
      })
    );
  }
}

function* changePhoneNumberSuccessful(action: TODO_ANY) {
  yield put(actions.reset());
  action.payload.history.push(routingConfig.profile.path);
  yield put(actions.getProfile({}));
  yield;
}

function* changePhoneNumberFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload.data) }));
  action.payload.history.push(routingConfig.profilePhoneNumberChange.path);
  yield;
}

function* changeCodeWord(action: TODO_ANY) {
  try {
    yield api.post(apiEndpoints.profile.codeWordChange, action.payload.data);
    yield put(actions.changeCodeWordSuccessful({ history: action.payload.history }));
  } catch (error) {
    yield put(
      actions.changeCodeWordFailure({
        data: error.response.data,
        history: action.payload.history,
      })
    );
  }
}

function* changeCodeWordSuccessful(action: TODO_ANY) {
  yield put(actions.reset());
  action.payload.history.push(routingConfig.profile.path);
  yield put(actions.getProfile({}));
  yield;
}

function* changeCodeWordFailure(action: TODO_ANY) {
  yield put(actions.setError({ api: convertApiErrorCodesToMessages(action.payload.data) }));
  action.payload.history.push(routingConfig.profileCodeWordChange.path);
  yield;
}

const sagas = function* () {
  yield takeEvery(actions.getProfile, getProfile);
  yield takeEvery(actions.getProfileSuccessful, getProfileSuccessful);
  yield takeEvery(actions.getProfileFailure, getProfileFailure);

  yield takeEvery(actions.getOrganization, getOrganization);
  yield takeEvery(actions.getOrganizationSuccessful, getOrganizationSuccessful);
  yield takeEvery(actions.getOrganizationFailure, getOrganizationFailure);

  yield takeEvery(actions.changePassword, changePassword);
  yield takeEvery(actions.changePasswordSuccessful, changePasswordSuccessful);
  yield takeEvery(actions.changePasswordFailure, changePasswordFailure);

  yield takeEvery(actions.changePhoneNumber, changePhoneNumber);
  yield takeEvery(actions.changePhoneNumberSuccessful, changePhoneNumberSuccessful);
  yield takeEvery(actions.changePhoneNumberFailure, changePhoneNumberFailure);

  yield takeEvery(actions.changeCodeWord, changeCodeWord);
  yield takeEvery(actions.changeCodeWordSuccessful, changeCodeWordSuccessful);
  yield takeEvery(actions.changeCodeWordFailure, changeCodeWordFailure);
};

export default sagas;
