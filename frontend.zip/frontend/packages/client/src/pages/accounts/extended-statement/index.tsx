import React from "react";

import { History } from '@rfb/ui-kit';

import routingConfig from 'configs/routing';

import AppFullWidthTemplate from '../../../templates/AppFullWidthTemplate';

import ExtendedStatement from '../../../modules/accounts/components/ExtendedStatementPage';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

import styles from './assets/styles/index.module.css';

const ExtendedStatementPage = (props: TODO_ANY) => {
  const renderContent = () => (
    <div>
      <History 
        wrapperClassName={styles.wrapperHistory}
        type="back"
        to={routingConfig.accounts.path}
        title='Назад в расчетные счета'
      />
      <ExtendedStatement id={props.match.params.id} />
    </div>
  );

  return <AppFullWidthTemplate content={renderContent()} />;
};

export default ExtendedStatementPage;
