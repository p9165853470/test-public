import React from 'react';

import { ButtonPrint } from '@rfb/ui-kit';

import AppTemplate from 'templates/AppTemplate';

import AppHelp from 'modules/app/components/Help';

import styles from './assets/styles/index.module.css';

const Help = () => {
  const renderContent = () => (
    <div className={styles.main}>
      <AppHelp />
      <div className={styles.sidebarRight}>
        <ButtonPrint />
      </div>
    </div>
  );

  return <AppTemplate content={renderContent()} />;
};

export default Help;
