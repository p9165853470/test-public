import React from 'react';

import { AuthTemplate, ButtonWithIcon } from '@rfb/ui-kit';
import { actions } from 'modules/auth/store';

import Organization from 'modules/auth/components/Organization';

import styles from './assets/styles/index.module.css';
import { useDispatch } from 'react-redux';
import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const OrganizationPage = (props: TODO_ANY) => {
  const dispatch = useDispatch();

  const renderContent = () => (
    <div className={styles.main}>
      <h1 className={styles.title}>Выберите организацию</h1>

      <div className={styles.navigation}>
        <Organization history={props.history} />
      </div>

      <div>
        <ButtonWithIcon
          wrapperClassName={styles.logout}
          type="exit"
          text="Выход"
          isActive
          onClick={() => dispatch(actions.logout({}))}
        />
      </div>
    </div>
  );

  return <AuthTemplate content={renderContent()} />;
};

export default OrganizationPage;
