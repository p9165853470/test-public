import React from 'react';

import { History } from '@rfb/ui-kit';

import routingConfig from 'configs/routing';

import AppTemplate from 'templates/AppTemplate';

import ClientLineDetail from 'modules/client-line/components/Detail';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const DetailById = (props: TODO_ANY) => {
  const renderContent = () => (
    <div className={styles.main}>
      <ClientLineDetail
        id={props.match.params.id}
        type={props.match.params.type}
      />
    </div>
  );

  const renderSidebarLeft = () => <History type="back" to={routingConfig.main.path} />;

  return <AppTemplate content={renderContent()} sidebarLeft={renderSidebarLeft()} />;
};

export default DetailById;
