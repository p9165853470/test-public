import React from 'react';

import { ButtonPrint, History } from '@rfb/ui-kit';

import routingConfig from 'configs/routing';

import AppTemplate from 'templates/AppTemplate';

import InformationContacts from 'modules/information/components/Contacts';

const Contacts = () => {
  const renderContent = () => <InformationContacts />;
  const renderSidebarLeft = () => <History type="back" to={routingConfig.information.path} />;
  const renderSidebarRight = () => <ButtonPrint />;

  return (
    <AppTemplate
      content={renderContent()}
      sidebarLeft={renderSidebarLeft()}
      sidebarRight={renderSidebarRight()}
    />
  );
};

export default Contacts;
