import React from 'react';

import { History } from '@rfb/ui-kit';

import routingConfig from 'configs/routing';

import AppTemplate from 'templates/AppTemplate';

import InformationFeedback from 'modules/information/components/Feedback';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const Feedback = (props: TODO_ANY) => {
  const renderLeftSidebar = () => (
    <div className={styles.sidebarLeft}>
      <History type="back" to={routingConfig.information.path} />
    </div>
  );

  const renderContent = () => (
    <div className={styles.content}>
      <InformationFeedback history={props.history} />
    </div>
  );

  return <AppTemplate content={renderContent()} sidebarLeft={renderLeftSidebar()} />;
};

export default Feedback;
