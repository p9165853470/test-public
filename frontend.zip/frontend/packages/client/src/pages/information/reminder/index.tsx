import React from 'react';

import { ButtonPrint, History } from '@rfb/ui-kit';

import routingConfig from 'configs/routing';

import AppTemplate from 'templates/AppTemplate';

import InformationReminder from 'modules/information/components/Reminder';

const Reminder = () => {
  const renderContent = () => <InformationReminder />;
  const renderSidebarLeft = () => <History type="back" to={routingConfig.information.path} />;
  const renderSidebarRight = () => <ButtonPrint />;

  return (
    <AppTemplate
      content={renderContent()}
      sidebarLeft={renderSidebarLeft()}
      sidebarRight={renderSidebarRight()}
    />
  );
};

export default Reminder;
