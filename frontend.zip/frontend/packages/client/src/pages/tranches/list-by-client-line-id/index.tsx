import React from 'react';

import AppFullWidthTemplate from 'templates/AppFullWidthTemplate';

import TrancheFilter from 'modules/tranche/components/Filter';
import TrancheTable from 'modules/tranche/components/Table';

import styles from './assets/styles/index.module.css';

import { TODO_ANY } from '@rfb/common/types/TODO_ANY';

const ListByClientLineId = (props: TODO_ANY) => {
  const renderContent = () => (
    <div>
      <div className={styles.filter}>
        <TrancheFilter
          clientLineId={props.match.params.clientLineId}
          clientLineType={props.match.params.clientLineType}
        />
      </div>

      <div className={styles.table}>
        <TrancheTable
          clientLineId={props.match.params.clientLineId}
          clientLineType={props.match.params.clientLineType}
        />
      </div>
    </div>
  );

  return <AppFullWidthTemplate content={renderContent()} />;
};

export default ListByClientLineId;
