import { ApiAxios } from '@rfb/common';

import apiConfig from './configs';

export default ApiAxios(apiConfig);
