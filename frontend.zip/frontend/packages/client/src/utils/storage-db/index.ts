import { StorageLocalStorage } from '@rfb/common';

export default StorageLocalStorage;
