import fp from 'lodash/fp';

import { ValidatorYup } from '@rfb/common';

import translations from 'configs/validation/translations';

export default ValidatorYup(fp.omit('app', translations));
