<?php

namespace backend\actions;

use common\actions\crud\ViewAction;
use common\exceptions\NotFoundModelException;
use common\modules\rfinfo\services\RFInfoRequestService;
use yii\db\ActiveRecord;

class FrontUserViewAction extends ViewAction
{
    /**
     * @param $id
     * @return ActiveRecord
     * @throws NotFoundModelException
     */
    public function run($id)
    {
        $model = parent::run($id);
        
        $rfInfoService = new RFInfoRequestService();  
            
        // obtain and set additional fields (name, inn, kpp) for each dealer
        foreach ($model->dealers as $dealer) {
            $info = $rfInfoService->getInfo2($dealer->diasoft_id);
                
            $dealer->inn = $info->inn;
            $dealer->kpp = $info->kpp;
            $dealer->name = $info->name;
            
            $dealer->attributes;
        }
        
        return $model;
    }
    
}

