<?php

namespace backend\actions;

use backend\behaviors\BlockServiceInterface;
use common\helpers\Filter;
use yii\base\Action;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class UnblockAllAction extends Action
{
    /**
     * @var BlockServiceInterface
     */
    protected $service;

    public function __construct($id, $controller, BlockServiceInterface $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(Request $request, Response $response): void
    {
        $ids = Filter::arrayOfInt($request->post('ids'));

        if (empty($ids)) {
            throw new BadRequestHttpException('No input data.');
        }

        $this->service->unblockAll($ids);

        $response->setStatusCode(204);
    }
}