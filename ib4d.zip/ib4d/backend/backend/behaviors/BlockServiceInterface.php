<?php

namespace backend\behaviors;

interface BlockServiceInterface
{
    public const EVENT_AFTER_BLOCK_ALL = 'afterBlockAll';
    public const EVENT_AFTER_UNBLOCK_ALL = 'afterUnblockAll';

    public function blockAll(array $ids): void;

    public function unblockAll(array $ids): void;
}