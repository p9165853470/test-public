<?php
Yii::$container->setDefinitions([
    \common\modules\session\behaviors\SessionServiceInterface::class => \common\modules\session\services\BackUserSessionService::class,
    \common\modules\password\behaviors\PasswordServiceInterface::class => \common\modules\password\services\BackUserPasswordService::class,
    \common\modules\password\forms\ChangePasswordForm::class => \backend\forms\ChangePasswordForm::class,
    \common\modules\password\forms\ResetPasswordForm::class => \backend\forms\ResetPasswordForm::class,
    \common\modules\rfinfo\behaviors\RequestCacheServiceInterface::class => \common\modules\rfinfo\services\RequestCacheService::class,
]);