<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

return [
    'id' => 'app-backend',
    'basePath' => dirname(__DIR__),
    'controllerNamespace' => 'backend\controllers',
    'bootstrap' => ['log'],
    'components' => [
        'request' => [
            'parsers' => [
                'application/json' => \yii\web\JsonParser::class,
            ]
        ],
        'response' => [
            'format' => \yii\web\Response::FORMAT_JSON,
            'formatters' => [
                'json' => [
                    'class' => \yii\web\JsonResponseFormatter::class,
                    'prettyPrint' => YII_DEBUG,
                    'encodeOptions' => JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE,
                ],
            ],
        ],
        'errorHandler' => [
            'class' => \common\components\ErrorHandler::class
        ],
        'user' => [
            'identityClass' => \common\modules\user\models\BackUser::class,
            'enableAutoLogin' => false,
            'enableSession' => false,
        ],
        'jwt' => [
            'class' => \common\modules\authentication\components\Jwt::class,
        ],
        'authManager' => [
            'class' => \yii\rbac\DbManager::class,
            'itemTable' => '{{%back_auth_item}}',
            'itemChildTable' => '{{%back_auth_item_child}}',
            'assignmentTable' => '{{%back_auth_assignment}}',
            'ruleTable' => '{{%back_auth_rule}}',
            'cacheKey' => 'backRBAC',
        ],
        'log' => [
            'traceLevel' => YII_DEBUG ? 3 : 0,
            'targets' => [
                [
                    'class' => \yii\log\FileTarget::class,
                    'levels' => ['error', 'warning'],
                ],
                [
                    'class' => \common\modules\audit\components\AuditLogTarget::class,
                    'levels' => ['error'],
                    'except' => [
                        'yii\web\HttpException:4*',
                    ],
                ],
            ],
        ],
        'urlManager' => [
            'enablePrettyUrl' => true,
            'showScriptName' => false,
            //'enableStrictParsing' => true,
            'rules' => [
                'docs/<file>' => 'swagger/file',
                'docs' => 'swagger/index',
                'variable/<key>/get' => 'variable/view',
                'variable/<key>/set' => 'variable/update',
                'variable/<key>/upload' => 'variable/upload',
                'front-user/rf-info' => 'front-user/rfinfo',
                '<controller>/<id:\d+>/<action:(view|update|delete)>' => '<controller>/<action>',
            ],
        ],
    ],
    'controllerMap' => [
        'swagger' => [
            'class' => \common\modules\swagger\controllers\SwaggerController::class,
            'fileUrl' => '/docs/swagger.yaml',
            'filePath' => '@backend/swagger/',
        ]
    ],
    'params' => $params,
];
