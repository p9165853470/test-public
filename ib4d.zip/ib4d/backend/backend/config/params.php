<?php
return [
    'audit.logPath' => getenv('audit_backend_log_path'),
];
