<?php

namespace backend\controllers;

use backend\events\authentication\AfterValidateEventHandler;
use common\controllers\Controller;
use common\modules\authentication\actions\CreateTokenAction;
use common\modules\authentication\actions\DestroyTokenAction;
use common\modules\authentication\actions\RefreshTokenAction;
use common\modules\authentication\forms\CreateTokenForm;
use yii\base\Event;

class AuthenticationController extends Controller
{
    public function init(): void
    {
        parent::init();

        Event::on(
            CreateTokenForm::class,
            CreateTokenForm::EVENT_AFTER_VALIDATE,
            AfterValidateEventHandler::get()
        );
    }

    public function behaviors(): array
    {
        $behaviors = parent::behaviors();
        $behaviors[self::BEHAVIOR_AUTH_KEY]['except'] = ['create-token', 'refresh-token'];
        $behaviors[self::BEHAVIOR_IDENTITY_RESTRICT_KEY]['except'] = ['destroy-token'];

        return $behaviors;
    }

    protected function verbs(): array
    {
        return [
            'create-token' => ['POST'],
            'refresh-token' => ['POST'],
            'destroy-token' => ['POST'],
        ];
    }

    public function actions(): array
    {
        return [
            'create-token' => CreateTokenAction::class,
            'refresh-token' => RefreshTokenAction::class,
            'destroy-token' => DestroyTokenAction::class,
        ];
    }
}