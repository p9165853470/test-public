<?php

namespace backend\controllers;

use backend\actions\BlockAllAction;
use backend\actions\UnblockAllAction;
use backend\behaviors\BlockServiceInterface;
use backend\events\backUser\AfterCreateEventHandler;
use backend\events\backUser\AfterDeleteEventHandler;
use backend\events\backUser\AfterUnblockAllEventHandler;
use backend\events\backUser\AuditEventHandler;
use backend\events\backUser\BeforeActionEventHandler;
use backend\events\backUser\BeforeServiceActionEventHandler;
use backend\rbac\Role;
use backend\services\BackUserService;
use common\actions\crud\Action;
use common\actions\crud\CreateAction;
use common\actions\crud\DeleteAction;
use common\actions\crud\DeleteAllAction;
use common\actions\crud\IndexAction;
use common\actions\crud\UpdateAction;
use common\actions\crud\ViewAction;
use common\controllers\Controller;
use common\services\CrudService;
use Yii;
use yii\base\Event;

class BackUserController extends Controller
{
    public function init(): void
    {
        parent::init();

        Yii::$container->setDefinitions([
            CrudService::class => BackUserService::class,
            BlockServiceInterface::class => BackUserService::class,
        ]);

        Event::on(
            BackUserService::class,
            BackUserService::EVENT_AFTER_CREATE,
            AfterCreateEventHandler::get()
        );
        Event::on(
            Action::class,
            Action::EVENT_BEFORE_SERVICE_ACTION,
            BeforeServiceActionEventHandler::get()
        );
        Event::on(
            self::class,
            self::EVENT_BEFORE_ACTION,
            BeforeActionEventHandler::get()
        );
        Event::on(
            BackUserService::class,
            BackUserService::EVENT_AFTER_DELETE,
            AfterDeleteEventHandler::get()
        );
        Event::on(
            BackUserService::class,
            BackUserService::EVENT_AFTER_UNBLOCK_ALL,
            AfterUnblockAllEventHandler::get()
        );

        AuditEventHandler::subscribe(BackUserService::class, [
            BackUserService::EVENT_AFTER_CREATE,
            BackUserService::EVENT_AFTER_UPDATE,
            BackUserService::EVENT_AFTER_DELETE,
            BackUserService::EVENT_AFTER_DELETE_ALL,
            BackUserService::EVENT_AFTER_BLOCK_ALL,
            BackUserService::EVENT_AFTER_UNBLOCK_ALL,
        ]);

    }

    protected function access(): array
    {
        return [
            [
                'allow' => true,
                'roles' => [Role::MASTER_ADMIN],
            ]
        ];
    }

    protected function verbs(): array
    {
        return [
            'index' => ['GET'],
            'create' => ['POST'],
            'update' => ['POST'],
            'delete' => ['POST'],
            'delete-all' => ['POST'],
            'view' => ['GET'],
            'block-all' => ['POST'],
            'unblock-all' => ['POST'],
        ];
    }

    public function actions(): array
    {
        return [
            'index' => IndexAction::class,
            'create' => CreateAction::class,
            'update' => UpdateAction::class,
            'delete' => DeleteAction::class,
            'view' => ViewAction::class,
            'delete-all' => DeleteAllAction::class,
            'block-all' => BlockAllAction::class,
            'unblock-all' => UnblockAllAction::class,
        ];
    }
}