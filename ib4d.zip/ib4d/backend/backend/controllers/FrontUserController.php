<?php

namespace backend\controllers;

use backend\actions\BlockAllAction;
use backend\actions\FrontUserViewAction;
use backend\actions\UnblockAllAction;
use backend\behaviors\BlockServiceInterface;
use backend\events\frontUser\AfterCreateEventHandler;
use backend\events\frontUser\AfterUnblockAllEventHandler;
use backend\rbac\Role;
use backend\services\FrontUserService;
use common\actions\crud\CreateAction;
use common\actions\crud\DeleteAction;
use common\actions\crud\DeleteAllAction;
use common\actions\crud\IndexAction;
use common\actions\crud\UpdateAction;
use common\actions\crud\ViewAction;
use common\controllers\Controller;
use common\modules\rfinfo\actions\RequestAction;
use common\services\CrudService;
use Yii;
use yii\base\Event;

class FrontUserController extends Controller
{
    public function init(): void
    {
        parent::init();

        Yii::$container->setDefinitions([
            CrudService::class => FrontUserService::class,
            BlockServiceInterface::class => FrontUserService::class,
        ]);

        Event::on(
            FrontUserService::class,
            FrontUserService::EVENT_AFTER_CREATE,
            AfterCreateEventHandler::get()
        );
        Event::on(
            FrontUserService::class,
            FrontUserService::EVENT_AFTER_UNBLOCK_ALL,
            AfterUnblockAllEventHandler::get()
        );
    }

    protected function verbs(): array
    {
        return [
            'index' => ['GET'],
            'create' => ['POST'],
            'update' => ['POST'],
            'delete' => ['POST'],
            'delete-all' => ['POST'],
            'view' => ['GET'],
            'block-all' => ['POST'],
            'unblock-all' => ['POST'],
            'rfinfo' => ['GET'],
        ];
    }

    protected function access(): array
    {
        return [
            [
                'allow' => true,
                'roles' => [Role::ADMIN, Role::MASTER_ADMIN],
            ]
        ];
    }

    public function actions(): array
    {
        return [
            'index' => IndexAction::class,
            'create' => CreateAction::class,
            'update' => UpdateAction::class,
            'delete' => DeleteAction::class,
            'delete-all' => DeleteAllAction::class,
            'view' => FrontUserViewAction::class,
            'block-all' => BlockAllAction::class,
            'unblock-all' => UnblockAllAction::class,
            'rfinfo' => RequestAction::class,
        ];
    }
}