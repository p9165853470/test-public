<?php

namespace backend\controllers;

use backend\controllers\profile\UpdateAction;
use backend\controllers\profile\ViewAction;
use backend\events\profile\AuditEventHandler;
use backend\services\BackUserService;
use common\controllers\Controller;

class ProfileController extends Controller
{
    public function init(): void
    {
        parent::init();

        AuditEventHandler::subscribe(BackUserService::class, BackUserService::EVENT_AFTER_UPDATE);
    }

    public function actions(): array
    {
        return [
            'view' => ViewAction::class,
            'update' => UpdateAction::class,
        ];
    }

    protected function verbs(): array
    {
        return [
            'view' => ['GET'],
            'update' => ['POST'],
        ];
    }
}