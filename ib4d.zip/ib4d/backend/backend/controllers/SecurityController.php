<?php

namespace backend\controllers;

use backend\events\security\AfterChangePasswordEventHandler;
use backend\events\security\AuditEventHandler;
use common\controllers\Controller;
use common\modules\password\actions\ChangePasswordAction;
use common\modules\password\actions\ResetPasswordAction;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\behaviors\IdentityRestrictBehavior;
use yii\base\Event;

class SecurityController extends Controller
{
    public function init(): void
    {
        parent::init();

        Event::on(
            BackUserPasswordService::class,
            BackUserPasswordService::EVENT_AFTER_CHANGE_PASSWORD,
            AfterChangePasswordEventHandler::get()
        );

        AuditEventHandler::subscribe(
            BackUserPasswordService::class,
            BackUserPasswordService::EVENT_AFTER_CHANGE_PASSWORD
        );
    }

    public function behaviors(): array
    {
        $behaviors = parent::behaviors();
        $behaviors[self::BEHAVIOR_AUTH_KEY]['except'] = ['reset-password'];

        return $behaviors;
    }

    public function beforeAction($action): bool
    {
        /** @var IdentityRestrictBehavior $behavior */
        $behavior = $this->getBehavior(self::BEHAVIOR_IDENTITY_RESTRICT_KEY);

        if ($action->id === 'change-password') {
            $behavior->removeRule(IdentityRestrictBehavior::RULE_IDENTITY_HAS_UNSAFE_PASSWORD);
        }

        return parent::beforeAction($action);
    }

    public function actions(): array
    {
        return [
            'change-password' => ChangePasswordAction::class,
            'reset-password' => ResetPasswordAction::class,
        ];
    }

    protected function verbs(): array
    {
        return [
            'change-password' => ['POST'],
            'reset-password' => ['POST'],
        ];
    }
}