<?php

namespace backend\controllers;

use backend\events\variable\AfterUpdateEventHandler;
use backend\events\variable\AuditEventHandler;
use backend\rbac\Role;
use common\controllers\Controller;
use common\modules\variable\actions\UpdateAction;
use common\modules\variable\actions\UploadAction;
use common\modules\variable\actions\ViewAction;
use common\modules\variable\services\VariableService;

class VariableController extends Controller
{
    public function init(): void
    {
        parent::init();

        AuditEventHandler::subscribe(VariableService::class, [
            VariableService::EVENT_AFTER_SET,
            VariableService::EVENT_AFTER_UNSET,
        ]);

        AfterUpdateEventHandler::subscribe(VariableService::class, [
            VariableService::EVENT_AFTER_SET,
            VariableService::EVENT_AFTER_UNSET,
        ]);
    }

    public function actions(): array
    {
        return [
            'update' => UpdateAction::class,
            'view' => ViewAction::class,
            'upload' => UploadAction::class,
        ];
    }

    protected function verbs(): array
    {
        return [
            'view' => ['GET'],
            'update' => ['POST'],
            'upload' => ['POST'],
        ];
    }

    protected function access(): array
    {
        return [
            [
                'allow' => true,
                'roles' => [Role::MASTER_ADMIN, Role::ADMIN],
            ]
        ];
    }
}