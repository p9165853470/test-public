<?php

namespace backend\controllers\profile;

use backend\forms\ProfileForm;
use backend\services\BackUserService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\BackUser;
use yii\base\Action;
use yii\web\BadRequestHttpException;
use yii\web\Request;

class UpdateAction extends Action
{
    /**
     * @var BackUserService
     */
    protected $service;

    public function __construct($id, $controller, BackUserService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param IdentityInterface|BackUser $identity
     * @param Request $request
     * @return ProfileForm|BackUser
     */
    public function run(IdentityInterface $identity, Request $request)
    {
        $form = new ProfileForm($identity);

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $this->service->update($identity, $form);

            return $identity;
        }
        return $form;
    }
}