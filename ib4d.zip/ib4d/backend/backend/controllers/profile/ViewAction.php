<?php

namespace backend\controllers\profile;

use backend\resources\ProfileResource;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\Action;

class ViewAction extends Action
{
    public function run(IdentityInterface $identity): ProfileResource
    {
        return new ProfileResource($identity);
    }
}