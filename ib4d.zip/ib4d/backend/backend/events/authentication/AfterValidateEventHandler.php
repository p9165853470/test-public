<?php

namespace backend\events\authentication;

use backend\services\BackUserService;
use common\events\EventHandler;
use common\models\errors\OfferToResetPasswordError;
use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\authentication\forms\CreateTokenForm;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\enums\BlockReasonEnum;
use common\modules\user\models\BackUser;
use yii\base\Event;

/**
 * Блокировка пользователя после череды неудачных попыток аутентификации
 */
final class AfterValidateEventHandler extends EventHandler
{
    public function __invoke(
        Event $e,
        BackUserService $service,
        BackUserPasswordService $passwordService,
        AuditService $auditService
    ) {
        if ($e->sender instanceof CreateTokenForm) {
            $identity = $e->sender->getIdentity();

            if ($identity instanceof BackUser && !$identity->hasBlock()) {
                if ($e->sender->hasErrors()) {
                    $identity->failed_auth_attempt_count++;
                } elseif ($identity->failed_auth_attempt_count > 0) {
                    $identity->failed_auth_attempt_count = 0;
                }

                if ($identity->failed_auth_attempt_count >= BackUser::FAILED_AUTH_ATTEMPT_LIMIT) {
                    $lastPassword = $passwordService->getRepository()->findLastByIdentity($identity);

                    if ($lastPassword !== null && $lastPassword->isManual()) {
                        $service->updateBlockReason($identity, BlockReasonEnum::BY_FAILED_AUTHENTICATION);
                        $auditService->audit(new IdentityAuditMessage(ActionEnum::BLOCK_STATE_CHANGE, $identity));
                    } else {
                        $e->sender->addError('login', new OfferToResetPasswordError());
                    }
                } elseif ($identity->isAttributeChanged('failed_auth_attempt_count')) {
                    $identity::getRepository()->save($identity);
                }
            }
        }
    }
}