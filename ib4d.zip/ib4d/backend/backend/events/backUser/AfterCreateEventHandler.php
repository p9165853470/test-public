<?php

namespace backend\events\backUser;

use backend\forms\BackUserForm;
use backend\rbac\Role;
use backend\services\BackUserService;
use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\mail\NewUserMessageComposer;
use common\modules\user\models\BackUser;
use yii\rbac\ManagerInterface;
use yii\web\Response;

/**
 * @see BackUserService
 */
final class AfterCreateEventHandler extends EventHandler
{
    public function __invoke(
        CrudServiceEvent $e,
        BackUserPasswordService $passwordService,
        ManagerInterface $authManager,
        Response $response
    ) {
        /** @var BackUser $identity */
        $identity = $e->model;
        /** @var BackUserForm $form */
        $form = $e->form;

        $passwordService->store($identity, $form->password, false);

        $authManager->assign(
            $authManager->getRole(Role::ADMIN), $identity->getId()
        );

        $response->on(Response::EVENT_AFTER_SEND, static function () use ($form) {
            NewUserMessageComposer::compose([
                'login' => $form->email,
                'password' => $form->password,
                'url' => \Yii::$app->params['backend.host'],
            ])->send($form->email);
        });
    }
}