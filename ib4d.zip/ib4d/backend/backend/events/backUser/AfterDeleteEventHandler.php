<?php

namespace backend\events\backUser;

use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\modules\user\models\BackUser;
use yii\rbac\ManagerInterface;

/**
 * После удаления системного пользователя откреплять от него роли/права
 */
final class AfterDeleteEventHandler extends EventHandler
{
    public function __invoke(CrudServiceEvent $e, ManagerInterface $authManager)
    {
        /** @var BackUser $model */
        $model = $e->model;

        $authManager->revokeAll($model->id);
    }
}