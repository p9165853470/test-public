<?php

namespace backend\events\backUser;

use backend\repositories\BackUserRepository;
use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\helpers\Filter;
use common\modules\password\helpers\PasswordGenerator;
use common\modules\password\mail\PasswordResetMessageComposer;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\models\BackUser;
use Yii;
use yii\web\Request;
use yii\web\Response;

class AfterUnblockAllEventHandler extends EventHandler
{
    public function __invoke(
        CrudServiceEvent $e,
        Request $request,
        Response $response,
        BackUserPasswordService $passwordService,
        BackUserRepository $userRepository
    ) {
        $ids = Filter::arrayOfInt($request->post('ids'));

        if (empty($ids)) {
            return;
        }

        $users = [];

        foreach ($userRepository->findAll($ids) as $user) {
            $password = PasswordGenerator::generate(BackUser::PASSWORD_LENGTH, BackUser::PASSWORD_GROUPS);
            $passwordService->change($user, $password);
            $passwordService->store($user, $password, false);

            $users[] = [
                'email' => $user->email,
                'password' => $password,
            ];
        }

        $response->on(Response::EVENT_AFTER_SEND, static function () use ($users) {
            foreach ($users as $user) {
                PasswordResetMessageComposer::compose([
                    'login' => $user['email'],
                    'password' => $user['password'],
                    'url' => Yii::$app->params['backend.host'],
                ])->send($user['email']);
            }
        });
    }
}