<?php

namespace backend\events\backUser;

use backend\services\BackUserService;
use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\ManageBackUserAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\BackUser;

class AuditEventHandler extends EventHandler
{
    /**
     * @param CrudServiceEvent $e
     * @param IdentityInterface|BackUser $identity
     * @param AuditService $auditService
     */
    public function __invoke(CrudServiceEvent $e, IdentityInterface $identity, AuditService $auditService)
    {
        /** @var BackUser|null $target */
        $target = $e->model;

        switch ($e->name) {
            case BackUserService::EVENT_AFTER_CREATE:
                $message = new ManageBackUserAuditMessage(ActionEnum::CREATE, $identity, $target);
                break;
            case BackUserService::EVENT_AFTER_UPDATE:
                $message = new ManageBackUserAuditMessage(ActionEnum::UPDATE, $identity, $target);
                break;
            case BackUserService::EVENT_AFTER_DELETE:
                $message = new ManageBackUserAuditMessage(ActionEnum::DELETE, $identity, $target);
                break;
            case BackUserService::EVENT_AFTER_DELETE_ALL:
                $message = new ManageBackUserAuditMessage(ActionEnum::DELETE_ALL, $identity, null);
                break;
            case BackUserService::EVENT_AFTER_BLOCK_ALL:
                $message = new ManageBackUserAuditMessage(ActionEnum::BLOCK_ALL, $identity, null);
                break;
            case BackUserService::EVENT_AFTER_UNBLOCK_ALL:
                $message = new ManageBackUserAuditMessage(ActionEnum::UNBLOCK_ALL, $identity, null);
                break;
            default:
                return;
        }

        $auditService->audit($message);
    }
}