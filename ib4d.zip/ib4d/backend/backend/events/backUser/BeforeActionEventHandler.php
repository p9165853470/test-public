<?php

namespace backend\events\backUser;

use common\events\EventHandler;
use common\helpers\Filter;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\ActionEvent;
use yii\web\ForbiddenHttpException;
use yii\web\Request;

/**
 * Запретить пользователю производить манипуляции с самим собой
 */
final class BeforeActionEventHandler extends EventHandler
{
    public function __invoke(ActionEvent $e, Request $request, IdentityInterface $identity)
    {
        if ($request->getIsPost()) {
            $id = (int)$request->get('id');
            $ids = Filter::arrayOfInt($request->post('ids'));

            if ($id === $identity->getId() || in_array($identity->getId(), $ids, true)) {
                throw new ForbiddenHttpException('Access denied.');
            }
        }
    }
}