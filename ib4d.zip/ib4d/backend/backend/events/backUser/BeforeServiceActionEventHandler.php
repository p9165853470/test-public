<?php

namespace backend\events\backUser;

use common\events\CrudActionEvent;
use common\events\EventHandler;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\BackUser;

/**
 * Запрерить пользователю управлять другими мастер-админами
 */
final class BeforeServiceActionEventHandler extends EventHandler
{
    public function __invoke(CrudActionEvent $e, IdentityInterface $identity)
    {
        if ($e->model instanceof BackUser && $e->model->isMaster()) {
            $e->isValid = false;
        }
    }
}