<?php

namespace backend\events\frontUser;

use backend\forms\FrontUserForm;
use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\modules\password\services\FrontUserPasswordService;
use common\modules\user\mail\NewUserMessageComposer;
use common\modules\user\models\FrontUser;
use yii\web\Response;

final class AfterCreateEventHandler extends EventHandler
{
    public function __invoke(
        CrudServiceEvent $e,
        FrontUserPasswordService $passwordService,
        Response $response
    ) {
        /** @var FrontUser $identity */
        $identity = $e->model;
        /** @var FrontUserForm $form */
        $form = $e->form;

        $passwordService->store($identity, $form->password, false);

        $response->on(Response::EVENT_AFTER_SEND, static function () use ($form) {
            NewUserMessageComposer::compose([
                'login' => $form->email,
                'password' => $form->password,
                'url' => \Yii::$app->params['frontend.host'],
            ])->send($form->email);
        });
    }
}