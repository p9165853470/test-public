<?php

namespace backend\events\frontUser;

use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\helpers\Filter;
use common\modules\password\helpers\PasswordGenerator;
use common\modules\password\mail\PasswordResetMessageComposer;
use common\modules\password\services\FrontUserPasswordService;
use common\modules\user\models\FrontUser;
use common\modules\user\repositories\FrontUserRepository;
use Yii;
use yii\web\Request;
use yii\web\Response;

class AfterUnblockAllEventHandler extends EventHandler
{
    public function __invoke(
        CrudServiceEvent $e,
        Request $request,
        Response $response,
        FrontUserPasswordService $passwordService,
        FrontUserRepository $userRepository
    ) {
        $ids = Filter::arrayOfInt($request->post('ids'));

        if (empty($ids)) {
            return;
        }

        $users = [];

        foreach ($userRepository->findAll($ids) as $user) {
            $password = PasswordGenerator::generate(FrontUser::PASSWORD_LENGTH, FrontUser::PASSWORD_GROUPS);
            $passwordService->change($user, $password);
            $passwordService->store($user, $password, false);

            $users[] = [
                'email' => $user->email,
                'password' => $password,
            ];
        }

        $response->on(Response::EVENT_AFTER_SEND, static function () use ($users) {
            foreach ($users as $user) {
                PasswordResetMessageComposer::compose([
                    'login' => $user['email'],
                    'password' => $user['password'],
                    'url' => Yii::$app->params['frontend.host'],
                ])->send($user['email']);
            }
        });
    }
}