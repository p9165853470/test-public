<?php

namespace backend\events\profile;

use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\user\models\BackUser;

class AuditEventHandler extends EventHandler
{
    public function __invoke(CrudServiceEvent $e, AuditService $auditService)
    {
        /** @var BackUser $initiator */
        $initiator = $e->model;

        $auditService->audit(new IdentityAuditMessage(ActionEnum::PROFILE_UPDATE, $initiator));
    }
}