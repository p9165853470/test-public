<?php

namespace backend\events\security;

use backend\controllers\ProfileController;
use backend\services\BackUserService;
use common\events\EventHandler;
use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\password\events\PasswordEvent;
use common\modules\password\mail\PasswordResetMessageComposer;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\enums\BlockReasonEnum;
use common\modules\user\models\BackUser;
use yii\web\Response;

/**
 * Добавить пароль в список и сделать профиль пользователя активным
 *
 * @see ProfileController
 */
final class AfterChangePasswordEventHandler extends EventHandler
{
    public function __invoke(
        PasswordEvent $e,
        Response $response,
        BackUserService $service,
        AuditService $auditService
    ) {
        /** @var BackUser $identity */
        $identity = $e->identity;
        $password = $e->password;

        $isManual = false;

        if ($e->context === BackUserPasswordService::CONTEXT_ACTION_CHANGE) {
            $isManual = true;
        } elseif ($e->context === BackUserPasswordService::CONTEXT_ACTION_RESET) {
            $response->on(Response::EVENT_AFTER_SEND, static function () use ($identity, $password) {
                PasswordResetMessageComposer::compose([
                    'login' => $identity->email,
                    'password' => $password,
                    'url' => \Yii::$app->params['backend.host'],
                ])->send($identity->email);
            });

            // Если пользвоатель был заблокирован по причине неудачных попыток авторизаций, то снять блокировку
            if ($identity->block_reason === BlockReasonEnum::BY_FAILED_AUTHENTICATION) {
                $service->updateBlockReason($identity, BlockReasonEnum::NO_REASON);
                $auditService->audit(new IdentityAuditMessage(ActionEnum::BLOCK_STATE_CHANGE, $identity));
            }
        }

        $identity->touch('updated_at');

        $e->sender->store($identity, $password, $isManual);
    }
}