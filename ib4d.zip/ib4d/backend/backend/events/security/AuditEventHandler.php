<?php

namespace backend\events\security;

use common\events\EventHandler;
use common\modules\audit\enum\ActionEnum;
use common\modules\audit\messages\IdentityAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\password\events\PasswordEvent;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\models\BackUser;

class AuditEventHandler extends EventHandler
{
    public function __invoke(PasswordEvent $e, AuditService $auditService)
    {
        /** @var BackUser $initiator */
        $initiator = $e->identity;

        switch ($e->context) {
            case BackUserPasswordService::CONTEXT_ACTION_CHANGE:
                $message = new IdentityAuditMessage(ActionEnum::CHANGE_PASSWORD, $initiator);
                break;
            case BackUserPasswordService::CONTEXT_ACTION_RESET:
                $message = new IdentityAuditMessage(ActionEnum::RESET_PASSWORD, $initiator);
                break;
            default:
                return;
        }

        $auditService->audit($message);
    }
}