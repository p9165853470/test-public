<?php

namespace backend\events\variable;

use common\events\EventHandler;
use common\modules\storage\services\FileService;
use common\modules\variable\behaviors\VariableSerializerInterface;
use common\modules\variable\events\VariableServiceEvent;

/**
 * Удалить файлы, которые больше не используются в тексте
 */
class AfterUpdateEventHandler extends EventHandler
{
    /**
     * @var VariableSerializerInterface
     */
    protected $serializer;
    /**
     * @var FileService
     */
    protected $fileService;

    public function __construct(VariableSerializerInterface $serializer, FileService $fileService)
    {
        $this->serializer = $serializer;
        $this->fileService = $fileService;
    }

    public function __invoke(VariableServiceEvent $e)
    {
        $data = $this->serializer->deserialize($e->model->value);

        if (!is_array($data) || !isset($data['text'])) {
            return;
        }

        foreach ($e->model->files as $file) {
            $path = parse_url($this->fileService->getStorage()->getUrl($file), PHP_URL_PATH);

            if (mb_strpos($data['text'], $path) === false) {
                $this->fileService->delete($file);
            }
        }
    }
}