<?php

namespace backend\events\variable;

use common\events\EventHandler;
use common\modules\audit\messages\VariableAuditMessage;
use common\modules\audit\services\AuditService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\BackUser;
use common\modules\variable\events\VariableServiceEvent;

class AuditEventHandler extends EventHandler
{
    /**
     * @param VariableServiceEvent $e
     * @param IdentityInterface|BackUser $identity
     * @param AuditService $auditService
     */
    public function __invoke(VariableServiceEvent $e, IdentityInterface $identity, AuditService $auditService)
    {
        $auditService->audit(new VariableAuditMessage($e->model->key, $identity));
    }
}