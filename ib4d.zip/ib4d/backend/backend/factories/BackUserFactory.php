<?php

namespace backend\factories;

use backend\forms\BackUserForm;
use backend\search\BackUserSearch;
use common\behaviors\FormProviderInterface;
use common\behaviors\FormProviderTrait;
use common\behaviors\SearchProviderInterface;
use common\behaviors\SearchProviderTrait;
use yii\db\ActiveRecord;

class BackUserFactory implements FormProviderInterface, SearchProviderInterface
{
    use FormProviderTrait;
    use SearchProviderTrait;

    protected function getFormClass(): string
    {
        return BackUserForm::class;
    }

    protected function getSearchClass(): string
    {
        return BackUserSearch::class;
    }
}