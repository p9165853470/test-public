<?php

namespace backend\factories;

use backend\forms\FrontUserForm;
use backend\search\FrontUserSearch;
use common\behaviors\FormProviderInterface;
use common\behaviors\FormProviderTrait;
use common\behaviors\SearchProviderInterface;
use common\behaviors\SearchProviderTrait;

class FrontUserFactory implements FormProviderInterface, SearchProviderInterface
{
    use FormProviderTrait;
    use SearchProviderTrait;

    protected function getFormClass(): string
    {
        return FrontUserForm::class;
    }

    protected function getSearchClass(): string
    {
        return FrontUserSearch::class;
    }
}