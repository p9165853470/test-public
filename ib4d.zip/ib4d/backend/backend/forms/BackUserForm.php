<?php

namespace backend\forms;

use backend\repositories\BackUserRepository;
use common\forms\Form;
use common\models\errors\AdminEmailAlreadyExistsError;
use common\models\errors\EmailDiasoftIdAlreadyExistsError;
use common\modules\password\helpers\PasswordGenerator;
use common\modules\user\models\BackUser;
use common\modules\user\repositories\FrontUserRepository;
use yii\db\ActiveQuery;
use yii\di\Instance;

/**
 * @method BackUser getModel()
 */
class BackUserForm extends Form
{
    /**
     * @var string
     */
    public $email;
    /**
     * @var string
     */
    public $password;
    /**
     * @var string
     */
    public $first_name;
    /**
     * @var string
     */
    public $middle_name;
    /**
     * @var string
     */
    public $last_name;

    public function scenarios(): array
    {
        $scenarios = parent::scenarios();

        // Сделать поле password небезопасным для присваивания
        $scenarios[self::SCENARIO_CREATE] = array_diff($scenarios[self::SCENARIO_CREATE], ['password']);
        $scenarios[self::SCENARIO_CREATE][] = '!password';

        $attributes = $scenarios[$this->getScenario()];
        $attributes = array_diff($attributes, ['first_name', 'middle_name', 'last_name']);
        $scenarios[$this->getScenario()] = array_merge($attributes, ['!first_name', '!middle_name', '!last_name']);

        return $scenarios;
    }

    public function rules(): array
    {
        return [
            ['name', 'safe'],
            [['email', 'first_name', 'middle_name', 'last_name'], 'required'],
            ['email', 'string', 'max' => 128],
            ['email', 'email'],
            [['first_name', 'middle_name', 'last_name'], 'string', 'max' => 128],
            [
                'email',
                function () {
                    /** @var BackUserRepository $repository */
                    $repository = Instance::ensure(BackUserRepository::class);
                    if ($repository->existsEmail($this->email, $this->hasModel() ? $this->getModel()->id : null)) {
                        $this->addError('email', new AdminEmailAlreadyExistsError());
                    }
                }
            ],
            [
                'password',
                'filter',
                'filter' => static function () {
                    return PasswordGenerator::generate(
                        BackUser::PASSWORD_LENGTH,
                        BackUser::PASSWORD_GROUPS
                    );
                },
                'on' => self::SCENARIO_CREATE,
            ],
        ];
    }

    public function setName(string $name): void
    {
        $parts = explode(' ', $name);

        $this->last_name = trim($parts[0] ?? '');
        $this->first_name = trim($parts[1] ?? '');
        $this->middle_name = trim($parts[2] ?? '');
    }

    public function getName(): string
    {
        $parts = [
            $this->last_name,
            $this->first_name,
            $this->middle_name,
        ];

        $parts = array_filter($parts, static function ($part) {
            return (string)$part !== '';
        });

        return implode(' ', $parts);
    }
}