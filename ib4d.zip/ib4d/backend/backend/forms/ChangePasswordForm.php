<?php

namespace backend\forms;

use common\models\errors\FrequentPasswordChangesError;
use common\models\errors\ReUsingPasswordError;
use common\modules\password\models\BackUserPassword;
use common\modules\password\services\BackUserPasswordService;
use common\modules\password\validators\PasswordValidator;
use common\modules\user\models\BackUser;

class ChangePasswordForm extends \common\modules\password\forms\ChangePasswordForm
{
    public function rules(): array
    {
        return array_merge(parent::rules(), [
            [
                'new_password',
                function () {
                    $model = BackUserPasswordService::instance()->getRepository()->findLastByIdentity($this->identity);
                    $interval = new \DateInterval(BackUserPassword::MANUAL_PASSWORDS_INTERVAL);

                    if ($model !== null && $model->isManual() && $model->getDate() > date_create()->sub($interval)) {
                        $this->addError('new_password', new FrequentPasswordChangesError());
                    }
                }
            ],
            ['new_password', PasswordValidator::class, 'min' => BackUser::PASSWORD_LENGTH],
            [
                'new_password',
                function () {
                    if (!BackUserPasswordService::instance()->validate($this->identity, $this->new_password)) {
                        $this->addError('new_password', new ReUsingPasswordError());
                    }
                }
            ]
        ]);
    }
}