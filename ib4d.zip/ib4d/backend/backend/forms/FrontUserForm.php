<?php

namespace backend\forms;

use common\forms\Form;
use common\helpers\Date;
use common\models\errors\EmailAlreadyExistsError;
use common\modules\password\helpers\PasswordGenerator;
use common\modules\user\models\Dealer;
use common\modules\user\models\FrontUser;
use common\modules\user\repositories\FrontUserRepository;
use yii\di\Instance;
use yii\validators\DateValidator;
use yii\validators\RequiredValidator;
use yii\validators\Validator;

/**
 * @method FrontUser|null getModel()
 */
class FrontUserForm extends Form
{
    /**
     * @var string
     */
    public $email;
    /**
     * @var string
     */
    public $password;
    /**
     * @var string
     */
    public $first_name;
    /**
     * @var string
     */
    public $middle_name;
    /**
     * @var string
     */
    public $last_name;
    /**
     * @var string
     */
    public $phone_number;
    /**
     * @var string
     */
    public $key_word;
    /**
     * @var Dealer[]
     */
    public $dealers;
    

    public function scenarios(): array
    {
        $scenarios = parent::scenarios();

        // Сделать поле password небезопасным для присваивания
        $scenarios[self::SCENARIO_CREATE] = array_diff($scenarios[self::SCENARIO_CREATE], ['password']);
        $scenarios[self::SCENARIO_CREATE][] = '!password';

        $attributes = $scenarios[$this->getScenario()];
        $attributes = array_diff($attributes, ['first_name', 'middle_name', 'last_name']);
        $scenarios[$this->getScenario()] = array_merge($attributes, ['!first_name', '!middle_name', '!last_name']);

        return $scenarios;
    }

    public function rules(): array
    {
        return [
            ['name', 'safe'],
            [['email', 'first_name', 'last_name'], 'required'],
            ['email', 'string', 'max' => 128],
            ['email', 'email'],
            [['first_name', 'middle_name', 'last_name'], 'string', 'max' => 80],
            ['middle_name', 'default'],
            // TODO раньше здесь была проверка на уникальность пары (email, diasoftId). восстановить проверку, но теперь тянуть diasoftId из другой таблицы
            [
                'email',
                function () {
                    /** @var FrontUserRepository $repository */
                    $repository = Instance::ensure(FrontUserRepository::class);
                    if ($repository->existsEmail($this->email, $this->hasModel() ? $this->getModel()->id : null)) {
                        $this->addError('email', new EmailAlreadyExistsError());
                    }
                }
            ],
            [
                'password',
                'filter',
                'filter' => static function () {
                    return PasswordGenerator::generate(
                        FrontUser::PASSWORD_LENGTH,
                        FrontUser::PASSWORD_GROUPS
                    );
                },
                'on' => self::SCENARIO_CREATE,
            ],
            ['phone_number', 'safe'],
            ['key_word', 'safe'],
            ['dealers', 'each', 'rule' => [
                DealerValidator::class
            ]]
            
        ];
    }

    public function setName(string $name): void
    {
        $parts = explode(' ', $name);

        $this->last_name = trim($parts[0] ?? '');
        $this->first_name = trim($parts[1] ?? '');
        $this->middle_name = trim($parts[2] ?? '');
    }

    public function getName(): string
    {
        $parts = [
            $this->last_name,
            $this->first_name,
            $this->middle_name,
        ];

        $parts = array_filter($parts, static function ($part) {
            return (string)$part !== '';
        });

        return implode(' ', $parts);
    }
}


/**
 * Class DealerValidator
 * Валидация вложенной формы. Эквивалент для правил валидации формы:
 * public function rules(): array {
 *   return [
 *     [['authority_begin_date', 'authority_end_date'], 'required'],
 *     [['authority_begin_date', 'authority_end_date'], 'date', 'format' => 'php:' . Date::INTERNAL_DATE_FORMAT],
 *     ['authority_end_date', 'compare', 'compareAttribute' => 'authority_begin_date', 'operator' => '>']
 *   ];
 * }
 * @package backend\forms
 */
class DealerValidator extends Validator
{
    public function validateAttribute($model, $attribute)
    {
        $dealer = $model['dealers'];

        $v = new RequiredValidator();
        
        $fieldName = 'authority_begin_date';
        $f = array_key_exists($fieldName, $dealer) ? $dealer[$fieldName] : null;
        $result = $v->validateValue($f);
        if (!empty($result)) {
            $model->addError($attribute, $fieldName . ' cannot be blank.');
        }

        $fieldName = 'authority_end_date';
        $f = array_key_exists($fieldName, $dealer) ? $dealer[$fieldName] : null;
        $result = $v->validateValue($f);
        if (!empty($result)) {
            $model->addError($attribute, $fieldName . ' cannot be blank.');
        }

        $v = new DateValidator(['format' => 'php:' . Date::INTERNAL_DATE_FORMAT]);
        
        $fieldName = 'authority_begin_date';
        $f = array_key_exists($fieldName, $dealer) ? $dealer[$fieldName] : null;
        $result = $v->validateValue($f);
        if (!empty($result)) {
            $model->addError($attribute, 'The format of ' . $fieldName . ' is invalid.');
        }

        $fieldName = 'authority_end_date';
        $f = array_key_exists($fieldName, $dealer) ? $dealer[$fieldName] : null;
        $result = $v->validateValue($f);
        if (!empty($result)) {
            $model->addError($attribute, 'The format of ' . $fieldName . ' is invalid.');
        }

        $fieldName1 = 'authority_begin_date';
        $fieldName2 = 'authority_end_date';
        $f1 = $dealer[$fieldName1];
        $f2 = $dealer[$fieldName2];
        if ($f1 >= $f2) {
            $model->addError($attribute,  $fieldName2 . ' must be greater than ' . $fieldName1);
        }
        
    }
}