<?php

namespace backend\forms;

use common\forms\Form;
use common\modules\user\models\BackUser;

/**
 * @method BackUser|null getModel()
 */
class ProfileForm extends Form
{
    /**
     * @var string
     */
    public $first_name;
    /**
     * @var string
     */
    public $middle_name;
    /**
     * @var string
     */
    public $last_name;

    public function rules(): array
    {
        return [
            [['first_name', 'last_name'], 'required'],
            ['middle_name', 'default'],
            [['first_name', 'middle_name', 'last_name'], 'string', 'max' => 128],
        ];
    }
}