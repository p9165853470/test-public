<?php

namespace backend\forms;

use common\modules\password\helpers\PasswordGenerator;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\BackUser;

class ResetPasswordForm extends \common\modules\password\forms\ResetPasswordForm
{
    protected function findIdentity(): ?IdentityInterface
    {
        return BackUser::findIdentityByLogin($this->login);
    }

    public function getPassword(): string
    {
        return PasswordGenerator::generate(
            BackUser::PASSWORD_LENGTH,
            BackUser::PASSWORD_GROUPS
        );
    }
}