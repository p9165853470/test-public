<?php

namespace backend\rbac;

use console\components\RbacMapper;

class Mapper extends RbacMapper
{
    public function items(): array
    {
        return [
            $this->role(Role::ADMIN),
            $this->role(Role::MASTER_ADMIN),
        ];
    }

    public function rules(): array
    {
        return [];
    }
}