<?php

namespace backend\rbac;

class Role
{
    /**
     * Администратор системных пользователей
     */
    public const MASTER_ADMIN = 'master-admin';
    /**
     * Администратор (системный пользователь)
     */
    public const ADMIN = 'admin';
}