<?php

namespace backend\repositories;

use common\helpers\Date;
use common\modules\user\models\BackUser;

class BackUserRepository extends \common\modules\user\repositories\BackUserRepository
{
    public function updateBlockAll(array $ids, int $reason): int
    {
        return BackUser::updateAll([
            'block_reason' => $reason,
            'updated_at' => date_create()->format(Date::INTERNAL_DATETIME_FORMAT),
        ], [
            'and',
            ['id' => $ids],
            ['!=', 'block_reason', $reason]
        ]);
    }
}