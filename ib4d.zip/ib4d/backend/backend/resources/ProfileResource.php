<?php

namespace backend\resources;

use common\helpers\Date;
use common\modules\password\models\BackUserPassword;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\models\BackUser;
use common\resources\Resource;

class ProfileResource extends Resource
{
    /**
     * @var BackUser
     */
    protected $resource;

    protected function properties(): array
    {
        $fields = $this->resource->fields();
        $fields['password_unsafe_at'] = static function (BackUser $user) {
            $password = BackUserPasswordService::instance()->getRepository()->findLastByIdentity($user);

            if ($password === null || !$password->isManual()) {
                return date_create()->format(Date::INTERNAL_DATETIME_FORMAT);
            }

            $interval = new \DateInterval(BackUserPassword::PASSWORD_UNSAFE_INTERVAL);

            return date_create($password->created_at)->add($interval)->format(Date::INTERNAL_DATETIME_FORMAT);
        };

        return $fields;
    }
}