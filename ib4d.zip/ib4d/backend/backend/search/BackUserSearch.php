<?php

namespace backend\search;

use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\BackUser;
use common\modules\user\scopes\BackUserQuery;
use common\search\Search;

class BackUserSearch extends Search
{
    /**
     * @var string
     */
    public $name;
    /**
     * @var string
     */
    public $email;
    /**
     * @var IdentityInterface
     */
    private $identity;

    public function __construct(IdentityInterface $identity, $config = [])
    {
        $this->identity = $identity;

        parent::__construct($config);
    }

    public function rules(): array
    {
        return [
            [$this->attributes(), 'trim'],
        ];
    }

    protected function query(): BackUserQuery
    {
        return BackUser::getRepository()->find();
    }

    /**
     * @param BackUserQuery $query
     */
    protected function applyFilter($query): void
    {
        $query
            ->andWhere(['master' => false])
            ->andWhere(['!=', 'id', $this->identity->getId()])
            ->andFilterWhere(['ILIKE', 'email', $this->email])
        ;

        if ($this->name !== null) {
            $name = mb_strtolower($this->name);
            $name = str_replace('ё', 'е', $name);
            $name = preg_replace('/\s+/u', ' ', $name);

            $query->andWhere('[[search_name]] LIKE :name', ['name' => "%{$name}%"]);
        }
    }
}