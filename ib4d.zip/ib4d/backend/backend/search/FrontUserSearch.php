<?php

namespace backend\search;

use common\modules\user\models\FrontUser;
use common\modules\user\scopes\FrontUserQuery;
use common\search\Search;

class FrontUserSearch extends Search
{
    /**
     * @var string
     */
    public $name;
    /**
     * @var string
     */
    public $email;
    /**
     * @var string
     */
    public $phone_number;

    public function rules(): array
    {
        return [
            [$this->attributes(), 'trim'],
        ];
    }

    protected function query(): FrontUserQuery
    {
        return FrontUser::getRepository()->find();
    }

    /**
     * @param FrontUserQuery $query
     */
    protected function applyFilter($query): void
    {
        $query
            ->andFilterWhere(['ILIKE', 'email', $this->email]);

        if ($this->name !== null && $this->name !== '') {
            $name = mb_strtolower($this->name);
            $name = str_replace('ё', 'е', $name);
            $name = preg_replace('/\s+/u', ' ', $name);

            $query->andWhere('[[search_name]] LIKE :name', ['name' => "%{$name}%"]);
        }

        if ($this->phone_number !== null && $this->phone_number !== '') {
            $query->andWhere(['ILIKE', 'phone_number', $this->phone_number]);
        }
    }
}