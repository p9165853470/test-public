<?php

namespace backend\services;

use backend\behaviors\BlockServiceInterface;
use backend\factories\BackUserFactory;
use backend\repositories\BackUserRepository;
use common\events\CrudServiceEvent;
use common\modules\user\enums\BlockReasonEnum;
use common\modules\user\models\BackUser;
use common\services\CrudService;

/**
 * @method BackUser get($id)
 * @method BackUser[] getAll()
 * @method BackUserRepository getRepository()
 * @method BackUserFactory getFactory()
 */
class BackUserService extends CrudService implements BlockServiceInterface
{
    /**
     * @var BackUserRepository
     */
    protected $repository;
    /**
     * @var BackUserFactory
     */
    protected $factory;

    public function __construct(
        BackUserRepository $repository,
        BackUserFactory $factory
    ) {
        $this->repository = $repository;
        $this->factory = $factory;
    }

    public function updateBlockReason(BackUser $user, int $reason): void
    {
        if ($user->block_reason !== $reason) {
            $block = $reason !== BlockReasonEnum::NO_REASON;

            if (!$block && $user->block_reason === BlockReasonEnum::BY_FAILED_AUTHENTICATION) {
                $user->failed_auth_attempt_count = 0;
            }

            $user->block_reason = $reason;

            $this->repository->save($user);
        }
    }

    public function blockAll(array $ids): void
    {
        $result = $this->repository->updateBlockAll($ids, BlockReasonEnum::BY_ADMIN);

        $this->trigger(self::EVENT_AFTER_BLOCK_ALL, new CrudServiceEvent([
            'affectedRowsCount' => $result,
        ]));
    }

    public function unblockAll(array $ids): void
    {
        $result = $this->repository->updateBlockAll($ids, BlockReasonEnum::NO_REASON);

        $this->trigger(self::EVENT_AFTER_UNBLOCK_ALL, new CrudServiceEvent([
            'affectedRowsCount' => $result,
        ]));
    }
}