<?php

namespace backend\services;

use backend\behaviors\BlockServiceInterface;
use backend\factories\FrontUserFactory;
use common\events\CrudServiceEvent;
use common\modules\user\enums\BlockReasonEnum;
use common\modules\user\models\FrontUser;
use common\modules\user\repositories\FrontUserRepository;
use common\services\CrudService;

/**
 * @method FrontUser get($id)
 * @method FrontUser[] getAll()
 * @method FrontUserRepository getRepository()
 * @method FrontUserFactory getFactory()
 */
class FrontUserService extends CrudService implements BlockServiceInterface
{
    /**
     * @var FrontUserRepository
     */
    protected $repository;
    /**
     * @var FrontUserFactory
     */
    protected $factory;

    public function __construct(
        FrontUserRepository $repository,
        FrontUserFactory $factory
    ) {
        $this->repository = $repository;
        $this->factory = $factory;
    }

    public function blockAll(array $ids): void
    {
        $result = $this->repository->updateBlockAll($ids, BlockReasonEnum::BY_ADMIN);

        $this->trigger(self::EVENT_AFTER_BLOCK_ALL, new CrudServiceEvent([
            'affectedRowsCount' => $result,
        ]));
    }

    public function unblockAll(array $ids): void
    {
        $result = $this->repository->updateBlockAll($ids, BlockReasonEnum::NO_REASON);

        $this->trigger(self::EVENT_AFTER_UNBLOCK_ALL, new CrudServiceEvent([
            'affectedRowsCount' => $result,
        ]));
    }
}