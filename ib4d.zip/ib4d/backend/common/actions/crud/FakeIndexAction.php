<?php

namespace common\actions\crud;

use yii\data\DataProviderInterface;
use yii\web\Request;

use Yii;
use yii\data\ArrayDataProvider;

class FakeIndexAction extends Action
{
    public function run(Request $request): DataProviderInterface
    {
        $data = [
            [
                'id' => 1,
                'email' => 'TverdovaNM@rusfinance.ru',
                'first_name' => 'Natalya',
                'middle_name' => 'Mikhaylovna',
                'last_name' => 'Tverdova',
                'phone_number' => '79151234567',
                'key_word' => 'Мурка',
                'created_at' => '2020-11-13 06:15:24',
                'updated_at' => '2021-02-16 12:19:26',
                'block_reason' => 0,
                'active' => true,
                'dealers' => [
                    [
                        'diasoft_id' => '2845QW5T',
                        'authority_begin_date' => '2020-11-12',
                        'authority_end_date' => '2021-11-19',
                        'agreement_at' => '2020-11-16 11:39:34',
                        'validated_at' => '2020-11-16 11:39:04',
                    ],
                    [
                        'diasoft_id' => '12345678',
                        'authority_begin_date' => '2020-11-13',
                        'authority_end_date' => '2021-11-20',
                        'agreement_at' => '2020-11-17 11:39:34',
                        'validated_at' => '2020-11-17 11:39:04',
                    ],
                    [
                        'diasoft_id' => '87654321',
                        'authority_begin_date' => '2020-11-14',
                        'authority_end_date' => '2021-11-21',
                        'agreement_at' => '2020-11-18 11:39:34',
                        'validated_at' => '2020-11-18 11:39:04',
                    ]
                ]
            ],
            [
                'id' => 1,
                'email' => 'IvanovII@rusfinance.ru',
                'first_name' => 'Ivan',
                'middle_name' => 'Ivanovich',
                'last_name' => 'Ivanov',
                'phone_number' => '79159876543',
                'key_word' => 'Алладин',
                'created_at' => '2020-11-13 06:15:24',
                'updated_at' => '2021-02-16 12:19:26',
                'block_reason' => 0,
                'active' => true,
                'dealers' => [
                    [
                        'diasoft_id' => '2845QW5T',
                        'authority_begin_date' => '2020-11-12',
                        'authority_end_date' => '2021-11-19',
                        'agreement_at' => '2020-11-16 11:39:34',
                        'validated_at' => '2020-11-16 11:39:04',
                    ],
                    [
                        'diasoft_id' => '12345678',
                        'authority_begin_date' => '2020-11-13',
                        'authority_end_date' => '2021-11-20',
                        'agreement_at' => '2020-11-17 11:39:34',
                        'validated_at' => '2020-11-17 11:39:04',
                    ]
                ]
            ]
        ];
        return new ArrayDataProvider([
            'allModels' => $data,
            'pagination' => [
                'pageSize' => 10,
            ],
            'sort' => [
                'attributes' => ['id', 'name'],
            ],
        ]);
    }
}