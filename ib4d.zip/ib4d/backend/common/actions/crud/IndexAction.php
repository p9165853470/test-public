<?php

namespace common\actions\crud;

use yii\data\DataProviderInterface;
use yii\web\Request;

class IndexAction extends Action
{
    public function run(Request $request): DataProviderInterface
    {
        $searchModel = $this->service->search();

        if (!$this->beforeServiceAction(null, null)) {
            $this->handleFailure();
        }

        return $searchModel->search($request->queryParams);
    }
}