<?php

namespace common\actions\crud;

use common\exceptions\NotFoundModelException;
use yii\db\ActiveRecord;

class ViewAction extends Action
{
    /**
     * @param $id
     * @return ActiveRecord
     * @throws NotFoundModelException
     */
    public function run($id)
    {
        $model = $this->service->get($id);

        if (!$this->beforeServiceAction($model, null)) {
            $this->handleFailure();
        }

        return $model;
    }
}