<?php

namespace common\behaviors;

trait FormProviderTrait
{
    abstract protected function getFormClass(): string;

    public function getForm($model = null)
    {
        return \Yii::createObject($this->getFormClass(), [$model]);
    }
}