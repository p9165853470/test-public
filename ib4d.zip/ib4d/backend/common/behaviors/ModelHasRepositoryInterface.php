<?php

namespace common\behaviors;

use common\repositories\Repository;

interface ModelHasRepositoryInterface
{
    /**
     * @return Repository
     */
    public static function getRepository();
}