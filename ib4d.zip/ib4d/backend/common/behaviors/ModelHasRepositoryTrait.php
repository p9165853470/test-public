<?php

namespace common\behaviors;

use common\repositories\Repository;
use yii\di\Instance;

trait ModelHasRepositoryTrait
{
    abstract public static function getRepositoryClass(): string;

    /**
     * @return Repository|object
     */
    public static function getRepository()
    {
        return Instance::ensure(static::getRepositoryClass());
    }
}