<?php

namespace common\behaviors;

use common\search\Search;

interface SearchProviderInterface
{
    /**
     * @return Search
     */
    public function getSearch();
}