<?php

namespace common\behaviors;

trait SearchProviderTrait
{
    abstract protected function getSearchClass(): string;

    public function getSearch()
    {
        return \Yii::createObject($this->getSearchClass());
    }
}