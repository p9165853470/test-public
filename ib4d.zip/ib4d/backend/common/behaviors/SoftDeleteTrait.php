<?php

namespace common\behaviors;

trait SoftDeleteTrait
{
    public static function softDeleteAttribute(): string
    {
        return 'deleted_at';
    }

    public function isSoftDeleted(): bool
    {
        return $this->{static::softDeleteAttribute()} !== null;
    }
}