<?php

namespace common\bootstrap;

use ProxyManager\Factory\LazyLoadingValueHolderFactory;

class CommonBootstrap implements \yii\base\BootstrapInterface
{
    /**
     * @param \yii\web\Application|\yii\console\Application $app
     */
    public function bootstrap($app): void
    {
        \Yii::$container->setSingletons([
            /*
             * Проксирования объекта сущности авторизованного пользователя.
             * Используется для того, чтобы можно было внедрять объект в конструкторы классов,
             * которые инициализируются еще до того, как сущность пользователя будет загружена по токену
             */
            \common\modules\user\behaviors\IdentityInterface::class => static function () use ($app) {
                $factory = new LazyLoadingValueHolderFactory();

                return $factory->createProxy(
                    $app->getUser()->identityClass,
                    static function (&$wrappedObject, $proxy, $method, $parameters, &$initializer) use ($app) {
                        $wrappedObject = $app->getUser()->getIdentity();
                        $initializer = null;
                    }
                );
            },
            \yii\mail\MailerInterface::class => static function () use ($app) {
                return $app->getMailer();
            },
            \yii\rbac\ManagerInterface::class => static function () use ($app) {
                return $app->getAuthManager();
            }
        ]);
    }
}