<?php
Yii::setAlias('@common', dirname(__DIR__));
Yii::setAlias('@frontend', dirname(__DIR__, 2) . '/frontend');
Yii::setAlias('@backend', dirname(__DIR__, 2) . '/backend');
Yii::setAlias('@console', dirname(__DIR__, 2) . '/console');

Yii::$container->setDefinitions([
    \common\modules\authentication\behaviors\AuthenticationServiceInterface::class => \common\modules\authentication\services\AuthenticationService::class,
    \common\modules\authentication\behaviors\TokenServiceInterface::class => \common\modules\authentication\services\JwtTokenService::class,
    \common\modules\variable\behaviors\VariableSerializerInterface::class => \common\modules\variable\services\VariableSerializer::class,
    \common\modules\variable\behaviors\VariableFactoryInterface::class => \common\modules\variable\factories\VariableFactory::class,
    \common\modules\rfinfo\behaviors\RequestServiceInterface::class => \common\modules\rfinfo\services\RFInfoRequestService::class,
    \common\modules\rfinfo\behaviors\ResponseServiceInterface::class => \common\modules\rfinfo\services\ResponseService::class,
    \common\modules\rfinfo\behaviors\ResponseResourceInterface::class => \common\modules\rfinfo\resources\ResponseResource::class,
    \common\modules\audit\behaviors\AuditTargetInterface::class => \common\modules\audit\services\AuditFileTarget::class,
    \common\modules\storage\behaviors\FileStorageInterface::class => \common\modules\storage\services\FrontFileStorage::class,
]);