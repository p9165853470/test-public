<?php

return [
    'aliases' => [
        '@bower' => '@vendor/bower-asset',
        '@npm' => '@vendor/npm-asset',
    ],
    'vendorPath' => dirname(__DIR__, 2) . '/vendor',
    'bootstrap' => [
        \common\bootstrap\CommonBootstrap::class,
    ],
    'container' => [
        'definitions' => [
            \cornernote\softdelete\SoftDeleteBehavior::class => [
                'value' => static function () {
                    return date(\common\helpers\Date::INTERNAL_DATETIME_FORMAT);
                }
            ],
            \yii\behaviors\TimestampBehavior::class => [
                'value' => static function () {
                    return date(\common\helpers\Date::INTERNAL_DATETIME_FORMAT);
                }
            ],
        ],
    ],
    'components' => [
        'db' => [
            'class' => \yii\db\Connection::class,
            'dsn' => getenv('db_dsn'),
            'username' => getenv('db_username'),
            'password' => getenv('db_password'),
            'charset' => getenv('db_charset'),
            'schemaMap' => [
                'pgsql' => [
                    'class' => \yii\db\pgsql\Schema::class,
                    'defaultSchema' => 'public'
                ]
            ],
        ],
        'cache' => [
            'class' => \yii\caching\FileCache::class,
        ],
    ],
];
