<?php

namespace common\controllers;

use bizley\jwt\JwtHttpBearerAuth;
use common\components\Serializer;
use common\enums\MimeTypeEnum;
use common\modules\session\behaviors\SessionTouchBehavior;
use common\modules\user\behaviors\IdentityRestrictBehavior;
use yii\filters\AccessControl;
use yii\filters\Cors;
use yii\web\Response;

abstract class Controller extends \yii\rest\Controller
{
    protected const BEHAVIOR_CORS_KEY = 'cors';
    protected const BEHAVIOR_AUTH_KEY = 'authenticator';
    protected const BEHAVIOR_SESSION_TOUCH_KEY = 'sessionTouch';
    protected const BEHAVIOR_IDENTITY_RESTRICT_KEY = 'identityRestrict';
    protected const BEHAVIOR_ACCESS_CONTROL_KEY = 'accessControl';
    protected const BEHAVIOR_VERB_FILTER_KEY = 'verbFilter';
    protected const BEHAVIOR_CONTENT_NEGOTIATOR_KEY = 'contentNegotiator';

    public $serializer = Serializer::class;

    public function behaviors(): array
    {
        $behaviors = [];

        $verbs = array_map(static function ($verbs) {
            if (!in_array('OPTIONS', $verbs, true)) {
                $verbs[] = 'OPTIONS';
            }
            return $verbs;
        }, $this->verbs());

        $behaviors[self::BEHAVIOR_CORS_KEY] = [
            'class' => Cors::class,
            'cors' => [
                'Origin' => [
                    \Yii::$app->params['backend.host'],
                    \Yii::$app->params['frontend.host'],
                ],
                'Access-Control-Request-Method' => ['GET', 'POST', 'OPTIONS'],
                'Access-Control-Request-Headers' => ['*'],
                'Access-Control-Expose-Headers' => ['*'],
            ],
            'actions' => array_map(static function ($verbs) {
                return ['Access-Control-Request-Method' => $verbs];
            }, $verbs),
        ];

        $behaviors = array_merge($behaviors, parent::behaviors());

        $behaviors[self::BEHAVIOR_CONTENT_NEGOTIATOR_KEY]['formats'][MimeTypeEnum::XLSX] = Response::FORMAT_RAW;
        $behaviors[self::BEHAVIOR_CONTENT_NEGOTIATOR_KEY]['formats'][MimeTypeEnum::TXT] = Response::FORMAT_RAW;

        $behaviors[self::BEHAVIOR_VERB_FILTER_KEY]['actions'] = $verbs;

        $behaviors[self::BEHAVIOR_AUTH_KEY] = [
            'class' => JwtHttpBearerAuth::class,
        ];

        $behaviors[self::BEHAVIOR_IDENTITY_RESTRICT_KEY] = [
            'class' => IdentityRestrictBehavior::class,
            'rules' => [
                IdentityRestrictBehavior::RULE_IDENTITY_BLOCK,
                IdentityRestrictBehavior::RULE_IDENTITY_ACTIVE,
                IdentityRestrictBehavior::RULE_IDENTITY_HAS_UNSAFE_PASSWORD,
            ]
        ];

        if ($access = $this->access()) {
            $behaviors[self::BEHAVIOR_ACCESS_CONTROL_KEY] = [
                'class' => AccessControl::class,
                'rules' => $access,
            ];
        }

        $behaviors[self::BEHAVIOR_SESSION_TOUCH_KEY] = [
            'class' => SessionTouchBehavior::class,
        ];

        return $behaviors;
    }

    protected function access(): array
    {
        return [];
    }
}