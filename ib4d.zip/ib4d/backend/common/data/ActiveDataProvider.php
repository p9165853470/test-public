<?php

namespace common\data;

use common\resources\Resource;

class ActiveDataProvider extends \yii\data\ActiveDataProvider
{
    /**
     * @var string|Resource
     */
    public $resourceClass;

    protected function prepareModels(): array
    {
        $models = parent::prepareModels();

        if ($this->resourceClass !== null) {
            return $this->resourceClass::collection($models);
        }
        return $models;
    }
}