<?php

namespace common\enums;

use common\behaviors\EnumTrait;

class ErrorEnum
{
    use EnumTrait;

    public const DEFAULT = 0;
    public const IDENTITY_NOT_FOUND = 1000;
    public const IDENTITY_IS_BLOCKED = 1001;
    public const IDENTITY_BLOCKED_BY_ADMIN = 1002;
    public const IDENTITY_BLOCKED_BY_FAILED_AUTHENTICATION = 1003;
    public const IDENTITY_IS_NOT_ACTIVE = 1010;
    public const IDENTITY_HAS_UNSAFE_PASSWORD = 1020;
    public const IDENTITY_IS_NOT_VALIDATED = 1030;
    public const IDENTITY_PHONE_IS_NOT_VALIDATED = 1031;
    public const IDENTITY_IDENTITY_IS_NOT_CONFIRMED = 1032;
    public const IDENTITY_IDENTITY_MISSING_DIASOFT_ID = 1033;
    public const IDENTITY_DID_NOT_ACCEPT_AGREEMENT = 1040;
    public const INVALID_LOGIN_OR_PASSWORD = 1050;
    public const OFFER_TO_RESET_PASSWORD = 1051;
    public const FREQUENT_PASSWORD_CHANGES = 1052;
    public const REUSING_PASSWORD = 1053;
    public const OLD_PASSWORD_IS_INVALID = 1054;
    public const INVALID_INN_OR_KPP = 1060;
    public const EMAIL_ALREADY_EXISTS = 1070;
    public const EMAIL_DIASOFT_ID_ALREADY_EXISTS = 1071;
    public const ADMIN_EMAIL_ALREADY_EXISTS = 1080;
    public const INVALID_PHONE_NUMBER = 1090;
    public const RFINFO_REQUEST_ERROR = 2010;
}