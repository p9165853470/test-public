<?php

namespace common\exceptions;

use yii\base\Exception;

class RepositoryException extends Exception
{

}