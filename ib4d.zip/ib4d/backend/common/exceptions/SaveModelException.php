<?php

namespace common\exceptions;

class SaveModelException extends RepositoryException
{

}