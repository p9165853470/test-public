<?php

namespace common\forms;

use yii\base\Model;
use yii\db\ActiveRecord;

abstract class Form extends Model
{
    public const SCENARIO_CREATE = 'create';
    public const SCENARIO_UPDATE = 'update';

    /**
     * @var ActiveRecord
     */
    private $model;

    public function __construct(?ActiveRecord $model, $config = [])
    {
        $this->model = $model;

        parent::__construct($config);
    }

    public function init(): void
    {
        parent::init();

        $this->setScenario(self::SCENARIO_CREATE);

        if ($this->hasModel()) {
            $this->setScenario(self::SCENARIO_UPDATE);
            $this->loadModel();
            $this->loadDependency();
        }
        $this->loadDefault();
    }

    public function scenarios(): array
    {
        $scenarios = parent::scenarios();

        if (!isset($scenarios[self::SCENARIO_CREATE])) {
            $scenarios[self::SCENARIO_CREATE] = $scenarios[self::SCENARIO_DEFAULT];
        }

        if (!isset($scenarios[self::SCENARIO_UPDATE])) {
            $scenarios[self::SCENARIO_UPDATE] = $scenarios[self::SCENARIO_DEFAULT];
        }

        return $scenarios;
    }

    /**
     * Загрузить данные из модели в форму
     */
    protected function loadModel(): void
    {
        foreach ($this->safeAttributes() as $attribute) {
            if ($this->model->canGetProperty($attribute)) {
                $this->$attribute = $this->model->$attribute;
            }
        }
    }

    /**
     * Загрузить остальные данные из модели в форму
     */
    protected function loadDependency(): void { }

    /**
     * Указать значения по умолчнаю
     */
    protected function loadDefault(): void { }

    public function getModel(): ?ActiveRecord
    {
        return $this->model;
    }

    public function hasModel(): bool
    {
        return $this->model !== null;
    }

    public function formName(): string
    {
        return '';
    }
}