<?php

namespace common\helpers;

class Filter
{
    public static function arrayOfInt($data): array
    {
        $data = filter_var($data, FILTER_VALIDATE_INT, FILTER_FORCE_ARRAY | FILTER_NULL_ON_FAILURE);
        $data = array_filter($data, static function ($value) {
            return $value !== null;
        });

        return array_values($data);
    }
}