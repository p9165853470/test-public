<?php

namespace common\helpers;

use yii\base\UnknownMethodException;

abstract class StaticInstanceHelper
{
    abstract protected static function getInstance(): object;

    public static function __callStatic($name, $arguments)
    {
        $instance = static::getInstance();

        if (method_exists($instance, $name)) {
            return call_user_func_array([$instance, $name], $arguments);
        }
        throw new UnknownMethodException('Calling unknown static method: ' . static::class . "::$name()");
    }
}