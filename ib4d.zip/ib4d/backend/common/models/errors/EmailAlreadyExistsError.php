<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Email уже существует
 */
final class EmailAlreadyExistsError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::EMAIL_ALREADY_EXISTS;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}