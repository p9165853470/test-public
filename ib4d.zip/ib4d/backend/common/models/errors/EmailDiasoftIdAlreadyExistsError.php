<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Email + Diasoft id уже существует
 */
final class EmailDiasoftIdAlreadyExistsError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::EMAIL_DIASOFT_ID_ALREADY_EXISTS;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}