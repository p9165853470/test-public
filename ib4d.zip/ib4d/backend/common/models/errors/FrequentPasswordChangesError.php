<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Прошло мало времени после последней ручной смены пароля
 */
final class FrequentPasswordChangesError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::FREQUENT_PASSWORD_CHANGES;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}