<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Непревильные ИНН или КПП при валидации
 */
final class InvalidInnOrKppError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::INVALID_INN_OR_KPP;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}