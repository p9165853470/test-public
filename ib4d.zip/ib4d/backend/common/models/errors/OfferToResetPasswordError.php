<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Преложить пользователю сбросить пароль
 */
final class OfferToResetPasswordError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::OFFER_TO_RESET_PASSWORD;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}