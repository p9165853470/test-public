<?php

namespace common\models\errors;

use common\enums\ErrorEnum;

/**
 * Попытка установить ранее использованный пароль
 */
final class ReUsingPasswordError extends ModelError
{
    public function __construct()
    {
        $code = ErrorEnum::REUSING_PASSWORD;
        $message = ErrorEnum::getLabel($code);

        parent::__construct($message, $code);
    }
}