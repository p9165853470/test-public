<?php

namespace common\modules\audit\behaviors;

use common\modules\audit\components\AuditTag;

interface AuditMessageInterface
{
    public function getDate(): \DateTimeInterface;

    public function getTag(): AuditTag;

    public function getMessage(): string;
}