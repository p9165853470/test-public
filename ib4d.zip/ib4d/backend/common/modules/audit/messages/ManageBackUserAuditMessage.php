<?php

namespace common\modules\audit\messages;

use common\modules\audit\behaviors\AuditInitiatorInterface;
use common\modules\audit\behaviors\AuditMessageInterface;
use common\modules\audit\components\AuditTag;
use common\modules\audit\enum\ActionEnum;
use common\modules\user\models\BackUser;

class ManageBackUserAuditMessage implements AuditMessageInterface
{
    /**
     * @var \DateTimeInterface
     */
    protected $date;
    /**
     * @var string
     */
    protected $action;
    /**
     * @var AuditInitiatorInterface
     */
    protected $initiator;
    /**
     * @var BackUser|null
     */
    protected $target;

    public function __construct(string $action, AuditInitiatorInterface $initiator, ?BackUser $target)
    {
        $this->date = date_create_immutable();
        $this->action = $action;
        $this->initiator = $initiator;
        $this->target = $target;
    }

    public function getDate(): \DateTimeInterface
    {
        return $this->date;
    }

    public function getTag(): AuditTag
    {
        return $this->initiator->getAuditTag();
    }

    public function getMessage(): string
    {
        $message = ActionEnum::getLabel($this->action);

        switch ($this->action) {
            case ActionEnum::CREATE:
            case ActionEnum::UPDATE:
            case ActionEnum::DELETE:
                $message .= ' системного пользователя (' . $this->target->getAuditTag() . ')';
                break;
            case ActionEnum::DELETE_ALL:
            case ActionEnum::BLOCK_ALL:
            case ActionEnum::UNBLOCK_ALL:
                $message .= ' системных пользователей';
                break;
        }

        return $message;
    }
}