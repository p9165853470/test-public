<?php

namespace common\modules\audit\messages;

use common\modules\audit\behaviors\AuditInitiatorInterface;
use common\modules\audit\behaviors\AuditMessageInterface;
use common\modules\audit\components\AuditTag;
use common\modules\variable\enums\VariableEnum;
use DateTimeInterface;

class VariableAuditMessage implements AuditMessageInterface
{
    /**
     * @var DateTimeInterface
     */
    protected $date;
    /**
     * @var AuditInitiatorInterface
     */
    protected $initiator;
    /**
     * @var string
     */
    protected $variable;

    public function __construct(string $variable, AuditInitiatorInterface $initiator)
    {
        $this->date = date_create_immutable();
        $this->variable = $variable;
        $this->initiator = $initiator;
    }

    public function getDate(): DateTimeInterface
    {
        return $this->date;
    }

    public function getTag(): AuditTag
    {
        return $this->initiator->getAuditTag();
    }

    public function getMessage(): string
    {
        return sprintf('Изменение справочника "%s"', VariableEnum::getLabel($this->variable));
    }
}