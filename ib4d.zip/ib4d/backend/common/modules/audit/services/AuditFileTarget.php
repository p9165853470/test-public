<?php

namespace common\modules\audit\services;

use common\modules\audit\behaviors\AuditMessageInterface;
use common\modules\audit\behaviors\AuditTargetInterface;
use common\modules\audit\exceptions\AuditException;

class AuditFileTarget implements AuditTargetInterface
{
    protected const COLUMN_SEPARATOR = ';';
    protected const LOG_FILENAME_DATE_FORMAT = 'Y-m-d';

    /**
     * @var string
     */
    protected $path;
    /**
     * @var string
     */
    protected $file;

    public function __construct()
    {
        $this->path = \Yii::getAlias(\Yii::$app->params['audit.logPath']);
        $this->file = $this->path . DIRECTORY_SEPARATOR . date(self::LOG_FILENAME_DATE_FORMAT) . '.log';
    }

    /**
     * @param AuditMessageInterface $message
     * @throws AuditException
     */
    public function audit(AuditMessageInterface $message): void
    {
        $file = @fopen($this->file, 'ab');

        if ($file === false) {
            throw new AuditException("Unable to append to file: {$this->file}");
        }

        @flock($file, LOCK_EX);

        if (@fwrite($file, $this->formatMessage($message)) === false) {
            $error = error_get_last();

            throw new AuditException("Unable to export log through file ({$this->file})!: {$error['message']}");
        }

        @flock($file, LOCK_UN);
        @fclose($file);
    }

    protected function formatMessage(AuditMessageInterface $message): string
    {
        $tag = $message->getTag();

        return implode(self::COLUMN_SEPARATOR, [
            $message->getDate()->format('d-m-Y H:i:s'),
            $tag ? $tag->getId() : '-',
            $tag ? $tag->getEmail() : '-',
            $message->getMessage(),
        ]) . "\r\n";
    }
}