<?php

namespace common\modules\audit\services;

use common\modules\audit\behaviors\AuditMessageInterface;
use common\modules\audit\behaviors\AuditTargetInterface;
use common\modules\audit\exceptions\AuditException;

class AuditService
{
    /**
     * @var AuditTargetInterface
     */
    protected $target;

    public function __construct(AuditTargetInterface $target)
    {
        $this->target = $target;
    }

    public function audit(AuditMessageInterface $message): void
    {
        try {
            $this->target->audit($message);
        } catch (AuditException $ex) {
            \Yii::warning($ex);
        }
    }
}