<?php

namespace common\modules\authentication\actions;

use common\modules\authentication\behaviors\AuthenticationServiceInterface;
use common\modules\authentication\forms\RefreshTokenForm;
use common\modules\authentication\resources\AuthenticationTokenResource;
use yii\base\Action;
use yii\di\Instance;
use yii\web\Request;

class RefreshTokenAction extends Action
{
    /**
     * @var AuthenticationServiceInterface
     */
    protected $service;

    public function __construct($id, $controller, AuthenticationServiceInterface $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param Request $request
     * @return RefreshTokenForm|AuthenticationTokenResource
     */
    public function run(Request $request)
    {
        /** @var RefreshTokenForm $form */
        $form = Instance::ensure(RefreshTokenForm::class);
        $form->load($request->post());

        if ($form->validate()) {
            return new AuthenticationTokenResource(
                $this->service->refreshToken($form->token)
            );
        }
        return $form;
    }
}