<?php

namespace common\modules\authentication\behaviors;

use common\modules\user\behaviors\IdentityInterface;

/**
 * Интерфейс сервиса аутентификации
 */
interface AuthenticationServiceInterface
{
    public const EVENT_AFTER_CREATE_TOKEN = 'afterCreateToken';
    public const EVENT_AFTER_REFRESH_TOKEN = 'afterRefreshToken';

    /**
     * Создать токен для пользователя
     *
     * @param IdentityInterface $identity
     * @return TokenInterface
     */
    public function createToken(IdentityInterface $identity): TokenInterface;

    /**
     * Создать новый токен, используя старый
     *
     * @param TokenInterface $oldToken
     * @return TokenInterface
     */
    public function refreshToken(TokenInterface $oldToken): TokenInterface;

    /**
     * Удалить токен пользователя
     *
     * @param TokenInterface $token
     */
    public function destroyToken(TokenInterface $token): void;
}