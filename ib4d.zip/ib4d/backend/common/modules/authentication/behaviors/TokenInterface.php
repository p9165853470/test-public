<?php

namespace common\modules\authentication\behaviors;

use common\modules\authentication\exceptions\TokenException;
use common\modules\session\behaviors\SessionInterface;

/**
 * Интерфейс сущности токена
 */
interface TokenInterface
{
    /**
     * Токен пригоден для обновления
     *
     * @return bool
     */
    public function isRefresh(): bool;

    /**
     * Токен устарел
     *
     * @return bool
     */
    public function isExpired(): bool;

    /**
     * Токен имеет верные данные по сессии и ее пользователю
     *
     * @return bool
     */
    public function isValid(): bool;

    /**
     * Получить сущность сессии по токену
     *
     * @return SessionInterface
     * @throws TokenException
     */
    public function getSession(): SessionInterface;

    /**
     * Получить идентификатор токена
     *
     * @return mixed
     */
    public function getId();
}