<?php

namespace common\modules\authentication\resources;

use common\modules\authentication\behaviors\TokenInterface;
use common\resources\Resource;
use yii\base\Arrayable;
use yii\base\ArrayableTrait;

class AuthenticationTokenResource extends Resource
{
    public function toArray(): array
    {
        return [
            'type' => 'Bearer',
            'token' => (string)$this->resource,
        ];
    }
}