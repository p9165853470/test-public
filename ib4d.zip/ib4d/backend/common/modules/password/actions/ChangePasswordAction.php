<?php

namespace common\modules\password\actions;

use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\password\forms\ChangePasswordForm;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\Action;
use yii\di\Instance;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class ChangePasswordAction extends Action
{
    /**
     * @var PasswordServiceInterface
     */
    protected $service;

    public function __construct($id, $controller, PasswordServiceInterface $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param Request $request
     * @param Response $response
     * @param IdentityInterface $identity
     * @return ChangePasswordForm|void
     * @throws BadRequestHttpException
     */
    public function run(Request $request, Response $response, IdentityInterface $identity)
    {
        /** @var ChangePasswordForm $form */
        $form = Instance::ensure(ChangePasswordForm::class);
        $form->setIdentity($identity);

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }

        if ($form->validate()) {
            $this->service->change(
                $identity,
                $form->getPassword(),
                PasswordServiceInterface::CONTEXT_ACTION_CHANGE
            );

            $response->setStatusCode(204);
        } else {
            return $form;
        }
    }
}