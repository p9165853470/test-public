<?php

namespace common\modules\password\behaviors;

use common\behaviors\GarbageCollectorInterface;
use common\modules\user\behaviors\IdentityInterface;

/**
 * Интерфейс сервиса для проверки пароля
 */
interface PasswordServiceInterface extends GarbageCollectorInterface
{
    public const EVENT_AFTER_CHANGE_PASSWORD = 'afterChangePassword';
    public const CONTEXT_ACTION_CHANGE = 'actionChange';
    public const CONTEXT_ACTION_RESET = 'actionReset';

    /**
     * Проверить, можно ли использовать пароль для пользователя
     *
     * @param IdentityInterface $identity
     * @param string $password
     * @return bool
     */
    public function validate(IdentityInterface $identity, string $password): bool;

    /**
     * Установить новый пароль для пользователя
     *
     * @param IdentityInterface $identity
     * @param string $password
     * @param string|null $context
     */
    public function change(IdentityInterface $identity, string $password, string $context = null): void;

    /**
     * Добавить хэш пароля в историю
     *
     * @param IdentityInterface $identity
     * @param string $hash
     * @param bool $isManual пароль установлен пользователем
     * @return mixed
     */
    public function store(IdentityInterface $identity, string $hash, bool $isManual);

    /**
     * Генерировать хэщ пароля
     *
     * @param string $password
     * @return string
     */
    public function generatePasswordHash(string $password): string;

    /**
     * Проверить, нужно ли менять пользователю пароль
     *
     * @param IdentityInterface $identity
     * @return bool
     */
    public function hasUnsafePassword(IdentityInterface $identity): bool;

    /**
     * Получить последний пароль пользователя
     *
     * @param IdentityInterface $identity
     * @return UserPasswordInterface|null
     */
    public function getLastPassword(IdentityInterface $identity): ?UserPasswordInterface;
}