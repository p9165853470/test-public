<?php

namespace common\modules\password\behaviors;

use common\modules\user\behaviors\IdentityInterface;
use DateTimeInterface;

interface UserPasswordInterface
{
    /**
     * Получить владельца пароля
     *
     * @return IdentityInterface
     */
    public function getIdentity(): IdentityInterface;

    /**
     * Получить хэш пароля
     *
     * @return string
     */
    public function getPasswordHash(): string;

    /**
     * Получить дату создания пароля
     *
     * @return DateTimeInterface
     */
    public function getDate(): DateTimeInterface;

    /**
     * Пароль установлен пользователем
     *
     * @return bool
     */
    public function isManual(): bool;
}