<?php

namespace common\modules\password\events;

use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\user\behaviors\IdentityInterface;
use yii\base\Event;

/**
 * @property PasswordServiceInterface $sender
 */
class PasswordEvent extends Event
{
    /**
     * @var IdentityInterface
     */
    public $identity;
    /**
     * @var string
     */
    public $password;
    /**
     * @var string|null
     */
    public $context;
}