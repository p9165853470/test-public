<?php

namespace common\modules\password\forms;

use common\models\errors\IdentityIsBlockedError;
use common\models\errors\IdentityIsNotActiveError;
use common\models\errors\IdentityNotFoundError;
use common\modules\password\behaviors\PasswordServiceInterface;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\enums\BlockReasonEnum;
use common\modules\user\models\BackUser;
use yii\base\Model;
use yii\di\Instance;

abstract class ResetPasswordForm extends Model
{
    /**
     * @var string
     */
    public $login;
    /**
     * @var BackUser|false|null
     */
    private $identity = false;

    /**
     * Поиск сущности пользователя по логину
     *
     * @return IdentityInterface|null
     */
    abstract protected function findIdentity(): ?IdentityInterface;

    /**
     * Сгенерировать новый пароль для пользователя
     *
     * @return string
     */
    abstract public function getPassword(): string;

    public function getIdentity(): ?IdentityInterface
    {
        if ($this->identity === false) {
            $this->identity = $this->findIdentity();
        }
        return $this->identity;
    }

    public function scenarios(): array
    {
        return [
            self::SCENARIO_DEFAULT => ['login', '!password'],
        ];
    }

    public function rules(): array
    {
        return [
            ['login', 'required'],
            ['login', 'email'],
            [
                'login',
                function () {
                    $identity = $this->getIdentity();

                    if ($identity === null) {
                        $this->addError('login', new IdentityNotFoundError());
                    } elseif (
                        $identity->hasBlock()
                        && (
                            !$identity->hasBlock(BlockReasonEnum::BY_FAILED_AUTHENTICATION)
                            || $this->lastPasswordIsManual($identity)
                        )
                    ) {
                        $this->addError('login', new IdentityIsBlockedError($identity));
                    } elseif (!$identity->isActive()) {
                        $this->addError('login', new IdentityIsNotActiveError());
                    }
                }
            ],
        ];
    }

    public function formName(): string
    {
        return '';
    }

    protected function lastPasswordIsManual(IdentityInterface $identity): bool
    {
        /** @var PasswordServiceInterface $passwordService */
        $passwordService = Instance::ensure(PasswordServiceInterface::class);
        $userPassword = $passwordService->getLastPassword($identity);

        return $userPassword !== null && $userPassword->isManual();
    }
}