<?php

namespace common\modules\password\mail;

use common\mail\MessageComposer;

class PasswordResetMessageComposer extends MessageComposer
{
    protected function getSubject(): string
    {
        return 'Подтверждение смены пароля учетной записи в ИНФО-Банк для дилера';
    }

    protected function getHtmlView(): ?string
    {
        return '@common/modules/password/mail/views/reset-password';
    }

    protected function getTextView(): ?string
    {
        return null;
    }
}