<?php

use console\components\Migration;

/**
 * Class m200728_071540_update_fk_in_back_user_password_table
 */
class m200728_071540_update_fk_in_back_user_password_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropForeignKeyNamed('{{%back_user_password}}', 'user_id', '{{%back_user}}', 'id');
        $this->addForeignKeyNamed('{{%back_user_password}}', 'user_id', '{{%back_user}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropForeignKeyNamed('{{%back_user_password}}', 'user_id', '{{%back_user}}', 'id');
        $this->addForeignKeyNamed('{{%back_user_password}}', 'user_id', '{{%back_user}}', 'id');
    }
}
