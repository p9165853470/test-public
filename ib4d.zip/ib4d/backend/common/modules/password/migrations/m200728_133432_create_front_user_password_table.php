<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%front_user_password}}`.
 */
class m200728_133432_create_front_user_password_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%front_user_password}}', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer()->notNull(),
            'password_hash' => $this->string(128)->notNull(),
            'created_at' => $this->timestamp()->notNull(),
        ]);

        $this->addForeignKeyNamed('{{%front_user_password}}', 'user_id', '{{%front_user}}', 'id');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%front_user_password}}');
    }
}
