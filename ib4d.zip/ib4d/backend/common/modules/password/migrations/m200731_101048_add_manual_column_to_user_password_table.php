<?php

use console\components\Migration;

/**
 * Handles adding columns to table `{{%user_password}}`.
 */
class m200731_101048_add_manual_column_to_user_password_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%back_user_password}}', 'manual', $this->boolean()->notNull()->defaultValue(false));
        $this->addColumn('{{%front_user_password}}', 'manual', $this->boolean()->notNull()->defaultValue(false));
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropColumn('{{%front_user_password}}', 'manual');
        $this->dropColumn('{{%back_user_password}}', 'manual');
    }
}
