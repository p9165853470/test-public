<?php

namespace common\modules\password\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\behaviors\ModelHasRepositoryTrait;
use common\modules\password\behaviors\UserPasswordInterface;
use common\modules\password\repositories\BackUserPasswordRepository;
use common\modules\session\repositories\BackUserSessionRepository;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\BackUser;
use DateTimeInterface;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $user_id
 * @property string $password_hash
 * @property string $created_at
 * @property bool $manual
 *
 * @property-read BackUser $user
 *
 * @method static BackUserPasswordRepository getRepository()
 */
class BackUserPassword extends ActiveRecord implements ModelHasRepositoryInterface, UserPasswordInterface
{
    use ModelHasRepositoryTrait;

    /**
     * Сколько времени долдно пройти с последней установки пароля,
     * чтобы запросить у пользователя изменить пароль
     * @todo Вынести в конфиг
     */
    public const PASSWORD_UNSAFE_INTERVAL = 'P90D';
    /**
     * Мин интервал времени, которе должно пройти с последней ручной смены пароля
     * @todo Вынести в конфиг
     */
    public const MANUAL_PASSWORDS_INTERVAL = 'P1D';
    /**
     * Кол-во последних паролей, среди которых необходимо проверять
     * новый пароль на переиспользование
     * @todo Вынести в конфиг
     */
    public const NUMBER_TO_CHECK_FOR_REUSE = 9;

    public static function getRepositoryClass(): string
    {
        return BackUserSessionRepository::class;
    }

    public function behaviors(): array
    {
        return [
            [
                'class' => TimestampBehavior::class,
                'attributes' => [
                    self::EVENT_BEFORE_INSERT => ['created_at'],
                ]
            ]
        ];
    }

    public function getUser(): ActiveQuery
    {
        return $this->hasOne(BackUser::class, ['id' => 'user_id']);
    }

    public function getIdentity(): IdentityInterface
    {
        return $this->user;
    }

    public function getPasswordHash(): string
    {
        return $this->password_hash;
    }

    public function getDate(): DateTimeInterface
    {
        return date_create($this->created_at);
    }

    public function isManual(): bool
    {
        return $this->manual;
    }
}