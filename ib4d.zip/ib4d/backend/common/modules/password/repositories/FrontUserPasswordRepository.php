<?php

namespace common\modules\password\repositories;

use common\modules\password\behaviors\UserPasswordInterface;
use common\modules\password\behaviors\UserPasswordRepositoryInterface;
use common\modules\password\models\FrontUserPassword;
use common\modules\user\behaviors\IdentityInterface;
use common\repositories\Repository;
use yii\db\ActiveRecord;

/**
 * @method FrontUserPassword model()
 * @method FrontUserPassword findOne($condition = null)
 * @method FrontUserPassword[] findAll($condition = null)
 */
class FrontUserPasswordRepository extends Repository implements UserPasswordRepositoryInterface
{
    public function getModelClass(): string
    {
        return FrontUserPassword::class;
    }

    /**
     * @param IdentityInterface $identity
     * @return UserPasswordInterface|FrontUserPassword|ActiveRecord|null
     */
    public function findLastByIdentity(IdentityInterface $identity): ?UserPasswordInterface
    {
        return $this->find(['user_id' => $identity->getId()])
            ->orderBy(['created_at' => SORT_DESC])
            ->one();
    }

    public function create(IdentityInterface $identity, string $hash, bool $isManual): UserPasswordInterface
    {
        $model = $this->model();

        $model->user_id = $identity->getId();
        $model->password_hash = $hash;
        $model->manual = $isManual;

        $this->save($model);

        return $model;
    }
}