<?php

namespace common\modules\rfinfo\behaviors;

use common\modules\rfinfo\components\RequestContext;
use common\modules\rfinfo\dto\Account;
use common\modules\rfinfo\dto\AccountArrests;
use common\modules\rfinfo\dto\AccountStatements;
use common\modules\rfinfo\dto\AccountTransactions;
use common\modules\rfinfo\dto\ClientLine;
use common\modules\rfinfo\dto\ClientLineShort;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\dto\Rate;
use common\modules\rfinfo\dto\SendSms;
use common\modules\rfinfo\dto\Tranche;

interface RequestServiceInterface
{
    /**
     * Информация по ЮЛ
     *
     * @param RequestContext $context
     * @return Info
     */
    public function getInfo(RequestContext $context);

    /**
     * Список линий (договоров) клинета
     *
     * @param RequestContext $context
     * @return ClientLineShort[]
     */
    public function getClientLines(RequestContext $context);

    /**
     * Данные по линии (договору) клиента
     *
     * @param RequestContext $context
     * @return ClientLine
     */
    public function getClientLine(RequestContext $context);

    /**
     * Список траншей клиента
     *
     * @param RequestContext $context
     * @return Tranche[]
     */
    public function getTranches(RequestContext $context);

    /**
     * Расчетные счета клиента
     *
     * @param RequestContext $context
     * @return Account[]
     */
    public function getAccounts(RequestContext $context);

    /**
     * Операции по расчетному счету
     *
     * @param RequestContext $context
     * @return AccountTransactions
     */
    public function getAccountTransactions(RequestContext $context);

    /**
     * Выписки по расчетному счету
     *
     * @param RequestContext $context
     * @return AccountStatements
     */
    public function getAccountStatements(RequestContext $context);

    /**
     * Ограничения по расчетному счету
     *
     * @param RequestContext $context
     * @return AccountArrests
     */
    public function getAccountArrests(RequestContext $context);

    /**
     * История ставок МосПрайм
     *
     * @param RequestContext $context
     * @return Rate[]
     */
    public function getRate(RequestContext $context);

    /**
     * Запрос кода подтверждения
     *
     * @param RequestContext $context
     * @return SendSms
     */
    public function postSendSms(RequestContext $context);
}