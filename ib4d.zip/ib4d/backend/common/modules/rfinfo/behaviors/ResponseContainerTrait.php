<?php

namespace common\modules\rfinfo\behaviors;

use common\modules\rfinfo\dto\AbstractDto;
use common\repositories\AnonymousRepository;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

trait ResponseContainerTrait
{
    /**
     * @var callable
     */
    private $itemsSerializer;

    abstract protected function getItemsAttribute(): string;

    public function setItemsSerializer($callback): void
    {
        $this->itemsSerializer = $callback;
    }

    public function setItems(array $items): void
    {
        $this->populateRelation($this->getItemsAttribute(), $items);
    }

    public function getItems(): array
    {
        return $this->{$this->getItemsAttribute()};
    }

    public function getItemsQuery(): ActiveQuery
    {
        return $this->getRelation($this->getItemsAttribute());
    }

    protected function attachItems(array $items): void
    {
        /** @var ActiveRecord $modelClass */
        $modelClass = $this->getRelation($this->getItemsAttribute())->modelClass;

        $models = array_map(static function ($item) use ($modelClass) {
            /** @var ActiveRecord $model */
            $model = new $modelClass;
            $model->attributes = $item instanceof AbstractDto ? $item->toArray() : $item;

            return $model;
        }, $items);

        $this->on(self::EVENT_AFTER_INSERT, function () use ($modelClass, $models) {
            /** @var AnonymousRepository $repository */
            $repository = \Yii::createObject(AnonymousRepository::class, [$modelClass]);

            foreach ($models as $model) {
                $model->setAttribute('container_id', $this->id);
                $repository->save($model);
            }

            $this->populateRelation($this->getItemsAttribute(), $models);
        });
    }

    public function fields(): array
    {
        if (!is_callable($this->itemsSerializer)) {
            return parent::fields();
        }

        $attribute = $this->getItemsAttribute();

        $fields = parent::fields();
        $fields = array_diff($fields, [$attribute]);
        $fields = array_diff_key($fields, [$attribute => 0]);

        $fields[$attribute] = static function (self $model) {
            return call_user_func($model->itemsSerializer, $model->getItemsQuery());
        };

        return $fields;
    }
}