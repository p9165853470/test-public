<?php

namespace common\modules\rfinfo\behaviors;

use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

trait XlsxFormatterTrait
{
    protected function setCellValueAsText(Worksheet $worksheet, string $pCoordinate, $value): void
    {
        $this->setCellValue($worksheet, $pCoordinate, $value, NumberFormat::FORMAT_TEXT);
    }

    /**
     * Число с дробной частью в 2 знака и делителем порядка
     *
     * @param Worksheet $worksheet
     * @param string $pCoordinate
     * @param $value
     */
    protected function setCellValueAsNumeric(Worksheet $worksheet, string $pCoordinate, $value): void
    {
        $this->setCellValue($worksheet, $pCoordinate, $value, NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
    }

    protected function setCellValueAsNumber(Worksheet $worksheet, string $pCoordinate, $value): void
    {
        $this->setCellValue($worksheet, $pCoordinate, $value, NumberFormat::FORMAT_NUMBER);
    }

    protected function setCellValueAsDate(Worksheet $worksheet, string $pCoordinate, \DateTimeInterface $value): void
    {
        $this->setCellValue($worksheet, $pCoordinate, Date::dateTimeToExcel($value), 'dd.mm.yyyy');
    }

    private function setCellValue(Worksheet  $worksheet, string $pCoordinate, $value, string $format): void
    {
        $cell = $worksheet->getCell($pCoordinate);

        if ($cell !== null) {
            $cell->getStyle()->getNumberFormat()->setFormatCode($format);
            $cell->setValue($value);
        }
    }
}