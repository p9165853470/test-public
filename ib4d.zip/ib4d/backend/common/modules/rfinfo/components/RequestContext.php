<?php

namespace common\modules\rfinfo\components;

use common\behaviors\ParameterizedInterface;
use common\behaviors\ParameterizedTrait;
use common\modules\rfinfo\forms\FilterForm;
use common\modules\rfinfo\forms\QueryForm;

class RequestContext implements ParameterizedInterface
{
    use ParameterizedTrait;

    /**
     * @var string
     */
    protected $method;
    /**
     * @var QueryForm
     */
    protected $query;
    /**
     * @var FilterForm
     */
    protected $filter;

    public function __construct(string $method)
    {
        $this->method = $method;
    }

    public function getMethod(): string
    {
        return $this->method;
    }

    public function getQuery(): QueryForm
    {
        return $this->query;
    }

    public function setQuery(QueryForm $query): void
    {
        $this->query = $query;
    }

    public function getFilter(): FilterForm
    {
        return $this->filter;
    }

    public function setFilter(FilterForm $filter): void
    {
        $this->filter = $filter;
    }

    public function create(string $method): self
    {
        $context = new self($method);

        if ($this->query instanceof QueryForm) {
            $context->query = clone $this->query;
            $context->query->setContext($context);
        }

        if ($this->filter instanceof FilterForm) {
            $context->filter = clone $this->filter;
            $context->filter->setContext($context);
        }

        return $context;
    }
}