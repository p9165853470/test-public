<?php

use common\enums\MimeTypeEnum;

return [
    'xlsx' => MimeTypeEnum::XLSX,
    'txt' => MimeTypeEnum::TXT,
];