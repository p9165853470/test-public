<?php

namespace common\modules\rfinfo\dto;

class AccountArrests extends AbstractDto
{
    /**
     * @var AccountArrest[]
     */
    public $arrests = [];
    public $krt_count;
    public $krt_qty;
}