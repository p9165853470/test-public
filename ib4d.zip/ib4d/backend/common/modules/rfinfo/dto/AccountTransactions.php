<?php

namespace common\modules\rfinfo\dto;

class AccountTransactions extends AbstractDto
{
    /**
     * @var AccountTransaction[]
     */
    public $transactions = [];
    public $rest_in;
    public $rest_out;
    public $turn_cred;
    public $turn_debt;
    public $comment;
}