<?php

namespace common\modules\rfinfo\dto;

class ClientLine extends AbstractDto
{
    public $number;
    public $type;
    public $status;
    public $name_brand;
    public $name_product;
    public $start_date;
    public $real_finish_date;
    public $finish_date;
    public $limit_amount;
    public $total_main_debt;
    public $rest_limit;
    public $date_near_line_pay;
    public $flag_near_line_pay;
    public $percent_rate;
    public $date_percent_rate;
    public $comiss_type;
    public $summ_comiss_debt;
    public $line_block;
    public $overdue_debt;
}