<?php

namespace common\modules\rfinfo\dto;

class ClientLineShort extends AbstractDto
{
    public $number;
    public $type;
    public $status;
    public $name_brand;
    public $name_product;
}