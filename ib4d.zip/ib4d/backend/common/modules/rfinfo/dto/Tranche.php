<?php

namespace common\modules\rfinfo\dto;

class Tranche extends AbstractDto
{
    public $vin;
    public $name_brand;
    public $model;
    public $number;
    public $type;
    public $status;
    public $sum_amount;
    public $sum_pre_pay;
    public $real_start_date;
    public $date_beg_pay;
    public $finish_date;
    public $rest_main_debt;
    public $overdue_debt;
    public $flag_overdue_debt;
    public $percent_rate;
    public $sum_percent;
    public $sum_fin;
    public $sum_comiss;
    /**
     * @var string
     */
    public $payment_type;
}