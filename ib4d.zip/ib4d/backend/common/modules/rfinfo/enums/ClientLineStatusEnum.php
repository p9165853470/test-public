<?php

namespace common\modules\rfinfo\enums;

use common\behaviors\EnumTrait;

class ClientLineStatusEnum
{
    use EnumTrait;

    public const OPENED = 0;
    public const CLOSED = 1;
    public const ALL = 2;
}