<?php

namespace common\modules\rfinfo\factories;

use common\modules\rfinfo\behaviors\ResponseServiceInterface;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\models\AbstractResponse;
use common\modules\rfinfo\models\Account;
use common\modules\rfinfo\models\AccountArrests;
use common\modules\rfinfo\models\AccountStatements;
use common\modules\rfinfo\models\AccountTransactions;
use common\modules\rfinfo\models\CheckCode;
use common\modules\rfinfo\models\ClientLine;
use common\modules\rfinfo\models\ClientLineShort;
use common\modules\rfinfo\models\Info;
use common\modules\rfinfo\models\Rate;
use common\modules\rfinfo\models\Tranche;
use common\modules\rfinfo\models\User;
use common\modules\rfinfo\models\SendSms;
use yii\base\InvalidArgumentException;
use yii\di\Instance;

class ResponseFactory
{
    public function getService(): ResponseServiceInterface
    {
        /** @var ResponseServiceInterface $service */
        $service = Instance::ensure(ResponseServiceInterface::class);

        return $service;
    }

    /**
     * @param string $method
     * @return string|AbstractResponse
     */
    public function getModelClass(string $method): string
    {
        switch ($method) {
            case RequestMethodEnum::INFO:
                return Info::class;
            case RequestMethodEnum::ACCOUNTS:
                return Account::class;
            case RequestMethodEnum::ACCOUNT_TRANSACTIONS:
                return AccountTransactions::class;
            case RequestMethodEnum::ACCOUNT_STATEMENTS:
                return AccountStatements::class;
            case RequestMethodEnum::ACCOUNT_ARRESTS:
                return AccountArrests::class;
            case RequestMethodEnum::CLIENT_LINE:
                return ClientLine::class;
            case RequestMethodEnum::CLIENT_LINES:
                return ClientLineShort::class;
            case RequestMethodEnum::TRANCHES:
                return Tranche::class;
            case RequestMethodEnum::RATE:
                return Rate::class;
            case RequestMethodEnum::USER:
                return User::class;
            case RequestMethodEnum::SEND_SMS:
                return SendSms::class;
            case RequestMethodEnum::CHECK_CODE:
                return CheckCode::class;
        }

        throw new InvalidArgumentException("Invalid method name: {$method}");
    }
}