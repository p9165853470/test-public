<?php

namespace common\modules\rfinfo\forms;

class AccountArrestsQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $diasoft_id;
    /**
     * @var string
     */
    public $account;

    public function rules(): array
    {
        return [
            [['diasoft_id', 'account'], 'required'],
        ];
    }
}