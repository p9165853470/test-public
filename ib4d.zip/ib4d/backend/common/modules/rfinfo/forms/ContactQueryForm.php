<?php
namespace common\modules\rfinfo\forms;

class ContactQueryForm extends QueryForm
{
    /**
     * @var string
     */

    public $email;

    /**
     * @var string
     */
    public $type;

    /**
     * @var string
     */
    public $value;

    public function rules(): array
    {
        return [
            [['value','email','type'], 'required'],
        ];
    }
}
