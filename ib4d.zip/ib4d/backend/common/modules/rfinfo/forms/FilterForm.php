<?php

namespace common\modules\rfinfo\forms;

use common\modules\rfinfo\components\RequestContext;
use yii\base\Model;

class FilterForm extends Model
{
    /**
     * @var RequestContext
     */
    protected $context;

    public function __construct(RequestContext $context, $config = [])
    {
        $this->setContext($context);

        parent::__construct($config);
    }

    public function rules(): array
    {
        return [
            [$this->attributes(), 'default'],
        ];
    }

    public function getContext(): RequestContext
    {
        return $this->context;
    }

    public function setContext(RequestContext $context): void
    {
        $this->context = $context;
    }

    /**
     * @param $data
     * @return mixed
     */
    public function apply($data)
    {
        return $data;
    }

    public function formName(): string
    {
        return '';
    }
}