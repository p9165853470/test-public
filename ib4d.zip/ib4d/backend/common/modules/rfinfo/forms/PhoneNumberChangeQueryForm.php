<?php
namespace common\modules\rfinfo\forms;

use common\modules\rfinfo\enums\SmsTypeEnum;

class PhoneNumberChangeQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $phone_number;

    public function rules(): array
    {
        return [
            ['phone_number', 'required'],
        ];
    }
}
