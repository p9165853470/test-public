<?php

namespace common\modules\rfinfo\forms;

use common\helpers\Date;
use common\modules\rfinfo\components\RequestContext;
use common\modules\rfinfo\enums\ClientLineStatusEnum;
use common\modules\rfinfo\enums\ClientLineTypeEnum;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\enums\TrancheStatusEnum;
use yii\base\Model;

class QueryForm extends Model
{
    protected const REQUEST_ID_LENGTH = 16;

    /**
     * @var RequestContext
     */
    protected $context;
    /**
     * @var string
     */
    public $id;

    public function __construct(RequestContext $context, $config = [])
    {
        $this->setContext($context);

        parent::__construct($config);
    }

    public function formName(): string
    {
        return '';
    }

    public function getContext(): RequestContext
    {
        return $this->context;
    }

    public function setContext(RequestContext $context): void
    {
        $this->context = $context;
    }

    public function getHash(): string
    {
        $data = array_filter($this->getAttributes(null, ['id']), static function ($value) {
            return $value !== null;
        });

        return md5($this->context->getMethod() . implode('', $data));
    }

    public function generateId(): string
    {
        return \Yii::$app->security->generateRandomString(static::REQUEST_ID_LENGTH);
    }
}