<?php

namespace common\modules\rfinfo\forms;

use common\helpers\Date;

class RateQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $start_date;
    /**
     * @var string
     */
    public $end_date;

    public function rules(): array
    {
        return [
            [['start_date', 'end_date'], 'default'],
            [['start_date', 'end_date'], 'date', 'format' => 'php:' . Date::INTERNAL_DATE_FORMAT],
        ];
    }
}