<?php

namespace common\modules\rfinfo\forms;

use yii\base\InvalidArgumentException;
use yii\db\ActiveQuery;
use yii\db\QueryInterface;

class TranchesFilterForm extends FilterForm
{
    public $vin;
    public $name_brand;
    public $model;
    public $number;
    public $finish_date;
    public $finish_date_from;
    public $finish_date_to;

    public function apply($data)
    {
        if ($data instanceof ActiveQuery) {
            $this->applyToQuery($data);
        } else {
            throw new InvalidArgumentException('Unsupported data type.');
        }

        return parent::apply($data);
    }

    /**
     * @param QueryInterface|ActiveQuery $query
     */
    protected function applyToQuery(QueryInterface $query): void
    {
        $query
            ->andFilterWhere(['like', 'vin', $this->vin])
            ->andFilterWhere([
                'name_brand' => $this->name_brand,
                'model' => $this->model,
                'number' => $this->number,
                'finish_date' => $this->finish_date,
            ])
            ->andFilterWhere(['>=', 'finish_date', $this->finish_date_from])
            ->andFilterWhere(['<=', 'finish_date', $this->finish_date_to]);
    }
}