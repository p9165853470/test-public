<?php

namespace common\modules\rfinfo\forms;

use common\helpers\Date;
use common\modules\rfinfo\enums\ClientLineTypeEnum;

class TranchesQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $diasoft_id;
    /**
     * @var string
     */
    public $status_tranche;
    /**
     * @var string
     */
    public $number_line;
    /**
     * @var string
     */
    public $type_line;
    /**
     * @var string
     */
    public $start_date;
    /**
     * @var string
     */
    public $end_date;

    public function rules(): array
    {
        return [
            [['diasoft_id', 'status_tranche'], 'required'],
            [['number_line', 'type_line'], 'default', 'value' => ''],
            ['type_line', 'in', 'range' => ClientLineTypeEnum::getRange()],
            [['start_date', 'end_date'], 'default'],
            [['start_date', 'end_date'], 'date', 'format' => 'php:' . Date::INTERNAL_DATE_FORMAT],
        ];
    }
}