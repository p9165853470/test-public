<?php

namespace common\modules\rfinfo\forms;

class UserQueryForm extends QueryForm
{
    /**
     * @var string
     */
    public $email;

    public function rules(): array
    {
        return [
            ['email', 'required'],
        ];
    }
}