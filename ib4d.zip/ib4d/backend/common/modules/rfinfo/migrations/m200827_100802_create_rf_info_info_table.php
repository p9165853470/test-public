<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_info}}`.
 */
class m200827_100802_create_rf_info_info_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_info}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'diasoft_id' => $this->string(20),
            'name' => $this->string(255),
            'inn' => $this->string(20),
            'kpp' => $this->string(20),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_info}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_info}}');
    }
}
