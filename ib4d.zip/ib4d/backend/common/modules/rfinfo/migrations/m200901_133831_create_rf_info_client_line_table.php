<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_client_line}}`.
 */
class m200901_133831_create_rf_info_client_line_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_client_line}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'number' => $this->string(100),
            'type' => $this->string(3),
            'status' => $this->tinyInteger(),
            'name_brand' => $this->string(255),
            'name_product' => $this->string(255),
            'start_date' => $this->date(),
            'real_finish_date' => $this->date(),
            'finish_date' => $this->date(),
            'limit_amount' => $this->float(2),
            'total_main_debt' => $this->float(2),
            'rest_limit' => $this->float(2),
            'date_near_line_pay' => $this->date(),
            'flag_near_line_pay' => $this->tinyInteger(),
            'percent_rate' => $this->string(50),
            'date_percent_rate' => $this->date(),
            'comiss_type' => $this->string(50),
            'summ_comiss_debt' => $this->float(2),
            'line_block' => $this->tinyInteger(),
            'overdue_debt' => $this->tinyInteger(),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_client_line}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_client_line}}');
    }
}
