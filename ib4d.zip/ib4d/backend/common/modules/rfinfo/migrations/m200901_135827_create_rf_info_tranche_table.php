<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_tranche}}`.
 */
class m200901_135827_create_rf_info_tranche_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_tranche}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer(),
            'vin' => $this->string(100),
            'name_brand' => $this->string(255),
            'model' => $this->string(255),
            'number' => $this->string(255),
            'type' => $this->string(3),
            'status' => $this->tinyInteger(),
            'sum_amount' => $this->float(2),
            'sum_pre_pay' => $this->float(2),
            'real_start_date' => $this->date(),
            'date_beg_pay' => $this->date(),
            'finish_date' => $this->date(),
            'rest_main_debt' => $this->float(2),
            'overdue_debt' => $this->float(2),
            'percent_rate' => $this->float(2),
            'sum_percent' => $this->float(2),
            'sum_fin' => $this->float(2),
            'sum_comiss' => $this->float(2),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_tranche}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_tranche}}');
    }
}
