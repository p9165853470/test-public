<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_account}}`.
 */
class m200902_062302_create_rf_info_account_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_account}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'diasoft_id' => $this->string(20),
            'account' => $this->string(255),
            'rest' => $this->float(2),
            'rko_debt' => $this->float(2),
            'arrest' => $this->tinyInteger(),
            'open_date' => $this->date(),
            'close_date' => $this->date(),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_account}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_account}}');
    }
}
