<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_account_statements}}`.
 */
class m200902_073825_create_rf_info_account_statements_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_account_statements}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'rest_in' => $this->float(2),
            'turn_cred' => $this->float(2),
            'turn_debt' => $this->float(2),
            'doc_quantity' => $this->integer(),
            'rest_out' => $this->float(2),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_account_statements}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');

        $this->createTable('{{%rf_info_account_statement}}', [
            'id' => $this->primaryKey(),
            'container_id' => $this->integer()->notNull(),
            'diasoft_id' => $this->string(20),
            'account' => $this->string(255),
            'date_start' => $this->date(),
            'date_end' => $this->date(),
            'doc_date' => $this->date(),
            'doc_number' => $this->string(255),
            'vo' => $this->string(255),
            'bic_contractor' => $this->string(255),
            'account_contractor' => $this->string(255),
            'contractor' => $this->string(255),
            'qty_cred' => $this->float(2),
            'qty_debt' => $this->float(2),
            'inn_contractor' => $this->string(20),
            'comment' => $this->string(255),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_account_statement}}', 'container_id', '{{%rf_info_account_statements}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_account_statement}}');

        $this->dropTable('{{%rf_info_account_statements}}');
    }
}
