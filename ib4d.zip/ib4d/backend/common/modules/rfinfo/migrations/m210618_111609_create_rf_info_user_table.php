<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_user}}`.
 */
class m210618_111609_create_rf_info_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_user}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'user_name' => $this->string(255),
            'authority_begin_date' => $this->date(),
            'authority_end_date' => $this->date(),
            'phone_number' => $this->string(30),
            'key_word' => $this->string(30),
            'diasoft_id' => $this->string(20),
            'name' => $this->string(255),
            'inn' => $this->string(20),
            'kpp' => $this->string(20),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_user}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_user}}');
    }
}
