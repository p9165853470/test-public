<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%rf_info_check_code}}`.
 */
class m210629_054158_create_rf_info_check_code_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%rf_info_check_code}}', [
            'id' => $this->primaryKey(),
            'request_id' => $this->integer()->notNull(),
            'check_factor_result' => $this->string(50),
            'check_factor_msg' => $this->string(255),
        ]);

        $this->addForeignKeyNamed('{{%rf_info_check_code}}', 'request_id', '{{%rf_info_request}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%rf_info_check_code}}');
    }
}
