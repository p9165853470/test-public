<?php

namespace common\modules\rfinfo\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\modules\rfinfo\repositories\ResponseRepository;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $request_id
 *
 * @property-read Request|null $request
 */
abstract class AbstractResponse extends ActiveRecord implements ModelHasRepositoryInterface
{
    public static function getRepository(): ResponseRepository
    {
        $result = new ResponseRepository(static::class);
        return $result;
    }

    public function getRequest(): ActiveQuery
    {
        return $this->hasOne(Request::class, ['id' => 'request_id']);
    }

    public function fields(): array
    {
        return $this->dtoAttributes();
    }

    public function rules(): array
    {
        return [
            [$this->dtoAttributes(), 'safe'],
        ];
    }

    public function dtoAttributes(): array
    {
        return array_diff($this->attributes(), ['id', 'request_id']);
    }
}