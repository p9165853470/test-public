<?php


namespace common\modules\rfinfo\models;

/**
 * @property string $diasoft_id
 * @property string $account
 * @property float $rest
 * @property float $rko_debt
 * @property int $arrest
 * @property string $open_date
 * @property string $close_date
 */
class Account extends AbstractResponse
{
    public static function tableName(): string
    {
        return '{{%rf_info_account}}';
    }
}