<?php

namespace common\modules\rfinfo\models;

use common\modules\rfinfo\behaviors\ResponseContainerInterface;
use common\modules\rfinfo\behaviors\ResponseContainerTrait;
use yii\db\ActiveQuery;

/**
 * @property float $rest_in
 * @property float $turn_cred
 * @property float $turn_debt
 * @property int $doc_quantity
 * @property float $rest_out
 *
 * @property AccountStatement[] $statements
 */
class AccountStatements extends AbstractResponse implements ResponseContainerInterface
{
    use ResponseContainerTrait;

    public static function tableName(): string
    {
        return '{{%rf_info_account_statements}}';
    }

    public function getStatements(): ActiveQuery
    {
        return $this->hasMany(AccountStatement::class, ['container_id' => 'id']);
    }

    public function setStatements(array $items): void
    {
        $this->attachItems($items);
    }

    public function dtoAttributes(): array
    {
        return array_merge(parent::dtoAttributes(), ['statements']);
    }

    protected function getItemsAttribute(): string
    {
        return 'statements';
    }
}