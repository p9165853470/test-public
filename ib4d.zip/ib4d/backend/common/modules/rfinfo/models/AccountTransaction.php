<?php

namespace common\modules\rfinfo\models;

use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property int $container_id
 * @property string $diasoft_id
 * @property string $doc_date
 * @property string $doc_number
 * @property float $qty_cred
 * @property float $qty_debt
 * @property string $comment
 *
 * @property-read AccountTransactions $container
 */
class AccountTransaction extends ActiveRecord
{
    public static function tableName(): string
    {
        return '{{%rf_info_account_statement}}';
    }

    public function fields(): array
    {
        return $this->dtoAttributes();
    }

    public function rules(): array
    {
        return [
            [$this->dtoAttributes(), 'safe'],
        ];
    }

    public function dtoAttributes(): array
    {
        return ['diasoft_id', 'doc_date', 'doc_number', 'qty_cred', 'qty_debt', 'comment'];
    }

    public function getContainer(): ActiveQuery
    {
        return $this->hasOne(AccountTransactions::class, ['id' => 'container_id']);
    }
}