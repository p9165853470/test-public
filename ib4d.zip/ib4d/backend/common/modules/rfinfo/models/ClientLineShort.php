<?php

namespace common\modules\rfinfo\models;

class ClientLineShort extends ClientLine
{
    public function dtoAttributes(): array
    {
        return ['number', 'type', 'status', 'name_brand', 'name_product'];
    }
}