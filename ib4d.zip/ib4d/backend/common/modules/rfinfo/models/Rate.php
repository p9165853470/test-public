<?php

namespace common\modules\rfinfo\models;

/**
 * @property string $date_rate
 * @property float $value
 */
class Rate extends AbstractResponse
{
    public static function tableName(): string
    {
        return '{{%rf_info_rate}}';
    }
}