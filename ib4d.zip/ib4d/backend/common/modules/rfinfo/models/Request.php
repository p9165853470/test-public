<?php

namespace common\modules\rfinfo\models;

use yii\behaviors\TimestampBehavior;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property string $form_id
 * @property string $form_hash
 * @property string $method
 * @property bool $multiple
 * @property string $created_at
 */
class Request extends ActiveRecord
{
    /**
     * Интервал, за который запрос считается устаревшим
     * @todo Вынести в конфиг
     */
    public const EXPIRE_INTERVAL = 'PT15M';

    public static function tableName(): string
    {
        return '{{%rf_info_request}}';
    }

    public function behaviors(): array
    {
        return [
            [
                'class' => TimestampBehavior::class,
                'attributes' => [
                    self::EVENT_BEFORE_INSERT => ['created_at']
                ]
            ],
        ];
    }

    public function getResponse(string $responseModelClass): ActiveQuery
    {
        return $this->createRelationQuery($responseModelClass, ['request_id' => 'id'], $this->multiple)
            ->inverseOf('request');
    }
}