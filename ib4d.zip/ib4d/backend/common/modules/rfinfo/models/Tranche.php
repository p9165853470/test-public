<?php


namespace common\modules\rfinfo\models;

use common\modules\rfinfo\repositories\ResponseRepository;
use common\modules\tranche\repositories\TrancheResponseRepository;

/**
 * @property string $vin
 * @property string $name_brand
 * @property string $model
 * @property string $number
 * @property string $type
 * @property int $status
 * @property float $sum_amount
 * @property float $sum_pre_pay
 * @property string $real_start_date
 * @property string $date_beg_pay
 * @property string $finish_date
 * @property float $rest_main_debt
 * @property float $overdue_debt
 * @property boolean $flag_overdue_debt
 * @property float $percent_rate
 * @property float $sum_percent
 * @property float $sum_fin
 * @property float $sum_comiss
 */
class Tranche extends AbstractResponse
{
    /**
     * Тип погашения
     *
     * @var string
     */
    public $payment_type;

    public static function getRepository(): ResponseRepository
    {
        $result = new TrancheResponseRepository(static::class);
        return $result;
    }

    public static function tableName(): string
    {
        return '{{%rf_info_tranche}}';
    }

    public function fields(): array
    {
        return array_merge(parent::fields(), ['payment_type']);
    }
}