<?php

namespace common\modules\rfinfo\models;

/**
 * @property string $user_name
 * @property string $authority_begin_date
 * @property string $authority_end_date
 * @property string $phone_number
 * @property string $key_word
 * @property string $diasoft_id
 * @property string $name
 * @property string $inn
 * @property string $kpp
 */
class User extends AbstractResponse
{
    public static function tableName(): string
    {
        return '{{%rf_info_user}}';
    }
}