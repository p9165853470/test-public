<?php

namespace common\modules\rfinfo\repositories;

use common\modules\rfinfo\dto\AbstractDto;
use common\modules\rfinfo\models\AbstractResponse;
use common\modules\rfinfo\models\Request;
use common\repositories\AnonymousRepository;

/**
 * @method AbstractResponse model()
 * @method AbstractResponse findOne($condition = null)
 * @method AbstractResponse[] findAll($condition = null)
 */
class ResponseRepository extends AnonymousRepository
{
    public function create(Request $request, AbstractDto $data): AbstractResponse
    {
        $model = $this->model();
        $model->setAttributes($data->toArray());
        $model->request_id = $request->id;

        $this->save($model);

        return $model;
    }

    /**
     * @param Request $request
     * @param AbstractDto[] $data
     * @return array
     */
    public function createMany(Request $request, array $data): array
    {
        $models = [];

        foreach ($data as $item) {
            $models[] = $this->create($request, $item);
        }

        return $models;
    }
}