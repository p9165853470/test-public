<?php

namespace common\modules\rfinfo\services;

use common\enums\MimeTypeEnum;
use common\modules\rfinfo\behaviors\AccountStatementsFormatterInterface;
use common\modules\rfinfo\behaviors\AccountStatementsFormatterTrait;

class AccountStatementsTxtFormatter implements AccountStatementsFormatterInterface
{
    use AccountStatementsFormatterTrait;

    private const DATE_FORMAT = 'd.m.Y';

    /**
     * @var string
     */
    private $templatePath = '@common/modules/rfinfo/templates/account-statements.txt';

    public function __construct()
    {
        $this->templatePath = \Yii::getAlias($this->templatePath);
    }

    public function format(): string
    {
        $content = file_get_contents($this->templatePath);

        $qtyDebtSum = array_sum(array_column($this->accountStatements->statements, 'qty_debt'));
        $qtyCredSum = array_sum(array_column($this->accountStatements->statements, 'qty_cred'));

        $content = strtr($content, [
            '{request_start_date}' => date_create($this->query->start_date)->format(self::DATE_FORMAT),
            '{request_end_date}' => date_create($this->query->end_date)->format(self::DATE_FORMAT),
            '{account_number}' => $this->query->account,
            '{company_name}' => $this->info->name,
            '{rest_in}' => $this->formatNumber($this->accountStatements->rest_in),
            '{turn_debt}' => $this->formatNumber($this->accountStatements->turn_debt),
            '{turn_cred}' => $this->formatNumber($this->accountStatements->turn_cred),
            '{doc_quantity}' => $this->accountStatements->doc_quantity,
            '{rest_out}' => $this->formatNumber($this->accountStatements->rest_out),
            '{qty_debt_sum}' => $this->formatNumber($qtyDebtSum),
            '{qty_cred_sum}' => $this->formatNumber($qtyCredSum),
        ]);

        return preg_replace_callback('/{items:}(.+?){:items}/su', function ($data) {
            $content = '';

            foreach ($this->accountStatements->statements as $i => $statement) {
                $content .= strtr($data[1], [
                    '{item_doc_date}' => date_create($statement->doc_date)->format(self::DATE_FORMAT),
                    '{item_doc_number}' => $statement->doc_number,
                    '{item_vo}' => $statement->vo,
                    '{item_bic_contractor}' => $statement->bic_contractor,
                    '{item_account_contractor}' => $statement->account_contractor,
                    '{item_qty_cred}' => $this->formatNumber($statement->qty_cred),
                    '{item_qty_debt}' => $this->formatNumber($statement->qty_debt),
                    '{item_contractor}' => $statement->contractor,
                    '{item_inn_contractor}' => $statement->inn_contractor,
                    '{item_comment}' => $statement->comment,
                ]);
            }

            return $content;
        }, $content);
    }

    public function getMimeType(): string
    {
        return MimeTypeEnum::TXT;
    }
}