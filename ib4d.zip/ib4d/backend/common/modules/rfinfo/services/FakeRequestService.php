<?php

namespace common\modules\rfinfo\services;

use common\helpers\Date;
use common\modules\rfinfo\behaviors\RequestServiceInterface;
use common\modules\rfinfo\components\RequestContext;
use common\modules\rfinfo\dto\Account;
use common\modules\rfinfo\dto\AccountArrest;
use common\modules\rfinfo\dto\AccountArrests;
use common\modules\rfinfo\dto\AccountStatement;
use common\modules\rfinfo\dto\AccountStatements;
use common\modules\rfinfo\dto\AccountTransaction;
use common\modules\rfinfo\dto\AccountTransactions;
use common\modules\rfinfo\dto\ClientLine;
use common\modules\rfinfo\dto\ClientLineShort;
use common\modules\rfinfo\dto\Info;
use common\modules\rfinfo\dto\Rate;
use common\modules\rfinfo\dto\Tranche;
use common\modules\rfinfo\enums\AccountArrestEnum;
use common\modules\rfinfo\enums\ClientLineStatusEnum;
use common\modules\rfinfo\enums\ClientLineTypeEnum;
use common\modules\rfinfo\enums\RequestMethodEnum;

class FakeRequestService implements RequestServiceInterface
{
    public function getInfo(RequestContext $context): Info
    {
        return new Info([
            'diasoft_id' => $context->getQuery()->diasoft_id,
            'name' => 'ООО "ПОРШЕ РУССЛАНД"',
            'inn' => '5316035231',
            'kpp' => '828143030',
        ]);
    }

    public function getClientLines(RequestContext $context): array
    {
        $result = [];

        $types = $this->getClientLineTypes();
        $statuses = $this->getClientLineStatuses();

        for ($i = 0; $i < 50; $i++) {
            $result[] = new ClientLineShort([
                'number' => 800 + $i,
                'type' => $this->value($types),
                'status' => $this->value($statuses),
                'name_brand' => 'ООО "ПОРШЕ РУССЛАНД"',
                'name_product' => 'Новые автомобили',
            ]);
        }

        $this->filter($result, 'status', $context->getQuery()->line_status);

        return $result;
    }

    public function getClientLine(RequestContext $context): ClientLine
    {
        $types = $this->getClientLineTypes();
        $statuses = $this->getClientLineStatuses();

        return new ClientLine([
            'number' => $context->getQuery()->number_line,
            'type' => $this->value($types),
            'status' => $this->value($statuses),
            'name_brand' => 'ООО "ПОРШЕ РУССЛАНД"',
            'name_product' => 'Новые автомобили',
            'start_date' => '2018-12-29',
            'real_finish_date' => '2020-04-20',
            'finish_date' => '2020-03-31',
            'limit_amount' => 4000000.00,
            'total_main_debt' => 900000.00,
            'rest_limit' => 3100000.00,
            'date_near_line_pay' => '2020-04-15',
            'flag_near_line_pay' => 0,
            'percent_rate' => '2.50;5.00',
            'date_percent_rate' => '2018-12-29',
            'comiss_type' => '1;2',
            'summ_comiss_debt' => 0.00,
            'line_block' => 0,
            'overdue_debt' => 0,
        ]);
    }

    public function getTranches(RequestContext $context): array
    {
        $result = [];

        $brands = ['Porsche', 'BMW', 'Opel', 'Nissan'];
        $models = ['Cayenne', 'M3', 'Astra', 'Silvia'];
        $types = $this->getClientLineTypes();
        $statuses = $this->getClientLineStatuses();

        for ($i = 0; $i < 50; $i++) {
            $result[] = new Tranche([
                'vin' => 'ZBB0000112223' . $context->getQuery()->diasoft_id . (10 + $i),
                'name_brand' => $this->value($brands),
                'model' => $this->value($models),
                'number' => 800 + $i,
                'type' => $this->value($types),
                'status' => $this->value($statuses),
                'sum_amount' => 5000000.00,
                'sum_pre_pay' => 1000000.00,
                'real_start_date' => '2020-01-31',
                'date_beg_pay' => '2020-02-01',
                'finish_date' => '2020-12-31',
                'rest_main_debt' => 4000000.00,
                'overdue_debt' => 0.00,
                'flag_overdue_debt' => false,
                'percent_rate' => 20.00,
                'sum_percent' => 120000.00,
                'sum_fin' => 0.00,
                'sum_comiss' => 15000.00,
            ]);
        }

        $this->filter($result, 'number', $context->getQuery()->number_line);
        $this->filter($result, 'type', $context->getQuery()->type_line);
        $this->filter($result, 'status', $context->getQuery()->line_status);

        return $result;
    }

    public function getAccounts(RequestContext $context): array
    {
        $result = [];

        $arrests = AccountArrestEnum::getRange();

        for ($i = 0; $i < 50; $i++) {
            $result[] = new Account([
                'diasoft_id' => $context->getQuery()->diasoft_id,
                'account' => 900 + $i,
                'rest' => 900000.00,
                'rko_debt' => 120.00,
                'arrest' => $this->value($arrests),
                'open_date' => '2020-02-23',
                'close_date' => ($i + 1) % 2 === 0 ? '2020-03-08' : null,
            ]);
        }

        return $result;
    }

    public function getAccountTransactions(RequestContext $context): AccountTransactions
    {
        $accountStatements = $this->getAccountStatements($context->create(RequestMethodEnum::ACCOUNT_STATEMENTS));
        $container = new AccountTransactions();

        foreach ($accountStatements->statements as $statement) {
            $container->transactions[] = new AccountTransaction([
                'diasoft_id' => $statement->diasoft_id,
                'doc_date' => $statement->doc_date,
                'doc_number' => $statement->doc_number,
                'qty_cred' => $statement->qty_cred,
                'qty_debt' => $statement->qty_debt,
                'comment' => $statement->comment,
            ]);
        }

        $container->rest_in = $accountStatements->rest_in;
        $container->rest_out = $accountStatements->rest_out;
        $container->turn_cred = $accountStatements->turn_cred;
        $container->turn_debt = $accountStatements->turn_debt;

        return $container;
    }

    public function getAccountStatements(RequestContext $context): AccountStatements
    {
        $container = new AccountStatements();

        for ($i = 0; $i < 50; $i++) {
            if (($i + 1) % 2 === 0) {
                $qty_cred = 9000000.00;
                $qty_debt = null;
            } else {
                $qty_cred = null;
                $qty_debt = 1500000.00;
            }

            $container->statements[] = new AccountStatement([
                'diasoft_id' => $context->getQuery()->diasoft_id,
                'account' => $context->getQuery()->account,
                'date_start' => '2020-02-23',
                'date_end' => '2020-03-08',
                'doc_date' => '2020-02-05',
                'doc_number' => '1577530',
                'vo' => '17',
                'bic_contractor' => '123456789',
                'account_contractor' => '12345678901234567890',
                'contractor' => 'ООО "Контрагент"',
                'qty_cred' => $qty_cred,
                'qty_debt' => $qty_debt,
                'inn_contractor' => '302543502',
                'comment' => 'Перевод через банкомат',
            ]);
        }

        $container->rest_in = 1000000.00;
        $container->turn_cred = 554000.00;
        $container->turn_debt = 125000.00;
        $container->doc_quantity = 5;
        $container->rest_out = 1200000.00;

        return $container;
    }

    public function getAccountArrests(RequestContext $context): AccountArrests
    {
        $container = new AccountArrests();

        for ($i = 0; $i < 10; $i++) {
            $container->arrests[] = new AccountArrest([
                'diasoft_id' => $context->getQuery()->diasoft_id,
                'account' => $context->getQuery()->account,
                'arrest_type' => 'Вид ограничения',
                'arrest_date' => '2020-05-29',
                'arrest_qty' => ($i + 1) % 3 === 0 ? null : 1260000.00,
                'arrest_organization' => 'ООО "Накладываю арест по фото"'
            ]);
        }

        $container->krt_count = 12;
        $container->krt_qty = 150000.00;

        return $container;
    }

    public function getRate(RequestContext $context): array
    {
        return [
            new Rate([
                'date_rate' => date(Date::INTERNAL_DATE_FORMAT),
                'value' => 6.43,
            ])
        ];
    }

    protected function value(array &$items)
    {
        $value = array_shift($items);
        $items[] = $value;

        return $value;
    }

    protected function filter(array &$items, string $key, $value, string $operator = '='): void
    {
        $items = array_values(array_filter($items, static function ($item) use ($key, $value, $operator) {
            if ($value === null) {
                return true;
            }

            switch ($operator) {
                case '=':
                    return (string)$item->{$key} === (string)$value;
                case '!=':
                    return (string)$item->{$key} !== (string)$value;
                case '>':
                    return $item->{$key} > $value;
                case '>=':
                    return $item->{$key} >= $value;
                case '<':
                    return $item->{$key} < $value;
                case '<=':
                    return $item->{$key} <= $value;
            }

            return false;
        }));
    }

    protected function getClientLineTypes(): array
    {
        return ClientLineTypeEnum::getRange();
    }

    protected function getClientLineStatuses(): array
    {
        return [
            ClientLineStatusEnum::OPENED,
            ClientLineStatusEnum::CLOSED,
        ];
    }
}