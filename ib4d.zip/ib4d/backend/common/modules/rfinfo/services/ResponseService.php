<?php

namespace common\modules\rfinfo\services;

use common\exceptions\NotFoundModelException;
use common\modules\rfinfo\behaviors\RequestServiceInterface;
use common\modules\rfinfo\behaviors\ResponseResourceInterface;
use common\modules\rfinfo\behaviors\ResponseServiceInterface;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\factories\ResponseFactory;
use common\modules\rfinfo\forms\QueryForm;
use common\modules\rfinfo\repositories\RequestRepository;
use yii\helpers\Inflector;

class ResponseService implements ResponseServiceInterface
{
    /**
     * @var RequestRepository
     */
    protected $repository;
    /**
     * @var ResponseFactory
     */
    protected $responseFactory;

    public function __construct(
        RequestRepository $repository,
        ResponseFactory $responseFactory
    ) {
        $this->repository = $repository;
        $this->responseFactory = $responseFactory;
    }

    public function has(QueryForm $query): bool
    {
        try {
            $this->repository->findOneByQuery($query);
        } catch (NotFoundModelException $ex) {
            return false;
        }

        return true;
    }

    public function set(QueryForm $query, $data): void
    {
        $responseClass = $this->responseFactory->getModelClass($query->getContext()->getMethod());
        $responseRepository = $responseClass::getRepository();

        $transaction = \Yii::$app->getDb()->beginTransaction();

        try {
            $request = $this->repository->create($query, is_array($data));

            if ($request->multiple) {
                $responseRepository->createMany($request, $data);
            } else {
                $responseRepository->create($request, $data);
            }
        } catch (\Throwable $ex) {
            if ($transaction !== null) {
                $transaction->rollBack();
            }

            throw $ex;
        }

        if ($transaction !== null) {
            $transaction->commit();
        }
    }

    public function get(QueryForm $query): ResponseResourceInterface
    {
        $request = $this->repository->findOneByQuery($query);

        $responseClass = $this->responseFactory->getModelClass($query->getContext()->getMethod());
        $responseQuery = $request->getResponse($responseClass);

        $query->id = $request->form_id;

        /** @var ResponseResourceInterface $resource */
        $resource = \Yii::createObject(ResponseResourceInterface::class, [$responseQuery]);

        return $resource;
    }
}