<?php

namespace common\modules\session\behaviors;

use common\modules\authentication\behaviors\TokenInterface;
use common\modules\session\exceptions\SessionException;
use common\modules\user\behaviors\IdentityInterface;

/**
 * Интерфейс сущности сессии пользователя
 */
interface SessionInterface
{
    /**
     * Указать токен для сессии
     *
     * @param TokenInterface $token
     */
    public function setToken(TokenInterface $token): void;

    /**
     * Указать пользователя для сессии
     *
     * @param IdentityInterface $identity
     */
    public function setIdentity(IdentityInterface $identity): void;

    /**
     * Получить пользователя сессии
     *
     * @return IdentityInterface
     * @throws SessionException
     */
    public function getIdentity(): IdentityInterface;

    /**
     * Проверить, не истекло ли время сессии по последнему действию
     *
     * @return bool
     */
    public function isExpired(): bool;


    /**
     * Проверить, подтвержден ли вход
     *
     * @return bool
     */
    public function isConfirmed(): bool;

    /**
     * Установить дату подтверждения входа
     *
     */
    public function setConfirm(): void;

    /**
     * Получить код DiasoftId из сессии
     *
     * @return string
     */
    public function getDiasoftId(): ?string;
}