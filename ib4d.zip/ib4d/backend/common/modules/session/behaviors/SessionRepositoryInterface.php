<?php

namespace common\modules\session\behaviors;

use common\exceptions\NotFoundModelException;
use common\exceptions\SaveModelException;
use common\modules\authentication\behaviors\TokenInterface;
use common\modules\user\behaviors\IdentityInterface;
use yii\db\ActiveRecord;

/**
 * Интерфейс репозитория для сессий пользователя
 */
interface SessionRepositoryInterface
{
    /**
     * Найти сессию по токену
     *
     * @param TokenInterface $token
     * @return SessionInterface|ActiveRecord
     * @throws NotFoundModelException
     */
    public function findOneByToken(TokenInterface $token): SessionInterface;

    /**
     * Создать сессию по токену
     *
     * @param TokenInterface $token
     * @param IdentityInterface $identity
     * @return SessionInterface
     * @throws SaveModelException
     */
    public function create(TokenInterface $token, IdentityInterface $identity): SessionInterface;

    /**
     * Удплить все сессии пользователя
     *
     * @param IdentityInterface $identity
     */
    public function deleteByIdentity(IdentityInterface $identity): void;
}