<?php

namespace common\modules\session\behaviors;

use common\behaviors\GarbageCollectorInterface;
use common\modules\authentication\behaviors\TokenInterface;
use common\modules\session\exceptions\SessionException;
use common\modules\user\behaviors\IdentityInterface;

/**
 * Интерфейс сервиса по работе с сессиями пользователями
 */
interface SessionServiceInterface extends GarbageCollectorInterface
{
    /**
     * Проверить, существует ли сессия для токена
     *
     * @param TokenInterface $token
     * @return bool
     */
    public function has(TokenInterface $token): bool;

    /**
     * Получить сессию по токену
     *
     * @param TokenInterface $token
     * @return SessionInterface
     * @throws SessionException
     */
    public function get(TokenInterface $token): SessionInterface;

    /**
     * Создать сессию для токена
     *
     * @param TokenInterface $token
     * @param IdentityInterface $identity
     * @return SessionInterface
     * @throws SessionException
     */
    public function add(TokenInterface $token, IdentityInterface $identity): SessionInterface;

    /**
     * Обновить токен для сессии
     *
     * @param SessionInterface $session
     * @param TokenInterface $token
     * @throws SessionException
     */
    public function renew(SessionInterface $session, TokenInterface $token): void;

    /**
     * Установить время последнего запроса в сессии
     *
     * @param SessionInterface $session
     */
    public function touch(SessionInterface $session): void;

    /**
     * Удалить конкретную сессию
     * @param SessionInterface $session
     */
    public function destroy(SessionInterface $session): void;

    /**
     * Удалить все сессии для пользователя
     *
     * @param IdentityInterface $identity
     */
    public function destroyAll(IdentityInterface $identity): void;
}