<?php

namespace common\modules\session\behaviors;

use common\exceptions\DeleteModelException;
use common\exceptions\NotFoundModelException;
use common\exceptions\SaveModelException;
use common\modules\authentication\behaviors\TokenInterface;
use common\modules\session\exceptions\SessionException;
use common\modules\user\behaviors\IdentityInterface;
use common\repositories\Repository;
use yii\db\ActiveRecord;

trait SessionServiceTrait
{
    /**
     * @var SessionRepositoryInterface|Repository
     */
    protected $repository;

    public function has(TokenInterface $token): bool
    {
        try {
            $this->repository->findOneByToken($token);
        } catch (NotFoundModelException $ex) {
            return false;
        }
        return true;
    }

    public function get(TokenInterface $token): SessionInterface
    {
        try {
            return $this->repository->findOneByToken($token);
        } catch (NotFoundModelException $ex) {
            throw new SessionException('Session not found.');
        }
    }

    public function add(TokenInterface $token, IdentityInterface $identity): SessionInterface
    {
        try {
            return $this->repository->create($token, $identity);
        } catch (SaveModelException $ex) {
            throw new SessionException('Unable to create session: ' . $ex->getMessage());
        }
    }

    /**
     * @param SessionInterface|ActiveRecord $session
     * @param TokenInterface $token
     */
    public function renew(SessionInterface $session, TokenInterface $token): void
    {
        $session->setToken($token);

        try {
            $this->repository->save($session);
        } catch (SaveModelException $ex) {
            throw new SessionException('Unable to renew session: ' . $ex->getMessage());
        }
    }

    /**
     * @param SessionInterface|ActiveRecord $session
     * @throws DeleteModelException
     */
    public function destroy(SessionInterface $session): void
    {
        $this->repository->delete($session);
    }

    public function destroyAll(IdentityInterface $identity): void
    {
        $this->repository->deleteByIdentity($identity);
    }
}