<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%front_user_session}}`.
 */
class m200728_131452_create_front_user_session_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%front_user_session}}', [
            'id' => $this->primaryKey(),
            'token_id' => $this->string(16)->notNull()->unique(),
            'user_id' => $this->integer()->notNull(),
            'created_at' => $this->timestamp()->notNull(),
            'updated_at' => $this->timestamp()->notNull(),
        ]);

        $this->addForeignKeyNamed('{{%front_user_session}}', 'user_id', '{{%front_user}}', 'id', 'CASCADE');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%front_user_session}}');
    }
}
