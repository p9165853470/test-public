<?php

namespace common\modules\session\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\behaviors\ModelHasRepositoryTrait;
use common\modules\authentication\behaviors\TokenInterface;
use common\modules\session\behaviors\SessionInterface;
use common\modules\session\repositories\BackUserSessionRepository;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\BackUser;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property string $token_id
 * @property int $user_id
 * @property string $created_at
 * @property string $updated_at
 *
 * @property BackUser|null $user
 *
 * @method static BackUserSessionRepository getRepository()
 * @method void touch($attribute)
 */
class BackUserSession extends ActiveRecord implements ModelHasRepositoryInterface, SessionInterface
{
    use ModelHasRepositoryTrait;

    /**
     * Столько должно пройти времени после последнего
     * запроса по сессии, чтобы считать ее устаревшей
     * @todo Вынести в конфиг
     */
    public const EXPIRE_INTERVAL = 'PT1H';

    public static function getRepositoryClass(): string
    {
        return BackUserSessionRepository::class;
    }

    public function behaviors(): array
    {
        return [
            TimestampBehavior::class,
        ];
    }

    public function getUser(): ActiveQuery
    {
        return $this->hasOne(BackUser::class, ['id' => 'user_id']);
    }

    public function rules(): array
    {
        return [
            ['token_id', 'string', 'max' => 16],
            ['token_id', 'unique'],
            ['user_id', 'exist', 'targetClass' => BackUser::class, 'targetAttribute' => 'id'],
        ];
    }

    public function setToken(TokenInterface $token): void
    {
        $this->token_id = $token->getId();
    }

    public function setIdentity(IdentityInterface $identity): void
    {
        $this->user_id = $identity->getId();
    }

    public function getIdentity(): IdentityInterface
    {
        return $this->user;
    }

    public function isExpired(): bool
    {
        $date1 = date_create($this->updated_at);
        $date2 = date_create()->sub(new \DateInterval(self::EXPIRE_INTERVAL));

        return $date1 < $date2;
    }
    public function isConfirmed(): bool
    {
        return true;
    }
    public function setConfirm(): void
    {
        // TODO: Implement setConfirm() method.
    }

    public function getDiasoftId(): ?string
    {
        // TODO: Implement getDiasoftId() method.
        return '';
    }
}