<?php

namespace common\modules\session\repositories;

use common\exceptions\NotFoundModelException;
use common\helpers\Date;
use common\modules\authentication\behaviors\TokenInterface;
use common\modules\session\behaviors\SessionInterface;
use common\modules\session\behaviors\SessionRepositoryInterface;
use common\modules\session\models\FrontUserSession;
use common\modules\user\behaviors\IdentityInterface;
use common\repositories\Repository;
use yii\db\ActiveRecord;

/**
 * @method FrontUserSession model()
 * @method FrontUserSession findOne($condition = null)
 * @method FrontUserSession[] findAll($condition = null)
 */
class FrontUserSessionRepository extends Repository implements SessionRepositoryInterface
{
    public function getModelClass(): string
    {
        return FrontUserSession::class;
    }

    /**
     * @param TokenInterface $token
     * @return SessionInterface|ActiveRecord
     */
    public function findOneByToken(TokenInterface $token): SessionInterface
    {
        //$expireDate = date_create()->sub(new \DateInterval(FrontUserSession::EXPIRE_INTERVAL));

        $model = $this->find([
            'and',
            ['token_id' => $token->getId()],
            //['>=', 'updated_at', $expireDate->format(Date::INTERNAL_DATETIME_FORMAT)]
        ])->one();

        if ($model === null) {
            throw new NotFoundModelException('Model not found.');
        }

        return $model;
    }

    public function create(TokenInterface $token, IdentityInterface $identity): SessionInterface
    {
        $model = $this->model();

        $model->token_id = $token->getId();
        $model->user_id = $identity->getId();

        $this->save($model);

        return $model;
    }

    public function deleteByIdentity(IdentityInterface $identity): void
    {
        /** @var FrontUserSession $modelClass */
        $modelClass = $this->getModelClass();
        $modelClass::deleteAll([
            'user_id' => $identity->getId(),
        ]);
    }
}