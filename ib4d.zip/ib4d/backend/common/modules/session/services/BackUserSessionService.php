<?php

namespace common\modules\session\services;

use common\helpers\Date;
use common\modules\session\behaviors\SessionInterface;
use common\modules\session\behaviors\SessionServiceInterface;
use common\modules\session\behaviors\SessionServiceTrait;
use common\modules\session\models\BackUserSession;
use common\modules\session\repositories\BackUserSessionRepository;

class BackUserSessionService implements SessionServiceInterface
{
    use SessionServiceTrait;

    public function __construct(BackUserSessionRepository $repository)
    {
        $this->repository = $repository;
    }

    /**
     * @param SessionInterface|BackUserSession $session
     */
    public function touch(SessionInterface $session): void
    {
        $session->touch('updated_at');
    }

    public function collectGarbage(): int
    {
        $date = date_create()
            ->sub(new \DateInterval(BackUserSession::EXPIRE_INTERVAL))
            ->format(Date::INTERNAL_DATETIME_FORMAT);

        return BackUserSession::deleteAll(['<', 'updated_at', $date]);
    }
}