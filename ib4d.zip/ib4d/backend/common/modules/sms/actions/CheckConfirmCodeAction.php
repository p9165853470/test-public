<?php

namespace common\modules\sms\actions;

use common\enums\ErrorEnum;
use common\models\errors\RFInfoRequestError;
use common\modules\rfinfo\behaviors\RequestServiceInterface;
use common\modules\session\behaviors\SessionServiceInterface;
use common\modules\session\services\FrontUserSessionService;
use frontend\services\FrontUserService;
use common\modules\sms\enums\CheckFactorResultEnum;
use common\modules\sms\resources\CheckCodeResource;
use common\modules\rfinfo\behaviors\RequestCacheServiceInterface;
use common\modules\rfinfo\behaviors\ResponseResourceInterface;
use common\modules\rfinfo\enums\RequestMethodEnum;
use common\modules\rfinfo\exceptions\RequestServiceException;
use common\modules\rfinfo\factories\RequestFactory;
use common\modules\rfinfo\resources\ResponseResource;
use common\modules\sms\forms\CheckCodeForm;
use common\modules\sms\services\CheckCodeService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use common\modules\user\enums\BlockReasonEnum;
use Yii;
use yii\base\Action;
use yii\di\Instance;
use yii\web\BadRequestHttpException;
use yii\web\Request;
use yii\web\Response;

class CheckConfirmCodeAction extends Action
{
    /**
     * @var CheckCodeService
     */
    protected $service;
    /**
     * @var RequestCacheServiceInterface
     */
    protected $requestService;
    /**
     * @var RequestFactory
     */
    protected $requestFactory;

    public function __construct(
        $id,
        $controller,
        CheckCodeService $service,
        RequestCacheServiceInterface $requestService,
        RequestFactory $requestFactory,
        $config = []
    ) {
        $this->service = $service;
        $this->requestService = $requestService;
        $this->requestFactory = $requestFactory;

        parent::__construct($id, $controller, $config);
    }

    public function init(): void
    {
        parent::init();

        Yii::$container->set(ResponseResourceInterface::class, ResponseResource::class);
    }

    /**
     * @param Request $request
     * @param Response $response
     * @param IdentityInterface|FrontUser $identity
     * @return CheckCodeForm|CheckCodeResource
     * @throws BadRequestHttpException
     */
    public function run(Request $request, Response $response, IdentityInterface $identity)
    {
        $form = new CheckCodeForm();

        if (!$form->load($request->post())) {
            throw new BadRequestHttpException('No input data.');
        }
        if ($form->validate()) {
            /** @var RequestServiceInterface $service */
            $service = Instance::ensure(RequestServiceInterface::class);
            /** @var RequestFactory $factory */
            $factory = Instance::ensure(RequestFactory::class);
            $context = $factory->getContext(RequestMethodEnum::CHECK_CODE,

//todo Заменить diasoft_id на адекватное наименование - уникальный номер сессии.
                ['diasoft_id' => substr_replace($identity->phone_number,'1',0,1),
                    'factor_url' => $form->factor_url,
                    'confirm_code' => $form->confirm_code,
                    'type_confirm_code' => $form->type_confirm_code,
                ]);
            try {
                $checkCode = $service->postCheckCode($context);
            } catch (RequestServiceException $ex) {
                throw new BadRequestHttpException($ex->getMessage());
            }
            /** @var FrontUserSessionService $sessionService */
            $sessionService = Instance::ensure(FrontUserSessionService::class);
            $session = $identity->getToken()->getSession();
            switch ($checkCode->check_factor_result) {
                case CheckFactorResultEnum::OK:
                    $sessionService->confirm($session);
                    $response->setStatusCode(201);
                    break;
                case CheckFactorResultEnum::CONFIRM_ATTEMPT_COUNT_EXCEEDED:
                    $sessionService->confirmError($session);
                    $response->setStatusCode(400);
                    /**todo Необходимо переместить логику проверки кол-ва ошибок и блокировки пользователя.
                    Для того что бы избавиться от использования объектов из frontend
                     */
                    if ($session->confirm_count >= $session::FILED_SMS_COUNT & !$identity->hasBlock())
                    {
                        $userService = Instance::ensure(FrontUserService::class);
                        $userService->updateBlockReason($identity, BlockReasonEnum::BY_FAILED_CONFIRM);
                        $checkCode->check_factor_result = CheckFactorResultEnum::CONFIRM_SMS_COUNT_EXCEEDED;
                        $checkCode->check_factor_msg = 'Превышено число СМС для подтверждения';
                    }
                default:
                    $response->setStatusCode(400);
            }
            return new CheckCodeResource(
                $checkCode
            );
        }
        return $form;
    }
}