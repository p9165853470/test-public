<?php

namespace common\modules\sms\forms;

use common\modules\rfinfo\enums\SmsTypeEnum;
use yii\base\Model;

class CheckCodeForm extends Model
{
    /**
     * @var string
     */
    public $factor_url;
    /**
     * @var string
     */
    public $confirm_code;
    /**
     * @var string
     */
    public $type_confirm_code;

    public function rules(): array
    {
        return [
            [['factor_url', 'confirm_code', 'type_confirm_code'], 'required'],
            ['type_confirm_code', 'in', 'range' => SmsTypeEnum::getRange()],
        ];
    }

    public function formName(): string
    {
        return '';
    }
}