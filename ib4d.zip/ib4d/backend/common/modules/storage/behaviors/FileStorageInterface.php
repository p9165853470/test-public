<?php

namespace common\modules\storage\behaviors;

use common\modules\storage\models\File;
use yii\web\UploadedFile;

interface FileStorageInterface
{
    /**
     * Сохранить файл в хранилище
     *
     * @param File $model
     * @param UploadedFile $file
     */
    public function save(File $model, UploadedFile $file): void;

    /**
     * Удалить файл из хранилища
     *
     * @param File $model
     */
    public function delete(File $model): void;

    /**
     * Получить ссылку на файл из хранилища
     *
     * @param File $model
     * @return string
     */
    public function getUrl(File $model): string;
}