<?php

namespace common\modules\storage\behaviors;

use common\exceptions\SaveModelException;
use common\modules\storage\exceptions\StorageException;
use common\modules\storage\models\File;
use common\modules\storage\services\FileService;
use Yii;
use yii\db\ActiveRecord;
use yii\web\UploadedFile;

trait UploadServiceTrait
{
    /**
     * @var FileService
     */
    protected $fileService;

    /**
     * @param ActiveRecord $owner
     * @param UploadedFile[]|UploadedFile $files
     * @param string $group
     * @return File|File[]
     */
    public function upload(ActiveRecord $owner, $files, string $group)
    {
        if (is_array($files)) {
            return $this->saveMultiple($owner, $files, $group);
        }

        return $this->saveOne($owner, $files, $group);
    }

    protected function saveOne(ActiveRecord $owner, UploadedFile $file, string $group): ?File
    {
        $transaction = Yii::$app->getDb()->beginTransaction();

        try {
            $model = $this->save($owner, $file, $group);
        } catch (StorageException $ex) {
            if ($transaction !== null) {
                $transaction->rollBack();
            }

            return null;
        }

        if ($transaction !== null) {
            $transaction->commit();
        }

        return $model;
    }

    /**
     * @param ActiveRecord $owner
     * @param UploadedFile[] $files
     * @param string $group
     * @return File[]
     */
    protected function saveMultiple(ActiveRecord $owner, array $files, string $group): array
    {
        $transaction = Yii::$app->getDb()->beginTransaction();

        $models = [];

        foreach ($files as $file) {
            try {
                $models[] = $this->save($owner, $file, $group);
            } catch (SaveModelException|StorageException $ex) {
                if ($transaction !== null) {
                    $transaction->rollBack();
                }

                $this->deleteMultiple($models);

                return [];
            }
        }

        if ($transaction !== null) {
            $transaction->commit();
        }

        return $models;
    }

    /**
     * @param ActiveRecord $owner
     * @param UploadedFile $file
     * @param string $group
     * @return File
     * @throws SaveModelException
     * @throws StorageException
     */
    protected function save(ActiveRecord $owner, UploadedFile $file, string $group): File
    {
        $model = $this->fileService->create($file->name, $group, $owner->getPrimaryKey());

        $this->fileService->getStorage()->save($model, $file);

        return $model;
    }

    /**
     * @param File[] $models
     */
    protected function deleteMultiple(array $models): void
    {
        foreach ($models as $model) {
            $this->fileService->getStorage()->delete($model);
        }
    }
}