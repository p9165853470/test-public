<?php

namespace common\modules\storage\exceptions;

use yii\base\Exception;

class StorageException extends Exception
{

}