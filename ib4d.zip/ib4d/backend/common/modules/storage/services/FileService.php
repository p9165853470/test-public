<?php

namespace common\modules\storage\services;

use common\exceptions\DeleteModelException;
use common\modules\storage\behaviors\FileStorageInterface;
use common\modules\storage\exceptions\StorageException;
use common\modules\storage\models\File;
use common\modules\storage\repositories\FileRepository;

class FileService
{
    /**
     * @var FileRepository
     */
    protected $repository;
    /**
     * @var FileStorageInterface
     */
    protected $storage;

    public function __construct(FileRepository $repository, FileStorageInterface $storage)
    {
        $this->repository = $repository;
        $this->storage = $storage;
    }

    public function getRepository(): FileRepository
    {
        return $this->repository;
    }

    public function getStorage(): FileStorageInterface
    {
        return $this->storage;
    }

    public function create(string $originalName, string $groupCode, int $ownerId): File
    {
        $model = $this->repository->model();
        $model->original_name = $originalName;
        $model->group_code = $groupCode;
        $model->owner_id = $ownerId;

        $model->name = \Yii::$app->security->generateRandomString(24);

        if ($ext = pathinfo($originalName, PATHINFO_EXTENSION)) {
            $model->name .= '.' . $ext;
        }

        $this->repository->save($model);

        return $model;
    }

    public function delete(File $model): bool
    {
        try {
            $this->repository->delete($model);
            $this->storage->delete($model);
        } catch (DeleteModelException $ex) {
            return false;
        }

        return true;
    }
}