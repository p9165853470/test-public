<?php

namespace common\modules\swagger\controllers\swagger;

use common\modules\swagger\controllers\SwaggerController;
use common\modules\swagger\exceptions\SwaggerException;
use common\modules\swagger\services\SwaggerService;
use yii\base\Action;
use yii\helpers\FileHelper;
use yii\web\NotFoundHttpException;
use yii\web\Response;

class FileAction extends Action
{
    /**
     * @var SwaggerController
     */
    public $controller;
    /**
     * @var SwaggerService
     */
    protected $service;

    public function __construct($id, $controller, SwaggerService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    /**
     * @param string $file
     * @param Response $response
     * @return Response|void
     * @throws NotFoundHttpException
     */
    public function run(string $file, Response $response)
    {
        $response->format = Response::FORMAT_RAW;

        try {
            $filePath = $this->service->findFile(\Yii::getAlias($this->controller->filePath), $file);

            return $response->sendFile($filePath, $file, [
                'inline' => true,
                'mimeType' => FileHelper::getMimeType($filePath),
            ]);
        } catch (SwaggerException $ex) {
            throw new NotFoundHttpException('Page not found.');
        }
    }
}