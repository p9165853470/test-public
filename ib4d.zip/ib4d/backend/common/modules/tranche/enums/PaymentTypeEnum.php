<?php

namespace common\modules\tranche\enums;

use common\behaviors\EnumTrait;

class PaymentTypeEnum
{
    use EnumTrait;

    public const FULL_REPAYMENT = 'full-repayment';
    public const PREPAYMENT = 'prepayment';
}