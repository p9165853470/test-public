<?php

namespace common\modules\tranche\forms;

use common\modules\rfinfo\dto\Tranche;
use yii\base\Model;
use yii\helpers\ArrayHelper;

class TranchePaymentsForm extends Model
{
    /**
     * @var TranchePaymentForm[]|array
     */
    public $payments = [];
    /**
     * @var Tranche[]
     */
    protected $tranches = [];

    /**
     * @param Tranche[] $tranches
     */
    public function setTranches(array $tranches): void
    {
        $this->tranches = $tranches;
    }

    /**
     * @return Tranche[]
     */
    public function getTranches(): array
    {
        return $this->tranches;
    }

    public function rules(): array
    {
        return [
            ['payments', 'required'],
            [
                'payments',
                function ($attribute) {
                    $vin = ArrayHelper::getColumn($this->payments, 'vin');

                    if ($vin !== array_unique($vin)) {
                        $this->addError($attribute, 'Vin list is not unique.');
                    }
                }
            ],
            [
                'payments',
                function ($attribute) {
                    foreach ($this->payments as $payment) {
                        if (!$payment->validate()) {
                            $error = $payment->getFirstError(key($payment->getErrors()));

                            $this->addError($attribute, $error);
                        }
                    }
                }
            ],
        ];
    }

    public function beforeValidate(): bool
    {
        $result = parent::beforeValidate();

        if ($result) {
            $this->normalizePayments();
        }

        return $result;
    }

    protected function normalizePayments(): void
    {
        if (!is_array($this->payments)) {
            $this->payments = [];
        }

        foreach ($this->payments as $i => $payment) {
            if (!$payment instanceof TranchePaymentForm) {
                $form = new TranchePaymentForm();
                $form->setAttributes($payment);

                $this->payments[$i] = $form;
            }

            $this->payments[$i]->setTranches($this->tranches);
        }
    }

    public function formName(): string
    {
        return '';
    }
}