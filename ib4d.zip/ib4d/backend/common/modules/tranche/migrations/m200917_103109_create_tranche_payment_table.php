<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%tranche_payment}}`.
 */
class m200917_103109_create_tranche_payment_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%tranche_payment}}', [
            'id' => $this->primaryKey(),
            'user_id' => $this->integer(),
            'vin' => $this->string(100)->notNull()->unique(),
            'sum' => $this->float()->notNull(),
            'type' => $this->string(16)->notNull(),
            'exported' => $this->boolean()->notNull()->defaultValue(false),
            'created_at' => $this->timestamp()->notNull(),
        ]);

        $this->addForeignKeyNamed('{{%tranche_payment}}', 'user_id', '{{%front_user}}', 'id', 'SET NULL');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%tranche_payment}}');
    }
}
