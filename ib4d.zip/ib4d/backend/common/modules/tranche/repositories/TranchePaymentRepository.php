<?php

namespace common\modules\tranche\repositories;

use common\exceptions\SaveModelException;
use common\modules\rfinfo\dto\Tranche;
use common\modules\tranche\enums\PaymentTypeEnum;
use common\modules\tranche\models\TranchePayment;
use common\modules\user\behaviors\IdentityInterface;
use common\repositories\Repository;

/**
 * @method TranchePayment model()
 * @method TranchePayment findOne($condition = null)
 * @method TranchePayment[] findAll($condition = null)
 */
class TranchePaymentRepository extends Repository
{
    public function getModelClass(): string
    {
        return TranchePayment::class;
    }

    /**
     * @param Tranche $tranche
     * @param string $type
     * @param IdentityInterface $identity
     * @return TranchePayment
     * @throws SaveModelException
     */
    public function create($tranche, string $type, IdentityInterface $identity): TranchePayment
    {
        $model = $this->model();
        $model->user_id = $identity->getId();
        $model->type = $type;
        $model->vin = $tranche->vin;

        switch ($type) {
            case PaymentTypeEnum::FULL_REPAYMENT:
                $model->sum = $tranche->sum_amount;
                break;
            case PaymentTypeEnum::PREPAYMENT:
                $model->sum = $tranche->sum_pre_pay;
                break;
        }

        $this->save($model);

        return $model;
    }

    /**
     * @param TranchePayment[] $models
     * @throws SaveModelException
     */
    public function markAsExported(array $models): void
    {
        foreach ($models as $model) {
            $model->exported = true;

            $this->save($model);
        }
    }
}