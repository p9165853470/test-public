<?php

namespace common\modules\tranche\repositories;

use common\modules\rfinfo\dto\AbstractDto;
use common\modules\rfinfo\models\AbstractResponse;
use common\modules\rfinfo\models\Request;
use common\modules\rfinfo\repositories\ResponseRepository;

class TrancheResponseRepository extends ResponseRepository
{
    public function create(Request $request, AbstractDto $data): AbstractResponse
    {
        $model = $this->model();
        $model->setAttributes($data->toArray());
        $model->request_id = $request->id;

        if($model->flag_overdue_debt == null) {
            $model->flag_overdue_debt = false;
        }
        $this->save($model);

        return $model;
    }

}