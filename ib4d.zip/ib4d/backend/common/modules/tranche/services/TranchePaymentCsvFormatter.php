<?php

namespace common\modules\tranche\services;

use common\modules\rfinfo\services\RFInfoRequestService;
use common\modules\tranche\models\TranchePayment;
use common\modules\user\behaviors\IdentityInterface;
use Yii;

class TranchePaymentCsvFormatter
{
    /**
     * @var TranchePayment[]
     */
    protected $payments = [];

    /**
     * @param TranchePayment[] $payments
     */
    public function setPayments(array $payments): void
    {
        $this->payments = $payments;
    }

    public function format(): string
    {
        $file = fopen('php://temp', 'wb');

        //fwrite($file, chr(0xEF) . chr(0xBB) . chr(0xBF));
        $identity = Yii::$app->getUser()->getIdentity();
        $rfInfoService = new RFInfoRequestService();
        if ($identity instanceof IdentityInterface) {
            $info = $rfInfoService->getInfo2($identity->getToken()->getSession()->diasoft_id);
            $name = $info->name;
        }
        else{
            $name = '';
        }
        if ($identity != null) {
            fputcsv($file, [
                'InfoBank',
                $name
            ], ';');
        }
        foreach ($this->payments as $payment) {
            fputcsv($file, [
                'InfoBank',
                $payment->vin,
                number_format($payment->sum, 2, ',', '')
            ], ';');
        }

        rewind($file);
        $content = stream_get_contents($file);

        fclose($file);

        return $content;
    }
}