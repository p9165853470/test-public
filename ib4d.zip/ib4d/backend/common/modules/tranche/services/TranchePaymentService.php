<?php

namespace common\modules\tranche\services;

use common\exceptions\SaveModelException;
use common\modules\rfinfo\dto\Tranche;
use common\modules\tranche\forms\TranchePaymentsForm;
use common\modules\tranche\models\TranchePayment;
use common\modules\tranche\repositories\TranchePaymentRepository;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\models\FrontUser;
use common\services\Service;
use Yii;
use yii\helpers\ArrayHelper;

/**
 * @method TranchePayment get($id)
 * @method TranchePayment[] getAll()
 * @method TranchePaymentRepository getRepository()
 */
class TranchePaymentService extends Service
{
    /**
     * @var TranchePaymentCsvFormatter
     */
    protected $formatter;

    public function __construct(TranchePaymentRepository $repository, TranchePaymentCsvFormatter $formatter)
    {
        $this->repository = $repository;
        $this->formatter = $formatter;
    }

    /**
     * @param Tranche[] $tranches
     */
    public function load(array $tranches): void
    {
        /** @var array $payments */
        $payments = $this->repository
            ->find([
                'vin' => ArrayHelper::getColumn($tranches, 'vin'),
            ])
            ->select(['vin', 'type'])
            ->asArray()
            ->all();

        $payments = ArrayHelper::map($payments, 'vin', 'type');

        foreach ($tranches as $tranche) {
            $tranche->payment_type = $payments[$tranche->vin] ?? null;
        }
    }

    public function create(TranchePaymentsForm $form, IdentityInterface $identity): array
    {
        $transaction = Yii::$app->getDb()->beginTransaction();
        $models = [];

        /** @var Tranche[] $tranches */
        $tranches = ArrayHelper::index($form->getTranches(), 'vin');

        foreach ($form->payments as $payment) {
            try {
                $models[] = $this->repository->create(
                    $tranches[$payment->vin],
                    $payment->payment_type,
                    $identity
                );
            } catch (SaveModelException $ex) {
                if ($transaction !== null) {
                    $transaction->rollBack();
                }

                throw $ex;
            }
        }

        if ($transaction !== null) {
            $transaction->commit();
        }

        return $models;
    }

    /**
     * @param TranchePayment[] $models
     * @param FrontUser|IdentityInterface $user
     * @throws SaveModelException
     */
    public function export(array $models, IdentityInterface $user): void
    {
        $this->formatter->setPayments($models);

        $content = $this->formatter->format();

        $file = "Pay_{$user->diasoft_id}_" . date('H.i.s_d.m.Y') . '.csv';
        $directory = Yii::getAlias(Yii::$app->params['tranche.exportPath']);
        file_put_contents($directory . '/' . $file, $content);

        $this->repository->markAsExported($models);
    }

    public function createAndExport(TranchePaymentsForm $form, IdentityInterface $identity): void
    {
        $transaction = Yii::$app->getDb()->beginTransaction();

        try {
            $this->export($this->create($form, $identity), $identity);

            if ($transaction !== null) {
                $transaction->commit();
            }
        } catch (\Throwable $ex) {
            if ($transaction !== null) {
                $transaction->rollBack();
            }

            throw $ex;
        }
    }

    /**
     * @return TranchePayment[]
     */
    public function getAllExported(): array
    {
        return $this->repository->findAll(['exported' => true]);
    }

    public function delete(TranchePayment $model): void
    {
        $this->repository->delete($model);
    }
}