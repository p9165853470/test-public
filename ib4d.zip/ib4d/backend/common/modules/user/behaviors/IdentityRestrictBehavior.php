<?php

namespace common\modules\user\behaviors;

use common\enums\ErrorEnum;
use common\modules\password\behaviors\PasswordServiceInterface;
use yii\base\Action;
use yii\base\ActionFilter;
use yii\web\ForbiddenHttpException;
use yii\web\HttpException;

class IdentityRestrictBehavior extends ActionFilter
{
    public const RULE_IDENTITY_BLOCK = 'identity-block';
    public const RULE_IDENTITY_ACTIVE = 'identity-active';
    public const RULE_IDENTITY_HAS_UNSAFE_PASSWORD = 'identity-has-unsafe-password';

    /**
     * @var PasswordServiceInterface
     */
    protected $passwordService;
    /**
     * @var string[]
     */
    public $rules = [];

    public function __construct(PasswordServiceInterface $passwordService, $config = [])
    {
        $this->passwordService = $passwordService;

        parent::__construct($config);
    }

    public function addRule(string $rule, bool $prepend = false): void
    {
        if (!in_array($rule, $this->rules, true)) {
            if ($prepend) {
                array_unshift($this->rules, $rule);
            } else {
                $this->rules[] = $rule;
            }
        }
    }

    public function removeRule(string $rule): void
    {
        $index = array_search($rule, $this->rules, true);

        if ($index !== false) {
            array_splice($this->rules, $index, 1);
        }
    }

    /**
     * @param Action $action
     * @return bool
     * @throws \Throwable
     */
    public function beforeAction($action): bool
    {
        $identity = \Yii::$app->getUser()->getIdentity();

        if ($identity instanceof IdentityInterface) {
            foreach ($this->rules as $rule) {
                if ($this->validate($identity, $rule)) {
                    $ruleErrors = $this->ruleErrors();

                    throw $this->createExceptionFromErrorCode($ruleErrors[$rule] ?? ErrorEnum::DEFAULT);
                }
            }
        }

        return parent::beforeAction($action);
    }

    protected function ruleErrors(): array
    {
        return [
            self::RULE_IDENTITY_BLOCK => ErrorEnum::IDENTITY_IS_BLOCKED,
            self::RULE_IDENTITY_ACTIVE => ErrorEnum::IDENTITY_IS_NOT_ACTIVE,
            self::RULE_IDENTITY_HAS_UNSAFE_PASSWORD => ErrorEnum::IDENTITY_HAS_UNSAFE_PASSWORD,
        ];
    }

    protected function validate(IdentityInterface $identity, string $rule): bool
    {
        switch ($rule) {
            case self::RULE_IDENTITY_BLOCK:
                return $identity->hasBlock();
            case self::RULE_IDENTITY_ACTIVE:
                return !$identity->isActive();
            case self::RULE_IDENTITY_HAS_UNSAFE_PASSWORD:
                return $this->passwordService->hasUnsafePassword($identity);
        }

        return false;
    }

    protected function createExceptionFromErrorCode(int $code): HttpException
    {
        return new ForbiddenHttpException(ErrorEnum::getLabel($code), $code);
    }
}