<?php

namespace common\modules\user\behaviors;

use common\exceptions\NotFoundModelException;
use common\modules\authentication\behaviors\TokenInterface;
use common\modules\authentication\exceptions\TokenException;
use common\modules\authentication\helpers\TokenHelper;
use common\modules\session\exceptions\SessionException;
use common\repositories\Repository;

trait IdentityTrait
{
    /**
     * @var TokenInterface
     */
    private $token;

    /**
     * @return Repository
     */
    abstract public static function getRepository();

    public static function findIdentity($id)
    {
        try {
            return static::getRepository()->findOne($id);
        } catch (NotFoundModelException $ex) {
            return null;
        }
    }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        $token = TokenHelper::load($token, false, false);

        if ($token instanceof TokenInterface) {
            try {
                /** @var static $identity */
                $identity = $token->getSession()->getIdentity();
            } catch (TokenException|SessionException $ex) {
                return null;
            }
            $identity->token = $token;

            return $identity;
        }
        return null;
    }

    public function getToken(): ?TokenInterface
    {
        return $this->token;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getAuthKey()
    {
        return '';
    }

    public function validateAuthKey($authKey)
    {
        return true;
    }
}