<?php

namespace common\modules\user\mail;

use common\mail\MessageComposer;

class NewUserMessageComposer extends MessageComposer
{
    protected function getSubject(): string
    {
        return 'Вы успешно зарегистрированы в системе ИНФО-Банк для дилера';
    }

    protected function getHtmlView(): ?string
    {
        return '@common/modules/user/mail/views/new-user';
    }

    protected function getTextView(): ?string
    {
        return null;
    }
}