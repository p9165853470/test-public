<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%back_user}}`.
 */
class m200709_131151_create_back_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%back_user}}', [
            'id' => $this->primaryKey(),
            'email' => $this->string(128)->notNull()->unique(),
            'password_hash' => $this->string(128)->notNull(),
            'first_name' => $this->string(128),
            'middle_name' => $this->string(128),
            'last_name' => $this->string(128),
            'active' => $this->boolean()->notNull()->defaultValue(false),
            'block' => $this->boolean()->notNull()->defaultValue(false),
            'master' => $this->boolean()->notNull()->defaultValue(false),
            'created_at' => $this->timestamp()->notNull(),
            'updated_at' => $this->timestamp()->notNull(),
            'created_by' => $this->integer(),
            'updated_by' => $this->integer(),
        ]);

        $this->addForeignKeyNamed('{{%back_user}}', 'created_by', '{{%back_user}}', 'id');
        $this->addForeignKeyNamed('{{%back_user}}', 'updated_by', '{{%back_user}}', 'id');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%back_user}}');
    }
}
