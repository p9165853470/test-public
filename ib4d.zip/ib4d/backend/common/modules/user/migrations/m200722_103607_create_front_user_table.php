<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%front_user}}`.
 */
class m200722_103607_create_front_user_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%front_user}}', [
            'id' => $this->primaryKey(),
            'email' => $this->string(128)->notNull(),
            'code' => $this->string(16)->notNull(),
            'password_hash' => $this->string(128)->notNull(),
            'first_name' => $this->string(128),
            'middle_name' => $this->string(128),
            'last_name' => $this->string(128),
            'active' => $this->boolean()->notNull()->defaultValue(false),
            'block' => $this->boolean()->notNull()->defaultValue(false),
            'authority_begin_date' => $this->date()->null(),
            'authority_end_date' => $this->date()->null(),
            'created_at' => $this->timestamp()->notNull(),
            'updated_at' => $this->timestamp()->notNull(),
            'created_by' => $this->integer()->notNull(),
            'updated_by' => $this->integer()->notNull(),
            'deleted_at' => $this->timestamp()->null(),
            'self_updated_at' => $this->timestamp()->null(),
        ]);

        $this->createIndexNamed('{{%front_user}}', ['email', 'code'], true);

        $this->addForeignKeyNamed('{{%front_user}}', 'created_by', '{{%back_user}}', 'id');
        $this->addForeignKeyNamed('{{%front_user}}', 'updated_by', '{{%back_user}}', 'id');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%front_user}}');
    }
}
