<?php

use yii\db\Migration;

/**
 * Class m200731_134852_drop_active_column_from_user_tables
 */
class m200731_134852_drop_active_column_from_user_tables extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropColumn('{{%back_user}}', 'active');
        $this->dropColumn('{{%front_user}}', 'active');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->addColumn('{{%front_user}}', 'active', $this->boolean()->notNull()->defaultValue(false));
        $this->addColumn('{{%back_user}}', 'active', $this->boolean()->notNull()->defaultValue(false));
    }
}
