<?php

use yii\db\Migration;

/**
 * Class m210615_122202_create_user_code
 */
class m210615_122202_create_user_code extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->execute('CREATE SEQUENCE user_code_id_seq');

        $this->createTable('user_code', [
            'user_code_id' => 'INT NOT NULL DEFAULT nextval(\'user_code_id_seq\'::regclass) PRIMARY KEY',
            'user_id' => $this->integer()->notNull(),
            'diasoft_id' => $this->string(16)->notNull(),
            'authority_begin_date' => $this->date(),
            'authority_end_date' => $this->date(),
            'created_at' => 'TIMESTAMP DEFAULT current_timestamp NOT NULL',
            'updated_at' => 'TIMESTAMP DEFAULT current_timestamp NOT NULL',
            'agreement_at' => $this->timestamp(0),
            'validated_at' => $this->timestamp(0),
            'insert_back_user_id' => $this->integer()->notNull(),
            'date_ins' => 'TIMESTAMP DEFAULT current_timestamp NOT NULL'
        ]);

        $this->addForeignKey('fk-user_code-user_id', 'user_code', 'user_id', 'front_user', 'id', 'CASCADE', 'CASCADE');

        $this->createIndex('front_user_code_ux_user_id_dias', 'user_code', ['user_id', 'diasoft_id'], true);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropIndex('front_user_code_ux_user_id_dias', 'user_code');
        $this->dropForeignKey('fk-user_code-user_id', 'user_code');
        $this->dropTable('user_code');
        $this->execute('DROP SEQUENCE user_code_id_seq');

        return true;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210615_154225_create_user_code cannot be reverted.\n";

        return false;
    }
    */
}
