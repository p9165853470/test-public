<?php

use yii\db\Migration;

/**
 * Class m210615_122302_create_user_code_history
 */
class m210615_122302_create_user_code_history extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        
        // а) добавить в исходную таблицу поля
        $this->addColumn('user_code', 'deleted', $this->tinyInteger()->notNull()->defaultValue(0));
        $this->addColumn('user_code', 'change_number', $this->integer()->notNull()->defaultValue(1));
        $this->addColumn('user_code', 'change_date', 'TIMESTAMP DEFAULT current_timestamp NOT NULL');
        $this->addColumn('user_code', 'change_back_user_id', $this->integer());
        $this->addColumn('user_code', 'change_front_user_id', $this->integer());


        // б) добавить ограничения
        $this->execute('ALTER TABLE user_code ADD constraint user_code_ck_change_number check ( change_number >= 1)');
        $this->execute('ALTER TABLE user_code ADD constraint user_code_ck_deleted check ( deleted in ( 0, 1))');


        // в) добавить внешний ключ для change_user_id ссылающийся на user_id
        $this->addForeignKey('fk-user_code-change_back_user_id', 'user_code', 'change_back_user_id', 'back_user', 'id', 'NO ACTION', 'NO ACTION');
        $this->addForeignKey('fk-user_code-change_front_user_id', 'user_code', 'change_front_user_id', 'front_user', 'id', 'NO ACTION', 'NO ACTION');


        // г) добавить таблицу any_table_history, содержащую, собственно, историю изменений
        $this->execute('CREATE SEQUENCE user_code_history_id_seq');
        
        $this->createTable('user_code_history', [
            'user_code_history_id' => 'INT NOT NULL DEFAULT nextval(\'user_code_history_id_seq\'::regclass)',
            'user_code_id' => $this->integer()->notNull(),
            'user_id' => $this->integer()->notNull(),
            'diasoft_id' => $this->string(16),
            'authority_begin_date' => $this->date(),
            'authority_end_date' => $this->date(),
            'created_at' => $this->timestamp(0)->notNull(),
            'updated_at' => $this->timestamp(0)->notNull(),
            'agreement_at' => $this->timestamp(0),
            'validated_at' => $this->timestamp(0),
            'insert_back_user_id' => $this->integer()->notNull(),
            'base_date_ins' => 'TIMESTAMP DEFAULT current_timestamp NOT NULL',

            'deleted' => $this->tinyInteger()->notNull()->defaultValue(0),
            'change_number' => $this->integer()->notNull()->defaultValue(1),
            'change_date' => 'TIMESTAMP DEFAULT current_timestamp NOT NULL',
            'change_back_user_id' => $this->integer(),
            'change_front_user_id' => $this->integer(),
            'date_ins' => 'TIMESTAMP DEFAULT current_timestamp NOT NULL',
        ]);

        $this->addForeignKey('fk-user_code_history-user_id', 'user_code_history', 'user_id', 'front_user', 'id', 'NO ACTION', 'NO ACTION');

        // д) добавить ограничение в исторической таблице
        $this->execute('ALTER TABLE user_code_history ADD constraint user_code_history_uk unique (user_code_history_id, change_number)');

        // е) добавить в исторической таблице внешние ключи для
        $this->addForeignKey('fk-user_code_history-change_back_user_id', 'user_code_history', 'change_back_user_id', 'back_user', 'id', 'NO ACTION', 'NO ACTION');
        $this->addForeignKey('fk-user_code_history-change_front_user_id', 'user_code_history', 'change_front_user_id', 'front_user', 'id', 'NO ACTION', 'NO ACTION');
        $this->addForeignKey('fk-user_code_history-insert_back_user_id', 'user_code_history', 'insert_back_user_id', 'back_user', 'id', 'NO ACTION', 'NO ACTION');
        $this->addForeignKey('fk-user_code_history-user_code_id', 'user_code_history', 'user_code_id', 'user_code', 'user_code_id', 'NO ACTION', 'NO ACTION');

        // ж) Добавить процедуру записи исторической информации в таблицу
        $this->execute(file_get_contents(__DIR__ . '/m210615_122302_create_user_code_history__addUserCodeHistory.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_122302_create_user_code_history__addUserCodeHistory2.sql'));

        // з) добавить триггер исходной таблицы user_code
        $this->execute('DROP TRIGGER IF EXISTS user_code_bi_define ON user_code CASCADE');
        $this->execute(file_get_contents(__DIR__ . '/m210615_122302_create_user_code_history__user_code_bi_define_tf.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_122302_create_user_code_history__user_code_bi_define_tf2.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_122302_create_user_code_history__user_code_bi_define_tf3.sql'));

        // з) добавить триггер для исходной таблицы user_code записывающий изменения в историческую таблицу user_code_history
        $this->execute('DROP TRIGGER IF EXISTS user_code_bu_history ON user_code CASCADE');
        $this->execute(file_get_contents(__DIR__ . '/m210615_122302_create_user_code_history__user_code_bu_history_tf.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_122302_create_user_code_history__user_code_bu_history_tf2.sql'));
        $this->execute(file_get_contents(__DIR__ . '/m210615_122302_create_user_code_history__user_code_bu_history_tf3.sql'));

    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->execute('DROP TRIGGER IF EXISTS user_code_bu_history ON user_code CASCADE');  
        $this->execute('DROP FUNCTION IF EXISTS user_code_bu_history_tf');

        $this->execute('DROP TRIGGER IF EXISTS user_code_bi_define ON user_code CASCADE');
        $this->execute('DROP FUNCTION IF EXISTS user_code_bi_define_tf');

        $this->execute('DROP PROCEDURE addUserCodeHistory');

        $this->dropForeignKey('fk-user_code_history-user_code_id', 'user_code_history');
        $this->dropForeignKey('fk-user_code_history-insert_back_user_id', 'user_code_history');
        $this->dropForeignKey('fk-user_code_history-change_front_user_id', 'user_code_history');
        $this->dropForeignKey('fk-user_code_history-change_back_user_id', 'user_code_history');        

        $this->execute('ALTER TABLE user_code_history DROP constraint user_code_history_uk');        

        $this->dropForeignKey('fk-user_code_history-user_id', 'user_code_history');   

        $this->dropTable('user_code_history');
        $this->execute('DROP SEQUENCE user_code_history_id_seq');
        
        $this->dropForeignKey('fk-user_code-change_front_user_id', 'user_code');
        $this->dropForeignKey('fk-user_code-change_back_user_id', 'user_code');

        $this->execute('ALTER TABLE user_code DROP constraint user_code_ck_deleted');
        $this->execute('ALTER TABLE user_code DROP constraint user_code_ck_change_number');
        
        $this->dropColumn('user_code', 'change_front_user_id');
        $this->dropColumn('user_code', 'change_back_user_id');
        $this->dropColumn('user_code', 'change_date');
        $this->dropColumn('user_code', 'change_number');
        $this->dropColumn('user_code', 'deleted');
        
        return true;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m210615_171537_create_user_code_history cannot be reverted.\n";

        return false;
    }
    */
}
