COMMENT ON FUNCTION user_code_bu_history_tf() IS 'Инициализация полей таблицы user_code при изменении записи и добавление информации в историческую таблицу user_code_history.';
