CREATE TRIGGER user_code_bu_history
BEFORE UPDATE ON user_code
FOR EACH ROW EXECUTE PROCEDURE user_code_bu_history_tf();
