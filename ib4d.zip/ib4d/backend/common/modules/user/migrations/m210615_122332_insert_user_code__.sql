INSERT INTO user_code (
    "user_id"
    , "diasoft_id"
    , "authority_begin_date"
    , "authority_end_date"
    , "created_at"
    , "updated_at"
    , "agreement_at"
    , "validated_at"
    , "insert_back_user_id"
    ) 
    SELECT 
        "id"
        , "diasoft_id"
        , "authority_begin_date"
        , "authority_end_date"
        , "created_at"
        , "updated_at"
        , "agreement_at"
        , "validated_at"
        , (select id from back_user where email = 'system@user.ins')
    from front_user