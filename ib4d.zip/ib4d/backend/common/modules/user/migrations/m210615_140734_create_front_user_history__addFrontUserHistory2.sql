COMMENT ON PROCEDURE addFrontUserHistory(front_user_history) IS 'Добавляет историческую запись в front_user_history.';
