CREATE TRIGGER front_user_bi_define
BEFORE INSERT ON front_user
FOR EACH ROW EXECUTE PROCEDURE front_user_bi_define_tf();
