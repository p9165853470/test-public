COMMENT ON FUNCTION front_user_bu_history_tf() IS 'Инициализация полей таблицы front_user при изменении записи и добавление информации в историческую таблицу front_user_history.';
