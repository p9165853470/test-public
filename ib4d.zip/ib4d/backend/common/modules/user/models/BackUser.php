<?php

namespace common\modules\user\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\behaviors\ModelHasRepositoryTrait;
use common\exceptions\NotFoundModelException;
use common\modules\audit\behaviors\AuditInitiatorInterface;
use common\modules\audit\components\AuditTag;
use common\modules\password\helpers\PasswordGenerator;
use common\modules\password\models\BackUserPassword;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\behaviors\IdentityTrait;
use common\modules\user\enums\BlockReasonEnum;
use common\modules\user\repositories\BackUserRepository;
use common\modules\user\scopes\BackUserQuery;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property string $email
 * @property string $password_hash
 * @property string|null $first_name
 * @property string|null $middle_name
 * @property string|null $last_name
 * @property bool $master
 * @property string $created_at
 * @property string $updated_at
 * @property int $failed_auth_attempt_count
 * @property string $block_reason
 * @property string $search_name
 *
 * @property-write string $password
 *
 * @property-read BackUserPassword[] $passwords
 *
 * @method static BackUserRepository getRepository()
 * @method void touch($attribute)
 */
class BackUser extends ActiveRecord implements IdentityInterface, ModelHasRepositoryInterface, AuditInitiatorInterface
{
    use IdentityTrait;
    use ModelHasRepositoryTrait;

    /**
     * Требуемая длина пароля
     * @todo Вынести в конфиг
     */
    public const PASSWORD_LENGTH = 16;
    /**
     * Группы символов в пароле для генерации/валидации
     * @todo Вынести в конфиг
     */
    public const PASSWORD_GROUPS = PasswordGenerator::GROUP_DGT | PasswordGenerator::GROUP_LLT | PasswordGenerator::GROUP_ULT;
    /**
     * Макс. кол-во неудачных попыток аутентификаций подряд перед блокировкой
     * @todo Вынести в конфиг
     */
    public const FAILED_AUTH_ATTEMPT_LIMIT = 5;

    public static function getRepositoryClass(): string
    {
        return BackUserRepository::class;
    }

    /**
     * @param string $login
     * @return ActiveRecord|BackUser|null
     */
    public static function findIdentityByLogin(string $login): ?IdentityInterface
    {
        try {
            return self::getRepository()->findOneByEmail($login);
        } catch (NotFoundModelException $ex) {
            return null;
        }
    }

    public static function find(): BackUserQuery
    {
        return new BackUserQuery(static::class);
    }

    public function behaviors(): array
    {
        return [
            TimestampBehavior::class,
        ];
    }

    public function getPasswords(): ActiveQuery
    {
        return $this->hasMany(BackUserPassword::class, ['user_id' => 'id']);
    }

    public function setPassword(string $password): void
    {
        $this->password_hash = BackUserPasswordService::instance()->generatePasswordHash($password);
    }

    public function validatePassword(string $password): bool
    {
        return strcmp($this->password_hash, BackUserPasswordService::instance()->generatePasswordHash($password)) === 0;
    }

    public function isActive(): bool
    {
        return true;
    }

    public function hasBlock(int $reason = null): bool
    {
        if ($reason !== null) {
            return $this->block_reason === $reason;
        }

        return $this->block_reason !== BlockReasonEnum::NO_REASON;
    }

    public function getAuditTag(): AuditTag
    {
        return new AuditTag($this->id, $this->email);
    }

    public function isMaster(): bool
    {
        return $this->master;
    }

    public function fields(): array
    {
        return [
            'id',
            'email',
            'first_name',
            'middle_name',
            'last_name',
            'created_at',
            'updated_at',
            'master',
            'block_reason',
            'active' => static function (self $model) {
                return $model->isActive();
            },
        ];
    }

    public function beforeSave($insert): bool
    {
        $result = parent::beforeSave($insert);

        if ($result) {
            $this->composeSearchName();
        }

        return $result;
    }

    public function getFullName(): string
    {
        return implode(' ', array_filter([
            $this->last_name,
            $this->first_name,
            $this->middle_name,
        ]));
    }

    protected function composeSearchName(): void
    {
        $this->search_name = mb_strtolower($this->getFullName());
        $this->search_name = str_replace('ё', 'е', $this->search_name);
    }
    
    public function getDealer(): ?Dealer
    {
        return null;
    }
}