<?php

namespace common\modules\user\models;

use common\helpers\Date;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $user_id
 * @property int $diasoft_id
 * @property string $authority_begin_date
 * @property string $authority_end_date
 * @property string $agreement_at
 * @property string $validated_at
 * @property int $change_back_user_id
 * @property int $insert_back_user_id
 * @property int $created_at
 * @property int $updated_at
 * @property string $inn
 * @property string $kpp
 * @property string $name
 */
class Dealer extends ActiveRecord
{
    // TODO эти три поля должны отображаться только в /front-user/{id}/view, но не должны отображаться в /front-user/index 
    public $inn;
    public $kpp;
    public $name;

    public static function tableName(): string
    {
        return 'user_code';
    }

    public function fields(): array
    {
        return ['diasoft_id', 'authority_begin_date', 'authority_end_date', 'agreement_at', 'validated_at', 
            'name' => static function (self $model) {
                return $model->name;
            }, 
            'inn' => static function (self $model) {
                return $model->inn;
            }, 
            'kpp' => static function (self $model) {
                return $model->kpp;
            }
            ];
    }

    public function rules(): array
    {
        return [
            [['diasoft_id', 'authority_begin_date', 'authority_end_date'], 'required'],
            [['authority_begin_date', 'authority_end_date'], 'date', 'format' => 'php:' . Date::INTERNAL_DATE_FORMAT],
            ['authority_end_date', 'compare', 'compareAttribute' => 'authority_begin_date', 'operator' => '>'],
            [['agreement_at', 'validated_at'], 'safe']
        ];
    }

    public function getUser(): ActiveQuery
    {
        return $this->hasOne(FrontUser::class, ['id' => 'diasoft_id']);
    }
}