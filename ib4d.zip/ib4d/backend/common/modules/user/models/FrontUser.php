<?php

namespace common\modules\user\models;

use common\behaviors\ModelHasRepositoryInterface;
use common\behaviors\ModelHasRepositoryTrait;
use common\exceptions\NotFoundModelException;
use common\modules\audit\behaviors\AuditInitiatorInterface;
use common\modules\audit\components\AuditTag;
use common\modules\password\helpers\PasswordGenerator;
use common\modules\password\services\FrontUserPasswordService;
use common\modules\user\behaviors\IdentityInterface;
use common\modules\user\behaviors\IdentityTrait;
use common\modules\user\enums\BlockReasonEnum;
use common\modules\user\repositories\FrontUserRepository;
use common\modules\user\scopes\FrontUserQuery;
use Yii;
use yii\behaviors\TimestampBehavior;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;

/**
 * @property int $id
 * @property string $email
 * @property string $diasoft_id
 * @property string $password_hash
 * @property string|null $first_name
 * @property string|null $middle_name
 * @property string|null $last_name
 * @property string $phone_number
 * @property string $key_word
 * @property string $created_at
 * @property string $updated_at
 * @property Dealer[] $dealers
 * @property string $deleted_at
 * @property string $self_updated_at
 * @property string $search_name
 * @property int $failed_auth_attempt_count
 * @property int $block_reason
 * @property int $change_front_user_id
 * @property int $change_back_user_id
 * @property int $insert_back_user_id
 * @property string $validate_phone_date
 *
 * @method static FrontUserRepository getRepository()
 * @method void touch($attribute)
 */
class FrontUser extends ActiveRecord implements IdentityInterface, ModelHasRepositoryInterface, AuditInitiatorInterface
{
    use IdentityTrait;
    use ModelHasRepositoryTrait;

    /**
     * Требуемая длина пароля
     * @todo Вынести в конфиг
     */
    public const PASSWORD_LENGTH = 8;
    /**
     * Группы символов в пароле для генерации/валидации
     * @todo Вынести в конфиг
     */
    public const PASSWORD_GROUPS = PasswordGenerator::GROUP_DGT | PasswordGenerator::GROUP_LLT | PasswordGenerator::GROUP_ULT;
    /**
     * Макс. кол-во неудачных попыток аутентификаций подряд перед блокировкой
     * @todo Вынести в конфиг
     */
    public const FAILED_AUTH_ATTEMPT_LIMIT = 5;

    public static function find(): FrontUserQuery
    {
        return new FrontUserQuery(static::class);
    }

    public static function getRepositoryClass(): string
    {
        return FrontUserRepository::class;
    }

    /**
     * @param string $login
     * @return IdentityInterface|ActiveRecord|null
     */
    public static function findIdentityByLogin(string $login): ?IdentityInterface
    {
        try {
            return static::getRepository()->findOneByEmail($login);
        } catch (NotFoundModelException $ex) {
            return null;
        }
    }

    public function isActive(): bool
    {
        return true;
    }

    public function hasBlock(int $reason = null): bool
    {
        if ($reason !== null) {
            return $this->block_reason === $reason;
        }

        return $this->block_reason !== BlockReasonEnum::NO_REASON;
    }

    public function setPassword(string $password): void
    {
        $this->password_hash = FrontUserPasswordService::instance()->generatePasswordHash($password);
    }

    public function validatePassword(string $password): bool
    {
        return strcmp($this->password_hash, FrontUserPasswordService::instance()->generatePasswordHash($password)) === 0;
    }

    public function getAuditTag(): AuditTag
    {
        return new AuditTag($this->id, $this->email);
    }

    public function behaviors(): array
    {
        return [
            TimestampBehavior::class,
        ];
    }

    public function fields(): array
    {
        return [
            'id',
            'email',
            'first_name',
            'middle_name',
            'last_name',
            'phone_number',
            'key_word',
            'created_at',
            'updated_at',
            'dealers',
            'block_reason',
            'active' => static function (self $model) {
                return $model->isActive();
            },
            'phone_number',
            'validate_phone_date',
        ];
    }

    public function getFullName(): string
    {
        return implode(' ', array_filter([
            $this->last_name,
            $this->first_name,
            $this->middle_name,
        ]));
    }

    public function beforeSave($insert): bool
    {
        $result = parent::beforeSave($insert);

        if ($result) {
            $this->composeSearchName();
        }

        $identity = Yii::$app->getUser()->getIdentity();
        if ($identity != null) {
            if (is_a($identity, "common\modules\user\models\FrontUser"))
                $this->change_front_user_id = $identity->getId();
            elseif (is_a($identity, "common\modules\user\models\BackUser"))
                $this->change_back_user_id = $identity->getId();
            if ($insert)
                $this->insert_back_user_id = $this->change_back_user_id = $identity->getId();
        }
        return $result;
    }

    public function getDealers(): ActiveQuery
    {
        return $this->hasMany(Dealer::class, ['user_id' => 'id']);
    }

    protected function composeSearchName(): void
    {
        $this->search_name = mb_strtolower($this->getFullName());
        $this->search_name = str_replace('ё', 'е', $this->search_name);
    }

    /**
     * @param Dealer[] $dealers
     */
    public function setDealers(array $dealers)
    {
        // TODO surprisingly this method is being invoked with 'array of arrays' parameter, instead of 'array of Dealer'.
        // TODO so, convert each array to Dealer object manually and then set the $this->dealers property
        $dealersTmp = array();
        
        foreach ($dealers as $dealerArray) {
            $dealer = new Dealer();
            foreach ($dealerArray as $key => $value) {
                $dealer->$key = $value;
            }
            $dealersTmp[] = $dealer;
        }

        $this->dealers = $dealersTmp;
    }
    
    
    
    public function afterSave($insert, $changedAttributes)
    {
        $identity = Yii::$app->getUser()->getIdentity();
        if ($identity != null) {
        $currentUserId = $identity->getId();

        foreach ($this->dealers as $dealer) {

            $diasoftId = $dealer->diasoft_id;

            $dealerExisting = Dealer::find()->where(['user_id' => $this->id, 'diasoft_id' => $diasoftId])->one();

            if ($dealerExisting != null) {
                // update existing
                
                // copy all fields
                foreach ($dealer as $key => $value) {
                    $dealerExisting->$key = $value;
                }
                
                $dealerExisting->authority_begin_date = $dealer->authority_begin_date;
                $dealerExisting->authority_end_date = $dealer->authority_end_date;
                $dealerExisting->updated_at = date("Y-m-d H:i:s");

                $dealerExisting->save();
            } else {
                // create new

                $dealer->user_id = $this->id;
                $dealer->change_back_user_id = $currentUserId;
                $dealer->insert_back_user_id = $currentUserId;
                $dealer->created_at = date("Y-m-d H:i:s");
                $dealer->updated_at = date("Y-m-d H:i:s");

                $dealer->save();
            }
        }
        }
        
        parent::afterSave($insert, $changedAttributes);
    }
    
    public function getDealer(): ?Dealer
    {
//        $userId = Yii::$app->getUser()->getIdentity()->getId();
        $userId = $this->getId();
        $diasoftId = $this->getToken()->getSession()->getDiasoftId();
        $dealer = Dealer::find()->where(['user_id' => $userId, 'diasoft_id' => $diasoftId])->one();
        return $dealer;
    }
}