<?php

namespace common\modules\variable\events;

use common\modules\variable\models\Variable;
use yii\base\Event;

class VariableServiceEvent extends Event
{
    /**
     * @var Variable
     */
    public $model;
}