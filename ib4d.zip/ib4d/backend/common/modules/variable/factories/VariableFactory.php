<?php

namespace common\modules\variable\factories;

use common\modules\variable\behaviors\VariableFactoryInterface;
use common\modules\variable\behaviors\VariableModelInterface;
use common\modules\variable\enums\VariableEnum;
use common\modules\variable\forms\ContactsVariableForm;
use common\modules\variable\forms\FeedbackVariableForm;
use common\modules\variable\forms\SettingsVariableForm;
use common\modules\variable\forms\TextVariableForm;
use yii\base\InvalidArgumentException;

class VariableFactory implements VariableFactoryInterface
{
    public function getModel(string $key): VariableModelInterface
    {
        switch ($key) {
            case VariableEnum::INSTRUCTION:
            case VariableEnum::REMINDER:
            case VariableEnum::TARIFFS:
            case VariableEnum::AGREEMENT:
            case VariableEnum::CONTACTS:
            case VariableEnum::REQUISITES:
                return new TextVariableForm();
            case VariableEnum::FEEDBACK:
                return new FeedbackVariableForm();
            case VariableEnum::SETTINGS:
                return new SettingsVariableForm();
        }

        throw new InvalidArgumentException("Unknown variable key: {$key}.");
    }
}