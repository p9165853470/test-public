<?php

use console\components\Migration;

/**
 * Handles the creation of table `{{%variable}}`.
 */
class m200724_133859_create_variable_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('{{%variable}}', [
            'id' => $this->primaryKey(),
            'key' => $this->string(32)->notNull()->unique(),
            'value' => $this->text()->null(),
            'created_at' => $this->timestamp()->notNull(),
            'updated_at' => $this->timestamp()->notNull(),
            'created_by' => $this->integer()->notNull(),
            'updated_by' => $this->integer()->notNull(),
        ]);

        $this->addForeignKeyNamed('{{%variable}}', 'created_by', '{{%back_user}}', 'id');
        $this->addForeignKeyNamed('{{%variable}}', 'updated_by', '{{%back_user}}', 'id');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('{{%variable}}');
    }
}
