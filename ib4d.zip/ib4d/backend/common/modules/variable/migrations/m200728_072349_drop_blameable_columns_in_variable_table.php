<?php

use console\components\Migration;

/**
 * Class m200728_072349_drop_blameable_columns_in_variable_table
 */
class m200728_072349_drop_blameable_columns_in_variable_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->dropForeignKeyNamed('{{%variable}}', 'created_by', '{{%back_user}}', 'id');
        $this->dropColumn('{{%variable}}', 'created_by');

        $this->dropForeignKeyNamed('{{%variable}}', 'updated_by', '{{%back_user}}', 'id');
        $this->dropColumn('{{%variable}}', 'updated_by');
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->addColumn('{{%variable}}', 'updated_by', $this->integer());
        $this->addForeignKeyNamed('{{%variable}}', 'updated_by', '{{%back_user}}', 'id');

        $this->addColumn('{{%variable}}', 'created_by', $this->integer());
        $this->addForeignKeyNamed('{{%variable}}', 'created_by', '{{%back_user}}', 'id');
    }
}
