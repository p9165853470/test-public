<?php

namespace common\modules\variable\repositories;

use common\exceptions\NotFoundModelException;
use common\modules\variable\models\Variable;
use common\repositories\Repository;

/**
 * @method Variable model()
 * @method Variable findOne($condition = null)
 * @method Variable[] findAll($condition = null)
 */
class VariableRepository extends Repository
{
    public function getModelClass(): string
    {
        return Variable::class;
    }

    /**
     * @param string $key
     * @return Variable
     * @throws NotFoundModelException
     */
    public function findOneByKey(string $key): Variable
    {
        return $this->findOne(['key' => $key]);
    }
}