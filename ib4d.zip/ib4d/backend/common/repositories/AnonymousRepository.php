<?php

namespace common\repositories;

use yii\base\InvalidArgumentException;
use yii\db\ActiveRecord;

class AnonymousRepository extends Repository
{
    /**
     * @var string
     */
    private $modelClass;

    public function __construct(string $modelClass)
    {
        if (!is_a($modelClass, ActiveRecord::class, true)) {
            throw new InvalidArgumentException("Class $modelClass must be extend " . ActiveRecord::class);
        }
        $this->modelClass = $modelClass;
    }

    public function getModelClass(): string
    {
        return $this->modelClass;
    }
}