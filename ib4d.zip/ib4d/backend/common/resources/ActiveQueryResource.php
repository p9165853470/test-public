<?php

namespace common\resources;

use yii\db\ActiveQuery;
use yii\helpers\ArrayHelper;

/**
 * @method ActiveQuery getResource()
 */
class ActiveQueryResource extends Resource
{
    /**
     * @var ActiveQuery
     */
    protected $resource;

    public function toArray(): ?array
    {
        return ArrayHelper::toArray($this->resource->multiple ? $this->resource->all() : $this->resource->one());
    }
}