<?php

namespace common\resources;

use yii\helpers\ArrayHelper;

abstract class Resource implements \ArrayAccess, \IteratorAggregate
{
    /**
     * @var mixed
     */
    protected $resource;

    public function __construct($resource)
    {
        $this->resource = $resource;
    }

    /**
     * @return mixed
     */
    public function getResource()
    {
        return $this->resource;
    }

    protected function properties(): array
    {
        return [];
    }

    public function toArray(): ?array
    {
        if ($this->resource === null) {
            return null;
        }

        return ArrayHelper::toArray($this->resource, [
            get_class($this->resource) => $this->properties(),
        ]);
    }

    public static function collection($collection): array
    {
        return array_map(static function ($resource) {
            return new static($resource);
        }, $collection);
    }

    public function offsetExists($offset): bool
    {
        if ($this->resource === null) {
            return false;
        }
        return isset($this->resource->{$offset});
    }

    public function offsetGet($offset)
    {
        return $this->resource->{$offset};
    }

    public function offsetSet($offset, $value): void
    {
        // void
    }

    public function offsetUnset($offset): void
    {
        // void
    }

    public function getIterator()
    {
        return new \ArrayIterator($this->toArray());
    }
}