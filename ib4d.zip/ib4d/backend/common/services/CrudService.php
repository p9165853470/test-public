<?php

namespace common\services;

use common\behaviors\EventSenderTrait;
use common\behaviors\FormProviderInterface;
use common\behaviors\SearchProviderInterface;
use common\events\CrudServiceEvent;
use common\exceptions\DeleteModelException;
use common\exceptions\SaveModelException;
use common\forms\Form;
use common\search\AnonymousSearch;
use common\search\Search;
use yii\base\InvalidConfigException;
use yii\db\ActiveRecord;

abstract class CrudService extends Service
{
    use EventSenderTrait;

    public const EVENT_AFTER_CREATE = 'afterCreate';
    public const EVENT_AFTER_UPDATE = 'afterUpdate';
    public const EVENT_AFTER_DELETE = 'afterDelete';
    public const EVENT_AFTER_DELETE_ALL = 'afterDeleteAll';

    /**
     * @var FormProviderInterface|SearchProviderInterface
     */
    protected $factory;

    /**
     * @return FormProviderInterface|SearchProviderInterface
     */
    public function getFactory()
    {
        return $this->factory;
    }

    /**
     * @param Form $form
     * @return ActiveRecord
     * @throws SaveModelException
     */
    public function create($form)
    {
        $model = $this->model();

        $this->save($model, $form);

        $this->trigger(self::EVENT_AFTER_CREATE, new CrudServiceEvent([
            'model' => $model,
            'form' => $form,
        ]));

        return $model;
    }

    /**
     * @param ActiveRecord $model
     * @param Form $form
     * @throws SaveModelException
     */
    public function update($model, $form): void
    {
        $this->save($model, $form);

        $this->trigger(self::EVENT_AFTER_UPDATE, new CrudServiceEvent([
            'model' => $model,
            'form' => $form,
        ]));
    }

    /**
     * @param ActiveRecord $model
     * @param Form $form
     * @throws SaveModelException
     */
    protected function save($model, $form): void
    {
        $this->fill($model, $form);
        $this->repository->save($model);
    }

    /**
     * @param ActiveRecord $model
     * @param Form $form
     */
    protected function fill($model, $form): void
    {
        foreach ($form->activeAttributes() as $attribute) {
            if ($model->canSetProperty($attribute)) {
                $model->$attribute = $form->$attribute;
            }
        }
    }

    /**
     * @param ActiveRecord $model
     * @throws DeleteModelException
     */
    public function delete($model): void
    {
        $this->repository->delete($model);

        $this->trigger(self::EVENT_AFTER_DELETE, new CrudServiceEvent([
            'model' => $model,
        ]));
    }

    /**
     * @param array $ids
     * @return int
     */
    public function deleteAll(array $ids): int
    {
        $result = 0;

        /** @var ActiveRecord $modelClass */
        $modelClass = $this->getRepository()->getModelClass();
        $primaryKey = $modelClass::primaryKey();

        if (isset($primaryKey[0])) {
            $result = $modelClass::deleteAll([
                $primaryKey[0] => $ids,
            ]);
        }

        $this->trigger(self::EVENT_AFTER_DELETE_ALL, new CrudServiceEvent([
            'affectedRowsCount' => $result
        ]));

        return $result;
    }

    /**
     * @return Search
     */
    public function search()
    {
        if ($this->factory instanceof SearchProviderInterface) {
            return $this->factory->getSearch();
        }
        return new AnonymousSearch($this->repository->find());
    }

    /**
     * @param ActiveRecord|null $model
     * @return Form
     */
    public function form($model = null)
    {
        if ($this->factory instanceof FormProviderInterface) {
            return $this->factory->getForm($model);
        }
        throw new InvalidConfigException('Factory must implement the interface ' . FormProviderInterface::class);
    }
}