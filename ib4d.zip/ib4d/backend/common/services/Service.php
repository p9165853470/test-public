<?php

namespace common\services;

use common\exceptions\NotFoundModelException;
use common\repositories\Repository;
use phpDocumentor\Reflection\Types\Collection;
use yii\base\InvalidConfigException;
use yii\db\ActiveRecord;

abstract class Service
{
    /**
     * @var Repository
     */
    protected $repository;

    public function getRepository(): Repository
    {
        return $this->repository;
    }

    /**
     * @param $id
     * @return ActiveRecord
     * @throws NotFoundModelException
     */
    public function get($id)
    {
        return $this->repository->findOne($id);
    }

    /**
     * @return ActiveRecord[]|Collection
     */
    public function getAll()
    {
        return $this->repository->findAll();
    }

    /**
     * @return ActiveRecord
     */
    public function model()
    {
        return $this->repository->model();
    }
}