<?php
$params = array_merge(
    require __DIR__ . '/../../common/config/params.php',
    require __DIR__ . '/../../common/config/params-local.php',
    require __DIR__ . '/params.php',
    require __DIR__ . '/params-local.php'
);

return [
    'id' => 'app-console',
    'basePath' => dirname(__DIR__),
    'bootstrap' => ['log'],
    'controllerNamespace' => 'console\controllers',
    'aliases' => [
        '@bower' => '@vendor/bower-asset',
        '@npm' => '@vendor/npm-asset',
    ],
    'controllerMap' => [
        'fixture' => [
            'class' => \yii\console\controllers\FixtureController::class,
            'namespace' => 'common\fixtures',
        ],
        'migrate' => [
            'class' => \yii\console\controllers\MigrateController::class,
            'migrationPath' => [
                '@app/migrations',
                '@app/modules/backend/migrations',
                '@common/modules/user/migrations',
                '@common/modules/session/migrations',
                '@common/modules/password/migrations',
                '@common/modules/variable/migrations',
                '@common/modules/rfinfo/migrations',
                '@common/modules/storage/migrations',
                '@common/modules/tranche/migrations',
            ]
        ],
    ],
    'modules' => [
        'backend' => \console\modules\backend\Module::class,
        'frontend' => \console\modules\frontend\Module::class,
        'rf-info' => \console\modules\rfinfo\Module::class,
    ],
    'components' => [
        'log' => [
            'targets' => [
                [
                    'class' => \yii\log\FileTarget::class,
                    'levels' => ['error', 'warning'],
                ],
            ],
        ],
        'backAuthManager' => [
            'class' => \yii\rbac\DbManager::class,
            'itemTable' => '{{%back_auth_item}}',
            'itemChildTable' => '{{%back_auth_item_child}}',
            'assignmentTable' => '{{%back_auth_assignment}}',
            'ruleTable' => '{{%back_auth_rule}}',
            'cacheKey' => 'backRBAC',
        ],
    ],
    'params' => $params,
];
