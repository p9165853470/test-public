<?php

namespace console\controllers;

use console\controllers\tranche\UncheckAction;
use yii\console\Controller;

class TrancheController extends Controller
{
    public function actions(): array
    {
        return [
            'uncheck' => UncheckAction::class,
        ];
    }
}