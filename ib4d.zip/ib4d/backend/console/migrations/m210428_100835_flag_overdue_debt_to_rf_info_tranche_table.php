<?php

use yii\db\Migration;

/**
 * Class m210428_100835_flag_overdue_debt_to_rf_info_tranche_table
 */
class m210428_100835_flag_overdue_debt_to_rf_info_tranche_table extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->addColumn('{{%rf_info_tranche}}', 'flag_overdue_debt', $this->boolean()->notNull()->defaultValue(false)->after('overdue_debt')); 
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
		$this->dropColumn('{{%rf_info_tranche}}', 'flag_overdue_debt');
    }
}
