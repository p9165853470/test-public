<?php

namespace console\modules\backend\controllers;

use console\modules\backend\controllers\session\RemoveOldAction;
use yii\console\Controller;

class SessionController extends Controller
{
    public function actions(): array
    {
        return [
            'remove-old' => RemoveOldAction::class
        ];
    }
}