<?php

namespace console\modules\backend\controllers;

use console\modules\backend\controllers\user\CreateAction;
use console\modules\backend\controllers\user\DeleteAction;
use console\modules\backend\events\user\AfterCreateEventHandler;
use console\modules\backend\events\user\AfterDeleteEventHandler;
use console\modules\backend\services\UserService;
use yii\base\Event;
use yii\console\Controller;

class UserController extends Controller
{
    public function init(): void
    {
        parent::init();

        Event::on(
            UserService::class,
            UserService::EVENT_AFTER_CREATE,
            AfterCreateEventHandler::get()
        );
        Event::on(
            UserService::class,
            UserService::EVENT_AFTER_DELETE,
            AfterDeleteEventHandler::get()
        );
    }

    public function actions(): array
    {
        return [
            'create' => CreateAction::class,
            'delete' => DeleteAction::class,
        ];
    }
}