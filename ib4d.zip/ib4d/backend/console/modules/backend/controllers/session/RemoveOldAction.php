<?php

namespace console\modules\backend\controllers\session;

use common\modules\session\services\BackUserSessionService;
use yii\base\Action;

class RemoveOldAction extends Action
{
    /**
     * @var BackUserSessionService
     */
    protected $service;

    public function __construct($id, $controller, BackUserSessionService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(): void
    {
        $this->controller->stdout("Remove old sessions count: {$this->service->removeAllOld()}\n");
    }
}