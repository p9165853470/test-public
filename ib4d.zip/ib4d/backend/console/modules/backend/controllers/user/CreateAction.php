<?php

namespace console\modules\backend\controllers\user;

use console\modules\backend\services\UserService;
use yii\base\Action;
use yii\console\Exception;
use yii\console\ExitCode;
use yii\helpers\Console;

/**
 * Создание мастер-администратора
 */
class CreateAction extends Action
{
    /**
     * @var UserService
     */
    protected $service;

    public function __construct($id, $controller, UserService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(string $email): int
    {
        $form = $this->service->form();
        $form->email = $email;

        if ($form->validate()) {
            $model = $this->service->create($form);

            $this->controller->stdout("ID: {$model->id}\nLogin: {$form->email}\nPassword: {$form->password}\n");
        } else {
            $this->controller->stdout(Console::errorSummary($form), Console::BG_RED);
            $this->controller->stdout("\n");

            return ExitCode::UNSPECIFIED_ERROR;
        }

        return ExitCode::OK;
    }
}