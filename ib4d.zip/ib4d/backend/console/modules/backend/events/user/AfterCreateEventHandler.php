<?php

namespace console\modules\backend\events\user;

use backend\rbac\Role;
use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\modules\password\services\BackUserPasswordService;
use common\modules\user\models\BackUser;
use console\modules\backend\forms\UserForm;
use yii\rbac\ManagerInterface;

final class AfterCreateEventHandler extends EventHandler
{
    public function __invoke(CrudServiceEvent $e, BackUserPasswordService $passwordService, ManagerInterface $authManager)
    {
        /** @var BackUser $identity */
        $identity = $e->model;
        /** @var UserForm $form */
        $form = $e->form;

        $passwordService->store($identity, $form->password, false);

        $authManager->assign(
            $authManager->getRole(Role::MASTER_ADMIN), $identity->getId()
        );
    }
}