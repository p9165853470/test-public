<?php

namespace console\modules\backend\events\user;

use common\events\CrudServiceEvent;
use common\events\EventHandler;
use common\modules\user\models\BackUser;
use yii\rbac\ManagerInterface;

class AfterDeleteEventHandler extends EventHandler
{
    public function __invoke(CrudServiceEvent $e, ManagerInterface $authManager)
    {
        /** @var BackUser $model */
        $model = $e->model;

        $authManager->revokeAll($model->id);
    }
}