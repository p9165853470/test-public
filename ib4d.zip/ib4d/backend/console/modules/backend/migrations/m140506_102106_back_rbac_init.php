<?php

require __DIR__ . '/../../../../vendor/yiisoft/yii2/rbac/migrations/m140506_102106_rbac_init.php';

class m140506_102106_back_rbac_init extends \m140506_102106_rbac_init
{
    protected function getAuthManager(): \yii\rbac\DbManager
    {
        /** @var \yii\rbac\DbManager $authManager */
        $authManager = Yii::$app->get('backAuthManager');

        return $authManager;
    }
}