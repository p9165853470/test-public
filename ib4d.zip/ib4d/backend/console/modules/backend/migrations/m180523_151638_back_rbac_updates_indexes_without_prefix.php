<?php

require __DIR__ . '/../../../../vendor/yiisoft/yii2/rbac/migrations/m180523_151638_rbac_updates_indexes_without_prefix.php';

class m180523_151638_back_rbac_updates_indexes_without_prefix extends \m180523_151638_rbac_updates_indexes_without_prefix
{
    protected function getAuthManager(): \yii\rbac\DbManager
    {
        /** @var \yii\rbac\DbManager $authManager */
        $authManager = Yii::$app->get('backAuthManager');

        return $authManager;
    }
}