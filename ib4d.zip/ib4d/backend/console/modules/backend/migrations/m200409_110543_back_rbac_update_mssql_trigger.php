<?php

require __DIR__ . '/../../../../vendor/yiisoft/yii2/rbac/migrations/m200409_110543_rbac_update_mssql_trigger.php';

class m200409_110543_back_rbac_update_mssql_trigger extends \m200409_110543_rbac_update_mssql_trigger
{
    protected function getAuthManager(): \yii\rbac\DbManager
    {
        /** @var \yii\rbac\DbManager $authManager */
        $authManager = Yii::$app->get('backAuthManager');

        return $authManager;
    }
}