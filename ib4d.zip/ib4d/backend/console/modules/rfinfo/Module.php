<?php

namespace console\modules\rfinfo;

use console\modules\rfinfo\controllers\RequestController;

class Module extends \yii\base\Module
{
    public function init(): void
    {
        parent::init();

        $this->controllerMap = [
            'request' => RequestController::class
        ];
    }
}