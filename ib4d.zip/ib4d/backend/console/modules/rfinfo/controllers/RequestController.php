<?php

namespace console\modules\rfinfo\controllers;

use console\modules\rfinfo\controllers\request\CollectGarbageAction;
use console\modules\rfinfo\controllers\request\DeleteAction;
use yii\console\Controller;

class RequestController extends Controller
{
    public function actions(): array
    {
        return [
            'delete' => DeleteAction::class,
            'collect-garbage' => CollectGarbageAction::class,
        ];
    }
}