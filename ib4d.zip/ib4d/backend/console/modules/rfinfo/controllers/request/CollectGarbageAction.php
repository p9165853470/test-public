<?php

namespace console\modules\rfinfo\controllers\request;

use console\modules\rfinfo\services\RequestService;
use yii\base\Action;
use yii\console\ExitCode;

class CollectGarbageAction extends Action
{
    /**
     * @var RequestService
     */
    protected $service;

    public function __construct($id, $controller, RequestService $service, $config = [])
    {
        $this->service = $service;

        parent::__construct($id, $controller, $config);
    }

    public function run(): int
    {
        $result = $this->service->collectGarbage();

        $this->controller->stdout("Removed requests: {$result}\n");

        return ExitCode::OK;
    }
}