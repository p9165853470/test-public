<?php

namespace console\modules\rfinfo\services;

use common\behaviors\GarbageCollectorInterface;
use common\modules\rfinfo\repositories\RequestRepository;
use common\services\Service;

class RequestService extends Service implements GarbageCollectorInterface
{
    /**
     * @var RequestRepository
     */
    protected $repository;

    public function __construct(RequestRepository $repository)
    {
        $this->repository = $repository;
    }

    public function deleteAll(): int
    {
        return $this->repository->deleteAll();
    }

    public function collectGarbage(): int
    {
        return $this->repository->deleteAllExpired();
    }
}